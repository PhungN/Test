
#include "stdafx.h"
#include <afxdtctl.h>		// MFC support for Internet Explorer 4 Common Controls
#include <windowsx.h>
#include <math.h>
#include "HardwareConfig\Protocols\Comm32\CommprocProtocolsComm.h"

using namespace Rtu;

void RemoveFileIndex(CStringArray& strArr, BOOL bRemoved)
{
	int index;
	TCHAR text[250];

	CString str;
	for(int i=0; i<strArr.GetSize(); i++) {
		str = strArr.GetAt(i);
		if(_istdigit(str[0])) {

			text[0] = _T('\0');

			LPTSTR pstr = str.GetBuffer(str.GetLength());
			if(sscanfx(pstr, _T("%d. %[^\r]"), &index, text)) {}

			str.ReleaseBuffer();
			strArr.SetAt(i, text);
		}
		else if(bRemoved){
			strArr.RemoveAt(i--);
		}
	}
}

extern	HINSTANCE hrInst;
int DispMessageBox(HWND hWnd, UINT nMsgID, UINT nCaptionID, UINT nType)
{
	return MessageBox(hWnd, RES_STRING(nMsgID), RES_STRING(nCaptionID), nType);
}

int DispMessageBox1(HWND hWnd, UINT nMsgID, UINT nCaptionID, UINT nType, int nNum)
{
	CString sMessage = _T("");
	CString sMsg = RES_STRING(nMsgID);
	try {
		sMessage.Format(sMsg, nNum);	
	}
	catch (...) {
		sMessage = sMsg;
	}

	return MessageBox(hWnd, sMessage, RES_STRING(nCaptionID), nType);
}

int DispMessageBox2(HWND hWnd, UINT nMsgID, UINT nCaptionID, UINT nType, int nNum1, int nNum2)
{
	CString sMessage = _T("");
	CString sMsg = RES_STRING(nMsgID);
	try {
		sMessage.Format(sMsg, nNum1, nNum2);	
	}
	catch (...) {
		sMessage = sMsg;
	}

	return MessageBox(hWnd, sMessage, RES_STRING(nCaptionID), nType);
}

int DispMessageBox3(HWND hWnd, UINT nMsgID, UINT nCaptionID, UINT nType, int nNum1, int nNum2, int nNum3)
{
	CString sMessage = _T("");
	CString sMsg = RES_STRING(nMsgID);
	try {
		sMessage.Format(sMsg, nNum1, nNum2, nNum3);	
	}
	catch (...) {
		sMessage = sMsg;
	}

	return MessageBox(hWnd, sMessage, RES_STRING(nCaptionID), nType);
}

void GetMonthStr(CStringArray& strMonths, BOOL bUnused)
{
	if(bUnused) {
		strMonths.Add(RES_STRING(IDS_EMPTY));
	}

	for(int i=0; i<12; i++) {
		strMonths.Add(RES_STRING(IDS_MONTH_1 + i));
	}
}

void GetUserTypeList(CStringArray& strUserTypes, BOOL bUndefined)
{
	if(bUndefined) {
		strUserTypes.Add(RES_STRING(IDS_UNDEFINED));
	}
	
	for(int i=0; i<15; i++) {
		strUserTypes.Add(RES_STRING(IDS_USER_TYPE_LIST + i));
	}
}

void GetRtuPortList(CStringArray& strPorts, int rtuType, BOOL bIsRtu8002)
{
	int i;
	
	switch (rtuType) {
		case RTU_1057_TYPE:
			for(i=0; i<12; i++) {
				strPorts.Add(RES_STRING(IDS_1057_PORT_TXT + i));
			}
			break;
		case RTU_1058_TYPE:
			for(i=0; i<6; i++) {
				strPorts.Add(RES_STRING(IDS_1058_PORT_TXT + i));
			}
			break;
		case RTU_2000_TYPE:
			for(i=0; i<7; i++) {
				strPorts.Add(RES_STRING(IDS_WNESS_PORT_TXT + i));
			}
			break;
		case RTU_8001_TYPE:
			strPorts.Add(CString((LPTSTR)IDS_8001_PORT_TXT));	// Mezz1
			strPorts.Add(CString((LPTSTR)IDS_8001_PORT_TXT2));	// Mezz2
			strPorts.Add(CString((LPTSTR)IDS_8001_PORT_TXT3));	// Mezz3
			strPorts.Add(CString((LPTSTR)IDS_8001_PORT_TXT8));	// Mezz4
			strPorts.Add(CString((LPTSTR)IDS_8001_PORT_TXT9));	// Mezz5
			strPorts.Add(CString((LPTSTR)IDS_8001_PORT_TXT10));	// Ethernet1
			if (bIsRtu8002)
				strPorts.Add(CString((LPTSTR)IDS_8001_PORT_TXT11));	// Ethernet2
			break;
		default:
			return;
	}

}
void GetRtuInternalPortList(CStringArray& strPorts)
{
	// Adding internal ports
	for(int i=0; i<3; i++) {
		strPorts.Add(RES_STRING(IDS_PORT_TXT + i));
		}
}
void GetPortList(CStringArray& strPorts, int rtuType, BOOL bAddInternalPort)
{
	int i;
	switch (rtuType) {
		case RTU_1057_TYPE:
			for(i=0; i<12; i++) {
				strPorts.Add(RES_STRING(IDS_1057_PORT_TXT + i));
			}
			break;
		case RTU_1058_TYPE:
			for(i=0; i<6; i++) {
				strPorts.Add(RES_STRING(IDS_1058_PORT_TXT + i));
			}
			break;
		case RTU_2000_TYPE:
			for(i=0; i<7; i++) {
				strPorts.Add(RES_STRING(IDS_WNESS_PORT_TXT + i));
			}
			break;
		case RTU_8001_TYPE:
			strPorts.Add(CString((LPTSTR)IDS_8001_PORT_TXT));	// Mezz1
			strPorts.Add(CString((LPTSTR)IDS_8001_PORT_TXT2));	// Mezz2
			strPorts.Add(CString((LPTSTR)IDS_8001_PORT_TXT3));	// Mezz3
			strPorts.Add(CString((LPTSTR)IDS_8001_PORT_TXT8));	// Mezz4
			strPorts.Add(CString((LPTSTR)IDS_8001_PORT_TXT9));	// Mezz5
			strPorts.Add(CString((LPTSTR)IDS_8001_PORT_TXT10));	// Ethernet1
			//strPorts.Add(CString((LPTSTR)IDS_8001_PORT_TXT11));	// Ethernet2
			break;
		default:
			return;
	}

	// Adding internal ports
	if(bAddInternalPort == TRUE) {
		for(i=0; i<3; i++) {
			strPorts.Add(RES_STRING(IDS_PORT_TXT + i));
		}
	}
}

BOOL ValidateEdtCtrl(HWND hDlg, UINT ctrlID, int min, int max)
{
	int n = GetDlgItemInt(hDlg, ctrlID, NULL, FALSE);
	if((n > max) || (n < min)) {
		CString sMsg = RES_STRING(IDS_RANGE_ERR);
		CString strMessage; strMessage.Format(sMsg, min, max);
		MessageBox(hDlg, strMessage, RES_STRING(IDS_ERROR), MB_OK | MB_ICONEXCLAMATION);
		SetFocus(GetDlgItem(hDlg, ctrlID));
		SendDlgItemMessage(hDlg, ctrlID, EM_SETSEL, 5, 0);
		return FALSE;
	}

	return TRUE;
}

void RtuLib::DDX_CBIndex(CDataExchange *pDX, int cid, BYTE &dataByte) 
{
	int	x;
	x = dataByte;

	::DDX_CBIndex(pDX, cid, x);

	if (pDX->m_bSaveAndValidate) 
	{		//.Reading from dlg control
		dataByte = (BYTE)x;
	}
}

void RtuLib::DDX_CBIndex(CDataExchange *pDX, int cid, BYTE &point, BYTE BitMask)
{
	int	x;

	x = (point & BitMask);
	::DDX_CBIndex(pDX, cid, x);
	if (pDX->m_bSaveAndValidate) {		//.Reading from dlg control
		point &= ~BitMask;
		x &= BitMask;
		point |= x;
	}
}

void RtuLib::DDX_CBIndexEx(CDataExchange *pDX, int cid, BYTE &point, int numBits, int sBit)
{
	int mask=0;
	for(int i=0; i<numBits; i++)
		mask |= (1 << (sBit+i));
	int x = (point & mask) >> sBit;
	::DDX_CBIndex(pDX, cid, x);
	if (pDX->m_bSaveAndValidate) 
	{
		point &= (BYTE)(~mask);
		point |= (BYTE)((x << sBit) & mask);
	}

}


void RtuLib::DDX_Check(CDataExchange *pDX, int cid, BYTE &dataByte, BYTE BitNumber) 
{

	BOOL	x;
	BYTE	BitMask;

	BitMask = (BYTE)(0x01 << BitNumber);
	
	x = (BOOL)((dataByte & BitMask) >> BitNumber);

	::DDX_Check(pDX, cid, x);

	if (pDX->m_bSaveAndValidate) 
	{		//.Reading from dlg control
		dataByte &= ~BitMask;
		dataByte |= ((BYTE)x << BitNumber);
	}
}

void RtuLib::DDX_Check(CDataExchange *pDX, int cid, WORD &dataByte, BYTE BitNumber) 
{
	BOOL	x;
	WORD	BitMask;

	BitMask = (WORD)(0x0001 << BitNumber);
	x = (BOOL)((dataByte & BitMask) >> BitNumber);

	::DDX_Check(pDX, cid, x);

	if (pDX->m_bSaveAndValidate) 
	{		//.Reading from dlg control
		dataByte &= ~BitMask;
		dataByte |= ((WORD)x << BitNumber);
	}
}

void RtuLib::DDX_Check(CDataExchange *pDX, int cid, ulong &dataByte, BYTE BitNumber) 
{
	BOOL	x;
	ulong	BitMask;

	BitMask = (ulong)(0x00000001 << BitNumber);
	x = (BOOL)((dataByte & BitMask) >> BitNumber);

	::DDX_Check(pDX, cid, x);

	if (pDX->m_bSaveAndValidate) 
	{		//.Reading from dlg control
		dataByte &= ~BitMask;
		dataByte |= ((ulong)x << BitNumber);
	}
}


void RtuLib::DDX_Text(CDataExchange *pDX, int cid, TCHAR *string) 
{

	CString		StringData = string;

	::DDX_Text(pDX, cid, StringData);
	if (pDX->m_bSaveAndValidate) 
	{		//.Reading from dlg control
		wsprintf(string, _T("%s"), (LPCTSTR)StringData);
	}
}

void RtuLib::DDX_Text(CDataExchange *pDX, int cid, WORD &point) 
{

	int x = point;

	::DDX_Text(pDX, cid, x);
	if (pDX->m_bSaveAndValidate) 
	{	//.Reading from dlg control
		point = (WORD)x;
	}
}

void RtuLib::DDX_Text(CDataExchange *pDX, int cid, BYTE& value) 
{
	int checkValue = value;

	::DDX_Text(pDX, cid, checkValue);
	if (pDX->m_bSaveAndValidate == TRUE) 
	{	//.Reading from dlg control
		DDV_MinMaxInt(pDX, checkValue, 0, 255);
		value = (BYTE)checkValue;
	}
}

//DDX Text with bitmask

void RtuLib::DDX_Text(CDataExchange *pDX, int cid, BYTE &point, BYTE BitMask) 
{
	BYTE x = (BYTE)(point & BitMask);

	::DDX_Text(pDX, cid, x);
	if (pDX->m_bSaveAndValidate) 
	{		//.Reading from dlg control
		x &= BitMask;
		point &= ~BitMask;
		point |= x;
	}
}

void RtuLib::DDX_Text(CDataExchange *pDX, int cid, BYTE &point, BYTE BitMask, BYTE offset) 
{
	BYTE x = (BYTE)(point & BitMask);
	x >>= offset;

	::DDX_Text(pDX, cid, x);
	if (pDX->m_bSaveAndValidate) 
	{		//.Reading from dlg control
		x <<= offset;
		x &= BitMask;
		point &= ~BitMask;
		point |= x;
	}
}


//DDX Text with bitmask

void RtuLib::DDX_Text(CDataExchange *pDX, int cid, WORD &point, WORD BitMask) 
{
	WORD x = (WORD)(point & BitMask);

	DDX_Text(pDX, cid, x);
	if (pDX->m_bSaveAndValidate) 
	{		//.Reading from dlg control
		x &= BitMask;
		point &= ~BitMask;
		point |= x;
	}
}

void RtuLib::DDX_TimeHHMM(CDataExchange *pDX, int cid, BYTE& hour, BYTE& minute)
{
	CString strData;
	strData.Format(_T("%02d:%02d"), hour, minute);
	::DDX_Text(pDX, cid, strData);
	if (pDX->m_bSaveAndValidate) 
	{	
		TCHAR sTime[100];
		_stprintf(sTime, _T("%s"), (LPCTSTR)strData);
		int time = ConvertTime(sTime, 23, 59);
		hour = (BYTE)((time >> 8) & 0xff);
		if(hour > 23) hour = 0;
		minute = (BYTE)(time & 0xff);
		if(minute > 59) minute = 0;
	}
}

void RtuLib::DDX_Radio(CDataExchange *pDX, int cid, int &point, int BitMask, int offset) 
{
	int x = point & BitMask;
	x >>= offset;

	::DDX_Radio(pDX, cid, x);
	if (pDX->m_bSaveAndValidate) 
	{		//.Reading from dlg control
		x <<= offset;
		x &= BitMask;
		point &= ~BitMask;
		point |= x;
	}
}

void RtuLib::SwapByteOrder(ushort &val)
{
	ushort temp =  (ushort)(val >> 8);
	temp |= (val << 8) & 0xFF00;
	val = temp;
}

void RtuLib::SwapByteOrder(ulong &val)
{
	ulong temp = (ulong)(val >> 24);
	temp |= (val >> 8) & 0xFF00;
	temp |= (val << 8) & 0xFF0000;
	temp |= (val << 24) & 0xFF000000;
	val = temp;
}

CString RtuLib::ToString(int value) 
{
	CString s; s.Format(_T("%d"), value);
	return s.GetBuffer(s.GetLength());
}

CString RtuLib::IpAddressToString(LPBYTE pIPA)
{
	CString s; s.Format(_T("%d.%d.%d.%d"), *pIPA, *(pIPA+1), *(pIPA+2), *(pIPA+3));
	return s.GetBuffer(s.GetLength());
}

CString RtuLib::PhonetoString(LPBYTE pData, int size)
{
	BYTE	temp[100]; memset(temp, 0, sizeof(temp));
	temp[0] = (BYTE)(size+2);
	memcpy(&temp[1], pData, size);
	
	TCHAR str[100]; Unpack_Tel(str, temp, size*2);

	CString s = str;
	return s.GetBuffer(s.GetLength());
}

int RtuLib::GetRtuPhysicalPortNumber(int portIndex, int rtuType)
{
	int physicalPortNumber = portIndex;
	if((rtuType == RTU_1058_TYPE) && (portIndex > 3))
		physicalPortNumber += 4;
	else if(rtuType == RTU_8001_TYPE) {
		switch(portIndex) {
			case  1: physicalPortNumber = 2 ; break;
			case  2: physicalPortNumber = 3 ; break;
			case  3: physicalPortNumber = 8 ; break;
			case  4: physicalPortNumber = 9 ; break;
			case  5: physicalPortNumber = 10; break;
			case  6: physicalPortNumber = 11; break;
			default: physicalPortNumber = 0 ; break;
		}
	}

	return physicalPortNumber;
}

int RtuLib::GetRtuPortIndex(int physicalPortNumber, int rtuType)
{
	int portIndex = physicalPortNumber;
	if(rtuType == RTU_1058_TYPE) {
		if(physicalPortNumber > 3)
			portIndex -= 4;
	} else if(rtuType == RTU_8001_TYPE) {
		switch(physicalPortNumber) {
		case  0: portIndex = 0; break;
		case  2: portIndex = 1; break;
		case  3: portIndex = 2; break;
		case  8: portIndex = 3; break;
		case  9: portIndex = 4; break;
		case 10: portIndex = 5; break;
		case 11: portIndex = 6; break;
		default: portIndex = -1; break;
		}
	}

	return portIndex;
}

CString RtuLib::GetRtuPortString(int physicalPortNumber, int rtuType)
{
	int portIndex = GetRtuPortIndex(physicalPortNumber, rtuType);
	CStringArray strArrPorts; GetPortList(strArrPorts, rtuType);
	CString strPortName = _T("");
	if(portIndex < strArrPorts.GetSize()) {
		strPortName = strArrPorts.GetAt(portIndex);
	}

	return strPortName.GetBuffer(strPortName.GetLength());
}

void RtuLib::ChangeDialogFont(CWnd* pWnd, CFont* pFont)
{
	HWND hWnd = pWnd->GetSafeHwnd();
	if(hWnd == NULL)
		return;

	pWnd->SetFont(pFont);
	
	// iterate through and move all child windows and change their font.

	// Get first child window
	CWnd* pChildWnd = pWnd->GetWindow(GW_CHILD);

	while(pChildWnd) {
		pChildWnd->SetFont(pFont);

		// Get next window
		pChildWnd = pChildWnd->GetWindow(GW_HWNDNEXT);	
	}
}

void RtuLib::FileExecute(HWND hWnd, TCHAR* fname, TCHAR* opMode)
{
	UINT retCode = (UINT)ShellExecute(hWnd, opMode, fname, NULL, NULL, SW_SHOWNORMAL);
	if(retCode == 0)
		DispMessageBox(hWnd, IDS_SYS_OUT_OF_MEM, IDS_ERROR, MB_OK | MB_ICONSTOP);
	else if(retCode == ERROR_BAD_FORMAT)
		DispMessageBox(hWnd, IDS_INVALID_FILE, IDS_ERROR, MB_OK | MB_ICONSTOP);
	else if(retCode == ERROR_FILE_NOT_FOUND) {
		CString s; s.Format(_T("%s %s"), fname, (LPCTSTR)RES_STRING(IDS_FILE_NOT_FOUND));
		MessageBox(hWnd, s, RES_STRING(IDS_ERROR), MB_OK | MB_ICONSTOP);
		//DispMessageBox(hWnd, IDS_FILE_NOT_FOUND, IDS_ERROR, MB_OK | MB_ICONSTOP);
	}
	else if(retCode == ERROR_PATH_NOT_FOUND)
		DispMessageBox(hWnd, IDS_PATH_NOT_FOUND, IDS_ERROR, MB_OK | MB_ICONSTOP);
}

void RtuLib::GetResourceStrings(HINSTANCE, CStringArray& strArr, UINT ids[], int nSize)
{
	strArr.RemoveAll();
	for(int i=0; i<nSize; i++) {
		strArr.Add(RES_STRING(ids[i]));
	}
}

void RtuLib::FillComboBox(HINSTANCE, CComboBox* pCB, UINT ids[], int nSize)
{
	CStringArray strArr;

	// Get strings from resource
	strArr.RemoveAll();
	for(int i=0; i<nSize; i++) {
		strArr.Add(RES_STRING(ids[i]));
	}

	// Fill the combobox
	pCB->ResetContent();
	for(int i=0; i<strArr.GetSize(); i++) {
		pCB->AddString(strArr.GetAt(i));
	}
}

void RtuLib::FillComboBox(HINSTANCE hInst, CWnd* pParent, UINT id, UINT ids[], int nSize)
{
	CComboBox* pCB = (CComboBox*)pParent->GetDlgItem(id);
	if(pCB != NULL) {
		FillComboBox(hInst, pCB, ids, nSize);
	}
}

BOOL RtuLib::ReadGMS32Registry(LPTSTR lpVersion, LPTSTR lpDir)
{
	HKEY hk;
    DWORD size=48, size1=128;
    DWORD type;

    if (RegOpenKey(HKEY_LOCAL_MACHINE, _T("Software\\PacomSystems\\GMS32"), &hk) ||
        RegQueryValueEx(hk, _T("Version"), 0, &type, (LPBYTE)lpVersion, &size) ||
        RegQueryValueEx(hk, _T("Path"),  0, &type, (LPBYTE)lpDir, &size1)) {   
		RegCloseKey(hk);
        return 0;
    }

   RegCloseKey(hk);
   return 1;
}

BOOL RtuLib::AddStringToFile(LPCTSTR lpszFileName, LPTSTR lpszText)
{
	BOOL bRetVal = FALSE;
	CMyFile file;

	try {
		TCHAR	str[260]; LPTSTR p1 = str;
		lstrcpy(str, lpszText);

		if (str[0] == '\0')
			return FALSE;

		if (!file.Open(DefaultLocation(lpszFileName), FILE_READWRITE|FILE_DENYWRITE, 0)) {
			if (!file.Open(DefaultLocation(lpszFileName), FILE_READWRITE|FILE_CREATE|FILE_DENYWRITE))
				return FALSE;
			#ifdef _UNICODE
			else
				file.WriteUnicodeData();
			#endif
		}

		int size = (int)file.GetLength();
		if (file.IsUnicodeFile()) {
			TCHAR text[260];
			//..Verify if the end of the file has <CR> <LF>
			size -= 2*sizeof(TCHAR);
			if (size > 2)  {
				file.Seek(size);
				file.Read(text, 2*sizeof(TCHAR));
				if (text[0] != '\r' || text[1] != '\n')
					file.Write(_T("\r\n"), 4);
			}

	   		file.SeekToEnd();
			wsprintf(text, _T("%s"), p1);
			p1 = text;
			file.Write(p1, lstrlen(p1)*sizeof(TCHAR));
			file.Write(_T("\r\n"), 2*sizeof(TCHAR));
		}
		else {
			char text[260];
			//..Verify if the end of the file has <CR> <LF>
			size -= 2;
			if (size > 2)  {
				file.Seek(size);
				file.Read(text, 2);
				if (text[0] != '\r' || text[1] != '\n')
					file.Write("\r\n", 2);
			}
	   		file.SeekToEnd();

			#ifdef _UNICODE
			wsprintfA(text, "%ls\r\n", str);
			#else
			wsprintfA(text, "%s\r\n", str);
			#endif
			file.Write(text, strlen(text));
		}
		file.Close();
		bRetVal = TRUE;
	}
	catch(...) {
		file.Close();
		bRetVal = FALSE;
		TRACE0("AddStringToFile failed \n");
	}

	return bRetVal;
}

int RtuLib::GetInputNumber(int nLabelID, int nTitleID)
{
	int nResult = -1;
	CInputBoxDlg* pDlg = new CInputBoxDlg(nTitleID, nLabelID);
	if(pDlg) {
		if(pDlg->DoModal() == IDOK) {
			CString s = pDlg->GetInputString();
			nResult = _ttoi(s);
		}

		delete pDlg; pDlg = NULL;
	}

	return nResult;
}

BOOL RtuLib::GetInputNumber2(int& in1, int& in2, int nLabelID1, int nLabelID2, int nTitleID)
{
	BOOL bResult = FALSE;
	CInputBox2Dlg* pDlg = new CInputBox2Dlg(nTitleID, nLabelID1, nLabelID2);
	if(pDlg) {
		if(pDlg->DoModal() == IDOK) {
			CString s = pDlg->GetInputString1();
			in1 = _ttoi(s);
			s = pDlg->GetInputString2();
			in2 = _ttoi(s);
			bResult = TRUE;
		}

		delete pDlg; pDlg = NULL;
	}

	return bResult;
}

BOOL RtuLib::IsConfigChanged(LPBYTE pConfig, int nCfgSize, LPCTSTR szFileName)
{
	int nSize = 0;
	BOOL bResult = FALSE;
	TCHAR	sFilePath[MAX_PATH];

	wsprintf(sFilePath, L"%s\\%s", CUSTOMER_RTU_UPLOAD_FOLDER, szFileName);

	CMyFile file;
	if (file.Open(DefaultLocation(sFilePath), FILE_READ|FILE_DENYNONE)) {
		int flen = (int)file.GetLength();
		if(flen) {
			LPBYTE pBuffer = new BYTE[flen + 1];
			if(pBuffer) {
				memset(pBuffer, 0, flen+1);
				nSize = file.Read(pBuffer, flen);

				if((nSize != nCfgSize) || (memcmp(pConfig, pBuffer, nCfgSize) != 0)) {
					bResult = TRUE;
				}

				delete[] pBuffer; pBuffer = NULL;
			}
		} 
		else {
			bResult = TRUE;
		}

		file.Close();
	}

	return bResult;
}

BOOL RtuLib::IsFileExist(LPTSTR szFileName)
{
	CFileFind finder;
	if(!finder.FindFile(szFileName)) {
		CString sMsg;
		sMsg.Format(_T("%s: %s"), (LPCTSTR)RES_STRING(IDS_CANT_OPEN_FILE), szFileName);
		MessageBox(NULL, sMsg, RES_STRING(IDS_ERROR), MB_OK|MB_ICONSTOP);
		return FALSE;
	}

	return TRUE;
}

BOOL RtuLib::IsNewControllerType(int nRtuType)
{
	BOOL bResult = FALSE;
	switch(nRtuType) {
		case RTU_1057_TYPE:
		case RTU_1058_TYPE:
		case RTU_2000_TYPE:
		case RTU_8001_TYPE:
			bResult = TRUE;
			break;
		default:
			bResult = FALSE;
			break;
	}

	return bResult;
}

void RtuLib::SendPcpCommand(HWND hDlg, int nRtuNumber, LPBYTE pData, UINT msgID)
{
	PCPCMD pc; memset(&pc, 0, sizeof(pc));
	pc.addr1 = (BYTE)GETGROUPNO(nRtuNumber);
	pc.addr2 = (BYTE)GETRTUOFFSET(nRtuNumber);
	pc.cport = 0;
	pc.lpCmd = pData;
	pc.hWnd = hDlg;
	pc.busy = 1;
	pc.errCode = 0;
	pc.bWait = HIRESP;
	pc.retFN = 0; 
	pc.timer = 100;					//.5 second timeout
	pc.bDisErr = 1;
	SendGPPcpCommand(&pc, msgID);
}

UINT RtuLib::GetGmsCodePage()
{
	//UINT nCodePage = CP_ACP;

	//TCHAR sFileName[MAX_PATH] = _T("");

	//DefaultLocation(GMS32_COMMON_PARAMS_INI).GetPath(sFileName);
	return GetPrivateProfileInt(SysParmSec, L"BCP_CP", /*-1*/::GetCurrentCodePage(), DefaultLocation(GMS32_COMMON_PARAMS_INI).Path);
	//if (bcpCodePage >= 0)
	//	nCodePage = bcpCodePage;
	//else
	//	nCodePage = ::GetCurrentCodePage();

	//return nCodePage;
}

WORD RtuLib::SwapByte(WORD value)
{
	return MAKEWORD(value>>8, value&0xff);
}

//////////////////////////////////////////
BOOL CALLBACK EnumChildProc(HWND, LPARAM);
LRESULT CALLBACK WndSpy(int, WPARAM, LPARAM);

#define IDC_CBO_FILTER	1136
#define MAX_CHAR		250

#ifdef _UNICODE
	#define lstricmp _wcsicmp // Case insensitive
#else
	#define lstricmp stricmp
#endif // _UNICODE

class CMyFileDialog : public CFileDialog {
	DECLARE_DYNAMIC(CMyFileDialog)
public:
	CMyFileDialog(BOOL bOpenFileDialog, LPCTSTR lpszDefExt, LPCTSTR lpszFileName, DWORD dwFlags, LPCTSTR lpszFilter, CWnd* pParentWnd);
	~CMyFileDialog();
	void SetSelFilter(LPCTSTR lpsz) { m_strSelFilter = lpsz; }
	HHOOK GetHookHandle() const { return m_hWndHook; }
	
protected:
	virtual BOOL OnInitDialog();
	afx_msg void OnFilterSelChange();	

public:
	static CMyFileDialog* s_pObject;

private:
	HHOOK m_hWndHook;
	CString m_strSelFilter;
	};

CMyFileDialog* CMyFileDialog::s_pObject = NULL;

IMPLEMENT_DYNAMIC(CMyFileDialog, CFileDialog)

CMyFileDialog::CMyFileDialog(BOOL bOpenFileDialog, LPCTSTR lpszDefExt, LPCTSTR lpszFileName, 
	DWORD dwFlags, LPCTSTR lpszFilter, CWnd* pParentWnd) : CFileDialog(bOpenFileDialog, lpszDefExt,
	lpszFileName, dwFlags, lpszFilter, pParentWnd)
{
	s_pObject = NULL; m_hWndHook = 0;
}

CMyFileDialog::~CMyFileDialog()
{
	CMyFileDialog::s_pObject = NULL;
	if(m_hWndHook) UnhookWindowsHookEx(m_hWndHook);
}

BOOL CMyFileDialog::OnInitDialog()
{
	BOOL result = CFileDialog::OnInitDialog();

	EnumChildWindows(::GetParent(m_hWnd), EnumChildProc, (LPARAM)this);

	// Set hook
	CMyFileDialog::s_pObject = this;
	m_hWndHook = SetWindowsHookEx(WH_CALLWNDPROC, (HOOKPROC)WndSpy, 
		(HINSTANCE)NULL, (DWORD)GetCurrentThreadId());

	return result;
}

BOOL CALLBACK EnumChildProc(HWND hWnd, LPARAM lParam)
{	
	TCHAR szClassName[MAX_CHAR];
	GetClassName(hWnd, szClassName, MAX_CHAR);	

	if (0 == lstricmp(szClassName, _T("ComboBox"))) {		
		const int id = ::GetDlgCtrlID(hWnd);
		if (IDC_CBO_FILTER == id) { // 1136
			CString str;
			CComboBox* pcb = (CComboBox*)CWnd::FromHandle(hWnd);
			const int index = pcb->GetCurSel();
			if (CB_ERR != index) {
				CMyFileDialog* pDlg = (CMyFileDialog*)lParam;
				pcb->GetLBText(index, str);
				pDlg->SetSelFilter(str);
				}			
			}
		}
	
  return TRUE;
}

int nSelChange;
LRESULT CALLBACK WndSpy(int nCode, WPARAM wParam,  LPARAM lParam)
{
	TCHAR szClassName[MAX_CHAR];
	CWPSTRUCT* x = (CWPSTRUCT*)lParam;
	const int id = ::GetDlgCtrlID(x->hwnd);
	GetClassName(x->hwnd, szClassName, MAX_CHAR);

	HHOOK hookHandle = NULL;

	if (NULL != CMyFileDialog::s_pObject)
		hookHandle = CMyFileDialog::s_pObject->GetHookHandle();

	if ((IDC_CBO_FILTER == id) && !lstricmp(szClassName, _T("ComboBox"))) {			
		CComboBox* pcb = (CComboBox*)CWnd::FromHandle(x->hwnd);	

		switch(x->message) {
			//case CBN_SELCHANGE:
			case 0x150: // Don not ask me why for this value				
				CString str;
				const int index = pcb->GetCurSel();
				nSelChange = index;
				if (CB_ERR != index && CMyFileDialog::s_pObject) {						
					pcb->GetLBText(index, str);
					CMyFileDialog::s_pObject->SetSelFilter(str);
					}				
				break;
			}
		}

	return CallNextHookEx(hookHandle, nCode, wParam, lParam);
}


//////////////////////////////////////////
BOOL RtuLib::GetPrintFileName(TCHAR* fname, TCHAR* defExt)
{
	nSelChange = 0;
	TCHAR szFilter[] = _T("Data Files (*.html;*.xls)|*.html; *.xls|Html Files (*.html)|*.html|Worksheet Files (*.xls)|*.xls|All Files (*.*)|*.*||");
	//CFileDialog dlg(FALSE, NULL, NULL, OFN_HIDEREADONLY|OFN_OVERWRITEPROMPT, (LPCTSTR)szFilter);
	CMyFileDialog dlg(FALSE, NULL, NULL, OFN_HIDEREADONLY|OFN_OVERWRITEPROMPT, szFilter, NULL);
	if(dlg.DoModal() == IDOK) {
		wsprintf(fname, _T("%s"), (LPCTSTR)dlg.GetPathName());
		CString pName = dlg.GetPathName();
		if(pName.GetLength() == 0) {
			return FALSE;
		}

		CString str = fname;
		//int idx = str.Find(_T("."));
		int idx = str.ReverseFind(_T('.'));

		if(idx == -1) {
			if(nSelChange == 2)
				str += _T(".xls");
			else
				str += defExt;
			wsprintf(fname, _T("%s"), (LPCTSTR)str);
		}
		else {
			int strLen = str.GetLength();
			CString strExtension = str.Right(strLen - (idx + 1));
			if( !((strExtension.Compare(_T("html")) == 0)  || (strExtension.Compare(_T("xls")) == 0)) ) {
				DispMessageBox(NULL, IDS_INV_FMT, IDS_ERROR, MB_OK | MB_ICONSTOP);
				return FALSE;
			}
		}
	}
	else {
		return FALSE;
	}

	return TRUE;
}

BOOL RtuLib::GetFileName(TCHAR* fname, TCHAR* defExt, TCHAR* szFilter, BOOL bOpen)
{
	nSelChange = 0;

	CMyFileDialog dlg(bOpen, NULL, NULL, OFN_HIDEREADONLY|OFN_OVERWRITEPROMPT, szFilter, NULL);
	if(dlg.DoModal() == IDOK) {
		CString sExtension = CString(defExt);
		CString sFileName = dlg.GetFileName().Trim();		
		CString sFileExtension = dlg.GetFileExt();
		int sFileNameLen = sFileName.GetLength();
		
		if (sFileNameLen == 0)
			return FALSE;
		
		int sExtensionLen = sExtension.GetLength();
		if (sExtension[0] == _T('.'))
			sExtension = sExtension.Right(sExtensionLen-1);
		
		if (sFileExtension.IsEmpty() == FALSE)
		{
			if (sFileExtension.CompareNoCase(sExtension) == 0) // extension is the same.
				sFileName = sFileName.Left(sFileNameLen - sExtensionLen);

			// "open for reading" needs to have the same extension: down loading file
			// "open for writing" can be 1.0.9.RTU.
			else if (bOpen) 
			{
				return 0;
			}
		}
		

		TCHAR sPathName[MAX_PATH] = {0};

		lstrcpy(sPathName, dlg.GetPathName()); // return path + file name.

		LPTSTR pBackSlash = lstrrchr(sPathName, '\\');
		if (pBackSlash != NULL)
		{
			*pBackSlash = NULL_CHR;
			wsprintf(fname, L"%s\\%s.%s", sPathName, (LPCTSTR)sFileName, (LPCTSTR)sExtension);
		}
		else
			lstrcpy(fname, sPathName);
		
		if (bOpen) { // check if file exists for reading.
			CFileStatus sts;			
			if (CFile::GetStatus(fname, sts) == FALSE)
			{
				return FALSE;
			}
		}

		return TRUE;
	
	}
	return FALSE;
	
}

//====================================================================================//
// Check if file is UNICODE, return TRUE if file is encoding as UNICODE ...			  //
//====================================================================================//
BOOL RtuLib::IsUnicodeFile(LPCTSTR fileName)
{
	BOOL isUnicode = FALSE;
	CMyFile* myFile = new CMyFile();
	if(myFile) {
		if(myFile->Open(DefaultLocation(fileName))) {
			if(myFile->IsUnicodeFile())
				isUnicode = TRUE;
			else 
				isUnicode = FALSE;

			myFile->Close();
		}

		delete myFile; myFile = NULL;
	}

	return isUnicode;
}

//====================================================================================//
// Read a line from the UNICODE file, return FALSE if end of file ...				  //
//====================================================================================//
BOOL RtuLib::LineFromFileW(FILE* f, CString& s)
{
    s.Empty();
    
    while (true) {
        wint_t c = fgetwc(f);        
        
        if (c == WEOF) 
			return FALSE;

        if (c == L'\n') 
			return TRUE;

        s += (wchar_t) c;
    };
}

//====================================================================================//
// Read a line from the ANSI file, return FALSE if end of file ...				      //
//====================================================================================//
BOOL RtuLib::LineFromFileA(FILE* f, CString& s)
{
    s.Empty();
    
	char str[101]={0};
	memset(str, 0, sizeof(str));
	int cnt = 0;
    while (true) {
        int c = fgetc(f);        
        
        if (c == EOF) {
			s = str;
			return FALSE;
		}

		if (c == LF) {
			s = str;
			return TRUE;
        }

		if((cnt < 100) && (c != CR)) {
			str[cnt++] = (char)c;
		}

    }

}

//====================================================================================//
//	Fill the strArray with lines from file ...										  //
//====================================================================================//
BOOL RtuLib::GetFileStrings(LPCTSTR fileName, CStringArray& strArray, BOOL bRemoveIndex)
{
	DefaultLocation fName(fileName);
	FILE* f = fopen(fName.Path, _T("rb"));
	if(f == NULL)
	{
		CString sMsg;;
		sMsg.Format(_T("%s: %s"), (LPCTSTR)RES_STRING(IDS_CANT_OPEN_FILE), fName.Path);
		MessageBox(NULL, sMsg, RES_STRING(IDS_ERROR), MB_OK|MB_ICONSTOP);
		return FALSE;
	}

	BOOL (*LineFromFile)(FILE*, CString&);
	LineFromFile = IsUnicodeFile(fileName) ? LineFromFileW : LineFromFileA;

	if (strArray.GetSize() > 0)
		strArray.RemoveAll();

	CString strLine;
	//TCHAR line[MAX_BUFF];
	BOOL bNotEndOfFile = TRUE;
	BOOL bFirstLine = TRUE;
	while (bNotEndOfFile)
	{
		bNotEndOfFile = LineFromFile(f, strLine);

		if(bFirstLine)
		{
			bFirstLine = FALSE;
			TCHAR c = strLine.GetAt(0);
			if(c == 0xfeff)
			{
				strLine = strLine.Mid(1);
			}
		}

		//wsprintf(line, _T("%s"), strLine);
		if(strLine.GetLength() > 0)
			strArray.Add(strLine);
	}

	fclose(f);


	if(bRemoveIndex) {
		RemoveFileIndex(strArray);
	}
	return TRUE;

}

//====================================================================================//
// Write a line to the ANSI file, return FALSE if end of file ...				  //
//====================================================================================//
BOOL LineToFile(FILE* f, const char *const s)
{
    if (!s)
        return FALSE;
    
    size_t length = strlen(s);
    size_t n = fwrite(s, sizeof(char), length, f);
	fputc('\r', f);
	fputc('\n', f);
            
    return (n == length);
}

BOOL LineToFile(FILE* f, const wchar_t *const s)
{
    if (!s)
        return FALSE;
        
    size_t length = wcslen(s);
    size_t n = fwrite(s, sizeof(wchar_t), length, f);
	fputwc(L'\r', f);
	fputwc(L'\n',f);
    return (n == length);
}

BOOL WriteLineW(FILE* f, const wchar_t *const wc)
{
	BOOL bResult=FALSE;
	int nLength=WideCharToMultiByte(CP_ACP, 0, wc, -1, NULL, 0, NULL, NULL);
	LPSTR lpStr=new char[nLength];
	WideCharToMultiByte(CP_ACP, 0, wc, -1, lpStr, nLength, NULL, NULL);
	bResult=LineToFile(f, lpStr);
	// MZ a BUG!
	delete[] lpStr;

	return bResult;
}
//====================================================================================//
//	Write the strArray of lines to file ...										      //
// numbering: -1 for none, 0 for 0-based, 1 for 1-based.
//====================================================================================//
BOOL RtuLib::WriteFileStrings(LPCTSTR fileName, CStringArray& strArray, bool bWriteAsUnicode, int numbering)
{
	DefaultLocation fName(fileName);
	FILE* f = fopen(fName.Path, _T("wb"));
	if(f == NULL)
	{
		CString sMsg;;
		sMsg.Format(_T("%s: %s"), (LPCTSTR)RES_STRING(IDS_CANT_OPEN_FILE), fName.Path);
		MessageBox(NULL, sMsg, RES_STRING(IDS_ERROR), MB_OK|MB_ICONSTOP);
		return FALSE;
	}

	if( bWriteAsUnicode)
	{
		WORD data = 0xfeff;
		fwrite(&data, 1, 2, f);
	}

	int max = strArray.GetSize();
	//CString strTmp;
	int currentIndex =numbering;
	for( int textInd = 0 ; textInd < max ; textInd++ ) 
	{
		CString currentText;
		if( numbering != -1)
		{
			currentText.Format(L"%d.%s", currentIndex++, (LPCTSTR)strArray[textInd]); 
		}
		else
		{
			currentText = strArray[textInd];
		}
		if( bWriteAsUnicode)
		{
			//strTmp = strArray[t];
			fwrite((LPCTSTR)currentText, 2, currentText.GetLength(), f);
			fwrite(L"\r\n", 2, 2, f);
		}
		else
		{
			//strTmp.Format(_T("%s"), strArray[t]);
			if(WriteLineW(f, /*strTmp*/currentText) == FALSE)
				break;
		}
	}

	fclose(f);

	return TRUE;
}


//==========================================================================================//
//==========================================================================================//
//==========================================================================================//
//==========================================================================================//
BEGIN_MESSAGE_MAP(CNumEdit, CEdit)
	//{{AFX_MSG_MAP(CNumEdit)
	ON_CONTROL_REFLECT(EN_CHANGE, OnChange)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

void CNumEdit::PreSubclassWindow() 
{
	m_nIDC = this->GetDlgCtrlID();
	ModifyStyle(0, ES_NUMBER);
	CEdit::PreSubclassWindow();
}

void CNumEdit::DoDataExchange(CDataExchange* pDX) 
{
	CEdit::DoDataExchange(pDX);
}

void CNumEdit::OnChange() 
{
	int liNum = GetParent()->GetDlgItemInt(m_nIDC, NULL, FALSE);
	if(liNum < m_nMin || liNum > m_nMax) {
		DispMessageBox2(GetSafeHwnd(), IDS_ENTER_RANGE, IDS_ERROR, MB_OK|MB_ICONSTOP, m_nMin, m_nMax);
		CEdit* pEdit = (CEdit*)GetParent()->GetDlgItem(m_nIDC);
		pEdit->SetFocus();
		pEdit->SetSel(0, m_nLimit);
	}
	
	GetParent()->SendMessage(WM_USER, m_nIDC, liNum);
}

BOOL CNumEdit::SetMinMaxLimit(int min, int max, UINT limit)
{
	m_nMin = min; m_nMax = max; m_nLimit = limit;
	SetLimitText(m_nLimit);
	return TRUE;
}

//==========================================================================================//
//==========================================================================================//
//==========================================================================================//
//==========================================================================================//
BEGIN_MESSAGE_MAP(CNumEditEx, CEdit)
	//{{AFX_MSG_MAP(CNumEditEx)
	ON_CONTROL_REFLECT(EN_CHANGE, OnChange)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

void CNumEditEx::PreSubclassWindow() 
{
	m_nIDC = this->GetDlgCtrlID();
	ModifyStyle(0, ES_NUMBER);
	CEdit::PreSubclassWindow();
}

void CNumEditEx::DoDataExchange(CDataExchange* pDX) 
{
	CEdit::DoDataExchange(pDX);
}

void CNumEditEx::OnChange() 
{
	__int64 i64Val=0;
	char str[MAX_BUFF];
	::GetDlgItemTextA(::GetParent(m_hWnd), m_nIDC, (LPSTR)str, MAX_BUFF);
	i64Val = _atoi64(str);
	m_i64Val = i64Val;
	m_bValid = TRUE;
	if((i64Val > m_nMax)) { // || (i64Val < m_nMin)) {
		CString strText;
		char minStr[MAX_BUFF], maxStr[MAX_BUFF];
		_i64toa(m_nMin, minStr, 10);
		_i64toa(m_nMax, maxStr, 10);
		TCHAR minStr1[20], maxStr1[20];
		wsprintf(minStr1, _T("%hs"), minStr);
		wsprintf(maxStr1, _T("%hs"), maxStr);
		CString sTmp = RES_STRING(IDS_ENTER_RANGE_STR);
		strText.Format(sTmp, minStr1, maxStr1);
		MessageBox(strText, RES_STRING(IDS_ERROR), MB_OK | MB_ICONSTOP);
		CEdit* pEdit = (CEdit*)GetParent()->GetDlgItem(m_nIDC);
		pEdit->SetFocus();
		strText = str;
		pEdit->SetSel(0, strText.GetLength());
		
		m_bValid = FALSE;
	}

	GetParent()->SendMessage(WM_USER, m_nIDC, (ulong)i64Val);
}

__int64 CNumEditEx::GetValue()
{
	char str[20];
//	TCHAR wstr[20];
//	GetParent()->GetDlgItemText(m_nIDC, (LPTSTR)wstr, 20);
//	wsprintfA(str, "%ls", wstr);

	::GetDlgItemTextA(::GetParent(m_hWnd), m_nIDC, (LPSTR)str, 20);
	return _atoi64(str);
}


void CNumEditEx::SetValue(__int64 val)
{ 															   
	//char str[20];
	//TCHAR wstr[20];
	//_i64toa(val, str, 10);
	//wsprintf(wstr, _T("%hs"), str);
	//GetParent()->SetDlgItemText(m_nIDC, wstr);

	char str[20];
	_i64toa(val, str, 10);
	::SetDlgItemTextA(::GetParent(m_hWnd), m_nIDC, (LPCSTR)str);

}

BOOL CNumEditEx::SetMinMaxLimit(__int64 min, __int64 max, UINT limit)
{
	m_nMin = min; m_nMax = max; m_nLimit = limit;
	SetLimitText(m_nLimit);
	return TRUE;
}

void CNumEditEx::DisplayRangeError(UINT nMsgID, UINT nCaptionID, int nType)
{
	HWND hDlg = GetParent()->GetSafeHwnd();
	DispMessageBox2(hDlg, nMsgID, nCaptionID, nType, (int)m_nMin, (int)m_nMax);
	SetFocus();
	SetSel(0, m_nLimit);
}

BOOL CNumEditEx::IsValid()
{
	this->OnChange();
	return m_bValid;
}

BOOL CNumEditEx::IsValidRange()
{
	__int64 i64Val=0;
	char str[MAX_BUFF];
	::GetDlgItemTextA(::GetParent(m_hWnd), m_nIDC, (LPSTR)str, MAX_BUFF);
	i64Val = _atoi64(str);
	m_i64Val = i64Val;
	m_bValid = TRUE;
	if((i64Val > m_nMax) || (i64Val < m_nMin)) {
		CString strText;
		char minStr[MAX_BUFF], maxStr[MAX_BUFF];
		_i64toa(m_nMin, minStr, 10);
		_i64toa(m_nMax, maxStr, 10);
		TCHAR minStr1[20], maxStr1[20];
		wsprintf(minStr1, _T("%hs"), minStr);
		wsprintf(maxStr1, _T("%hs"), maxStr);
		CString sTmp = RES_STRING(IDS_ENTER_RANGE_STR);
		strText.Format(sTmp, minStr1, maxStr1);
		MessageBox(strText, RES_STRING(IDS_ERROR), MB_OK | MB_ICONSTOP);
		CEdit* pEdit = (CEdit*)GetParent()->GetDlgItem(m_nIDC);
		pEdit->SetFocus();
		strText = str;
		pEdit->SetSel(0, strText.GetLength());
		
		m_bValid = FALSE;
	}

	GetParent()->SendMessage(WM_USER, m_nIDC, (ulong)i64Val);

	return m_bValid;
}


//==========================================================================================//
//==========================================================================================//
//==========================================================================================//
//==========================================================================================//
// CGenDialog Class
#if 0
CGenDialog::CGenDialog(CWnd* pParent /*=NULL*/)
	: CDialog(CGenDialog::IDD, pParent)
{
	//{{AFX_DATA_INIT(CGenDialog)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}
#endif

//#if 0
CGenDialog::CGenDialog(UINT nIDTemplate, CWnd* pParent /*= NULL*/)
    : m_ID(0), m_pParent(pParent), CDialog(nIDTemplate, pParent)
{
}
//#endif

CGenDialog::CGenDialog()
{
}

void CGenDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CGenDialog)
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CGenDialog, CDialog)
	//{{AFX_MSG_MAP(CGenDialog)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CGenDialog message handlers
CSize CGenDialog::CreateGenericChildDialog(CWnd *Parent, int PlaceMarkerCtrlID, 
		int Id, CRect *ABorderRect)
{
    m_pParent = Parent;
    m_ID = Id;

    // Create() the child dialog ...
    VERIFY(Create( GetMyDialogID(), m_pParent ));

    // use no borders if caller hasn't given any ...
    if (ABorderRect == NULL) {
        static CRect NoBordersRect(0,0,0,0);
        ABorderRect = &NoBordersRect;
    }

    // get position of place marker control ...
    CRect PlaceMarkerRect;
    CWnd *pPlaceMarkerWnd = m_pParent->GetDlgItem( PlaceMarkerCtrlID );
    pPlaceMarkerWnd->GetWindowRect(&PlaceMarkerRect);
    m_pParent->ScreenToClient(&PlaceMarkerRect);
    
    // get size of child dialog ...
    CRect ChildDBRect;
    GetClientRect(&ChildDBRect);

    // move child dialog to place indicated by the place marker control ...
    MoveWindow(PlaceMarkerRect.left + ABorderRect->left, PlaceMarkerRect.top + ABorderRect->top, 
               ChildDBRect.right, ChildDBRect.bottom);

    // adjust size of place marker control to match child dialog ...
    int cx = ChildDBRect.right  + ABorderRect->left + ABorderRect->right;
    int cy = ChildDBRect.bottom + ABorderRect->top  + ABorderRect->bottom;
    VERIFY(pPlaceMarkerWnd->SetWindowPos(NULL,  0,0, cx,cy, SWP_NOMOVE | SWP_NOZORDER));

    // put child dialog on top of the place marker control ...
    VERIFY(SetWindowPos(pPlaceMarkerWnd, 0,0, 0,0,  SWP_NOMOVE | SWP_NOSIZE));

	CSize sz(ChildDBRect.Width(), ChildDBRect.Height());
	
	return sz;
}


/////////////////////////////////////////////////////////////////////////////
// CGenDialog message handlers
void CGenDialog::CreateChildDialog(CWnd *Parent, CWnd* pCtrl, CRect& PlaceMarkerRect)
{
    m_pParent = Parent;

    // Create() the child dialog ...
    VERIFY(Create( GetMyDialogID(), m_pParent ));
   
    // get size of child dialog ...
    CRect ChildDBRect;
    GetClientRect(&ChildDBRect);

    // move child dialog to place indicated by the place marker control ...
    MoveWindow(PlaceMarkerRect.left, PlaceMarkerRect.top, ChildDBRect.right, ChildDBRect.bottom);

	
    // adjust size of place marker control to match child dialog ...
    int cx = ChildDBRect.right;
    int cy = ChildDBRect.bottom;
    VERIFY(pCtrl->SetWindowPos(NULL,  0,0, cx,cy, SWP_NOMOVE | SWP_NOZORDER));

    // put child dialog on top of the place marker control ...
    VERIFY(SetWindowPos(pCtrl, 0,0, 0,0,  SWP_NOMOVE | SWP_NOSIZE));
	
}

CSize CGenDialog::GetDlgSize()
{
	CRect rc;
    GetClientRect(&rc);

	CSize sz(rc.Width(), rc.Height());

	return sz;
}

//==========================================================================================//
//==========================================================================================//
//==========================================================================================//
//==========================================================================================//

const UINT nMessage=::RegisterWindowMessage(_T("ComboSelEndOK"));
/////////////////////////////////////////////////////////////////////////////
// CComboBoxDisabledItem
BEGIN_MESSAGE_MAP(CComboBoxDisabledItem, CComboBox)
	//{{AFX_MSG_MAP(CComboBoxDisabledItem)
	ON_WM_CHARTOITEM()
	ON_CONTROL_REFLECT(CBN_SELENDOK, OnSelendok)
	//}}AFX_MSG_MAP
	ON_REGISTERED_MESSAGE(nMessage, OnRealSelEndOK)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CComboBoxDisabledItem message handlers
void CComboBoxDisabledItem::PreSubclassWindow() 
{
	ASSERT((GetStyle()&(CBS_OWNERDRAWFIXED|CBS_HASSTRINGS))==(CBS_OWNERDRAWFIXED|CBS_HASSTRINGS));
	//ASSERT((GetStyle()&(CBS_OWNERDRAWVARIABLE|CBS_HASSTRINGS))==(CBS_OWNERDRAWVARIABLE|CBS_HASSTRINGS));
	CComboBox::PreSubclassWindow();
}

void CComboBoxDisabledItem::DrawItem(LPDRAWITEMSTRUCT lpDrawItemStruct) 
{
	CDC* pDC = CDC::FromHandle (lpDrawItemStruct->hDC);

	if (((LONG)(lpDrawItemStruct->itemID) >= 0) &&
		(lpDrawItemStruct->itemAction & (ODA_DRAWENTIRE | ODA_SELECT)))
	{

		BOOL fDisabled = !IsWindowEnabled () || !IsItemEnabled(lpDrawItemStruct->itemID);
		COLORREF newTextColor = fDisabled ?
			RGB(0x80, 0x80, 0x80) : GetSysColor (COLOR_WINDOWTEXT);	// light gray  
		COLORREF oldTextColor = pDC->SetTextColor (newTextColor);

		COLORREF newBkColor = GetSysColor (COLOR_WINDOW);
		//COLORREF newBkColor = GetSysColor (COLOR_BTNFACE);
		COLORREF oldBkColor = pDC->SetBkColor (newBkColor);

		if (newTextColor == newBkColor)
			newTextColor = RGB(0xC0, 0xC0, 0xC0);   // dark gray

		if (!fDisabled && ((lpDrawItemStruct->itemState & ODS_SELECTED) != 0))
		{
			pDC->SetTextColor (GetSysColor (COLOR_HIGHLIGHTTEXT));
			pDC->SetBkColor (GetSysColor (COLOR_HIGHLIGHT));
		}

		CString strText;
		GetLBText(lpDrawItemStruct->itemID, strText);

		const RECT &rc=lpDrawItemStruct->rcItem;
		pDC->ExtTextOut(rc.left + 2, rc.top + 1, ETO_OPAQUE, &rc,
				  strText, strText.GetLength (), NULL);

		pDC->SetTextColor (oldTextColor);
		pDC->SetBkColor (oldBkColor);
	}
	else if ((LONG)(lpDrawItemStruct->itemID)<0)	// drawing edit text
	{
		COLORREF newTextColor = GetSysColor (COLOR_WINDOWTEXT);  // light gray
		COLORREF oldTextColor = pDC->SetTextColor (newTextColor);

		COLORREF newBkColor = GetSysColor (COLOR_WINDOW);
		COLORREF oldBkColor = pDC->SetBkColor (newBkColor);

		if ((lpDrawItemStruct->itemState & ODS_SELECTED) != 0)
		{
			pDC->SetTextColor (GetSysColor (COLOR_HIGHLIGHTTEXT));
			pDC->SetBkColor (GetSysColor (COLOR_HIGHLIGHT));
		}

		CString strText;
		GetWindowText(strText);
		const RECT &rc=lpDrawItemStruct->rcItem;

		pDC->ExtTextOut(rc.left + 2, rc.top + 1, ETO_OPAQUE, &rc,
				  strText, strText.GetLength (), NULL);

		pDC->SetTextColor (oldTextColor);
		pDC->SetBkColor (oldBkColor);
	}

	if ((lpDrawItemStruct->itemAction & ODA_FOCUS) != 0)
		pDC->DrawFocusRect(&lpDrawItemStruct->rcItem);	
}

void CComboBoxDisabledItem::MeasureItem(LPMEASUREITEMSTRUCT lpMeasureItemStruct) 
{
	//UNREFERENCED_PARAMETER(lpMeasureItemStruct);

	ASSERT(lpMeasureItemStruct->CtlType == ODT_COMBOBOX);

	if (lpMeasureItemStruct->itemID != (UINT) -1)
	{
		LPCTSTR lpszText = (LPCTSTR) lpMeasureItemStruct->itemData;
		ASSERT(lpszText != NULL);
		CSize   sz;
		CDC*    pDC = GetDC();
		sz = pDC->GetTextExtent(lpszText);
		ReleaseDC(pDC);

		lpMeasureItemStruct->itemHeight = sz.cy - 2;
	}

}

int CComboBoxDisabledItem::OnCharToItem(UINT nchar, CListBox* pListBox, UINT nIndex) 
{	
	int ret=CComboBox::OnCharToItem(nchar, pListBox, nIndex);
	if (ret>=0 && !IsItemEnabled(ret))
		return -2;
	else
		return ret;
}

void CComboBoxDisabledItem::OnSelendok() 
{
	if (!IsWindow(m_hWnd))
		return;

	GetWindowText(m_strSavedText);
	PostMessage(nMessage);	
}

LRESULT CComboBoxDisabledItem::OnRealSelEndOK(WPARAM,LPARAM)
{
	if (!IsWindow(m_hWnd))
		return 0;

	CString currentText;
	GetWindowText(currentText);
	int index=FindStringExact(-1,currentText);
	if (index>=0 && index<_COUNTOF(m_bCurItemStus) && !IsItemEnabled(index))
	{
		SetWindowText(m_strSavedText);
		if (GetParent() && IsWindow(GetParent()->m_hWnd))
			GetParent()->SendMessage(WM_COMMAND,MAKELONG(GetWindowLong(m_hWnd,GWL_ID),CBN_SELCHANGE),(LPARAM)m_hWnd);
	}
	return 0;
}

//==========================================================================================//
//==========================================================================================//
//==========================================================================================//
//==========================================================================================//
#define BLACK RGB(0,0,0)
/////////////////////////////////////////////////////////////////////////////
// CStaticColor
CStaticColor::CStaticColor()
{
	m_crBkColor = ::GetSysColor(COLOR_3DFACE); // Initializing the Background Color to the system face color.
	m_crTextColor = BLACK; // Initializing the text to Black
	m_brBkgnd.CreateSolidBrush(m_crBkColor); // Create the Brush Color for the Background.
}

CStaticColor::CStaticColor(COLORREF bkColor, COLORREF fgColor)
{
	m_crBkColor = ::GetSysColor(COLOR_3DFACE); // Initializing the Background Color to the system face color.
	m_crTextColor = BLACK; // Initializing the text to Black
	m_brBkgnd.CreateSolidBrush(m_crBkColor); // Create the Brush Color for the Background.

	SetBkColor(bkColor);
	SetTextColor(fgColor);
}


CStaticColor::~CStaticColor()
{
}


BEGIN_MESSAGE_MAP(CStaticColor, CStatic)
	//{{AFX_MSG_MAP(CStaticColor)
	ON_WM_CTLCOLOR_REFLECT()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMyColorStatic message handlers

HBRUSH CStaticColor::CtlColor(CDC* pDC, UINT /*nCtlColor*/) 
{
	HBRUSH hbr;
	hbr = (HBRUSH)m_brBkgnd; // Passing a Handle to the Brush
	pDC->SetBkColor(m_crBkColor); // Setting the Color of the Text Background to the one passed by the Dialog
	pDC->SetTextColor(m_crTextColor); // Setting the Text Color to the one Passed by the Dialog
	return hbr;
}

void CStaticColor::SetBkColor(COLORREF crColor)
{
	m_crBkColor = crColor; // Passing the value passed by the dialog to the member varaible for Backgound Color
	m_brBkgnd.DeleteObject(); // Deleting any Previous Brush Colors if any existed.
	m_brBkgnd.CreateSolidBrush(crColor); // Creating the Brush Color For the Static Text Background
	RedrawWindow();
}

void CStaticColor::SetTextColor(COLORREF crColor)
{
	m_crTextColor = crColor; // Passing the value passed by the dialog to the member varaible for Text Color
	RedrawWindow();
}

void CStaticColor::SetColors(COLORREF bkColor, COLORREF fgColor)
{
	SetBkColor(bkColor);
	SetTextColor(fgColor);
}

void CStaticColor::SetText(LPCTSTR lpszText)
{
	SetWindowText(lpszText);
}
//==========================================================================================//
//==========================================================================================//
//==========================================================================================//
//==========================================================================================//
using namespace Rtu;

//-------------------------------------------------------------------
// class CThemeLib
//-------------------------------------------------------------------

#ifdef XPSUPPORT
	#define THEMECALL(f)			return (*m_p##f)
	#define GETTHEMECALL(f)			m_p##f = (_##f)GetProcAddress(m_hThemeLib, #f)
#else
	void ThemeDummy(...) {ASSERT(FALSE);}
	#define HTHEME					void*
	#define TABP_PANE				0
	#define THEMECALL(f)			return 0; ThemeDummy
#endif

#pragma warning(push)
// C4702: unreachable code
#pragma warning(disable:4702)

class CThemeLib
{
// construction/destruction
public:
	CThemeLib();
	~CThemeLib();

// operations
public:
	BOOL IsAvailable() const;

// call wrappers
public:
	BOOL IsThemeActive() 
	{THEMECALL(IsThemeActive)();}

	HTHEME OpenThemeData(HWND hwnd, LPCWSTR pszClassList) 
	{THEMECALL(OpenThemeData)(hwnd, pszClassList);}

	HRESULT CloseThemeData(HTHEME hTheme) 
	{THEMECALL(CloseThemeData)(hTheme);}

	HRESULT GetThemeBackgroundContentRect(HTHEME hTheme, OPTIONAL HDC hdc, int iPartId, int iStateId,  const RECT *pBoundingRect, OUT RECT *pContentRect)
	{THEMECALL(GetThemeBackgroundContentRect)(hTheme, hdc, iPartId, iStateId, pBoundingRect, pContentRect);}

	HRESULT DrawThemeBackground(HTHEME hTheme, HDC hdc, int iPartId, int iStateId, const RECT *pRect, OPTIONAL const RECT *pClipRect)
	{THEMECALL(DrawThemeBackground)(hTheme, hdc, iPartId, iStateId, pRect, pClipRect);}

// function pointers
private:
#ifdef XPSUPPORT
	THEMEAPITYPE_(BOOL, IsThemeActive)();
	THEMEAPIPTR(IsThemeActive);

	THEMEAPITYPE_(HTHEME, OpenThemeData)(HWND hwnd, LPCWSTR pszClassList);
	THEMEAPIPTR(OpenThemeData);

	THEMEAPITYPE(CloseThemeData)(HTHEME hTheme);
	THEMEAPIPTR(CloseThemeData);

	THEMEAPITYPE(GetThemeBackgroundContentRect)(HTHEME hTheme, OPTIONAL HDC hdc, int iPartId, int iStateId,  const RECT *pBoundingRect, OUT RECT *pContentRect);
	THEMEAPIPTR(GetThemeBackgroundContentRect);

	THEMEAPITYPE(DrawThemeBackground)(HTHEME hTheme, HDC hdc, int iPartId, int iStateId, const RECT *pRect, OPTIONAL const RECT *pClipRect);
	THEMEAPIPTR(DrawThemeBackground);
#endif

// properties
private:
	/** instance handle to the library or NULL. */
	HINSTANCE m_hThemeLib;
};
#pragma warning(pop)

static CThemeLib g_ThemeLib;

CThemeLib::CThemeLib() : m_hThemeLib(NULL)
{
#ifdef XPSUPPORT
	m_hThemeLib = LoadLibrary(_T("uxtheme.dll"));
	if (!m_hThemeLib)
		return;

	GETTHEMECALL(IsThemeActive);
	GETTHEMECALL(OpenThemeData);
	GETTHEMECALL(CloseThemeData);
	GETTHEMECALL(GetThemeBackgroundContentRect);
	GETTHEMECALL(DrawThemeBackground);
#endif
}

CThemeLib::~CThemeLib()
{
	if (m_hThemeLib)
		FreeLibrary(m_hThemeLib);
}

BOOL CThemeLib::IsAvailable() const
{
	return m_hThemeLib!=NULL;
}

//-------------------------------------------------------------------
// class CPropPageFrameDefault
//-------------------------------------------------------------------
BEGIN_MESSAGE_MAP(CPropPageFrameDefault, CWnd)
	//{{AFX_MSG_MAP(CPropPageFrameDefault)
	ON_WM_PAINT()
	ON_WM_ERASEBKGND()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

CPropPageFrameDefault::CPropPageFrameDefault()
{
}

CPropPageFrameDefault::~CPropPageFrameDefault()
{
	if (m_Images.GetSafeHandle())
		m_Images.DeleteImageList();
}

/////////////////////////////////////////////////////////////////////
// Overridings
BOOL CPropPageFrameDefault::Create(DWORD dwWindowStyle, const RECT &rect, CWnd *pwndParent, UINT nID)
{
	return CWnd::Create(
		AfxRegisterWndClass(CS_HREDRAW|CS_VREDRAW, AfxGetApp()->LoadStandardCursor(IDC_ARROW), GetSysColorBrush(COLOR_3DFACE)),
		_T("Page Frame"),
		dwWindowStyle, rect, pwndParent, nID);
}

CWnd* CPropPageFrameDefault::GetWnd()
{
	return static_cast<CWnd*>(this);
}

void CPropPageFrameDefault::SetCaption(LPCTSTR lpszCaption, HICON hIcon /*= NULL*/)
{
	CPropPageFrame::SetCaption(lpszCaption, hIcon);

	// build image list
	if (m_Images.GetSafeHandle())
		m_Images.DeleteImageList();
	if (hIcon)
	{
		ICONINFO	ii;
		if (!GetIconInfo(hIcon, &ii))
			return;

		CBitmap	bmMask;
		bmMask.Attach(ii.hbmMask);
		if (ii.hbmColor) DeleteObject(ii.hbmColor);

		BITMAP	bm;
		bmMask.GetBitmap(&bm);

		if (!m_Images.Create(bm.bmWidth, bm.bmHeight, ILC_COLOR32|ILC_MASK, 0, 1))
			return;

		if (m_Images.Add(hIcon) == -1)
			m_Images.DeleteImageList();
	}
}

CRect CPropPageFrameDefault::CalcMsgArea()
{
	CRect	rect;
	GetClientRect(rect);
	if (g_ThemeLib.IsAvailable() && g_ThemeLib.IsThemeActive())
	{
		HTHEME	hTheme = g_ThemeLib.OpenThemeData(m_hWnd, L"Tab");
		if (hTheme)
		{
			CRect	rectContent;
			CDC		*pDc = GetDC();
			g_ThemeLib.GetThemeBackgroundContentRect(hTheme, pDc->m_hDC, TABP_PANE, 0, rect, rectContent);
			ReleaseDC(pDc);
			g_ThemeLib.CloseThemeData(hTheme);
			
			if (GetShowCaption())
				rectContent.top = rect.top+GetCaptionHeight()+1;
			rect = rectContent;
		}
	}
	else if (GetShowCaption())
		rect.top+= GetCaptionHeight()+1;
	
	return rect;
}

CRect CPropPageFrameDefault::CalcCaptionArea()
{
	CRect	rect;
	GetClientRect(rect);
	if (g_ThemeLib.IsAvailable() && g_ThemeLib.IsThemeActive())
	{
		HTHEME	hTheme = g_ThemeLib.OpenThemeData(m_hWnd, L"Tab");
		if (hTheme)
		{
			CRect	rectContent;
			CDC		*pDc = GetDC();
			g_ThemeLib.GetThemeBackgroundContentRect(hTheme, pDc->m_hDC, TABP_PANE, 0, rect, rectContent);
			ReleaseDC(pDc);
			g_ThemeLib.CloseThemeData(hTheme);
			
			if (GetShowCaption())
				rectContent.bottom = rect.top+GetCaptionHeight();
			else
				rectContent.bottom = rectContent.top;

			rect = rectContent;
		}
	}
	else
	{
		if (GetShowCaption())
			rect.bottom = rect.top+GetCaptionHeight();
		else
			rect.bottom = rect.top;
	}

	return rect;
}

void CPropPageFrameDefault::DrawCaption(CDC *pDc, CRect rect, LPCTSTR lpszCaption, HICON hIcon)
{
	COLORREF	clrLeft = GetSysColor(COLOR_INACTIVECAPTION);
	COLORREF	clrRight = pDc->GetPixel(rect.right-1, rect.top);
	FillGradientRectH(pDc, rect, clrLeft, clrRight);

	// draw icon
	if (hIcon && m_Images.GetSafeHandle() && m_Images.GetImageCount() == 1)
	{
		IMAGEINFO	ii;
		m_Images.GetImageInfo(0, &ii);
		CPoint		pt(3, rect.CenterPoint().y - (ii.rcImage.bottom-ii.rcImage.top)/2);
		m_Images.Draw(pDc, 0, pt, ILD_TRANSPARENT);
		rect.left+= (ii.rcImage.right-ii.rcImage.left) + 3;
	}

	// draw text
	rect.left+= 2;

	COLORREF	clrPrev = pDc->SetTextColor(GetSysColor(COLOR_CAPTIONTEXT));
	int				nBkStyle = pDc->SetBkMode(TRANSPARENT);
	CFont			*pFont = (CFont*)pDc->SelectStockObject(SYSTEM_FONT);

	pDc->DrawText(lpszCaption, rect, DT_LEFT|DT_VCENTER|DT_SINGLELINE|DT_END_ELLIPSIS);

	pDc->SetTextColor(clrPrev);
	pDc->SetBkMode(nBkStyle);
	pDc->SelectObject(pFont);
}

/////////////////////////////////////////////////////////////////////
// Implementation helpers
void CPropPageFrameDefault::FillGradientRectH(CDC *pDc, const RECT &rect, COLORREF clrLeft, COLORREF clrRight)
{
	// pre calculation
	int	nSteps = rect.right-rect.left;
	int	nRRange = GetRValue(clrRight)-GetRValue(clrLeft);
	int	nGRange = GetGValue(clrRight)-GetGValue(clrLeft);
	int	nBRange = GetBValue(clrRight)-GetBValue(clrLeft);

	double	dRStep = (double)nRRange/(double)nSteps;
	double	dGStep = (double)nGRange/(double)nSteps;
	double	dBStep = (double)nBRange/(double)nSteps;

	double	dR = (double)GetRValue(clrLeft);
	double	dG = (double)GetGValue(clrLeft);
	double	dB = (double)GetBValue(clrLeft);

	CPen	*pPrevPen = NULL;
	for (int x = rect.left; x <= rect.right; ++x)
	{
		CPen	Pen(PS_SOLID, 1, RGB((BYTE)dR, (BYTE)dG, (BYTE)dB));
		pPrevPen = pDc->SelectObject(&Pen);
		pDc->MoveTo(x, rect.top);
		pDc->LineTo(x, rect.bottom);
		pDc->SelectObject(pPrevPen);
		
		dR+= dRStep;
		dG+= dGStep;
		dB+= dBStep;
	}
}

/////////////////////////////////////////////////////////////////////
// message handlers

void CPropPageFrameDefault::OnPaint() 
{
	CPaintDC dc(this);
	Draw(&dc);	
}

BOOL CPropPageFrameDefault::OnEraseBkgnd(CDC* pDC) 
{
	if (g_ThemeLib.IsAvailable() && g_ThemeLib.IsThemeActive())
	{
		HTHEME	hTheme = g_ThemeLib.OpenThemeData(m_hWnd, L"Tab");
		if (hTheme)
		{
			CRect	rect;
			GetClientRect(rect);
			g_ThemeLib.DrawThemeBackground(hTheme, pDC->m_hDC, TABP_PANE, 0, rect, NULL);

			g_ThemeLib.CloseThemeData(hTheme);
		}
		return TRUE;
	}
	else
	{
		return CWnd::OnEraseBkgnd(pDC);
	}
}



//-------------------------------------------------------------------
// class CTreePropSheet
//-------------------------------------------------------------------
BEGIN_MESSAGE_MAP(CTreePropSheet, CPropertySheet)
	//{{AFX_MSG_MAP(CTreePropSheet)
	ON_WM_DESTROY()
	//}}AFX_MSG_MAP
	ON_MESSAGE(PSM_ADDPAGE, OnAddPage)
	ON_MESSAGE(PSM_REMOVEPAGE, OnRemovePage)
	ON_MESSAGE(PSM_SETCURSEL, OnSetCurSel)
	ON_MESSAGE(PSM_SETCURSELID, OnSetCurSelId)
	ON_MESSAGE(PSM_ISDIALOGMESSAGE, OnIsDialogMessage)
	
	ON_NOTIFY(TVN_SELCHANGINGA, s_unPageTreeId, OnPageTreeSelChanging)
	ON_NOTIFY(TVN_SELCHANGINGW, s_unPageTreeId, OnPageTreeSelChanging)
	ON_NOTIFY(TVN_SELCHANGEDA, s_unPageTreeId, OnPageTreeSelChanged)
	ON_NOTIFY(TVN_SELCHANGEDW, s_unPageTreeId, OnPageTreeSelChanged)
END_MESSAGE_MAP()

IMPLEMENT_DYNAMIC(CTreePropSheet, CPropertySheet)

const UINT CTreePropSheet::s_unPageTreeId = 0x7EEE;

CTreePropSheet::CTreePropSheet()
:	CPropertySheet(),
	m_bPageTreeSelChangedActive(FALSE),
	m_bTreeViewMode(TRUE),
	m_bPageCaption(FALSE),
	m_bTreeImages(FALSE),
	m_nPageTreeWidth(150),
	m_pwndPageTree(NULL),
	m_pFrame(NULL)
{}


CTreePropSheet::CTreePropSheet(UINT nIDCaption, CWnd* pParentWnd, UINT iSelectPage)
:	CPropertySheet(nIDCaption, pParentWnd, iSelectPage),
	m_bPageTreeSelChangedActive(FALSE),
	m_bTreeViewMode(TRUE),
	m_bPageCaption(FALSE),
	m_bTreeImages(FALSE),
	m_nPageTreeWidth(150),
	m_pwndPageTree(NULL),
	m_pFrame(NULL)
{
}

CTreePropSheet::CTreePropSheet(LPCTSTR pszCaption, CWnd* pParentWnd, UINT iSelectPage)
:	CPropertySheet(pszCaption, pParentWnd, iSelectPage),
	m_bPageTreeSelChangedActive(FALSE),
	m_bTreeViewMode(TRUE),
	m_bPageCaption(FALSE),
	m_bTreeImages(FALSE),
	m_nPageTreeWidth(150),
	m_pwndPageTree(NULL),
	m_pFrame(NULL)
{
}

CTreePropSheet::~CTreePropSheet()
{
}

/////////////////////////////////////////////////////////////////////
// Operationen
BOOL CTreePropSheet::SetTreeViewMode(BOOL bTreeViewMode /* = TRUE */, BOOL bPageCaption /* = FALSE */, BOOL bTreeImages /* = FALSE */)
{
	if (IsWindow(m_hWnd))
	{
		// needs to becalled, before the window has been created
		ASSERT(FALSE);
		return FALSE;
	}

	m_bTreeViewMode = bTreeViewMode;
	if (m_bTreeViewMode)
	{
		m_bPageCaption = bPageCaption;
		m_bTreeImages = bTreeImages;
	}

	return TRUE;
}

BOOL CTreePropSheet::SetTreeWidth(int nWidth)
{
	if (IsWindow(m_hWnd))
	{
		// needs to be called, before the window is created.
		ASSERT(FALSE);
		return FALSE;
	}

	m_nPageTreeWidth = nWidth;

	return TRUE;
}

void CTreePropSheet::SetEmptyPageText(LPCTSTR lpszEmptyPageText)
{
	m_strEmptyPageMessage = lpszEmptyPageText;
}

DWORD CTreePropSheet::SetEmptyPageTextFormat(DWORD dwFormat)
{
	DWORD	dwPrevFormat = m_pFrame->GetMsgFormat();
	m_pFrame->SetMsgFormat(dwFormat);
	return dwPrevFormat;
}

BOOL CTreePropSheet::SetTreeDefaultImages(CImageList *pImages)
{
	if (pImages->GetImageCount() != 2)
	{
		ASSERT(FALSE);
		return FALSE;
	}

	if (m_DefaultImages.GetSafeHandle())
		m_DefaultImages.DeleteImageList();
	m_DefaultImages.Create(pImages);

	// update, if necessary
	if (IsWindow(m_hWnd))
		RefillPageTree();
	
	return TRUE;
}

BOOL CTreePropSheet::SetTreeDefaultImages(UINT unBitmapID, int cx, COLORREF crMask)
{
	if (m_DefaultImages.GetSafeHandle())
		m_DefaultImages.DeleteImageList();
	if (!m_DefaultImages.Create(unBitmapID, cx, 0, crMask))
		return FALSE;

	if (m_DefaultImages.GetImageCount() != 2)
	{
		m_DefaultImages.DeleteImageList();
		return FALSE;
	}

	return TRUE;
}

CTreeCtrl* CTreePropSheet::GetPageTreeControl()
{
	return m_pwndPageTree;
}

/////////////////////////////////////////////////////////////////////
// public helpers

BOOL CTreePropSheet::SetPageIcon(CPropertyPage *pPage, HICON hIcon)
{
	pPage->m_psp.dwFlags|= PSP_USEHICON;
	pPage->m_psp.hIcon = hIcon;
	return TRUE;
}

BOOL CTreePropSheet::SetPageIcon(CPropertyPage *pPage, UINT unIconId)
{
	HICON	hIcon = AfxGetApp()->LoadIcon(unIconId);
	if (!hIcon)
		return FALSE;

	return SetPageIcon(pPage, hIcon);
}

BOOL CTreePropSheet::SetPageIcon(CPropertyPage *pPage, CImageList &Images, int nImage)
{
	HICON	hIcon = Images.ExtractIcon(nImage);
	if (!hIcon)
		return FALSE;

	return SetPageIcon(pPage, hIcon);
}

BOOL CTreePropSheet::DestroyPageIcon(CPropertyPage *pPage)
{
	if (!pPage || !(pPage->m_psp.dwFlags&PSP_USEHICON) || !pPage->m_psp.hIcon)
		return FALSE;

	DestroyIcon(pPage->m_psp.hIcon);
	pPage->m_psp.dwFlags&= ~PSP_USEHICON;
	pPage->m_psp.hIcon = NULL;

	return TRUE;
}

/////////////////////////////////////////////////////////////////////
// Overridable implementation helpers

CString CTreePropSheet::GenerateEmptyPageMessage(LPCTSTR lpszEmptyPageMessage, LPCTSTR lpszCaption)
{
	CString	strMsg;
	strMsg.Format(lpszEmptyPageMessage, lpszCaption);
	return strMsg;
}


CTreeCtrl* CTreePropSheet::CreatePageTreeObject()
{
	return new CTreeCtrl;
}

CPropPageFrame* CTreePropSheet::CreatePageFrame()
{
	return new CPropPageFrameDefault;
}


/////////////////////////////////////////////////////////////////////
// Implementation helpers
void CTreePropSheet::MoveChildWindows(int nDx, int nDy)
{
	CWnd	*pWnd = GetWindow(GW_CHILD);
	while (pWnd)
	{
		CRect	rect;
		pWnd->GetWindowRect(rect);
		rect.OffsetRect(nDx, nDy);
		ScreenToClient(rect);
		pWnd->MoveWindow(rect);

		pWnd = pWnd->GetNextWindow();
	}
}

void CTreePropSheet::RefillPageTree()
{
	if (!IsWindow(m_hWnd))
		return;

	m_pwndPageTree->DeleteAllItems();

	CTabCtrl	*pTabCtrl = GetTabControl();
	if (!IsWindow(pTabCtrl->GetSafeHwnd()))
	{
		ASSERT(FALSE);
		return;
	}

	const int	nPageCount = pTabCtrl->GetItemCount();

	// rebuild image list
	if (m_bTreeImages)
	{
		for (int i = m_Images.GetImageCount()-1; i >= 0; --i)
			m_Images.Remove(i);

		// add page images
		CImageList	*pPageImages = pTabCtrl->GetImageList();
		if (pPageImages)
		{
			for (int nImage = 0; nImage < pPageImages->GetImageCount(); ++nImage)
			{
				HICON	hIcon = pPageImages->ExtractIcon(nImage);
				m_Images.Add(hIcon);
				DestroyIcon(hIcon);
			}
		}

		// add default images
		if (m_DefaultImages.GetSafeHandle())
		{	
			HICON	hIcon;

			// add default images
			hIcon = m_DefaultImages.ExtractIcon(0);
			if (hIcon)
			{
				m_Images.Add(hIcon);
				DestroyIcon(hIcon);
			}
			hIcon = m_DefaultImages.ExtractIcon(1);
			{
				m_Images.Add(hIcon);
				DestroyIcon(hIcon);
			}
		}
	}

	// insert tree items
	for (int nPage = 0; nPage < nPageCount; ++nPage)
	{
		// Get title and image of the page
		CString	strPagePath;

		TCITEM	ti;
		ZeroMemory(&ti, sizeof(ti));
		ti.mask = TCIF_TEXT|TCIF_IMAGE;
		ti.cchTextMax = MAX_PATH;
		ti.pszText = strPagePath.GetBuffer(ti.cchTextMax);
		ASSERT(ti.pszText);
		if (!ti.pszText)
			return;

		pTabCtrl->GetItem(nPage, &ti);
		strPagePath.ReleaseBuffer();

		// Create an item in the tree for the page
		HTREEITEM	hItem = CreatePageTreeItem(ti.pszText);
		ASSERT(hItem);
		if (hItem)
		{
			m_pwndPageTree->SetItemData(hItem, nPage);

			// set image
			if (m_bTreeImages)
			{
				int	nImage = ti.iImage;
				if (nImage < 0 || nImage >= m_Images.GetImageCount())
					nImage = m_DefaultImages.GetSafeHandle()? m_Images.GetImageCount()-1 : -1;

				m_pwndPageTree->SetItemImage(hItem, nImage, nImage);
			}
		}
	}
}

HTREEITEM CTreePropSheet::CreatePageTreeItem(LPCTSTR lpszPath, HTREEITEM hParent /* = TVI_ROOT */)
{
	CString		strPath(lpszPath);
	CString		strTopMostItem(SplitPageTreePath(strPath));
	
	// Check if an item with the given text does already exist
	HTREEITEM	hItem = NULL;
	HTREEITEM	hChild = m_pwndPageTree->GetChildItem(hParent);
	while (hChild)
	{
		if (m_pwndPageTree->GetItemText(hChild) == strTopMostItem)
		{
			hItem = hChild;
			break;
		}
		hChild = m_pwndPageTree->GetNextItem(hChild, TVGN_NEXT);
	}

	// If item with that text does not already exist, create a new one
	if (!hItem)
	{
		hItem = m_pwndPageTree->InsertItem(strTopMostItem, hParent);
		m_pwndPageTree->SetItemData(hItem, (DWORD)(-1));
		if (!strPath.IsEmpty() && m_bTreeImages && m_DefaultImages.GetSafeHandle())
			// set folder image
			m_pwndPageTree->SetItemImage(hItem, m_Images.GetImageCount()-2, m_Images.GetImageCount()-2);
	}
	if (!hItem)
	{
		ASSERT(FALSE);
		return NULL;
	}

	if (strPath.IsEmpty())
		return hItem;
	else
		return CreatePageTreeItem(strPath, hItem);
}

CString CTreePropSheet::SplitPageTreePath(CString &strRest)
{
	int	nSeperatorPos = 0;
	while (TRUE)
	{
		nSeperatorPos = strRest.Find(_T("::"), nSeperatorPos);
		if (nSeperatorPos == -1)
		{
			CString	strItem(strRest);
			strRest.Empty();
			return strItem;
		}
		else if (nSeperatorPos>0)
		{
			// if there is an odd number of backslashes infront of the
			// seperator, than do not interpret it as separator
			int	nBackslashCount = 0;
			for (int nPos = nSeperatorPos-1; nPos >= 0 && strRest[nPos]==_T('\\'); --nPos, ++nBackslashCount);
			if (nBackslashCount%2 == 0)
				break;
			else
				++nSeperatorPos;
		}
	}

	CString	strItem(strRest.Left(nSeperatorPos));
	strItem.Replace(_T("\\::"), _T("::"));
	strItem.Replace(_T("\\\\"), _T("\\"));
	strRest = strRest.Mid(nSeperatorPos+2);
	return strItem;
}

BOOL CTreePropSheet::KillActiveCurrentPage()
{
	HWND	hCurrentPage = PropSheet_GetCurrentPageHwnd(m_hWnd);
	if (!IsWindow(hCurrentPage))
	{
		ASSERT(FALSE);
		return TRUE;
	}

	// Check if the current page is really active (if page is invisible
	// an virtual empty page is the active one.
	if (!::IsWindowVisible(hCurrentPage))
		return TRUE;

	// Try to deactivate current page
	PSHNOTIFY	pshn;
	pshn.hdr.code = PSN_KILLACTIVE;
	pshn.hdr.hwndFrom = m_hWnd;
	pshn.hdr.idFrom = GetDlgCtrlID();
	pshn.lParam = 0;
	if (::SendMessage(hCurrentPage, WM_NOTIFY, pshn.hdr.idFrom, (LPARAM)&pshn))
		// current page does not allow page change
		return FALSE;

	// Hide the page
	::ShowWindow(hCurrentPage, SW_HIDE);

	return TRUE;
}

HTREEITEM CTreePropSheet::GetPageTreeItem(int nPage, HTREEITEM hRoot /* = TVI_ROOT */)
{
	// Special handling for root case
	if (hRoot == TVI_ROOT)
		hRoot = m_pwndPageTree->GetNextItem(NULL, TVGN_ROOT);

	// Check parameters
	if (nPage < 0 || nPage >= GetPageCount())
	{
		ASSERT(FALSE);
		return NULL;
	}

	if (hRoot == NULL)
	{
		ASSERT(FALSE);
		return NULL;
	}

	// we are performing a simple linear search here, because we are
	// expecting only little data
	HTREEITEM	hItem = hRoot;
	while (hItem)
	{
		if ((signed)m_pwndPageTree->GetItemData(hItem) == nPage)
			return hItem;
		if (m_pwndPageTree->ItemHasChildren(hItem))
		{
			HTREEITEM	hResult = GetPageTreeItem(nPage, m_pwndPageTree->GetNextItem(hItem, TVGN_CHILD));
			if (hResult)
				return hResult;
		}

		hItem = m_pwndPageTree->GetNextItem(hItem, TVGN_NEXT);
	}

	// we've found nothing, if we arrive here
	return hItem;
}

BOOL CTreePropSheet::SelectPageTreeItem(int nPage)
{
	HTREEITEM	hItem = GetPageTreeItem(nPage);
	if (!hItem)
		return FALSE;

	return m_pwndPageTree->SelectItem(hItem);
}

BOOL CTreePropSheet::SelectCurrentPageTreeItem()
{
	CTabCtrl	*pTab = GetTabControl();
	if (!IsWindow(pTab->GetSafeHwnd()))
		return FALSE;

	return SelectPageTreeItem(pTab->GetCurSel());
}

void CTreePropSheet::UpdateCaption()
{
	HWND			hPage = PropSheet_GetCurrentPageHwnd(GetSafeHwnd());
	BOOL			bRealPage = IsWindow(hPage) && ::IsWindowVisible(hPage);
	HTREEITEM	hItem = m_pwndPageTree->GetSelectedItem();
	if (!hItem)
		return;
	CString		strCaption = m_pwndPageTree->GetItemText(hItem);

	// if empty page, then update empty page message
	if (!bRealPage)
		m_pFrame->SetMsgText(GenerateEmptyPageMessage(m_strEmptyPageMessage, strCaption));

	// if no captions are displayed, cancel here
	if (!m_pFrame->GetShowCaption())
		return;

	// get tab control, to the the images from
	CTabCtrl	*pTabCtrl = GetTabControl();
	if (!IsWindow(pTabCtrl->GetSafeHwnd()))
	{
		ASSERT(FALSE);
		return;
	}

	if (m_bTreeImages)
	{
		// get image from tree
		int	nImage;
		m_pwndPageTree->GetItemImage(hItem, nImage, nImage);
		HICON	hIcon = m_Images.ExtractIcon(nImage);
		m_pFrame->SetCaption(strCaption, hIcon);
		if (hIcon)
			DestroyIcon(hIcon);
	}
	else if (bRealPage)
	{
		// get image from hidden (original) tab provided by the original
		// implementation
		CImageList	*pImages = pTabCtrl->GetImageList();
		if (pImages)
		{
			TCITEM	ti;
			ZeroMemory(&ti, sizeof(ti));
			ti.mask = TCIF_IMAGE;

			HICON	hIcon = NULL;
			if (pTabCtrl->GetItem((int)m_pwndPageTree->GetItemData(hItem), &ti))
				hIcon = pImages->ExtractIcon(ti.iImage);

			m_pFrame->SetCaption(strCaption, hIcon);
			if (hIcon)
				DestroyIcon(hIcon);
		}
		else
			m_pFrame->SetCaption(strCaption);
	}
	else
		m_pFrame->SetCaption(strCaption);
}

void CTreePropSheet::ActivatePreviousPage()
{
	if (!IsWindow(m_hWnd))
		return;

	if (!IsWindow(m_pwndPageTree->GetSafeHwnd()))
	{
		// normal tab property sheet. Simply use page index
		int	nPageIndex = GetActiveIndex();
		if (nPageIndex<0 || nPageIndex>=GetPageCount())
			return;

		int	nPrevIndex = (nPageIndex==0)? GetPageCount()-1 : nPageIndex-1;
		SetActivePage(nPrevIndex);
	}
	else
	{
		// property sheet with page tree.
		// we need a more sophisticated handling here, than simply using
		// the page index, because we won't skip empty pages.
		// so we have to walk the page tree
		HTREEITEM	hItem = m_pwndPageTree->GetSelectedItem();
		ASSERT(hItem);
		if (!hItem)
			return;

		HTREEITEM	hPrevItem = NULL;
		hPrevItem = m_pwndPageTree->GetPrevSiblingItem(hItem);
		if (hPrevItem)
		{
			while (m_pwndPageTree->ItemHasChildren(hPrevItem))
			{
				hPrevItem = m_pwndPageTree->GetChildItem(hPrevItem);
				while (m_pwndPageTree->GetNextSiblingItem(hPrevItem))
					hPrevItem = m_pwndPageTree->GetNextSiblingItem(hPrevItem);
			}
		}
		else 
			hPrevItem=m_pwndPageTree->GetParentItem(hItem);

		if (!hPrevItem)
		{
			// no prev item, so cycle to the last item
			hPrevItem = m_pwndPageTree->GetRootItem();

			while (TRUE)
			{
				while (m_pwndPageTree->GetNextSiblingItem(hPrevItem))
					hPrevItem = m_pwndPageTree->GetNextSiblingItem(hPrevItem);

				if (m_pwndPageTree->ItemHasChildren(hPrevItem))
					hPrevItem = m_pwndPageTree->GetChildItem(hPrevItem);
				else
					break;
			}
		}

		if (hPrevItem)
			m_pwndPageTree->SelectItem(hPrevItem);
	}
}

void CTreePropSheet::ActivateNextPage()
{
	if (!IsWindow(m_hWnd))
		return;

	if (!IsWindow(m_pwndPageTree->GetSafeHwnd()))
	{
		// normal tab property sheet. Simply use page index
		int	nPageIndex = GetActiveIndex();
		if (nPageIndex<0 || nPageIndex>=GetPageCount())
			return;

		int	nNextIndex = (nPageIndex==GetPageCount()-1)? 0 : nPageIndex+1;
		SetActivePage(nNextIndex);
	}
	else
	{
		// property sheet with page tree.
		// we need a more sophisticated handling here, than simply using
		// the page index, because we won't skip empty pages.
		// so we have to walk the page tree
		HTREEITEM	hItem = m_pwndPageTree->GetSelectedItem();
		ASSERT(hItem);
		if (!hItem)
			return;

		HTREEITEM	hNextItem = NULL;
		if((hNextItem = m_pwndPageTree->GetChildItem(hItem)) != 0);
		else if ((hNextItem=m_pwndPageTree->GetNextSiblingItem(hItem)) != 0);
		else if (m_pwndPageTree->GetParentItem(hItem))
		{
			while (!hNextItem)
			{
				hItem = m_pwndPageTree->GetParentItem(hItem);
				if (!hItem)
					break;

				hNextItem	= m_pwndPageTree->GetNextSiblingItem(hItem);
			}
		}

		if (!hNextItem)
			// no next item -- so cycle to the first item
			hNextItem = m_pwndPageTree->GetRootItem();

		if (hNextItem)
			m_pwndPageTree->SelectItem(hNextItem);
	}
}


/////////////////////////////////////////////////////////////////////
// Overridings
BOOL CTreePropSheet::OnInitDialog() 
{
	if (m_bTreeViewMode)
	{
		// be sure, there are no stacked tabs, because otherwise the
		// page caption will be to large in tree view mode
		EnableStackedTabs(FALSE);

		// Initialize image list.
		if (m_DefaultImages.GetSafeHandle())
		{
			IMAGEINFO	ii;
			m_DefaultImages.GetImageInfo(0, &ii);
			if (ii.hbmImage) DeleteObject(ii.hbmImage);
			if (ii.hbmMask) DeleteObject(ii.hbmMask);
			m_Images.Create(ii.rcImage.right-ii.rcImage.left, ii.rcImage.bottom-ii.rcImage.top, ILC_COLOR32|ILC_MASK, 0, 1);
		}
		else
			m_Images.Create(16, 16, ILC_COLOR32|ILC_MASK, 0, 1);
	}

	// perform default implementation
	BOOL bResult = CPropertySheet::OnInitDialog();

	if (!m_bTreeViewMode)
		// stop here, if we would like to use tabs
		return bResult;

	// Get tab control...
	CTabCtrl	*pTab = GetTabControl();
	if (!IsWindow(pTab->GetSafeHwnd()))
	{
		ASSERT(FALSE);
		return bResult;
	}

	// ... and hide it
	pTab->ShowWindow(SW_HIDE);
	pTab->EnableWindow(FALSE);

	// Place another (empty) tab ctrl, to get a frame instead
	CRect	rectFrame;
	pTab->GetWindowRect(rectFrame);
	ScreenToClient(rectFrame);

	m_pFrame = CreatePageFrame();
	if (!m_pFrame)
	{
		ASSERT(FALSE);
		AfxThrowMemoryException();
	}
	m_pFrame->Create(WS_CHILD|WS_VISIBLE|WS_CLIPSIBLINGS, rectFrame, this, 0xFFFF);
	m_pFrame->ShowCaption(m_bPageCaption);

	// Lets make place for the tree ctrl
	const int	nTreeWidth = m_nPageTreeWidth;
	const int	nTreeSpace = 5;

	CRect	rectSheet;
	GetWindowRect(rectSheet);
	rectSheet.right+= nTreeWidth;
	SetWindowPos(NULL, -1, -1, rectSheet.Width(), rectSheet.Height(), SWP_NOZORDER|SWP_NOMOVE);
	CenterWindow();

	MoveChildWindows(nTreeWidth, 0);

	// Lets calculate the rectangle for the tree ctrl
	CRect	rectTree(rectFrame);
	rectTree.right = rectTree.left + nTreeWidth - nTreeSpace;

	// calculate caption height
	CTabCtrl	wndTabCtrl;
	wndTabCtrl.Create(WS_CHILD|WS_VISIBLE|WS_CLIPSIBLINGS, rectFrame, this, 0x1234);
	wndTabCtrl.InsertItem(0, _T(""));
	CRect	rectFrameCaption;
	wndTabCtrl.GetItemRect(0, rectFrameCaption);
	wndTabCtrl.DestroyWindow();
	m_pFrame->SetCaptionHeight(rectFrameCaption.Height());

	// if no caption should be displayed, make the window smaller in
	// height
	if (!m_bPageCaption)
	{
		// make frame smaller
		m_pFrame->GetWnd()->GetWindowRect(rectFrame);
		ScreenToClient(rectFrame);
		rectFrame.top+= rectFrameCaption.Height();
		m_pFrame->GetWnd()->MoveWindow(rectFrame);

		// move all child windows up
		MoveChildWindows(0, -rectFrameCaption.Height());

		// modify rectangle for the tree ctrl
		rectTree.bottom-= rectFrameCaption.Height();

		// make us smaller
		CRect	rect;
		GetWindowRect(rect);
		rect.top+= rectFrameCaption.Height()/2;
		rect.bottom-= rectFrameCaption.Height()-rectFrameCaption.Height()/2;
		if (GetParent())
			GetParent()->ScreenToClient(rect);
		MoveWindow(rect);
	}

	// finally create tht tree control
	const DWORD	dwTreeStyle = TVS_SHOWSELALWAYS|TVS_TRACKSELECT|TVS_HASLINES|TVS_LINESATROOT|TVS_HASBUTTONS;
	m_pwndPageTree = CreatePageTreeObject();
	if (!m_pwndPageTree)
	{
		ASSERT(FALSE);
		AfxThrowMemoryException();
	}
	
	#if _MFC_VER >= 0x0700
	{
		m_pwndPageTree->CreateEx(
			WS_EX_CLIENTEDGE|WS_EX_NOPARENTNOTIFY, 
			WS_TABSTOP|WS_CHILD|WS_VISIBLE|dwTreeStyle, 
			rectTree, this, s_unPageTreeId);
	}
	#else
	{
		m_pwndPageTree->CreateEx(
			WS_EX_CLIENTEDGE|WS_EX_NOPARENTNOTIFY, 
			_T("SysTreeView32"), _T("PageTree"), 
			WS_TABSTOP|WS_CHILD|WS_VISIBLE|dwTreeStyle, 
			rectTree, this, s_unPageTreeId);
	}
	#endif
	
	if (m_bTreeImages)
	{
		m_pwndPageTree->SetImageList(&m_Images, TVSIL_NORMAL);
		m_pwndPageTree->SetImageList(&m_Images, TVSIL_STATE);
	}

	// Fill the tree ctrl
	RefillPageTree();

	// Select item for the current page
	if (pTab->GetCurSel() > -1)
		SelectPageTreeItem(pTab->GetCurSel());

	return bResult;
}

void CTreePropSheet::OnDestroy() 
{
	CPropertySheet::OnDestroy();
	
	if (m_Images.GetSafeHandle())
		m_Images.DeleteImageList();

	delete m_pwndPageTree;
	m_pwndPageTree = NULL;

	delete m_pFrame;
	m_pFrame = NULL;
}

LRESULT CTreePropSheet::OnAddPage(WPARAM wParam, LPARAM lParam)
{
	LRESULT	lResult = DefWindowProc(PSM_ADDPAGE, wParam, lParam);
	if (!m_bTreeViewMode)
		return lResult;

	RefillPageTree();
	SelectCurrentPageTreeItem();

	return lResult;
}

LRESULT CTreePropSheet::OnRemovePage(WPARAM wParam, LPARAM lParam)
{
	LRESULT	lResult = DefWindowProc(PSM_REMOVEPAGE, wParam, lParam);
	if (!m_bTreeViewMode)
		return lResult;

	RefillPageTree();
	SelectCurrentPageTreeItem();

	return lResult;
}

LRESULT CTreePropSheet::OnSetCurSel(WPARAM wParam, LPARAM lParam)
{
	LRESULT	lResult = DefWindowProc(PSM_SETCURSEL, wParam, lParam);
	if (!m_bTreeViewMode)
		return lResult;

	SelectCurrentPageTreeItem();
	UpdateCaption();
	return lResult;
}

LRESULT CTreePropSheet::OnSetCurSelId(WPARAM wParam, LPARAM lParam)
{
	LRESULT	lResult = DefWindowProc(PSM_SETCURSEL, wParam, lParam);
	if (!m_bTreeViewMode)
		return lResult;

	SelectCurrentPageTreeItem();
	UpdateCaption();
	return lResult;
}

void CTreePropSheet::OnPageTreeSelChanging(NMHDR *pNotifyStruct, LRESULT *plResult)
{
	*plResult = 0;
	if (m_bPageTreeSelChangedActive)
		return;
	else
		m_bPageTreeSelChangedActive = TRUE;

	NMTREEVIEW	*pTvn = reinterpret_cast<NMTREEVIEW*>(pNotifyStruct);
	int					nPage = m_pwndPageTree->GetItemData(pTvn->itemNew.hItem);
	BOOL				bResult;
	if (nPage<0 || (unsigned)nPage>=m_pwndPageTree->GetCount())
		bResult = KillActiveCurrentPage();
	else
		bResult = SetActivePage(nPage);

	if (!bResult)
		// prevent selection to change
		*plResult = TRUE;

	// Set focus to tree ctrl (I guess that's what the user expects)
	m_pwndPageTree->SetFocus();

	m_bPageTreeSelChangedActive = FALSE;

	return;
}

void CTreePropSheet::OnPageTreeSelChanged(NMHDR*, LRESULT *plResult)
{
	*plResult = 0;

	UpdateCaption();

	return;
}

LRESULT CTreePropSheet::OnIsDialogMessage(WPARAM wParam, LPARAM lParam)
{
	MSG	*pMsg = reinterpret_cast<MSG*>(lParam);
	if (pMsg->message==WM_KEYDOWN && pMsg->wParam==VK_TAB && GetKeyState(VK_CONTROL)&0x8000)
	{
		if (GetKeyState(VK_SHIFT)&0x8000)
			ActivatePreviousPage();
		else
			ActivateNextPage();
		return TRUE;
	}


	return CPropertySheet::DefWindowProc(PSM_ISDIALOGMESSAGE, wParam, lParam);
}

//==========================================================================================//
//==========================================================================================//
// class CPropPageFrame
//==========================================================================================//
//==========================================================================================//
CPropPageFrame::CPropPageFrame()
:	m_bShowCaption(FALSE),
	m_nCaptionHeight(0),
	m_hCaptionIcon(NULL),
	m_dwMsgFormat(DT_CENTER|DT_VCENTER|DT_NOPREFIX|DT_SINGLELINE)
{
}

CPropPageFrame::~CPropPageFrame()
{
}
/////////////////////////////////////////////////////////////////////
// Operations
void CPropPageFrame::ShowCaption(BOOL bEnable)
{
	m_bShowCaption = bEnable;
	SafeUpdateWindow(CalcCaptionArea());
}

BOOL CPropPageFrame::GetShowCaption() const
{
	return m_bShowCaption;
}

void CPropPageFrame::SetCaption(LPCTSTR lpszCaption, HICON hIcon /*= NULL*/)
{
	m_strCaption = lpszCaption;
	m_hCaptionIcon = hIcon;
	SafeUpdateWindow(CalcCaptionArea());
}

CString CPropPageFrame::GetCaption(HICON *pIcon /* = NULL */) const
{
	if (pIcon)
		*pIcon = m_hCaptionIcon;
	return m_strCaption;
}

void CPropPageFrame::SetCaptionHeight(int nCaptionHeight)
{
	m_nCaptionHeight = nCaptionHeight;
	SafeUpdateWindow(CalcCaptionArea());
}

int CPropPageFrame::GetCaptionHeight() const
{
	return m_nCaptionHeight;
}

void CPropPageFrame::SetMsgText(LPCTSTR lpszMsg)
{
	m_strMsg = lpszMsg;
	SafeUpdateWindow(CalcMsgArea());
}

CString CPropPageFrame::GetMsgText() const
{
	return m_strMsg;
}

void CPropPageFrame::SetMsgFormat(DWORD dwFormat)
{
	m_dwMsgFormat = dwFormat;
	SafeUpdateWindow(CalcMsgArea());
}

DWORD CPropPageFrame::GetMsgFormat() const
{
	return m_dwMsgFormat;
}

/////////////////////////////////////////////////////////////////////
// Overridable implementation helpers
void CPropPageFrame::Draw(CDC *pDc)
{
	if (GetShowCaption())
		DrawCaption(pDc, CalcCaptionArea(), m_strCaption, m_hCaptionIcon);
	DrawMsg(pDc, CalcMsgArea(), m_strMsg, m_dwMsgFormat);
}


CRect CPropPageFrame::CalcMsgArea()
{
	ASSERT(IsWindow(GetWnd()->GetSafeHwnd()));

	CRect	rectMsg;
	GetWnd()->GetClientRect(rectMsg);
	if (GetShowCaption())
		rectMsg.top+= GetCaptionHeight();

	return rectMsg;
}


void CPropPageFrame::DrawMsg(CDC *pDc, CRect rect, LPCTSTR, DWORD) 
{
	//CFont	*pPrevFont = dynamic_cast<CFont*>(pDc->SelectStockObject(DEFAULT_GUI_FONT));
	CFont	*pPrevFont = (CFont*)(pDc->SelectStockObject(DEFAULT_GUI_FONT));
	int		nPrevBkMode = pDc->SetBkMode(TRANSPARENT);

	pDc->DrawText(GetMsgText(), rect, GetMsgFormat());

	pDc->SetBkMode(nPrevBkMode);
	pDc->SelectObject(pPrevFont);
}


CRect CPropPageFrame::CalcCaptionArea()
{
	ASSERT(IsWindow(GetWnd()->GetSafeHwnd()));

	CRect	rectCaption;
	GetWnd()->GetClientRect(rectCaption);
	if (!GetShowCaption())
		rectCaption.bottom = rectCaption.top;
	else
		rectCaption.bottom = rectCaption.top+GetCaptionHeight();

	return rectCaption;
}


void CPropPageFrame::DrawCaption(CDC*, CRect, LPCTSTR, HICON) 
{
	// should be implemented by specialized classes
}


/////////////////////////////////////////////////////////////////////
// Implementation helpers
void CPropPageFrame::SafeUpdateWindow(LPCRECT lpRect /* = NULL */)
{
	if (!IsWindow(GetWnd()->GetSafeHwnd()))
		return;

	GetWnd()->InvalidateRect(lpRect, TRUE);
}



//==========================================================================================//
//==========================================================================================//
//==========================================================================================//
//==========================================================================================//

//==========================================================================================//
//==========================================================================================//
//==========================================================================================//
//==========================================================================================//
////////////////////////////////////////////////////////////////////////////
// CListCtrlEx implementation
////////////////////////////////////////////////////////////////////////////
CListCtrlEx::CListCtrlEx()
{
}

CListCtrlEx::~CListCtrlEx()
{
}

BEGIN_MESSAGE_MAP(CListCtrlEx, CListCtrl)
	//{{AFX_MSG_MAP(CListCtrlEx)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CListCtrlEx message handlers

void CListCtrlEx::PreSubclassWindow()
{
	// the list control must have the report style.
	ASSERT(GetStyle() & LVS_REPORT);
	CListCtrl::PreSubclassWindow();
	SetFullRowSelect(TRUE);
}

void CListCtrlEx::SetGridLines(BOOL bSet)
{
	DWORD dwStype = CListCtrl::GetExtendedStyle();
	if (bSet)
		dwStype |= LVS_EX_GRIDLINES;
	else
		dwStype &= ~LVS_EX_GRIDLINES;
	CListCtrl::SetExtendedStyle(dwStype);
}

void CListCtrlEx::SetSubItemImage(BOOL bSet)
{
	DWORD dwStype = CListCtrl::GetExtendedStyle();
	if (bSet)
		dwStype |= LVS_EX_SUBITEMIMAGES;
	else
		dwStype &= ~LVS_EX_SUBITEMIMAGES;
	CListCtrl::SetExtendedStyle(dwStype);
}

void CListCtrlEx::SetTrackSelect(BOOL bSet)
{
	DWORD dwStype = CListCtrl::GetExtendedStyle();
	if (bSet)
		dwStype |= LVS_EX_TRACKSELECT;
	else
		dwStype &= ~LVS_EX_TRACKSELECT;
	CListCtrl::SetExtendedStyle(dwStype);
}

void CListCtrlEx::SetCheckboxes(BOOL bSet)
{
	DWORD dwStype = CListCtrl::GetExtendedStyle();
	if (bSet)
		dwStype |= LVS_EX_CHECKBOXES;
	else
		dwStype &= ~LVS_EX_CHECKBOXES;
	CListCtrl::SetExtendedStyle(dwStype);
}

void CListCtrlEx::SetHeaderDragDrop(BOOL bSet)
{
	DWORD dwStyle = CListCtrl::GetExtendedStyle();
	if(bSet)
		dwStyle |= LVS_EX_HEADERDRAGDROP;
	else 
		dwStyle &= ~LVS_EX_HEADERDRAGDROP;
	CListCtrl::SetExtendedStyle(dwStyle);
}

void CListCtrlEx::SetFullRowSelect(BOOL bSet)
{
	DWORD dwStype = CListCtrl::GetExtendedStyle();
	if (bSet)
		dwStype |= LVS_EX_FULLROWSELECT;
	else
		dwStype &= ~LVS_EX_FULLROWSELECT;
	CListCtrl::SetExtendedStyle(dwStype);
}
 

BOOL CListCtrlEx::SetHeadings(UINT uiStringID)
{
	CString strHeadings;
	VERIFY(strHeadings.LoadString(uiStringID));
	return SetHeadings(strHeadings);
}

////////////////////////////////////////////////////////////////////////////////
// the heading text is in the format column 1 text,column 1 width;column 2 text,column 3 width;etc.
BOOL CListCtrlEx::SetHeadings(const CString& strHeadings)
{
	CString sPara;
	int nParaStart = 0;
	int nSemiColon = -1;
	BOOL bContinue = TRUE;

	while (nSemiColon < strHeadings.GetLength()) {
		// determine the paragraph ("xxx,xxx,xxx;")
		nSemiColon = strHeadings.Find(_T(';'), nParaStart);
		if(nSemiColon == -1) {
			// reached the end of string
			nSemiColon = strHeadings.GetLength();
			bContinue = FALSE;
		}

		sPara = strHeadings.Mid(nParaStart, nSemiColon - nParaStart);
		nParaStart = nSemiColon + 1; // ready to move on to next paragraph
		
		int iStart = 0;
		int iComma = -1;

		// find the heading name string
		iComma = sPara.Find(_T(','), iStart);

		if(iComma == -1)
			break;

		const CString sColName = sPara.Mid(iStart, iComma - iStart);

		iStart = iComma + 1;

		// find the heading format string (0=LVCFMT_LEFT, 1=LVCFMT_CENTER, 2=LVCFMT_RIGHT)
		int nFmt = LVCFMT_LEFT;
		iComma = sPara.Find(_T(','), iStart);
		if (iComma == -1) {
			// user does not specify a format, so use LVCFMT_LEFT as default)
		}
		else {
			// there is a format string
			int n = _ttoi(sPara.Mid(iStart, iComma - iStart));

			if (n == 1)
				nFmt = LVCFMT_CENTER;
			else if (n == 2)
				nFmt = LVCFMT_RIGHT;
			else
				nFmt = LVCFMT_LEFT;
			
			iStart = iComma + 1;
		}

		// remained is the column width string
		int iWidth = _ttoi(sPara.Mid(iStart, sPara.GetLength() - iStart));
		if (iWidth < 1)
			iWidth = 1; // width should be at least 1

		if(InsertColumn(GetHeaderCtrl()->GetItemCount(), sColName, nFmt, iWidth) == -1)
			return FALSE;
	}

	return TRUE;
}

//==========================================================================================//
//==========================================================================================//

//==========================================================================================//
//==========================================================================================//
CHtmlFile::CHtmlFile(HINSTANCE hInst, CString strFileName)
{
	m_strFileName = strFileName;
	m_hInst = hInst;

	bgcolor = _T("#ffffe0");
	m_thAlign = _T("left");
	m_tdAlign = _T("center");
	m_nThColSpan = 1;
	m_nThRowSpan = 1;
	m_nTdColSpan = 1;
	m_nTdRowSpan = 1;

	m_strArr.RemoveAll();
}


CHtmlFile::~CHtmlFile()
{
}

int CHtmlFile::SetBgColor(CString color)
{
	bgcolor.Format(_T("%s"), (LPCTSTR)color);
	return 1;
}

int CHtmlFile::StartTags(CString lpszTitle, CString lpszCaption)
{
	CString tempStr;

	tempStr.Format(_T("<HTML> \r\n<TITLE> %s </TITLE> \r\n<BODY> <CENTER>"), (LPCTSTR)lpszTitle);
	m_strArr.Add(tempStr);
	tempStr.Format(_T("\r\n<H3><br>%s"), (LPCTSTR)lpszCaption);
	m_strArr.Add(tempStr);
	tempStr.Format(_T("\r\n<TABLE border=1 frame=box borderColor=black> \r\n"));
	m_strArr.Add(tempStr);

	return 1;
}
	
int CHtmlFile::StartTags(int rtuType, int rtuNo, CString cfgTxt, CString paramTxt)
{
	CString rtuTypeTxt = RES_STRING(IDS_RTU_TYPE_TXT);
	CString rtuNumTxt = RES_STRING(IDS_RTU_NO_TXT);
	CString rtuTypeStr = GetRTUType(rtuType);

	CString txt; txt.Format(_T("%s <br>%s: %s <br>%s: %d <br>%s"), 
		(LPCTSTR)cfgTxt, (LPCTSTR)rtuTypeTxt, (LPCTSTR)rtuTypeStr, (LPCTSTR)rtuNumTxt, rtuNo + 1, (LPCTSTR)paramTxt);

	CString tempStr; tempStr.Format(_T("<HTML> \r\n<TITLE> %s </TITLE> \r\n<BODY> <CENTER>"), (LPCTSTR)cfgTxt);
	m_strArr.Add(tempStr);
	tempStr.Format(_T("\r\n<H3><br>%s"), (LPCTSTR)txt);
	m_strArr.Add(tempStr);
	tempStr.Format(_T("\r\n<TABLE border=1 frame=box borderColor=black> \r\n"));
	m_strArr.Add(tempStr);

	return 1;
}

int CHtmlFile::StartTags(int rtuType, int rtuNo, UINT cfgID, UINT paramID)
{
	return StartTags(rtuType, rtuNo, RES_STRING(cfgID), RES_STRING(paramID));
}

int CHtmlFile::StartTagsP(int rtuType, int rtuNo, UINT cfgID, int portNum, CString portProt)
{
	CString cfgTxt = RES_STRING(cfgID);
	CString rtuTypeTxt = RES_STRING(IDS_RTU_TYPE_TXT);
	CString rtuNumTxt = RES_STRING(IDS_RTU_NO_TXT);
	CString portNumTxt = RES_STRING(IDS_PORT_NUM);
	CString rtuTypeStr = GetRTUType(rtuType);

	CString txt; 
	txt.Format(_T("%s <br>%s: %s <br>%s: %d <br>%s: %d <br>%s"), 
		(LPCTSTR)cfgTxt, (LPCTSTR)rtuTypeTxt, (LPCTSTR)rtuTypeStr, (LPCTSTR)rtuNumTxt, rtuNo + 1, (LPCTSTR)portNumTxt, portNum + 1,  (LPCTSTR)portProt);

	CString tempStr;
	tempStr.Format(_T("<HTML> \r\n<TITLE> %s </TITLE> \r\n<BODY> <CENTER>"), (LPCTSTR)cfgTxt);
	m_strArr.Add(tempStr);
	tempStr.Format(_T("\r\n<H3><br>%s"), (LPCTSTR)txt);
	m_strArr.Add(tempStr);
	tempStr.Format(_T("\r\n<TABLE border=1 frame=box borderColor=black> \r\n"));
	m_strArr.Add(tempStr);

	return 1;
}

int CHtmlFile::EndTags()
{
	CString tempStr;
	tempStr.Format(_T("\r\n</TABLE> \r\n</BODY> \r\n</HTML>"));
	m_strArr.Add(tempStr);

	// Save data to file
	CTextFile htmlFile(_T(""), _T("\r\n"));
	htmlFile.WriteTextFile(m_strFileName, m_strArr);

	return 1;
}

int CHtmlFile::AddRow(int hCnt, CString hTxt, int dCnt, CString dTxt)
{
	CString tempStr;
	tempStr.Format(_T("\r\n <TR %s>"), (LPCTSTR)bgcolor);
	m_strArr.Add(tempStr);

	if((hCnt & TB_RC_SPAN_MASK) > 1) {
		if((hCnt & COL_SPAN) && (hCnt & ROW_SPAN)) {
			tempStr.Format(_T("<TH colspan=%d rowspan=%d align=%s> %s </TH>"),
				(hCnt >> 7) & TB_COL_MASK, hCnt & TB_ROW_MASK, (LPCTSTR)m_thAlign, (LPCTSTR)hTxt);
		}
		else if(hCnt & COL_SPAN)
			tempStr.Format(_T("<TH colspan=%d align=%s> %s </TH>"), hCnt & TB_COL_MASK, (LPCTSTR)m_thAlign, (LPCTSTR)hTxt);
		else if(hCnt & ROW_SPAN)
			tempStr.Format(_T("<TH rowspan=%d align=%s> %s </TH>"), hCnt & TB_ROW_MASK, (LPCTSTR)m_thAlign, (LPCTSTR)hTxt);
	}
	else
		tempStr.Format(_T("<TH align=%s> %s </TH>"), (LPCTSTR)m_thAlign, (LPCTSTR)hTxt);
	m_strArr.Add(tempStr);

	if((dCnt & TB_RC_SPAN_MASK) > 1) {
		if((dCnt & COL_SPAN) && (dCnt & ROW_SPAN)) {
			tempStr.Format(_T("<TD colspan=%d rowspan=%d align=%s> %s </TD>"),
				(dCnt >> 7) & TB_COL_MASK, dCnt & TB_ROW_MASK, (LPCTSTR)m_tdAlign, (LPCTSTR)dTxt);
		}
		else if(dCnt & COL_SPAN)
			tempStr.Format(_T("<TD colspan=%d align=%s> %s </TD>"), dCnt & TB_COL_MASK, (LPCTSTR)m_tdAlign, (LPCTSTR)dTxt);
		else if(dCnt & ROW_SPAN)
			tempStr.Format(_T("<TD rowspan=%d align=%s> %s </TD>"), dCnt & TB_ROW_MASK, (LPCTSTR)m_tdAlign, (LPCTSTR)dTxt);
	}
	else
		tempStr.Format(_T("<TD align=%s> %s </TD>"), (LPCTSTR)m_tdAlign, (LPCTSTR)dTxt);
	m_strArr.Add(tempStr);

	tempStr.Format(_T("</TR>"));
	m_strArr.Add(tempStr);
	
	return 1;
}

int CHtmlFile::AddRow(int hCnt, CString hTxt, int dCnt, int dData)
{
   	TCHAR dTxt[50];
	wsprintf(dTxt, _T("%d"), dData);

	return AddRow(hCnt, hTxt, dCnt, dTxt);
}

int CHtmlFile::AddRow(CString hTxt, CString dTxt)
{
	CString tempStr;
	tempStr.Format(_T("\r\n <TR %s> <TH align=%s> %s </TH> <TD align=%s> %s </TD> </TR>"), 
		(LPCTSTR)bgcolor, (LPCTSTR)m_thAlign, (LPCTSTR)hTxt, (LPCTSTR)m_tdAlign, (LPCTSTR)dTxt);
	
	m_strArr.Add(tempStr);

	return 1;
}

int CHtmlFile::AddRow(CString hTxt, int td)
{
	CString dTxt;
	dTxt.Format(_T("%d"), td);
	
	return AddRow(hTxt, dTxt);
}

int CHtmlFile::AddRow(int hCnt, int dCnt, ...)
{
	va_list marker;
	LPTSTR txt;
	int span;
	
	va_start(marker, dCnt);

	CString tempStr, pTxt;
	tempStr.Format(_T("\r\n <TR %s>"), (LPCTSTR)bgcolor);
	m_strArr.Add(tempStr);

	for(int i=0; i<hCnt; i++) {
		span = va_arg(marker, int);
		txt = va_arg(marker, LPTSTR);
		pTxt.Format(_T("%s"), txt);
		if((span & TB_RC_SPAN_MASK) > 1) {
			if((span & COL_SPAN) && (span & ROW_SPAN)) {
				tempStr.Format(_T("<TH colspan=%d rowspan=%d align=%s> %s </TH>"), 
					(span >> 7) & TB_COL_MASK, span & TB_ROW_MASK, (LPCTSTR)m_thAlign, (LPCTSTR)pTxt);
			}
			else if(span & COL_SPAN)
				tempStr.Format(_T("<TH colspan=%d align=%s> %s </TH>"), span & TB_COL_MASK, (LPCTSTR)m_thAlign, (LPCTSTR)pTxt);
			else if(span & ROW_SPAN)
				tempStr.Format(_T("<TH rowspan=%d align=%s> %s </TH>"), span & TB_ROW_MASK, (LPCTSTR)m_thAlign, (LPCTSTR)pTxt);
		}
		else
			tempStr.Format(_T("<TH align=%s> %s </TH>"), (LPCTSTR)m_thAlign, (LPCTSTR)pTxt);
	
		m_strArr.Add(tempStr);
	}

	for(int i=0; i<dCnt; i++) {
		span = va_arg(marker, int);
		txt = va_arg(marker, LPTSTR);
		pTxt.Format(_T("%s"), txt);
		if((span & TB_RC_SPAN_MASK) > 1) {
			if((span & COL_SPAN) && (span & ROW_SPAN)) {
				tempStr.Format(_T("<TD colspan=%d rowspan=%d align=%s> %s </TD>"), 
					(span >> 7) & TB_COL_MASK, span & TB_ROW_MASK, (LPCTSTR)m_tdAlign, (LPCTSTR)pTxt);
			}
			else if(span & COL_SPAN)
				tempStr.Format(_T("<TD colspan=%d align=%s> %s </TD>"), 
					span & TB_COL_MASK, (LPCTSTR)m_tdAlign, (LPCTSTR)pTxt);
			else if(span & ROW_SPAN)
				tempStr.Format(_T("<TD rowspan=%d align=%s> %s </TD>"), 
					span & TB_ROW_MASK, (LPCTSTR)m_tdAlign, (LPCTSTR)pTxt);
		}
		else
			tempStr.Format(_T("<TD align=%s> %s </TD>"), (LPCTSTR)m_tdAlign, (LPCTSTR)pTxt);
		
		m_strArr.Add(tempStr);
	}

	tempStr.Format(_T("</TR>"));
	m_strArr.Add(tempStr);
	va_end(marker);

	return 1;
}


int CHtmlFile::AddRowResID2(UINT hID, UINT dID)
{
	return AddRow(RES_STRING(hID), RES_STRING(dID));
}

int CHtmlFile::AddRowResID1(UINT hID, int td)
{
	CString dTxt; dTxt.Format(_T("%d"), td);
	return AddRow(RES_STRING(hID), dTxt);
}

int CHtmlFile::AddRowResID1(UINT hID, CString dTxt)
{
	return AddRow(RES_STRING(hID), dTxt);
}

int CHtmlFile::AddRowResID(int th, UINT hID, int td, UINT dID)
{
	return AddRow(th, RES_STRING(hID), td, dID);
}

int CHtmlFile::AddRowResID(int th, UINT hID, int td, CString dTxt)
{
	return AddRow(th, RES_STRING(hID), td, dTxt);
}

#define HTML_TH_ASPAN_FMT _T("<TH colspan=%d rowspan=%d align=%s> %s </TH>")
#define HTML_TD_ASPAN_FMT _T("<TD colspan=%d rowspan=%d align=%s> %s </TD>")
#define HTML_TH_CSPAN_FMT _T("<TH colspan=%d align=%s> %s </TH>")
#define HTML_TD_CSPAN_FMT _T("<TD colspan=%d align=%s> %s </TD>")
#define HTML_TH_RSPAN_FMT _T("<TH rowspan=%d align=%s> %s </TH>")
#define HTML_TD_RSPAN_FMT _T("<TD rowspan=%d align=%s> %s </TD>")
#define HTML_TH_NSPAN_FMT _T("<TH align=%s> %s </TH>")
#define HTML_TD_NSPAN_FMT _T("<TD align=%s> %s </TD>")


int CHtmlFile::AddRow(HINSTANCE, int hCnt, int dCnt, ...)
{
	va_list marker;
	UINT id;
	int span;
	CString tempStr;
	//TCHAR txt[MAX_BUFF];
	CString txt;
	
	va_start(marker, dCnt);

	tempStr.Format(_T("\r\n <TR %s>"), (LPCTSTR)bgcolor);
	m_strArr.Add(tempStr);

	for(int i=0; i<hCnt; i++) {
		span = va_arg(marker, int);
		id = va_arg(marker, UINT);
		txt = RES_STRING(id);
		if((span & TB_RC_SPAN_MASK) > 1) {
			if((span & COL_SPAN) && (span & ROW_SPAN)) {
				tempStr.Format(HTML_TH_ASPAN_FMT, 
					(span >> 7) & TB_COL_MASK, span & TB_ROW_MASK, (LPCTSTR)m_thAlign, (LPCTSTR)txt);
			}
			else if(span & COL_SPAN)
				tempStr.Format(HTML_TH_CSPAN_FMT, span & TB_COL_MASK, (LPCTSTR)m_thAlign, (LPCTSTR)txt);
			else if(span & ROW_SPAN)
				tempStr.Format(HTML_TH_RSPAN_FMT, span & TB_ROW_MASK, (LPCTSTR)m_thAlign, (LPCTSTR)txt);
		}
		else
			tempStr.Format(HTML_TH_NSPAN_FMT, (LPCTSTR)m_thAlign, (LPCTSTR)txt);
	
		m_strArr.Add(tempStr);
	}

	for(int i=0; i<dCnt; i++) {
		span = va_arg(marker, int);
		id = va_arg(marker, UINT);
		txt = RES_STRING(id);
		if((span & TB_RC_SPAN_MASK) > 1) {
			if((span & COL_SPAN) && (span & ROW_SPAN)) {
				tempStr.Format(HTML_TD_ASPAN_FMT, (span >> 7) & TB_COL_MASK, span & TB_ROW_MASK, (LPCTSTR)m_tdAlign, (LPCTSTR)txt);
			}
			else if(span & COL_SPAN)
				tempStr.Format(HTML_TD_CSPAN_FMT, span & TB_COL_MASK, (LPCTSTR)m_tdAlign, (LPCTSTR)txt);
			else if(span & ROW_SPAN)
				tempStr.Format(HTML_TD_RSPAN_FMT, span & TB_ROW_MASK, (LPCTSTR)m_tdAlign, (LPCTSTR)txt);
		}
		else
			tempStr.Format(HTML_TD_NSPAN_FMT, (LPCTSTR)m_tdAlign, (LPCTSTR)txt);
		
		m_strArr.Add(tempStr);
	}

	tempStr.Format(_T("</TR>"));
	m_strArr.Add(tempStr);
	va_end(marker);

	return 1;
}


int CHtmlFile::AddTH(int hCnt, ...)
{
	va_list marker;
	LPTSTR pTxt;
	int span;
	
	va_start(marker, hCnt);
	CString tempStr;
	tempStr.Format(_T("\r\n <TR %s>"), (LPCTSTR)bgcolor);
	m_strArr.Add(tempStr);

	for(int i=0; i<hCnt; i++) {
		span = va_arg(marker, int);
		pTxt = va_arg(marker, LPTSTR);
		if((span & TB_RC_SPAN_MASK) > 1) {
			if((span & COL_SPAN) && (span & ROW_SPAN))
				tempStr.Format(_T("<TH colspan=%d rowspan=%d> %s </TH>"), (span >> 7) & TB_COL_MASK, span & TB_ROW_MASK, (LPCTSTR)pTxt);
			else if(span & COL_SPAN)
				tempStr.Format(_T("<TH colspan=%d> %s </TH>"), span & TB_COL_MASK, (LPCTSTR)pTxt);
			else if(span & ROW_SPAN)
				tempStr.Format(_T("<TH rowspan=%d> %s </TH>"), span & TB_ROW_MASK, (LPCTSTR)pTxt);
		}
		else
			tempStr.Format(_T("<TH> %s </TH>"), (LPCTSTR)pTxt);

		m_strArr.Add(tempStr);
	}
	
	va_end(marker);

	tempStr.Format(_T("</TR>"));
	m_strArr.Add(tempStr);

	return 1;
}

int CHtmlFile::AddTD(int dCnt, ...)
{
	va_list marker;
	LPTSTR pTxt;
	int span;
	
	va_start(marker, dCnt);

	CString tempStr;
	tempStr.Format(_T("\r\n <TR %s>"), (LPCTSTR)bgcolor);
	m_strArr.Add(tempStr);

	for(int i=0; i<dCnt; i++) {
		span = va_arg(marker, int);
		pTxt = va_arg(marker, LPTSTR);
		if((span & TB_RC_SPAN_MASK) > 1) {
			if((span & COL_SPAN) && (span & ROW_SPAN))
				tempStr.Format(_T("<TD colspan=%d rowspan=%d align=%s> %s </TD>"), (span >> 7) & TB_COL_MASK, span & TB_ROW_MASK, (LPCTSTR)m_tdAlign, (LPCTSTR)pTxt);
			else if(span & COL_SPAN)
				tempStr.Format(_T("<TD colspan=%d align=%s> %s </TD>"), span & TB_COL_MASK, (LPCTSTR)m_tdAlign, (LPCTSTR)pTxt);
			else if(span & ROW_SPAN)
				tempStr.Format(_T("<TD rowspan=%d align=%s> %s </TD>"), span & TB_ROW_MASK, (LPCTSTR)m_tdAlign, (LPCTSTR)pTxt);
		}
		else
			tempStr.Format(_T("<TD  align=%s> %s </TD>"), (LPCTSTR)m_tdAlign, (LPCTSTR)pTxt);

		m_strArr.Add(tempStr);
	}

	tempStr.Format(_T("</TR>"));
	m_strArr.Add(tempStr);

	va_end(marker);
	
	return 1;
}

int CHtmlFile::AddTD(CString txt, int rspan)
{
	CString str;
	if(rspan > 1)
		str.Format(_T("<TD rowspan=%d align=%s> %s </TD>"), rspan, (LPCTSTR)m_tdAlign, (LPCTSTR)txt);
	else
		str.Format(_T("<TD align=%s> %s </TD>"), (LPCTSTR)m_tdAlign, (LPCTSTR)txt);
	
	m_strArr.Add(str);

	return 1;
}

int CHtmlFile::AddTDColor(CString txt, int rspan)
{
	CString str;
	if(rspan > 1)
		str.Format(_T("<TD rowspan=%d bgcolor=#ffff00 align=%s> %s </TD>"), rspan, (LPCTSTR)m_tdAlign, (LPCTSTR)txt);
	else
		str.Format(_T("<TD bgcolor=#ffff00 align=%s> %s </TD>"), (LPCTSTR)m_tdAlign, (LPCTSTR)txt);
	
	m_strArr.Add(str);
	return 1;
}

int CHtmlFile::WriteStr(CString& str) 
{
	return m_strArr.Add(str);
}
//
///*==========================================================================*/
///*						CTextFile class										*/
///*==========================================================================*/
//
//////////////////////////////////////////
//// CTextFile construction/destruction
//CTextFile::CTextFile( const CString& ext, const CString& eol )
//{
//	m_extension = ext;
//	m_eol = eol;
//
//}
//
//CTextFile::~CTextFile()
//{
//}
//
//////////////////////////////////////////
//// CTextFile operations
////
//BOOL CTextFile::ReadTextFile( LPCTSTR filename, CStringArray& contents, TCHAR delimit)
//{
//
//	ClearError();
//	BOOL result = TRUE;
//
//	CString strFileName = filename;
//	if( strFileName.IsEmpty() )
//		result = GetFilename( FALSE, strFileName );
//
//	if( result ) {
//		CStdioFile file;
//		CFileException feError;
//
//		if( file.Open( filename, CFile::modeRead, &feError ) ) {
//
//			contents.RemoveAll();
//
//			CString line;
//			while( file.ReadString( line ) ) {
//				if(line.GetLength() > 0) {
//					if(line.GetAt(line.GetLength() - 1) == CR)
//						line.SetAt(line.GetLength() - 1, 0);
//
//					if(line.GetAt(0) != delimit)
//						contents.Add( line );
//				}
//				
//				//if(line.GetAt(0) != delimit)
//				//	contents.Add( line );
//			}
//
//			file.Close();
//
//		}
//		else {
//
//			TCHAR	errBuff[256];
//			feError.GetErrorMessage( errBuff, 256 );
//			m_error = errBuff;
//			result = FALSE;
//
//		}
//	}
//
//	return result;
//}
//
//BOOL CTextFile::ReadTextFile( CString& filename, CString& contents )
//{
//
//	contents = _T( "" );
//
//	ClearError();
//
//	CStdioFile file;
//	CFileException feError;
//	BOOL result = TRUE;
//
//	if( filename.IsEmpty() )
//		result = GetFilename( FALSE, filename );
//
//	if( result ) {
//
//		// Reading the file
//		if( file.Open( filename, CFile::modeRead, &feError ) ) {
//			CString line;
//			while( file.ReadString( line ) )
//				contents += line + m_eol;
//
//			file.Close();
//		}
//		else {
//			// Setting error message
//			TCHAR	errBuff[256];
//			feError.GetErrorMessage( errBuff, 256 );
//			m_error = errBuff;
//			result = FALSE;
//		}
//	}
//
//	return result;
//}
//
//BOOL CTextFile::WriteTextFile( CString& filename, const CStringArray& contents )
//{
//	ClearError();
//
//	CStdioFile file;
//	CFileException feError;
//	BOOL result = TRUE;
//	CString strTmp;
//
//	const int nCodePage = GetCurrentCodePage();	
//
//	if( filename.IsEmpty() )
//		result = GetFilename( TRUE, filename );
//
//	if( result ) {
//		// Write file
//		if( file.Open( filename, CFile::modeWrite | CFile::modeCreate, &feError ) )	{
//			int max = contents.GetSize();
//			LPSTR pszBuffer = NULL;
////			int nBufferSize = 0;
//
//			for( int t = 0 ; t < max ; t++ ) {				
//				//strTmp.Format(_T("%s\n"), contents[t]);
//				//file.WriteString( strTmp );
//				const int len = contents[t].GetLength();
//				pszBuffer = new char[len*2]; // max size for given text length								
//				const int bytes = WideCharToMultiByte(nCodePage, WC_COMPOSITECHECK|WC_SEPCHARS, (LPCTSTR)contents[t], len, pszBuffer, len*2, NULL, NULL);
//
//				if (bytes > 0) {
//					pszBuffer[bytes] = '\0';
//					file.Write(pszBuffer, bytes);
//					}
//
//				delete []pszBuffer;
//			}
//
//			file.Close();
//		}
//		else {
//			// Set error message
//			TCHAR	errBuff[256];
//			feError.GetErrorMessage( errBuff, 256 );
//			m_error = errBuff;
//			result = FALSE;
//		}
//	}
//
//	return result;
//}
//
//BOOL CTextFile::WriteTextFile( CString& filename, const CStringArray contents[], int count )
//{
//
//	ClearError();
//
//	CStdioFile file;
//	CFileException feError;
//	BOOL result = TRUE;
//	CString strTmp;
//
//	if( filename.IsEmpty() )
//		result = GetFilename( TRUE, filename );
//
//	if( result ) {
//		// Write file
//		if( file.Open( filename, CFile::modeWrite | CFile::modeCreate, &feError ) )	{
//			for( int i=0; i<count; i++) {
//				int max = contents[i].GetSize();
//				for( int t = 0 ; t < max ; t++ ) {
//					strTmp.Format(_T("%s\r\n"), contents[i][t]);
//					file.WriteString( strTmp );
//				}
//			}
//
//			file.Close();
//		}
//		else {
//			// Set error message
//			TCHAR	errBuff[256];
//			feError.GetErrorMessage( errBuff, 256 );
//			m_error = errBuff;
//			result = FALSE;
//		}
//	}
//
//	return result;
//}
//
//
//BOOL CTextFile::WriteTextFile( CString& filename, const CString& contents )
//{
//	ClearError();
//
//	CFile file;
//	CFileException feError;
//	BOOL result = TRUE;
//
//	if( filename.IsEmpty() )
//		result = GetFilename( TRUE, filename );
//
//	if( result ) {
//		// Write the file
//		if( file.Open( filename, CFile::modeWrite | CFile::modeCreate, &feError ) )	{
//			file.Write( contents, contents.GetLength() );
//			file.Close();
//		}
//		else {
//			// Set error message
//			TCHAR	errBuff[256];
//			feError.GetErrorMessage( errBuff, 256 );
//			m_error = errBuff;
//			result = FALSE;
//
//		}
//	}
//
//	return result;
//}
//
//BOOL CTextFile::AppendFile( CString& filename, const CString& contents )
//{
//
//	CFile file;
//	CFileException feError;
//	BOOL result = TRUE;
//
//	if( filename.IsEmpty() )
//		result = GetFilename( TRUE, filename );
//
//	if( result ) {
//		// Write the file
//		if( file.Open( filename, CFile::modeWrite | CFile::modeCreate | CFile::modeNoTruncate, &feError ) ) {
//			file.SeekToEnd();
//			file.Write( contents, contents.GetLength() );
//			file.Close();
//		}
//		else {
//			// Set error message
//			TCHAR	errBuff[256];
//			feError.GetErrorMessage( errBuff, 256 );
//			m_error = errBuff;
//			result = FALSE;
//
//		}
//	}
//
//	return result;
//}
//
//BOOL CTextFile::AppendFile( CString& filename, const CStringArray& contents )
//{
//
//	CStdioFile file;
//	CFileException feError;
//	BOOL result = TRUE;
//
//	if( filename.IsEmpty() )
//		result = GetFilename( TRUE, filename );
//
//	if( result ) {
//		// Write the file
//		if( file.Open( filename, CFile::modeWrite | CFile::modeCreate | CFile::modeNoTruncate, &feError ) ) {
//			file.SeekToEnd();
//
//			int max = contents.GetSize();
//			for( int t = 0 ; t < max ; t++ )
//				file.WriteString( contents[ t ] + m_eol );
//
//			file.Close();
//		}
//		else {
//			// Set error message
//			TCHAR	errBuff[256];
//			feError.GetErrorMessage( errBuff, 256 );
//			m_error = errBuff;
//			result = FALSE;
//		}
//	}
//
//	return result;
//}
//
//////////////////////////////////////////
//// Window operations
////
//
//BOOL CTextFile::Load( CString& filename, CEdit* edit )
//{
//	BOOL result = FALSE;
//
//	// Error checking
//	if( ValidParam( edit ) ) {
//		CString contents;
//		if( ReadTextFile( filename, contents ) ) {
//			edit->SetWindowText( contents );
//			result = TRUE;
//		}
//	}
//
//	return result;
//}
//
//BOOL CTextFile::Load( CString& filename, CListBox* list )
//{
//	BOOL result = FALSE;
//
//	// Error checking
//	if( ValidParam( list ) ) {
//
//		// Read the file
//		CStringArray contents;
//		if( ReadTextFile( filename, contents ) ) {
//			// Set to listbox
//			int max = contents.GetSize();
//			for( int t = 0 ; t < max ; t++ )
//				if( contents[ t ].GetLength() )
//					list->AddString( contents[ t ] );
//			result = TRUE;
//		}
//	}
//
//	return result;
//}
//
//BOOL CTextFile::Save( CString& filename, CEdit* edit )
//{
//	BOOL result = FALSE;
//
//	// Error checking
//	if( ValidParam( edit ) ) {
//		// Get text
//		CString contents;
//		edit->GetWindowText( contents );
//
//		// Write file
//		if( WriteTextFile( filename, contents ) )
//			result = TRUE;
//	}
//
//	return result;
//}
//
//BOOL CTextFile::Save( CString& filename, CListBox* list )
//{
//	BOOL result = FALSE;
//
//	if( ValidParam( list ) ) {
//		// Get listbox contents
//		CStringArray contents;
//		int max = list->GetCount();
//		for( int t = 0; t < max ; t++ )	{
//			CString line;
//			list->GetText( t, line );
//			contents.Add( line );
//		}
//
//		// Write file
//		if( WriteTextFile( filename, contents ) )
//			result = TRUE;
//	}
//
//	return result;
//}

////////////////////////////////////////
// Error handling
//

//CString CTextFile::GetErrorMessage()
//{
//	return m_error;
//}
//
//////////////////////////////////////////
//// Private functions
////
//
//void CTextFile::ClearError()
//{
//	m_error = _T( "" );
//}
//
//BOOL CTextFile::ValidParam( CWnd* wnd )
//{
//
//	ClearError();
//	BOOL result = TRUE;
//
//	if( wnd == NULL ) {
//		ASSERT( FALSE );
//		result = FALSE;
//	}
//
//	if( !IsWindow( wnd->m_hWnd ) ) {
//		ASSERT( FALSE );
//		result = FALSE;
//	}
//
//	if( !result )
//		m_error = _T("Bad Window handle as parameter");
//
//	return result;
//}
//
//BOOL CTextFile::GetFilename( BOOL save, CString& filename )
//{
//	CString filter;
//	CString extension = GetExtension();
//	if( extension.GetLength() )
//		filter = extension + _T( "-files (*.") + extension + _T(")|*." ) + extension + _T( "|All Files (*.*)|*.*||" );
//
//	BOOL result = FALSE;
//	CFileDialog dlg( !save, extension, NULL, OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT, filter );
//
//	if( dlg.DoModal() == IDOK )	{
//		filename = dlg.GetPathName();
//		result = TRUE;
//	}
//
//	return result;
//}
//
//CString CTextFile::GetExtension()
//{
//	return m_extension;
//}

/////////////////////////////////////////////////////////////////////////////
// CGradientStatic
BEGIN_MESSAGE_MAP(CGradientStatic, CStatic)
	//{{AFX_MSG_MAP(CGradientStatic)
	ON_WM_PAINT()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CGradientStatic message handlers


CGradientStatic::CGradientStatic()
{
	m_bVertical = FALSE;
	m_iLeftSpacing = 10;
	SetColor(GetSysColor(COLOR_ACTIVECAPTION));
	SetGradientColor(GetSysColor(COLOR_BTNFACE));
	clText = GetSysColor(COLOR_CAPTIONTEXT);
	m_iAlign = DT_LEFT;
	m_bCanDoGradientFill = FALSE;
	grdRect.UpperLeft=0;
	grdRect.LowerRight=1;
	
	hinst_msimg32 = LoadLibrary( _T("msimg32.dll") );
	if(hinst_msimg32) {
		m_bCanDoGradientFill = TRUE;		
		GradientFill = ((LPFNDLLFUNC1) GetProcAddress( hinst_msimg32, "GradientFill" ));
	}
}

CGradientStatic::~CGradientStatic()
{
	FreeLibrary( hinst_msimg32 );
}

void CGradientStatic::PreSubclassWindow() 
{
	CRect rect;
	GetClientRect(&rect);
	rcVertex[0].x=rect.left;
	rcVertex[0].y=rect.top;
	rcVertex[0].Alpha=0x0000;
	rcVertex[1].x=rect.right; 
	rcVertex[1].y=rect.bottom;
	rcVertex[1].Alpha=0;

	CStatic::PreSubclassWindow();
}

void CGradientStatic::DrawGradRect(CDC *pDC, CRect r, COLORREF cLeft, COLORREF cRight, BOOL a_bVertical)
{
	CRect stepR;				// rectangle for color's band
	COLORREF color;				// color for the bands
	float fStep;
	
	if(a_bVertical)
		fStep = ((float)r.Height())/255.0f;	
	else
		fStep = ((float)r.Width())/255.0f;	// width of color's band
	
	for (int iOnBand = 0; iOnBand < 255; iOnBand++) {
		if(a_bVertical)	{
			SetRect(&stepR,	r.left, r.top+(int)(iOnBand * fStep),
				r.right, r.top+(int)((iOnBand+1)* fStep));	
		}
		else {
			SetRect(&stepR,	r.left+(int)(iOnBand * fStep), 
				r.top, r.left+(int)((iOnBand+1)* fStep), r.bottom);	
		}

		color = RGB((GetRValue(cRight)-GetRValue(cLeft))*((float)iOnBand)/255.0f+GetRValue(cLeft),
			(GetGValue(cRight)-GetGValue(cLeft))*((float)iOnBand)/255.0f+GetGValue(cLeft),
			(GetBValue(cRight)-GetBValue(cLeft))*((float)iOnBand)/255.0f+GetBValue(cLeft));
		
		pDC->FillSolidRect(stepR,color);
	}
}

void CGradientStatic::OnPaint() 
{
	CPaintDC dc(this); // device context for painting

	CRect rect;
	GetClientRect(&rect);
	
	if(m_bCanDoGradientFill) {	//msimg32.dll library is loaded
		GradientFill( dc,rcVertex,2, &grdRect,1, m_bVertical ? GRADIENT_FILL_RECT_V : GRADIENT_FILL_RECT_H);
		
	}
	else {
		DrawGradRect(&dc,rect,clLeft,clRight,m_bVertical);
	}
	
	::SetTextColor(dc,clText);

	HFONT hfontOld=0;
	CFont* pFont = GetFont();
	CString sTEXT;
	GetWindowText(sTEXT);
	
	if(pFont)
		hfontOld = (HFONT)SelectObject(dc.m_hDC, (HFONT)pFont->m_hObject);

	::SetBkMode(dc, TRANSPARENT);
	GetClientRect(&rect);

	if(m_iAlign == DT_CENTER)
		::DrawText(dc, sTEXT, -1, &rect, DT_SINGLELINE|DT_VCENTER|DT_CENTER);
	else if(m_iAlign == DT_LEFT) {
		rect.left+=m_iLeftSpacing;
		::DrawText(dc, sTEXT, -1, &rect, DT_SINGLELINE|DT_VCENTER|DT_LEFT);
	}
	else {	//right 
		rect.right-=m_iLeftSpacing;
		::DrawText(dc, sTEXT, -1, &rect, DT_SINGLELINE|DT_VCENTER|DT_RIGHT);
	}

	if(pFont)
		::SelectObject(dc.m_hDC, hfontOld);
}

void CGradientStatic::SetColor(long cl) 
{
	clLeft=cl;
	rcVertex[0].Red=(USHORT)(GetRValue(clLeft)<<8);	// color values from 0x0000 to 0xff00 !!!!
	rcVertex[0].Green=(USHORT)(GetGValue(clLeft)<<8);
	rcVertex[0].Blue=(USHORT)(GetBValue(clLeft)<<8);
}

void CGradientStatic::SetGradientColor(long cl) 
{
	clRight=cl;
	rcVertex[1].Red=(USHORT)(GetRValue(clRight)<<8);
	rcVertex[1].Green=(USHORT)(GetGValue(clRight)<<8);
	rcVertex[1].Blue=(USHORT)(GetBValue(clRight)<<8);
}

void CGradientStatic::SetReverseGradient()
{
	COLORREF cTemp = clLeft;
	clLeft = clRight;
	clRight = cTemp;

	// color values from 0x0000 to 0xff00 !!!!
	rcVertex[0].Red=(USHORT)(GetRValue(clLeft)<<8);	
	rcVertex[0].Green=(USHORT)(GetGValue(clLeft)<<8);
	rcVertex[0].Blue=(USHORT)(GetBValue(clLeft)<<8);
	rcVertex[1].Red=(USHORT)(GetRValue(clRight)<<8);
	rcVertex[1].Green=(USHORT)(GetGValue(clRight)<<8);
	rcVertex[1].Blue=(USHORT)(GetBValue(clRight)<<8);
}

void CGradientStatic::SetWindowText(LPCSTR a_lpstr)
{
	CStatic::SetWindowText((LPCTSTR)a_lpstr);
	Invalidate();
}

/////////////////////////////////////////////////////////////////////////////
// CToolTipListBox
CToolTipListBox::CToolTipListBox()
{
}

CToolTipListBox::~CToolTipListBox()
{
}


BEGIN_MESSAGE_MAP(CToolTipListBox, CListBox)
	//{{AFX_MSG_MAP(CToolTipListBox)
	ON_WM_MOUSEMOVE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CToolTipListBox message handlers

///////////////////////////////////////////////////////////////////////////////
void CToolTipListBox::OnMouseMove(UINT nFlags, CPoint point) 
{
	CRect rectClient;
	GetClientRect(&rectClient);

	if (rectClient.PtInRect(point))
	{
		CPoint pointScreen;
		::GetCursorPos(&pointScreen);
		BOOL bOutside = FALSE;
		int nItem = ItemFromPoint(point, bOutside);  // calculate listbox item number (if any)

		if (!bOutside && (nItem >= 0))
		{
			CString strText = _T("");
			GetText(nItem, strText);
			m_ToolInfo.lpszText = (LPTSTR)(LPCTSTR)strText;

			CRect rect;
			GetItemRect(nItem, &rect);
			ClientToScreen(&rect);

			HDC hDC = ::GetDC(m_hWnd);
			CFont *pFont = GetFont();
			HFONT hOldFont = (HFONT) ::SelectObject(hDC, (HFONT) *pFont);

			SIZE size;
			::GetTextExtentPoint32(hDC, strText, strText.GetLength(), &size);
			::SelectObject(hDC, hOldFont);
			::ReleaseDC(m_hWnd, hDC);

			if (size.cx > (rect.Width() - 3))
			{
				SetToolTipText(&strText);
			}
			else
			{
				m_ToolInfo.lpszText = NULL;
				m_toolTip.PostMessage(TTM_POP, 0, 0);
			}
		}
	}
	else
	{
		m_ToolInfo.lpszText = NULL;
		m_toolTip.PostMessage(TTM_POP, 0, 0);
	}
	
	CListBox::OnMouseMove(nFlags, point);
}

void CToolTipListBox::SetToolTipText(CString *spText, BOOL activate)
{
	if(spText == NULL)
		return;
	InitToolTip();
	if(m_toolTip.GetToolCount() == 0) {
		CRect btnRect;
		GetClientRect(btnRect);
		m_toolTip.AddTool(this, (LPCTSTR)*spText, btnRect, 1);
	}
	m_toolTip.UpdateTipText((LPCTSTR)*spText, this, 1);
	m_toolTip.Activate(activate);
}

void CToolTipListBox::InitToolTip()
{
	memset(&m_ToolInfo, 0, sizeof(m_ToolInfo));
	m_ToolInfo.cbSize = sizeof(m_ToolInfo);
	m_ToolInfo.uFlags = TTF_TRACK | TTF_TRANSPARENT;
	m_ToolInfo.hwnd = m_hWnd;

	if(m_toolTip.m_hWnd == NULL) {
		m_toolTip.Create(this);
		m_toolTip.Activate(TRUE);
	}
}

BOOL CToolTipListBox::PreTranslateMessage(MSG* pMsg) 
{
	// TODO: Add your specialized code here and/or call the base class
	InitToolTip();
	m_toolTip.RelayEvent(pMsg);
	return CListBox::PreTranslateMessage(pMsg);
}

/////////////////////////////////////////////////////////////////////////////
// CToolTipCheckListBox
CToolTipCheckListBox::CToolTipCheckListBox()
{
}

CToolTipCheckListBox::~CToolTipCheckListBox()
{
}


BEGIN_MESSAGE_MAP(CToolTipCheckListBox, CCheckListBox)
	//{{AFX_MSG_MAP(CToolTipCheckListBox)
	ON_WM_MOUSEMOVE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CToolTipCheckListBox message handlers

///////////////////////////////////////////////////////////////////////////////
void CToolTipCheckListBox::OnMouseMove(UINT nFlags, CPoint point) 
{
	CRect rectClient;
	GetClientRect(&rectClient);

	if (rectClient.PtInRect(point))
	{
		CPoint pointScreen;
		::GetCursorPos(&pointScreen);
		BOOL bOutside = FALSE;
		int nItem = ItemFromPoint(point, bOutside);  // calculate listbox item number (if any)

		if (!bOutside && (nItem >= 0))
		{
			CString strText = _T("");
			GetText(nItem, strText);
			m_ToolInfo.lpszText = (LPTSTR)(LPCTSTR)strText;

			CRect rect;
			GetItemRect(nItem, &rect);
			ClientToScreen(&rect);

			HDC hDC = ::GetDC(m_hWnd);
			CFont *pFont = GetFont();
			HFONT hOldFont = (HFONT) ::SelectObject(hDC, (HFONT) *pFont);

			SIZE size;
			::GetTextExtentPoint32(hDC, strText, strText.GetLength(), &size);
			::SelectObject(hDC, hOldFont);
			::ReleaseDC(m_hWnd, hDC);

			if (size.cx > (rect.Width() - 3))
			{
				SetToolTipText(&strText);
			}
			else
			{
				m_ToolInfo.lpszText = NULL;
				m_toolTip.PostMessage(TTM_POP, 0, 0);
			}
		}
	}
	else
	{
		m_ToolInfo.lpszText = NULL;
		m_toolTip.PostMessage(TTM_POP, 0, 0);
	}
	
	CCheckListBox::OnMouseMove(nFlags, point);
}

void CToolTipCheckListBox::SetToolTipText(CString *spText, BOOL activate)
{
	if(spText == NULL)
		return;
	InitToolTip();
	if(m_toolTip.GetToolCount() == 0) {
		CRect btnRect;
		GetClientRect(btnRect);
		m_toolTip.AddTool(this, (LPCTSTR)*spText, btnRect, 1);
	}
	m_toolTip.UpdateTipText((LPCTSTR)*spText, this, 1);
	m_toolTip.Activate(activate);
}

void CToolTipCheckListBox::InitToolTip()
{
	memset(&m_ToolInfo, 0, sizeof(m_ToolInfo));
	m_ToolInfo.cbSize = sizeof(m_ToolInfo);
	m_ToolInfo.uFlags = TTF_TRACK | TTF_TRANSPARENT;
	m_ToolInfo.hwnd = m_hWnd;

	if(m_toolTip.m_hWnd == NULL) {
		m_toolTip.Create(this);
		m_toolTip.Activate(TRUE);
	}
}

BOOL CToolTipCheckListBox::PreTranslateMessage(MSG* pMsg) 
{
	// TODO: Add your specialized code here and/or call the base class
	InitToolTip();
	m_toolTip.RelayEvent(pMsg);
	return CCheckListBox::PreTranslateMessage(pMsg);
}

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
CMultiSlider::CMultiSlider()
{
	m_bInit = FALSE;
	memset(m_thumb, 0, sizeof(m_thumb));
	m_fMin = 0;
	m_fMax = 100;
	m_nTickCount = 11;
	m_fRange = m_fMax - m_fMin;
	m_pDraggedMarker = NULL;
	m_strDispText = _T("");
	m_strWndText = _T("");
	m_nDispRange = -1;
	m_bDragBoth = FALSE;
}

CMultiSlider::~CMultiSlider()
{

}

BEGIN_MESSAGE_MAP(CMultiSlider, CSliderCtrl)
	//{{AFX_MSG_MAP(CMultiSlider)
	ON_WM_PAINT()
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONUP()
	ON_WM_MOUSEMOVE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

void CMultiSlider::SetMinMaxValue(float fMin, float fMax)
{
	m_thumb[0].m_pos = fMin;
	m_thumb[1].m_pos = fMax;
	Invalidate();
}

void CMultiSlider::SetMinMaxRange(float fMin, float fMax)
{
	m_fMin = fMin;
	m_fMax = fMax;
	m_fRange = m_fMax - m_fMin;
}

float CMultiSlider::GetMinValue()
{
	return RoundTo(m_fRange * m_thumb[0].m_pos / m_fRange, 2);
}

float CMultiSlider::GetMaxValue()
{
	return RoundTo(m_fRange * m_thumb[1].m_pos / m_fRange, 2);
}

void CMultiSlider::SetDisplayValueInfo(float nDispRange, CString strDispText)
{
	m_nDispRange = nDispRange;
	m_strDispText = strDispText;
}

void CMultiSlider::SetText(CString str)
{
	m_strWndText = str;
}

void CMultiSlider::SetText(UINT resourceID)
{
	m_strWndText = RES_STRING(resourceID);
}

void CMultiSlider::Initialize()
{
	GetClientRect(&m_clientRect);
	SendMessage(TBM_GETCHANNELRECT, 0, (LPARAM)(LPRECT)&m_channelRect);
	SendMessage(TBM_GETTHUMBRECT, 0, (LPARAM)(LPRECT)&m_thumbRect);
	InflateRect(&m_channelRect, -5, 0);

	// Centre the channel rectangle	
	int clHeight = m_clientRect.bottom - m_clientRect.top;
	int chHeight = m_channelRect.bottom - m_channelRect.top;
	int thHeight = m_thumbRect.bottom - m_thumbRect.top;

	chHeight = chHeight / 2;
	m_channelRect.top = (clHeight / 2) - (chHeight / 2);
	m_channelRect.bottom = m_channelRect.top + chHeight;

	m_thumbRect.top = (clHeight / 2) - (thHeight / 2);
	m_thumbRect.bottom = m_thumbRect.top + thHeight + 1;
	
	m_sliderRect = m_channelRect;
	InflateRect(&m_sliderRect, -2, 0);

	m_bInit = TRUE;
}

void CMultiSlider::OnPaint() 
{
	HWND hWnd = m_hWnd;
	PAINTSTRUCT ps;
	HBRUSH hOldBrush, hClBrush, hChBrush;
	HBITMAP hBitmap, hOldBitmap;
	BOOL fMemDC = FALSE;
	
	HDC hDC = ::BeginPaint(hWnd, &ps);
	if(!m_bInit) {
		Initialize();
	}

	HDC memDC = CreateCompatibleDC(hDC);
	hBitmap = CreateCompatibleBitmap(hDC, 
		m_clientRect.right - m_clientRect.left,
		m_clientRect.bottom - m_clientRect.top);
	
	LOGFONT lfFont;
	memset(&lfFont, 0, sizeof(LOGFONT));
	_tcscpy(lfFont.lfFaceName, _T("San Serif"));
	lfFont.lfHeight = 10;
	//lfFont.lfWeight = FW_BOLD;
	HFONT hFont = CreateFontIndirect(&lfFont);
	HFONT hOldFont = SelectFont(memDC, hFont);
	
	hOldBitmap = SelectBitmap(memDC, hBitmap);
	if(memDC && hBitmap)
		fMemDC = TRUE;
	
	// Create brushes for client area and channel area
	hClBrush = CreateSolidBrush(GetSysColor(COLOR_BTNFACE));
	hChBrush = CreateSolidBrush(GetSysColor(COLOR_WINDOW));	

	if(memDC == 0) return;
	hOldBrush = SelectBrush(memDC, hClBrush);		// Select client brush
	FillRect(memDC, &m_clientRect, hClBrush);
	DeleteBrush(hClBrush);	
	SelectBrush(memDC, hChBrush);					// Select channel brush
	FillRect(memDC, &m_channelRect, hChBrush);
	DeleteBrush(hChBrush);

	SetThumbRect(&m_thumb[0]);
	SetThumbRect(&m_thumb[1]);
	
	// Draw Color intervals in memory context
	float sliderMin, sliderWidth;
	GetSliderValues(&sliderMin, &sliderWidth);		
	DrawSliders(memDC, sliderMin, sliderWidth);

	// Draw Ticks
	DrawTicks(memDC, sliderMin, sliderWidth);

	// Draw Text
	DrawStrings(memDC, hFont);
	
	// Draw left and right thumbs to memory device context
	DrawThumbs(memDC);
	
	// Copy memory context to output device
	if(fMemDC) {
		RECT clipRect;
		GetClipBox(hDC, &clipRect);
		int width = clipRect.right - clipRect.left;
		int height = clipRect.bottom - clipRect.top;
		BitBlt(hDC, clipRect.left, clipRect.top, width, height, 
			memDC, clipRect.left, clipRect.top, SRCCOPY);		
	}

	SelectBrush(memDC, hOldBrush);
	SelectFont(memDC, hOldFont);
	SelectBitmap(memDC, hOldBitmap);
	
	if(hBitmap != 0)
		DeleteBitmap(hBitmap);
	DeleteFont(hFont);
	DeleteDC(memDC);
	::EndPaint(hWnd, &ps);
}

void CMultiSlider::DrawSliders(HDC cdc, float sliderMin, float sliderWidth)
{
	HBRUSH hClBrush = CreateSolidBrush(GetSysColor(COLOR_BTNFACE));
	HBRUSH hRedBrush = CreateSolidBrush(RGB(255,0,0));
	HBRUSH hGreenBrush = CreateSolidBrush(RGB(0,192,0));

	RECT intervalRect = m_channelRect;
	InflateRect(&intervalRect, -1, -1);
	intervalRect.left = (int)sliderMin;

	for(int i=0; i<2; i++) {
		SliderMarker* pMarker = &m_thumb[i];
		intervalRect.right = (int)(pMarker->m_leftRect.left + 6.0f);
		if(IsWindowEnabled())
			FillRect(cdc, &intervalRect, i==0? hRedBrush : hGreenBrush);
		else
			FillRect(cdc, &intervalRect, hClBrush);
		intervalRect.left = pMarker->m_leftRect.right;
	}
	intervalRect.right = (long)(sliderMin + sliderWidth);
	if(IsWindowEnabled())
		FillRect(cdc, &intervalRect, hRedBrush);
	else
		FillRect(cdc, &intervalRect, hClBrush);

	DeleteBrush(hClBrush);
	DeleteBrush(hRedBrush);
	DeleteBrush(hGreenBrush);
}

void CMultiSlider::DrawTicks(HDC cdc, float sliderMin, float sliderWidth)
{
	TCHAR str[10];
	int x, y, cnt;
	float sliderStep = sliderWidth / (m_nTickCount - 1);

	y = m_thumbRect.bottom + (int)(m_channelRect.bottom - m_channelRect.top);

	SetTextAlign(cdc, TA_CENTER );
	SetBkMode(cdc, TRANSPARENT);

	for(int i=0; i<m_nTickCount; i++) {
		x = (int)(sliderMin + i*sliderStep);
		MoveToEx(cdc, x, m_thumbRect.bottom, NULL);
		LineTo(cdc, x, y);
		float temp = ((float)m_nDispRange / (m_nTickCount-1)) * i;
		int q = (int)RoundTo(temp, 2);
		float r = RoundTo((temp - q)*100, 0);	// 2 decimal places

		cnt = wsprintf(str, _T("%d.%02d"), q, (int)r);
		TextOut(cdc, x, y, str, cnt);

	}
}

void CMultiSlider::DrawStrings(HDC cdc, HFONT)
{
	RECT rcText;
	CopyRect(&rcText, &m_clientRect);
	InflateRect(&rcText, -1, -1);

	// Create new font for displaying text
	LOGFONT lfFont;
	memset(&lfFont, 0, sizeof(LOGFONT));
	_tcscpy(lfFont.lfFaceName, _T("Arial"));
	lfFont.lfHeight = 16;
	HFONT hFont = CreateFontIndirect(&lfFont);
	SelectFont(cdc, hFont);	
	
	// Display low value
	SetTextAlign(cdc, TA_LEFT);
	CString str = GetDisplayString(m_thumb[0].m_pos);
	DrawText(cdc, str, str.GetLength(), &rcText, DT_LEFT);

	// Display high value
	str = GetDisplayString(m_thumb[1].m_pos);
	DrawText(cdc, str, str.GetLength(), &rcText, DT_RIGHT);
	DeleteFont(hFont);
	// Draw window text
	lfFont.lfHeight = 21;
	hFont = CreateFontIndirect(&lfFont);
	SelectFont(cdc, hFont);	
	DrawText(cdc, m_strWndText, m_strWndText.GetLength(), &rcText, DT_CENTER);
	DeleteFont(hFont);
}

void CMultiSlider::DrawThumbs(HDC cdc)
{
	for(int i=0; i<2; i++) {
		DrawEdge(cdc, &m_thumb[i].m_mainRect, EDGE_RAISED, BF_MIDDLE | BF_LEFT | BF_TOP | BF_RIGHT);
		DrawEdge(cdc, &m_thumb[i].m_leftRect, EDGE_RAISED, BF_DIAGONAL_ENDTOPLEFT | BF_MIDDLE);
		DrawEdge(cdc, &m_thumb[i].m_rightRect, EDGE_RAISED, BF_DIAGONAL_ENDBOTTOMLEFT | BF_MIDDLE);		
	}
}

CString CMultiSlider::GetDisplayString(float fValue)
{
	CString str; str.Empty();
	int nRange = (int)(m_fMax - m_fMin);
	
	str.Format(_T("%6.2f %s"), (float)((int)fValue * m_nDispRange) / nRange, (LPCTSTR)m_strDispText);
	return str;
}

void CMultiSlider::UpdateSlider(SliderMarker* pMarker, UINT nFlags, CPoint point)
{
	if(pMarker == NULL)
		return;

	float sliderMin, sliderWidth;
	GetSliderValues(&sliderMin, &sliderWidth);
	float m = ((float)(point.x - sliderMin) / (float)sliderWidth * (float)m_fRange) + 
		(float)m_fMin;
	if(nFlags & MK_SHIFT) {
		pMarker->m_pos = m;
	}
	else {
		int nStep = (m_nTickCount - 1);
		if(pMarker->m_pos < m) {
			if(pMarker->m_pos <= m_fMax - m_fMax/nStep)
				pMarker->m_pos += m_fMax / nStep;
			else
				pMarker->m_pos = m_fMax;
		}
		else {
			if(pMarker->m_pos >= m_fMax / nStep)
				pMarker->m_pos -= m_fMax / nStep;
			else
				pMarker->m_pos = m_fMin;
		}
	}
	
	SetThumbRect(pMarker);
	InvalidateRect(&m_clientRect, TRUE);
	UpdateWindow();
}

void CMultiSlider::OnLButtonDown(UINT nFlags, CPoint point) 
{
	SetCapture();
	// Check if Control Key is pressed
	m_bDragBoth = (nFlags & MK_CONTROL) ? TRUE : FALSE;

	POINT pt = {point.x, point.y};
	
	if(PtInRect(&m_sliderRect, pt) || PtInRect(&m_thumb[0].m_mainRect, pt) || 
		PtInRect(&m_thumb[1].m_mainRect, pt)) {
		float test = m_thumb[1].m_pos - m_thumb[0].m_pos;
		if(abs((int)test) <= 1) {
			float sliderMin, sliderWidth;
			GetSliderValues(&sliderMin, &sliderWidth);
			float m = ((float)(point.x - sliderMin) / (float)sliderWidth * (float)m_fRange) + (float)m_fMin;
			int x = (int)m_thumb[1].m_pos;
			int y = (int)m;
			if(x < y  || m < 0.0)
				m_pDraggedMarker = &m_thumb[1];
			else 
				m_pDraggedMarker = &m_thumb[0];
			UpdateSlider(m_pDraggedMarker, nFlags, point);
			return;
		}
		else
			m_pDraggedMarker = MarkerHitTest(pt);
		
		if(m_pDraggedMarker == NULL) {
			m_pDraggedMarker = GetMarker(pt);
			UpdateSlider(m_pDraggedMarker, nFlags, point);
		}
	}


	CSliderCtrl::OnLButtonDown(nFlags, point);
}

void CMultiSlider::OnLButtonUp(UINT nFlags, CPoint point) 
{
	ReleaseCapture();
	if(m_pDraggedMarker)
		m_pDraggedMarker = NULL;
	
	CSliderCtrl::OnLButtonUp(nFlags, point);
}

void CMultiSlider::OnMouseMove(UINT nFlags, CPoint point) 
{
	POINT pt = {point.x, point.y};

	if(!PtInRect(&m_clientRect, pt))
		return;

	float sliderMin, sliderWidth;
	GetSliderValues(&sliderMin, &sliderWidth);
	
	if(m_pDraggedMarker != NULL) {
		float x = ((float)(pt.x - sliderMin) / (float)sliderWidth * (float)m_fRange) + 
			(float)m_fMin;
		
		x = RoundTo(x, 1);
		AvoidCrossing(m_pDraggedMarker, &x);

		float dx = x - m_pDraggedMarker->m_pos;
		if(x >= m_fMin && x <= m_fMax) {
			SliderMarker* pToMove = m_pDraggedMarker;
			do {
				BOOL bOutOfRange = FALSE;
				SliderMarker newMarker;
				RECT oldRect = pToMove->m_mainRect;
				newMarker.m_pos = pToMove->m_pos + dx;
				SetThumbRect(&newMarker);
				
				if(m_bDragBoth) {
					SliderMarker* otherMarker;
					otherMarker = (m_pDraggedMarker == &m_thumb[0]) ? &m_thumb[1] : &m_thumb[0];
					otherMarker->m_pos += dx;
					if(otherMarker->m_pos <= m_fMin || otherMarker->m_pos >= m_fMax) {
						bOutOfRange = TRUE;
						otherMarker->m_pos -= dx;
					}
					else
						SetThumbRect(otherMarker);
				}

				RECT newRect = newMarker.m_mainRect;
				if(!bOutOfRange) {
					memcpy(pToMove, &newMarker, sizeof(SliderMarker));
					if(!EqualRect(&oldRect, &newRect)) {
						InvalidateRect(&m_clientRect, FALSE);
						UpdateWindow();
					}
				}
				
				if(pToMove != m_pDraggedMarker)
					pToMove = NULL;
				else {					
					for(int i=0; i<2; i++) {
						if((pToMove=&m_thumb[i]) != m_pDraggedMarker) {
							pToMove = NULL;
							break;
						}
					}
					
				}
			}
			while(pToMove);
		}
	}
	
	CSliderCtrl::OnMouseMove(nFlags, point);
}


void CMultiSlider::SetThumbRect(SliderMarker* marker)
{
	float sliderMin, sliderWidth;
	RECT topRC, leftRC, rightRC;

	GetSliderValues(&sliderMin, &sliderWidth);
	float x = (((marker->m_pos - m_fMin) / m_fRange) * sliderWidth) + sliderMin;
	x = RoundTo(x, 0);
	rightRC = leftRC = topRC = m_thumbRect;
	topRC.left = (int)(x - 6.0f);
	topRC.right = (int)(x + 6.0f);

	// point down
	topRC.bottom = m_channelRect.bottom;
	rightRC.top = leftRC.top = m_channelRect.bottom;
	rightRC.left = leftRC.right = (int)x;
	leftRC.left = topRC.left;
	rightRC.right = topRC.right;

	topRC.bottom += 2;
	marker->m_leftRect = leftRC;
	marker->m_mainRect = topRC;
	marker->m_rightRect = rightRC;
}

void CMultiSlider::GetSliderValues(float* min, float* width)
{
	float max = (float)m_sliderRect.right;
	*min = (float)m_sliderRect.left;
	*width = (float)(max - *min);
}

void CMultiSlider::AvoidCrossing(SliderMarker* pMarker, float* position)
{
	float otherPos;

	if(pMarker != &m_thumb[0]) {		
		if((otherPos = m_thumb[0].m_pos) >= *position) {
			*position = otherPos;
			return;
		}
	}

	if(pMarker != &m_thumb[1]) {
		if((otherPos = m_thumb[1].m_pos) <= *position) {
			*position = otherPos;
			return;
		}
	}
}

SliderMarker* CMultiSlider::MarkerHitTest(POINT pt)
{
	for(int i=0; i<2; i++) {
		if (PtInRect(&m_thumb[i].m_mainRect, pt) || 
			PtInRect(&m_thumb[i].m_leftRect, pt) || 
			PtInRect(&m_thumb[i].m_rightRect, pt) )
			return &m_thumb[i];
	}

	return NULL;
}

SliderMarker* CMultiSlider::GetMarker(POINT pt)
{	
	float min, width;
	GetSliderValues(&min, &width);
	float x = ((float)(pt.x - min) / (float)width * (float)m_fRange) + 
			(float)m_fMin;
	
	int lm = abs((int)(x - m_thumb[0].m_pos));
	int rm = abs((int)(x - m_thumb[1].m_pos));

	if(lm < rm)
		return &m_thumb[0];
	else if(lm > rm)
		return &m_thumb[1];
	else
		return NULL;
}

float CMultiSlider::RoundTo(float value, short decimal)
{
	value *= (float)pow(10.0, decimal);
	value += .5f;
	value = (float)floor(value);
	value /= (float)pow(10.0, decimal);
	return value;
}

/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////
// CInputBoxDlg dialog
void CInputBoxDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CInputBoxDlg)
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CInputBoxDlg, CDialog)
	//{{AFX_MSG_MAP(CInputBoxDlg)
	ON_BN_CLICKED(IDCANCEL, OnCancel)
	ON_BN_CLICKED(IDOK, OnOK)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CInputBoxDlg message handlers
/////////////////////////////////////////////////////////////////////////////
BOOL CInputBoxDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	SetWindowText(CString((LPTSTR)m_nTitleID));
	if(m_nNameID != -1) {
		GetDlgItem(IDC_LBL_NAME)->SetWindowText(CString((LPTSTR)m_nNameID));
	}
	return TRUE;
}

void CInputBoxDlg::OnOK()
{
	GetDlgItemText(IDC_TXT_NAME, m_strName);
	EndDialog(IDOK);
}

void CInputBoxDlg::OnCancel()
{
	EndDialog(FALSE);
}

/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////
// CInputBox2Dlg dialog
void CInputBox2Dlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CInputBox2Dlg)
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CInputBox2Dlg, CDialog)
	//{{AFX_MSG_MAP(CInputBox2Dlg)
	ON_BN_CLICKED(IDCANCEL, OnCancel)
	ON_BN_CLICKED(IDOK, OnOK)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CInputBox2Dlg message handlers
/////////////////////////////////////////////////////////////////////////////
BOOL CInputBox2Dlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	SetWindowText(CString((LPTSTR)m_nTitleID));
	if(m_nNameID1 != -1) {
		GetDlgItem(IDC_LBL_NAME1)->SetWindowText(CString((LPTSTR)m_nNameID1));
	}
	if(m_nNameID2 != -1) {
		GetDlgItem(IDC_LBL_NAME2)->SetWindowText(CString((LPTSTR)m_nNameID2));
	}
	return TRUE;
}

void CInputBox2Dlg::OnOK()
{
	GetDlgItemText(IDC_TXT_NAME1, m_strName1);
	GetDlgItemText(IDC_TXT_NAME2, m_strName2);
	EndDialog(IDOK);
}

void CInputBox2Dlg::OnCancel()
{
	EndDialog(FALSE);
}
