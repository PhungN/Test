#pragma once


#include "StdHdrRtu.h"
#include "RtuCtrlLib.h"
#include "HardwareConfig\Rtu\PANELGRF\PANELCFG.H"


using namespace Rtu; 

#define MAX_BOX 64
#define BTN_STYLE_HZ	0
#define BTN_STYLE_VERT	1


#define		MAX_RTU_MODESTAT	255
#define		MAX_RTU_ALMPNTS		256
#define		MAX_RTU_CAMPNTS		32
#define		MAX_RTU_ELEVFLOORS	16
#define		MAX_RTU_KEYPADS		256
#define		MAX_RTU_IOS			256
#define		MAX_RTU_READERS		256
#define		MAX_RTU_ELEVRECS	64		// Max Elevator Records

#define		HB0_ALARM_STATUS_INC		0x01
#define		HB0_OUTPUT_STATUS_INC		0x02
#define		HB0_MODE_STATUS_INC			0x04
#define		HB0_PANEL_STATUS_INC		0x08

#define		HB1_CAMERA_STATUS_INC		0x01
#define		HB1_TAMPER_STATUS_INC		0x02
#define     HB1_OFF_LINE_STATUS_INC		0x04
#define		HB1_INPUT_LATCH_STATUS_INC	0x08
#define		HB1_CLEANER_KEY_STATUS_INC	0x10
#define		HB1_CCTV_STATUS_INC			0x20
#define		HB1_SOAK_STATUS_INC			0x40
#define		HB1_READER_STATUS_INC		0x80

#define		HB2_ELEVATOR_STATUS_INC		0x01
#define		HB2_DRIVE_STATUS_INC		0x02
#define		HB2_EXTENDED_READER_INC		0x04
#define		HB2_POWER_MONITOR_INC		0x08
#define		HB2_VAULT_CONTROLLER_INC	0x10
#define		HB2_DEVICE_FIRMWARE_INC		0x20
#define		HB2_INPUT_EXTENDED_DATA_INC 0x40
#define		HB2_FULL_DEVICE_STS_INC		0x80 //TT 7804

#define		DEVINFO_KEYPAD_INC			0x01
#define		DEVINFO_16IO_INC			0x02
#define		DEVINFO_CAMCTRL_INC			0x04
#define		DEVINFO_ELEVCTRL_INC		0x08
#define		DEVINFO_DIALER_INC			0x10
#define		DEVINFO_CARDRDR_INC			0x20

#define		STATUS_PAGE_CNT				19

#pragma pack(1)

typedef struct tagRTU_PANEL60STATS {
	BYTE byte1;
	BYTE byte2;
	BYTE byte3;
	BYTE byte4;
	BYTE ctrlAddr1;
	BYTE ctrlAddr2;
	BYTE RtsCtsDly;
	BYTE graphStat;
	BYTE lineStat;
	BYTE DipnVoc;
	tagRTU_PANEL60STATS()
	{
		byte1 = 0;
		byte2 = 0;
		byte3 = 0;
		byte4 = 0;
		ctrlAddr1 = 0;
		ctrlAddr2 = 0;
		RtsCtsDly = 0;
		graphStat = 0;
		lineStat = 0;
		DipnVoc = 0;

	};
} RTU_PANEL60STATS;

typedef struct tagRTU_PANEL57STATS {
	BYTE byte1;
	BYTE byte2;
	BYTE byte3;
	BYTE byte4;
	BYTE ExtDevStat;
	BYTE spare1;
	BYTE spare2;
	BYTE graphStat;
	BYTE lineStat;
	BYTE DipnVoc;

	tagRTU_PANEL57STATS()
	{
		byte1 = 0;
		byte2 = 0;
		byte3 = 0;
		byte4 = 0;
		ExtDevStat = 0;
		spare1 = 0;
		spare2 = 0;
		graphStat = 0;
		lineStat = 0;
		DipnVoc = 0;
	};
} RTU_PANEL57STATS;

typedef	struct tagRTU_CAMSTATS {
	BYTE status;
	BYTE frameCntH;
	BYTE frameCntL;
} RTU_CAMSTATS;


typedef struct tagRTU_ELEVSTATS {
	BYTE size;						// bytes of data in this record
	BYTE eepCtrlAddress;			// EEPROM controller address
	BYTE elevatorNumber;			// Elevator number
	BYTE offlineStatus;
	BYTE accessFloors[MAX_RTU_ELEVFLOORS];
} RTU_ELEVSTATS;

typedef struct REALTIME {
	uchar sec;
	uchar min;
	uchar hour;
	uchar day;
	uchar month;
	uchar year;
	uchar dayWeek;
	} TIME;

typedef struct RECORDING_TIME {
	uchar number;
	TIME oldestTime;
	TIME youngestTime;
} RECORDINGTIME;

typedef struct tagRTU_DRIVESTATS {
	BYTE driveNumber;
	BYTE dataSize;
	BYTE flags;
	ULONG physicalSize;
	BYTE totalSizeFormatted;
	BYTE spaceRemain;
	BYTE modelName[256];
	BYTE numOfCams;
	RECORDINGTIME camStatus[8];
	BYTE numOfMics;
	RECORDINGTIME micStatus[2];
} RTU_DRIVESTATS;

typedef struct tagPOWER_MONITOR_STATUS {
	BYTE logicalNumber;
	BYTE size;
	BYTE flag1;
	BYTE flag2;
	BYTE adcBattLo;
	BYTE adcBattHi;
	BYTE adcPowerLo;
	BYTE adcPowerHi;
	BYTE adcTempLo;
	BYTE adcTempHi;
	BYTE adcBattMinLo;
	BYTE adcBattMinHi;
	BYTE adcBattMaxLo;
	BYTE adcBattMaxHi;
	BYTE adcLoadMinLo;
	BYTE adcLoadMinHi;
	BYTE adcLoadMaxLo;
	BYTE adcLoadMaxHi;
	BYTE adcPowerMinLo;
	BYTE adcPowerMinHi;
	BYTE adcPowerMaxLo;
	BYTE adcPowerMaxHi;
	BYTE adcTempMinLo;
	BYTE adcTempMinHi;
	BYTE adcTempdMaxLo;
	BYTE adcTempMaxHi;
	BYTE firmwareVersionMinor;	// 25
	BYTE firmwareVersionMajor;	// 26
	BYTE bootloadVersionMinor;	// 27
	BYTE bootloadVersionMajor;	// 28
	BYTE controllerPortNumber;	// 29
	BYTE reseverd[255-29];

} POWER_MONITOR_STATUS, *LPPOWER_MONITOR_STATUS;

typedef struct tagVAULT_CONTROLLER {
	BYTE logicalNumber;
	BYTE size;					
	BYTE byte1;					// 1
	BYTE byte2;					// 2
	BYTE firmwareVersionMinor;	// 3
	BYTE firmwareVersionMajor;	// 4
	BYTE bootloadVersionMinor;	// 5
	BYTE bootloadVersionMajor;	// 6
	BYTE flags;					// 7
	BYTE controllerPortNumber;	// 8
	BYTE data[255-8];
} VAULT_CONTROLLER, *LPVAULT_CONTROLLER;

typedef struct tagDEVICE_FIRMWARE
{
	BYTE deviceType;
	BYTE physicalAddress;
	BYTE physicalPort;
	BYTE bootLoaderVerMajor;
	BYTE bootLoaderVerMinor;
	BYTE firmwareVerMajor;
	BYTE firmwareVerMinor;
} DEVICE_FIRMWARE;

typedef struct tagEXTENDED_INPUT_STATUS
{
	BYTE transmiterStatusLevel : 3;
	BYTE inputTamperAlarm : 1;
	BYTE inputBatteryLowAlarm : 1;
	BYTE suspicionActive : 1;
	BYTE dummy : 2;
} EXTENDED_INPUT_STATUS;

#pragma pack()

/////////////////////////////////////////////////////////////////////////////
// CChkButton window
class CChkButton : public CButton
{
// Construction
public:
	CChkButton(){m_bFlag = FALSE; m_nNumStart; m_bTxtDisp = FALSE; m_bStyle=FALSE; m_nImage=0;
		m_nGap=0; m_nChkID = IDB_RS_CHK; m_nUnchkID = IDB_RS_UNCHK;};
	CChkButton(int image, int gap) {m_bFlag = FALSE; m_nNumStart; m_bTxtDisp = FALSE; m_bStyle=FALSE;
		m_nImage=image; m_nGap=gap;};
	void Init(int image, int gap){m_nImage=image; m_nGap=gap;};
	void Init(int byteCnt, BYTE* ptrData, int numBox, 
		BOOL fTxtTop=FALSE, BOOL fTxtDisp=FALSE, int numStart=1);
	void SetButtonColor(COLORREF btnColor){ m_btnColor = btnColor;}
	void SetButtonState(int btnNum, BYTE state){ btnState[btnNum] = state;}
	void SetBitMap(int byteCnt, BYTE* ptrData, int numStart);
	BYTE GetButtonState(int btnNum){ return btnState[btnNum];}
	void SetParityFlag(BOOL flag){m_bFlag = flag;};
	void SetGap(int gap){m_nGap = gap;}
	void SetBitmapIDs(int chk, int unchk) {m_nChkID = chk; m_nUnchkID = unchk;}
	void SetImage(int image) {m_nImage = image;}
// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CChkButton)
	public:
	virtual void DrawItem(LPDRAWITEMSTRUCT lpDrawItemStruct);
	protected:
	virtual void PreSubclassWindow();
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CChkButton(){};

	// Generated message map functions
protected:
	//{{AFX_MSG(CChkButton)
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()

private:
	CRect rc[MAX_BOX];
	CRect rcb[MAX_BOX];
	BYTE btnState[MAX_BOX];
	COLORREF m_btnColor;
	BOOL m_bFlag;
	int m_nMaxBox;
	int m_nNumStart;
	int m_nGap;
	BOOL m_bTxtDisp;
	BOOL m_bTxtTop;
	BOOL m_bStyle;		// 0: horizontal, 1: vertical
	BOOL m_bDefFlag;
	
	CImageList	m_imageList;
	int m_nImage;

	void DrawItem(CDC* pDC, UINT state);

	int m_nChkID;
	int m_nUnchkID;

};

/////////////////////////////////////////////////////////////////////////////
// CDIPSWButton window
#define MAX_DIPSWITCH	8
class CDIPSWButton : public CButton
{
public:
	CDIPSWButton(){};
	void Init(int numDS);
	void SetAddress(int addr){ m_addr = addr;}
	void SetDrawState(BOOL flag){ m_bDraw = flag;}
public:
	//{{AFX_VIRTUAL(CDIPSWButton)
	public:
	virtual void DrawItem(LPDRAWITEMSTRUCT lpDrawItemStruct);
	protected:
	virtual void PreSubclassWindow();
	//}}AFX_VIRTUAL
public:
	virtual ~CDIPSWButton(){};

protected:
	//{{AFX_MSG(CDIPSWButton)
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
private:
	CRect rct[MAX_DIPSWITCH];
	CRect rcb[MAX_DIPSWITCH];
	CRect rcl[MAX_DIPSWITCH];
	CRect rc1, rc2, rc3;
	int m_addr;
	BOOL m_bDraw;
	int m_numDS;
};

#define MAX_DEVINFO_BYTE 32

class CDeviceInfoData
{
public:
	enum {E_DEV_TYPE_KEYPAD, E_DEV_TYPE_IO, E_DEV_TYPE_CAM_CTRL, E_DEV_TYPE_DIALER, E_DEV_TYPE_READER, E_DEV_TYPE_ELEVATOR};
	CDeviceInfoData();
	CString GetTamperStatus();
	CString GetOfflineStatus();
	CString GetIsolatedStatus();
	CString GetKeyswitchStatus();
	int		GetImageIndex();
	void	MoveNext();
	void	Reset();
	LPBYTE  SetData(int deviceType, LPBYTE pData, int bc, BOOL bKeySwitchInc=FALSE);
	void	UpdateListItem(LVITEM& lvi, int item, CString& strText);
	int		GetCount() { return m_nDeviceCount; }
private:
	BYTE m_tamperData[MAX_DEVINFO_BYTE];
	BYTE m_offlineData[MAX_DEVINFO_BYTE];
	BYTE m_isolatedData[MAX_DEVINFO_BYTE];
	BYTE m_keyswitchData[MAX_DEVINFO_BYTE];

	BYTE m_tamper;
	BYTE m_offline;
	BYTE m_isolated;
	BYTE m_keyswitch;
	int	 m_nIndex;
	int	 m_nDeviceType;
	int	 m_nDeviceCount;
	BOOL m_bKeyswitchInc;
};
/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////
class CRtuStatusBase : public CPropertyPage
{
public:
	CRtuStatusBase(int id) : CPropertyPage(id) {};
	virtual void ShowStatus() = 0;
	virtual LPBYTE SetStatus(LPBYTE, int, BOOL) = 0;
	virtual void Print() = 0;
	virtual BOOL IsValid() = 0;
};

class CRtuStatusBase2 : public CXTPPropertyPage
{
public:
	CRtuStatusBase2(int id) : CXTPPropertyPage(id) {};
	virtual void ShowStatus() = 0;
	virtual LPBYTE SetStatus(LPBYTE, int, BOOL) = 0;
	virtual void Print() = 0;
	virtual BOOL IsValid() = 0;
};

/////////////////////////////////////////////////////////////////////////////
// CRtuModePage dialog
class CRtuModePage : public CRtuStatusBase
{
	DECLARE_DYNCREATE(CRtuModePage)
// Construction
public:
	//CRtuModePage() : CPropertyPage(CRtuModePage::IDD){};
	CRtuModePage();
	~CRtuModePage(){};
	LPBYTE SetStatus(LPBYTE, int=0, BOOL=FALSE);
	void ShowStatusNum(int curArea);
	void ShowStatus();
	void Print();
	BOOL IsValid() { return TRUE; }
// Dialog Data
	//{{AFX_DATA(CRtuModePage)
	enum { IDD = IDD_RTU_MODESTATS };
		// NOTE - ClassWizard will add data members here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_DATA

// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CRtuModePage)
	public:
	virtual BOOL OnInitDialog();
	virtual BOOL OnSetActive();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CRtuModePage)
	afx_msg void OnUpDownModeSts(NMHDR* pNMHDR, LRESULT* pResult);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

private:
	BYTE m_modeStatus[255];
	int m_nNumAreas;
	int m_nCurArea;
	void SetCheckStatus(UINT id, BYTE status);
};

/////////////////////////////////////////////////////////////////////////////
// CRtuPanel57Page dialog
class CRtuPanel57Page : public CRtuStatusBase
{
	DECLARE_DYNCREATE(CRtuPanel57Page)
// Construction
public:
	CRtuPanel57Page() : CRtuStatusBase(CRtuPanel57Page::IDD){};
	~CRtuPanel57Page(){};
	LPBYTE SetStatus(LPBYTE, int=0, BOOL=FALSE);
	void ShowStatus();
	void Print();
	BOOL IsValid() { return TRUE; }
// Dialog Data
	//{{AFX_DATA(CRtuPanel57Page)
	enum { IDD = IDD_RTU_PANEL57STATS };
		// NOTE - ClassWizard will add data members here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_DATA

// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CRtuPanel57Page)
	public:
	virtual BOOL OnInitDialog();
	virtual BOOL OnSetActive();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CRtuPanel57Page)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

private:
	RTU_PANEL57STATS m_panelStatus;
	CDIPSWButton m_btnDipSw;

	void ShowWitnessControls();
};

/////////////////////////////////////////////////////////////////////////////
// CRtuPanel60 Page dialog
class CRtuPanel60Page : public CRtuStatusBase
{
	DECLARE_DYNCREATE(CRtuPanel60Page)
// Construction
public:
	CRtuPanel60Page() : CRtuStatusBase(CRtuPanel60Page::IDD){};
	~CRtuPanel60Page(){};
	LPBYTE SetStatus(LPBYTE, int=0, BOOL=FALSE);
	void ShowStatus();
	void Print();
	BOOL IsValid() { return TRUE; }
// Dialog Data
	//{{AFX_DATA(CRtuPanel60Page)
	enum { IDD = IDD_RTU_PANEL60STATS };
		// NOTE - ClassWizard will add data members here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_DATA

// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CRtuPanel60Page)
	public:
	virtual BOOL OnInitDialog();
	virtual BOOL OnSetActive();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CRtuPanel60Page)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

private:
	RTU_PANEL60STATS m_panelStatus;
	CDIPSWButton m_btnDipSw;
};

//====================================================================================//
//====================================================================================//
// CRtuInpStsPage dialog
class CRtuInpStsPage : public CRtuStatusBase
{
	DECLARE_DYNCREATE(CRtuInpStsPage)
// Construction
public:
	CRtuInpStsPage();
	~CRtuInpStsPage(){};
	LPBYTE SetStatus(LPBYTE, int, BOOL);
	void ShowStatus();
	void Print();

	LPBYTE SetInpStsData(LPBYTE);
	LPBYTE SetLatchStsData(LPBYTE);
	LPBYTE SetSoakStsData(LPBYTE);
	LPBYTE SetExtendeInputData(LPBYTE);
	int GetNumInputs() {return m_numInputs;}
	BOOL IsValid() { return m_numInputs > 0; }
	
// Dialog Data
	//{{AFX_DATA(CRtuInpStsPage)
	enum { IDD = IDD_RTU_INPSTAT_PAGE };
	CListCtrlEx	m_inputList;
	CImageList m_imgList;

		// NOTE - ClassWizard will add data members here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_DATA

// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CRtuInpStsPage)
	public:
	virtual BOOL OnInitDialog();
	virtual BOOL OnSetActive();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CRtuInpStsPage)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

private:
	int m_numInputs;
	int m_curInputNum;
	BYTE m_inputStatus[MAX_RTU_ALMPNTS];

	int m_numLatches;
	
	BYTE m_latchedStatus[MAX_RTU_ALMPNTS];

	int m_numSoaks;
	BYTE m_soakedStatus[MAX_RTU_ALMPNTS];

	BYTE m_inputExtendedStatus[MAX_RTU_ALMPNTS];
	BOOL m_hasInputExtendedStatus;
	int m_numInputExtendedStatus;
};


//====================================================================================//
//====================================================================================//
// CRtuOpStsPage dialog
class CRtuOpStsPage : public CRtuStatusBase
{
	DECLARE_DYNCREATE(CRtuOpStsPage)
// Construction
public:
	CRtuOpStsPage() : CRtuStatusBase(CRtuOpStsPage::IDD){ m_numOutputs=0;};
	~CRtuOpStsPage(){};
	LPBYTE SetStatus(LPBYTE, int=0, BOOL=FALSE);
	void ShowStatus();
	void Print();
	BOOL IsValid() { return m_numOutputs > 0; }

	int GetNumOutputs() {return m_numOutputs;}
// Dialog Data
	//{{AFX_DATA(CRtuOpStsPage)
	enum { IDD = IDD_RTU_OPSTAT_PAGE };
		// NOTE - ClassWizard will add data members here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_DATA

// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CRtuOpStsPage)
	public:
	virtual BOOL OnInitDialog();
	virtual BOOL OnSetActive();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CRtuOpStsPage)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

private:  
	int m_numOutputs;
	BYTE m_outputStatus[MAX_RTU_ALMPNTS];
	CListCtrlEx	m_outputList;
	CImageList m_imgList;

};

//====================================================================================//
//====================================================================================//
// CRtuCamStsPage dialog
class CRtuCamStsPage : public CRtuStatusBase
{
	DECLARE_DYNCREATE(CRtuCamStsPage)
// Construction
public:
	CRtuCamStsPage() : CRtuStatusBase(CRtuCamStsPage::IDD){m_numCameras=0;};
	~CRtuCamStsPage(){};
	LPBYTE SetStatus(LPBYTE, int=0, BOOL=FALSE);
	void ShowStatus();
	void Print();
	BOOL IsValid() { return m_numCameras > 0; }
	
	int GetNumCameras() {return m_numCameras;}
// Dialog Data
	//{{AFX_DATA(CRtuCamStsPage)
	enum { IDD = IDD_RTU_CAMSTAT_PAGE };
		// NOTE - ClassWizard will add data members here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_DATA

// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CRtuCamStsPage)
	public:
	virtual BOOL OnInitDialog();
	virtual BOOL OnSetActive();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CRtuCamStsPage)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

private:  
	int m_numCameras;	
	RTU_CAMSTATS m_cameraStatus[MAX_RTU_CAMPNTS];
	CListCtrlEx m_camerList;
	CImageList m_imgList;
};


//====================================================================================//
//====================================================================================//
// CRtuCctvStsPage dialog
class CRtuCctvStsPage : public CRtuStatusBase
{
	DECLARE_DYNCREATE(CRtuCctvStsPage)
// Construction
public:
	CRtuCctvStsPage() : CRtuStatusBase(CRtuCctvStsPage::IDD){
	m_numCCTVs=0;};
	~CRtuCctvStsPage(){};
	LPBYTE SetStatus(LPBYTE, int=0, BOOL=FALSE);
	void ShowStatus();
	void Print();
	BOOL IsValid() { return m_numCCTVs > 0; }
	
	int GetNumCctvs() {return m_numCCTVs;}
	
// Dialog Data
	//{{AFX_DATA(CRtuCctvStsPage)
	enum { IDD = IDD_RTU_CCTVSTAT_PAGE };
		// NOTE - ClassWizard will add data members here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_DATA

// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CRtuCctvStsPage)
	public:
	virtual BOOL OnInitDialog();
	virtual BOOL OnSetActive();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CRtuCctvStsPage)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

private:  
	int m_numCCTVs;
	BYTE m_cctvStatus[MAX_RTU_ALMPNTS];
	CListCtrlEx m_cctvList;
	CImageList m_imgList;
};

//====================================================================================//
//====================================================================================//
/////////////////////////////////////////////////////////////////////////////
// CRtuKeypadPage dialog
class CRtuKeypadPage : public CRtuStatusBase
{
	DECLARE_DYNCREATE(CRtuKeypadPage)
// Construction
public:
	CRtuKeypadPage() : CRtuStatusBase(CRtuKeypadPage::IDD){
	m_numKeypads=0;};
	~CRtuKeypadPage(){};
	LPBYTE SetStatus(LPBYTE, int, BOOL);
	void ShowStatus();
	void Print();
	BOOL IsValid() { return TRUE; }
// Dialog Data
	//{{AFX_DATA(CRtuKeypadPage)
	enum { IDD = IDD_RTU_DEVINFO_KEYPADSTAT };
	// NOTE - ClassWizard will add data members here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_DATA

// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CRtuKeypadPage)
	public:
	virtual BOOL OnInitDialog();
	virtual BOOL OnSetActive();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CRtuKeypadPage)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

private:
	int m_numKeypads;
	
	BYTE m_tamperData[MAX_DEVINFO_BYTE];
	BYTE m_offlineData[MAX_DEVINFO_BYTE];
	BYTE m_isolatedData[MAX_DEVINFO_BYTE];
	BYTE m_keyswitchData[MAX_DEVINFO_BYTE];
	CListCtrlEx m_kpdList;
	CImageList m_imgList;
	BOOL m_bKeySwitchInc;

	CString GetDeviceTypeString(int index);
	CString GetFirmwareVersionString(int index);
	CString GetBootloaderVersionString(int index);
};

/////////////////////////////////////////////////////////////////////////////
// CRtu16IOPage dialog
class CRtu16IOPage : public CRtuStatusBase
{
	DECLARE_DYNCREATE(CRtu16IOPage)
// Construction
public:
	CRtu16IOPage() : CRtuStatusBase(CRtu16IOPage::IDD){
	m_num16IOs=0;};
	~CRtu16IOPage(){};
	LPBYTE SetStatus(LPBYTE, int, BOOL=FALSE);
	void ShowStatus();
	void Print();
	BOOL IsValid() { return TRUE; }
// Dialog Data
	//{{AFX_DATA(CRtu16IOPage)
	enum { IDD = IDD_RTU_DEVINFO_16IOSTAT };
		// NOTE - ClassWizard will add data members here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_DATA

// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CRtu16IOPage)
	public:
	virtual BOOL OnInitDialog();
	virtual BOOL OnSetActive();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CRtu16IOPage)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

private:
	int m_num16IOs;
	
	BYTE m_tamperData[MAX_DEVINFO_BYTE];
	BYTE m_offlineData[MAX_DEVINFO_BYTE];
	BYTE m_isolatedData[MAX_DEVINFO_BYTE];
	CListCtrlEx m_16ioList;
	CImageList m_imgList;

	CString GetDeviceTypeString(int index);
	CString GetFirmwareVersionString(int index);
	CString GetBootloaderVersionString(int index);
};

/////////////////////////////////////////////////////////////////////////////
// CRtuCamCtrlPage dialog
class CRtuCamCtrlPage : public CRtuStatusBase
{
	DECLARE_DYNCREATE(CRtuCamCtrlPage)
// Construction
public:
	CRtuCamCtrlPage() : CRtuStatusBase(CRtuCamCtrlPage::IDD){
	m_numCamCtrls=0;};
	~CRtuCamCtrlPage(){};
	LPBYTE SetStatus(LPBYTE, int, BOOL=FALSE);
	void ShowStatus();
	void Print();
	BOOL IsValid() { return TRUE; }
// Dialog Data
	//{{AFX_DATA(CRtuCamCtrlPage)
	enum { IDD = IDD_RTU_DEVINFO_CAMSTAT };
	
		// NOTE - ClassWizard will add data members here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_DATA

// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CRtuCamCtrlPage)
	public:
	virtual BOOL OnInitDialog();
	virtual BOOL OnSetActive();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CRtuCamCtrlPage)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

private:
	int m_numCamCtrls;
	
	BYTE m_tamperData[MAX_DEVINFO_BYTE];
	BYTE m_offlineData[MAX_DEVINFO_BYTE];
	BYTE m_isolatedData[MAX_DEVINFO_BYTE];
	CListCtrlEx m_camCtrlList;
	CImageList m_imgList;
};

/////////////////////////////////////////////////////////////////////////////
// CRtuElevCtrlPage dialog
class CRtuElevCtrlPage : public CRtuStatusBase
{
	DECLARE_DYNCREATE(CRtuElevCtrlPage)
// Construction
public:
	CRtuElevCtrlPage() : CRtuStatusBase(CRtuElevCtrlPage::IDD){
	m_numElevatorCtrls=0;};
	~CRtuElevCtrlPage(){};
	LPBYTE SetStatus(LPBYTE, int, BOOL=FALSE);
	void ShowStatus();
	void Print();
	BOOL IsValid() { return TRUE; }
// Dialog Data
	//{{AFX_DATA(CRtuElevCtrlPage)
	enum { IDD = IDD_RTU_DEVINFO_ELEVSTAT };
	
		// NOTE - ClassWizard will add data members here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_DATA

// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CRtuElevCtrlPage)
	public:
	virtual BOOL OnInitDialog();
	virtual BOOL OnSetActive();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CRtuElevCtrlPage)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

private:
	int m_numElevatorCtrls;
	
	BYTE m_tamperData[MAX_DEVINFO_BYTE];
	BYTE m_offlineData[MAX_DEVINFO_BYTE];
	BYTE m_isolatedData[MAX_DEVINFO_BYTE];
	CListCtrlEx m_elevCtrlList;
	CImageList m_imgList;
};


/////////////////////////////////////////////////////////////////////////////
// CRtuDialerPage dialog
class CRtuDialerPage : public CRtuStatusBase
{
	DECLARE_DYNCREATE(CRtuDialerPage)
// Construction
public:
	CRtuDialerPage() : CRtuStatusBase(CRtuDialerPage::IDD){
	m_numDialers=0;};
	~CRtuDialerPage(){};
	LPBYTE SetStatus(LPBYTE, int, BOOL=FALSE);
	void ShowStatus();
	void Print();
	BOOL IsValid() { return TRUE; }
// Dialog Data
	//{{AFX_DATA(CRtuDialerPage)
	enum { IDD = IDD_RTU_DEVINFO_DIALERSTAT };
		// NOTE - ClassWizard will add data members here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_DATA

// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CRtuDialerPage)
	public:
	virtual BOOL OnInitDialog();
	virtual BOOL OnSetActive();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CRtuDialerPage)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

private:
	int m_numDialers;
	
	BYTE m_tamperData[MAX_DEVINFO_BYTE];
	BYTE m_offlineData[MAX_DEVINFO_BYTE];
	BYTE m_isolatedData[MAX_DEVINFO_BYTE];
	CListCtrlEx m_dialList;
	CImageList m_imgList;
};


/////////////////////////////////////////////////////////////////////////////
// CRtuCardRdrPage dialog
class CRtuCardRdrPage : public CRtuStatusBase
{
	DECLARE_DYNCREATE(CRtuCardRdrPage)
// Construction
public:
	CRtuCardRdrPage() : CRtuStatusBase(CRtuCardRdrPage::IDD){
	m_numCardReaders=0;};
	~CRtuCardRdrPage(){};
	LPBYTE SetStatus(LPBYTE, int, BOOL=FALSE);
	void ShowStatus();
	int GetNumCardReaders() {return m_numCardReaders;}
	void Print();
	BOOL IsValid() { return m_numCardReaders > 0; }

// Dialog Data
	//{{AFX_DATA(CRtuCardRdrPage)
	enum { IDD = IDD_RTU_DEVINFO_CRDRSTAT };
		// NOTE - ClassWizard will add data members here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_DATA

// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CRtuCardRdrPage)
	public:
	virtual BOOL OnInitDialog();
	virtual BOOL OnSetActive();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CRtuCardRdrPage)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

private:  
	int m_numCardReaders;
	
	BYTE m_tamperData[MAX_DEVINFO_BYTE];
	BYTE m_offlineData[MAX_DEVINFO_BYTE];
	BYTE m_isolatedData[MAX_DEVINFO_BYTE];
	CListCtrlEx m_rdrList;
	CImageList m_imgList;

	CString GetDeviceTypeString(int index);
	CString GetFirmwareVersionString(int index);
	CString GetBootloaderVersionString(int index);
};


/////////////////////////////////////////////////////////////////////////////
// CRtuDeviceInfoPage dialog
class CRtuDeviceInfoPage : public CRtuStatusBase
{
	DECLARE_DYNCREATE(CRtuDeviceInfoPage)
// Construction
public:
	CRtuDeviceInfoPage() : CRtuStatusBase(CRtuDeviceInfoPage::IDD){};
	~CRtuDeviceInfoPage(){};

	LPBYTE Copy(LPBYTE, LPBYTE, int, int);
// Dialog Data
	//{{AFX_DATA(CRtuDeviceInfoPage)
	enum { IDD = IDD_RTU_DEVSTATS };
		// NOTE - ClassWizard will add data members here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_DATA

// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CRtuDeviceInfoPage)
	public:
	virtual BOOL OnInitDialog();
	virtual BOOL OnSetActive();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CRtuDeviceInfoPage)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

private:
	CRtuKeypadPage m_pageKeypad;
	CRtu16IOPage m_page16IO;
	CRtuCamCtrlPage m_pageCamCtrl;
	CRtuElevCtrlPage m_pageElevCtrl;
	CRtuDialerPage m_pageDialer;
	CRtuCardRdrPage m_pageCardRdr;
	CPropertySheet m_sheet;
};

//====================================================================================//
//====================================================================================//
#define MAX_RTU_RDRS	64

/////////////////////////////////////////////////////////////////////////////
// CRtuDoorStatusPage dialog
class CRtuDoorStatusPage : public CRtuStatusBase
{
	DECLARE_DYNCREATE(CRtuDoorStatusPage)
// Construction
public:
	CRtuDoorStatusPage() : CRtuStatusBase(CRtuDoorStatusPage::IDD)
	{
		m_numReaders=0; m_curReaderNum=0; 
		memset(m_readerStatus, 0, sizeof(m_readerStatus));
	};
	~CRtuDoorStatusPage(){};
	LPBYTE SetStatus(LPBYTE, int=0, BOOL=FALSE);
	void ShowStatus();
	int GetNumReaders(){return m_numReaders;}
	void Print();
	BOOL IsValid() { return m_numReaders > 0; }
// Dialog Data
	//{{AFX_DATA(CRtuDoorStatusPage)
	enum { IDD = IDD_RTU_RDRSTATS };
		// NOTE - ClassWizard will add data members here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_DATA

// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CRtuDoorStatusPage)
	public:
	virtual BOOL OnInitDialog();
	virtual BOOL OnSetActive();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CRtuDoorStatusPage)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

private:
	int m_numReaders;
	int m_curReaderNum;
	
	BYTE m_readerStatus[MAX_RTU_RDRS];

	CListCtrlEx m_rdrList;
	CImageList m_imgList;
};


/////////////////////////////////////////////////////////////////////////////
// CRtuElevFlrPage dialog
class CRtuElevFlrPage : public CRtuStatusBase
{
	DECLARE_DYNCREATE(CRtuElevFlrPage)
// Construction
public:
	CRtuElevFlrPage() : CRtuStatusBase(CRtuElevFlrPage::IDD){
	m_numElevators=0; m_curElevatorNum=0; memset(&m_elevatorStatus[0], 0, sizeof(m_elevatorStatus));};
	~CRtuElevFlrPage(){};
	LPBYTE SetStatus(LPBYTE, int=0, BOOL=FALSE);
	void ShowStatus();
	int GetNumElevators(){return m_numElevators;}
	void Print();
	BOOL IsValid() { return m_numElevators > 0; }
// Dialog Data
	//{{AFX_DATA(CRtuElevFlrPage)
	enum { IDD = IDD_RTU_ELEVSTATS };
	// NOTE - ClassWizard will add data members here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_DATA

// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CRtuElevFlrPage)
	public:
	virtual BOOL OnInitDialog();
	virtual BOOL OnSetActive();
	afx_msg void OnBtnFloor();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CRtuElevFlrPage)
	afx_msg void OnUpDownElevSts(NMHDR* pNMHDR, LRESULT* pResult);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

private:
	int m_numElevators;
	int m_curElevatorNum;
	
	RTU_ELEVSTATS m_elevatorStatus[MAX_RTU_ELEVRECS];

	CChkButton m_btn1;
	CChkButton m_btn2;
	CChkButton m_btn3;
	CChkButton m_btn4;
	CChkButton m_btn5;
	CChkButton m_btn6;
	CChkButton m_btn7;
	CChkButton m_btn8;

	CStaticColor m_lblElevNum;
	CListCtrlEx m_lstOffStatus;
	CChkButton m_chkFlrAccess;
	CChkButton m_chkFlrRestore;
};

/////////////////////////////////////////////////////////////////////////////
// CRtuDriveStatusPage Page dialog
class CRtuDriveStatusPage : public CRtuStatusBase
{
	DECLARE_DYNCREATE(CRtuDriveStatusPage)
// Construction
public:
	CRtuDriveStatusPage() : CRtuStatusBase(CRtuDriveStatusPage::IDD){m_ptrDriveStatus=NULL;};
	~CRtuDriveStatusPage(){};
	LPBYTE SetStatus(LPBYTE, int=0, BOOL=FALSE);
	void ShowStatus();
	int GetNumDrives(){return m_nNumDrives;}
	void Print();
	BOOL IsValid() { return m_nNumDrives > 0; }
// Dialog Data
	//{{AFX_DATA(CRtuDriveStatusPage)
	enum { IDD = IDD_RTU_DRIVE_STATS };
		// NOTE - ClassWizard will add data members here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_DATA

// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CRtuDriveStatusPage)
	public:
	virtual BOOL OnInitDialog();
	virtual BOOL OnSetActive();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CRtuDriveStatusPage)
	afx_msg void OnUpDownCamRecTimes(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnUpDownMicRecTimes(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnUpDownDriveStatus(NMHDR* pNMHDR, LRESULT* pResult);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

private:
	int m_nNumDrives;
	int m_nCurDrive;
	int m_nNumCamRecTimes;
	int m_nCurCamRecTime;
	int m_nNumMicRecTimes;
	int m_nCurMicRecTime;
	int m_nModelNameSize;
	RTU_DRIVESTATS* m_ptrDriveStatus;

	CStaticColor m_lblDriveNum;
	CStaticColor m_lblPhysSize;
	CStaticColor m_lblPhysSizeFormatted;
	CStaticColor m_lblPhysSizeRemain;
	CStaticColor m_lblModelName;

	CStaticColor m_lblCamNum;
	CStaticColor m_lblCamOldestTime;
	CStaticColor m_lblCamYoungestTime;

	CStaticColor m_lblMicNum;
	CStaticColor m_lblMicOldestTime;
	CStaticColor m_lblMicYoungestTime;


	void GetTime(CString& str, TIME*);
	void ShowCamRecTime();
	void ShowMicRecTime();
};

/////////////////////////////////////////////////////////////////////////////
// CRtuPowerMonitorStatusPage Page dialog
class CRtuPowerMonitorStatusPage : public CRtuStatusBase
{
	DECLARE_DYNCREATE(CRtuPowerMonitorStatusPage)
// Construction
public:
	enum {E_TYPE_BATTERY = 0, E_TYPE_POWER = 1, E_TYPE_TEMPERATURE = 2, E_NUM_STATUS_READINGS = 11, E_MAX_CTRL = 14};
	CRtuPowerMonitorStatusPage();
	~CRtuPowerMonitorStatusPage();
	LPBYTE SetStatus(LPBYTE, int=0, BOOL=FALSE);
	void ShowStatus();
	int GetNumDevices(){return m_nNumDevices;}
	void Print();
	BOOL IsValid() { return m_nNumDevices > 0; }
// Dialog Data
	//{{AFX_DATA(CRtuPowerMonitorStatusPage)
	enum { IDD = IDD_RTU_POW_MON_STATS };
		// NOTE - ClassWizard will add data members here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_DATA

// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CRtuPowerMonitorStatusPage)
	public:
	virtual BOOL OnInitDialog();
	virtual BOOL OnSetActive();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CRtuPowerMonitorStatusPage)
	afx_msg void OnUpDownDeviceStatus(NMHDR* pNMHDR, LRESULT* pResult);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

private:
	CStaticColor m_genCtrls[E_MAX_CTRL];

	int m_nNumDevices;
	int m_nCurDevice;
	LPPOWER_MONITOR_STATUS m_pStatus;
	BYTE m_Flag1, m_Flag2;

	CString GetStatusString(int index, int value);
};


/////////////////////////////////////////////////////////////////////////////
// CRtuVaultControllerStatusPage Page dialog
class CRtuVaultControllerStatusPage : public CRtuStatusBase
{
	DECLARE_DYNCREATE(CRtuVaultControllerStatusPage)
// Construction
public:
	CRtuVaultControllerStatusPage();
	~CRtuVaultControllerStatusPage();
	LPBYTE SetStatus(LPBYTE, int=0, BOOL=FALSE);
	void ShowStatus();
	int GetNumDevices(){return m_nNumDevices;}
	void Print();
	BOOL IsValid() { return m_nNumDevices > 0; }
// Dialog Data
	//{{AFX_DATA(CRtuVaultControllerStatusPage)
	enum { IDD = IDD_RTU_VAULT_CTRL_STATS };
		// NOTE - ClassWizard will add data members here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_DATA

// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CRtuVaultControllerStatusPage)
	public:
	virtual BOOL OnInitDialog();
	virtual BOOL OnSetActive();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CRtuVaultControllerStatusPage)
	afx_msg void OnUpDownDeviceStatus(NMHDR* pNMHDR, LRESULT* pResult);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

private:
	int m_nNumDevices;
	int m_nCurDevice;
	LPVAULT_CONTROLLER m_pStatus;
	BYTE m_Flag1;
	CStringArray m_strArrVaultStatus;
};

/////////////////////////////////////////////////////////////////////////////
// RTU Status dialog
class RTUStatus : public CDialog
{
// Construction
public:
	RTUStatus(LPPARMPROC lpps=NULL, int op=0, CWnd* pParent = NULL); 
	  ~RTUStatus();
	LPBYTE SetDevInfoStatus(LPBYTE, CMenu* pMenu);
	LPBYTE Copy(LPBYTE, LPBYTE, int, int, BOOL bKeypad=0);
	LPBYTE	GetStatusPtr(LPBYTE p1);
	void Init();
	void SetPageIcon();
	void ShowStatus();
	BOOL GetStatus();
	LPBYTE AddStatusPage(LPBYTE pData, BOOL bAdded, ulong mask, CRtuStatusBase* pPage, UINT menuID, 
		CMenu* pMenu, int cnt=0, BOOL inc=FALSE);
// Dialog Data
	//{{AFX_DATA(RTUStatus)
	enum { IDD = IDD_RTU_STATUS };
	//}}AFX_DATA
	
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(RTUStatus)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(RTUStatus)
	virtual BOOL OnInitDialog();
	afx_msg void OnClose();
	afx_msg void OnBtnRefresh();
	afx_msg LRESULT	OnGMS(WPARAM wParam, LPARAM lParam);
	afx_msg void OnPrintModeStatus();
	afx_msg void OnPrintPanelStatus();
	afx_msg void OnPrintInputStatus();
	afx_msg void OnPrintOutputStatus();
	afx_msg void OnPrintCameraStatus();
	afx_msg void OnPrintDevInfoKeypadStatus();
	afx_msg void OnPrintDevInfo16IOStatus();
	afx_msg void OnPrintDevInfoCamCtrlStatus();
	afx_msg void OnPrintDevInfoElevCtrlStatus();
	afx_msg void OnPrintDevInfoDialerStatus();
	afx_msg void OnPrintDevInfoCardRdrStatus();
	afx_msg void OnPrintDoorStatus();
	afx_msg void OnPrintCctvStatus();
	afx_msg void OnPrintElevatorStatus();
	afx_msg void OnPrintDriveStatus();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	int m_option;
	BOOL m_bIs1060Panel;
	LPPARMPROC m_lpps;
	LPBYTE m_pStatus;

	enum {
		Panel57Page				= 1, 
		Panel60Page				= 2, 
		ModePage				= 4, 
		
		DevInfoKeypadPage		= 8, 
		DevInfoIoPage			= 0x10,
		DevInfoCameraPage		= 0x20,
		DevInfoElevatorPage		= 0x40,
		DevInfoDialerPage		= 0x80,
		DevInfoCardReaderPage	= 0x100,
		
		OutputPage				= 0x200,
		CameraPage				= 0x400,
		CctvPage				= 0x800,
		InputPage				= 0x1000,
		DoorPage				= 0x2000,
		ElevatorFloorPage		= 0x4000,
		DrivePage				= 0x8000,
		PowerMonitorPage		= 0x10000,
		VaultControllerPage		= 0x20000
		
	};
	ulong							m_pages;
	CRtuPanel57Page					m_pagePanel57;
	CRtuPanel60Page					m_pagePanel60;
	CRtuModePage					m_pageMode;
	
	CRtuKeypadPage					m_pageKeypad;
	CRtu16IOPage					m_page16IO;
	CRtuCamCtrlPage					m_pageCamCtrl;
	CRtuElevCtrlPage				m_pageElevCtrl;
	CRtuDialerPage					m_pageDialer;
	CRtuCardRdrPage					m_pageCardRdr;

	CRtuOpStsPage					m_pageOpSts;
	CRtuCamStsPage					m_pageCamSts;
	CRtuCctvStsPage					m_pageCctvSts;
	CRtuInpStsPage					m_pageInpSts;
	CRtuDoorStatusPage				m_pageReader;
	CRtuElevFlrPage					m_pageElevFlr;
	CRtuDriveStatusPage				m_pageDriveStatus;	
	CRtuPowerMonitorStatusPage		m_pagePowerMonitorStatus;
	CRtuVaultControllerStatusPage	m_pageVaultCtrlStatus;

	CTreePropSheet		m_sheet;

	CStaticColor m_rtuType;
	CStaticColor m_panelType;
	CStaticColor m_commType;

	BYTE m_headerCount;
	BYTE m_header;
	BYTE m_header1;
	BYTE m_header2;
};




class CPropertyPageTaskPanelNavigator2 : public CXTPTaskPanel, public CXTPPropertyPageControlNavigator
{
public:
	CPropertyPageTaskPanelNavigator2();

public:
	virtual BOOL Create();
	virtual void OnPageSelected(CXTPPropertyPage* pPage);
	virtual HWND GetSafeHwnd() const { return m_hWnd; }

protected:
	virtual void SetFocusedItem(CXTPTaskPanelItem* pItem, BOOL bDrawFocusRect = FALSE, BOOL bSetFocus = TRUE);
};

/////////////////////////////////////////////////////////////////////////////
// CRtuModePage2 dialog
class CRtuModePage2 : public CRtuStatusBase2
{
	DECLARE_DYNCREATE(CRtuModePage2)
// Construction
public:
	//CRtuModePage() : CPropertyPage(CRtuModePage2::IDD){};
	CRtuModePage2();
	~CRtuModePage2(){};
	LPBYTE SetStatus(LPBYTE, int=0, BOOL=FALSE);
	void ShowStatusNum(int curArea);
	void ShowStatus();
	void Print();
	BOOL IsValid() { return TRUE; }
// Dialog Data
	//{{AFX_DATA(CRtuModePage2)
	enum { IDD = IDD_RTU_MODESTATS2 };
		// NOTE - ClassWizard will add data members here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_DATA

// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CRtuModePage2)
	public:
	virtual BOOL OnInitDialog();
	virtual BOOL OnSetActive();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CRtuModePage2)
	afx_msg void OnUpDownModeSts(NMHDR* pNMHDR, LRESULT* pResult);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

private:
	BYTE m_modeStatus[255];
	int m_nNumAreas;
	int m_nCurArea;
	BYTE m_status1;
	BYTE m_status2;
	BYTE m_status3;
	CMarkupStatic m_lblModeStatus;

	
	CString GetMainStatus();
	CString GetSubStatus();
};

/////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////
// CRtuPanelPage2 dialog
class CRtuPanelPage2 : public CRtuStatusBase2
{
	DECLARE_DYNCREATE(CRtuPanelPage2)
// Construction
public:
	CRtuPanelPage2() : CRtuStatusBase2(CRtuPanelPage2::IDD){m_bIsValid = FALSE;};
	~CRtuPanelPage2(){};
	LPBYTE SetStatus(LPBYTE, int=0, BOOL=FALSE);
	void ShowStatus();
	void Print();
	void Print1060Panel();
	BOOL IsValid() { return m_bIsValid; }
// Dialog Data
	//{{AFX_DATA(CRtuPanelPage2)
	enum { IDD = IDD_RTU_PANELSTATS };
		// NOTE - ClassWizard will add data members here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_DATA

// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CRtuPanelPage2)
	public:
	virtual BOOL OnInitDialog();
	virtual BOOL OnSetActive();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CRtuPanelPage2)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

private:
	RTU_PANEL57STATS m_panelStatus;
	
	BOOL m_bIsValid;
	BOOL m_bIs1060Panel;
	CMarkupStatic m_lblPowerStatus;
	CMarkupStatic m_lblNetworkStatus;
	CMarkupStatic m_lblTamperStatus;
	CMarkupStatic m_lblRemotePanelStatus;
	CMarkupStatic m_lblGraphicsStatus;
	CMarkupStatic m_lblGeneralStatus;
	CMarkupStatic m_lblWitness;
	CMarkupStatic m_lblDipSwitch;
	void ShowWitnessControls();
	void ShowPowerStatus();
	void ShowNetworkStatus();
	void ShowTamperStatus();
	void ShowRemotePanelStatus();
	void ShowGraphicsStatus();
	void ShowGeneralStatus();
public:
	BYTE GetVocabListId() { return (m_panelStatus.DipnVoc>>4);}
};



/////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////
// CRtuPanel60 Page dialog
class CRtuPanel60Page2 : public CRtuStatusBase2
{
	DECLARE_DYNCREATE(CRtuPanel60Page2)
// Construction
public:
	CRtuPanel60Page2() : CRtuStatusBase2(CRtuPanel60Page2::IDD){};
	~CRtuPanel60Page2(){};
	LPBYTE SetStatus(LPBYTE, int=0, BOOL=FALSE);
	void ShowStatus();
	void Print();
	BOOL IsValid() { return TRUE; }
// Dialog Data
	//{{AFX_DATA(CRtuPanel60Page2)
	enum { IDD = IDD_RTU_PANEL60STATS };
		// NOTE - ClassWizard will add data members here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_DATA

// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CRtuPanel60Page2)
	public:
	virtual BOOL OnInitDialog();
	virtual BOOL OnSetActive();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CRtuPanel60Page2)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

private:
	RTU_PANEL60STATS m_panelStatus;
	CDIPSWButton m_btnDipSw;
};

// CRtuKeypadPage2 dialog
class CRtuKeypadPage2 : public CRtuStatusBase2
{
	DECLARE_DYNCREATE(CRtuKeypadPage2)
public:
	CRtuKeypadPage2() : CRtuStatusBase2(CRtuKeypadPage2::IDD){};
	~CRtuKeypadPage2(){};
	LPBYTE SetStatus(LPBYTE, int, BOOL);
	void ShowStatus();
	void Print();
	BOOL IsValid() { return (m_devInfo.GetCount()>0); }
	enum { IDD = IDD_RTU_DEVINFO_KEYPADSTAT };

public:
	virtual BOOL OnInitDialog();
	virtual BOOL OnSetActive();
protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	DECLARE_MESSAGE_MAP()

private:
	int m_nNumColumns;
	CListCtrlEx m_kpdList;
	CImageList m_imgList;
	BOOL m_bKeySwitchInc;
	CDeviceInfoData m_devInfo;

	CString GetDeviceTypeString(int index);
	CString GetFirmwareVersionString(int index);
	CString GetBootloaderVersionString(int index);
	void UpdateStatusList();
};

/////////////////////////////////////////////////////////////////////////////
// CRtu16IOPage2 dialog
class CRtu16IOPage2 : public CRtuStatusBase2
{
	DECLARE_DYNCREATE(CRtu16IOPage2)
public:
	CRtu16IOPage2() : CRtuStatusBase2(CRtu16IOPage2::IDD){};
	~CRtu16IOPage2(){};
	LPBYTE SetStatus(LPBYTE, int, BOOL=FALSE);
	void ShowStatus();
	void Print();
	BOOL IsValid() { return (m_devInfo.GetCount()>0); }

	enum { IDD = IDD_RTU_DEVINFO_16IOSTAT };

public:
	virtual BOOL OnInitDialog();
	virtual BOOL OnSetActive();
protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	DECLARE_MESSAGE_MAP()

private:
	int m_nNumColumns;
	CListCtrlEx m_16ioList;
	CImageList m_imgList;
	CDeviceInfoData m_devInfo;

	CString GetDeviceTypeString(int index);
	CString GetFirmwareVersionString(int index);
	CString GetBootloaderVersionString(int index);
	void UpdateStatusList();
};

/////////////////////////////////////////////////////////////////////////////
// CRtuCamCtrlPage2 dialog
class CRtuCamCtrlPage2 : public CRtuStatusBase2
{
	DECLARE_DYNCREATE(CRtuCamCtrlPage2)
public:
	CRtuCamCtrlPage2() : CRtuStatusBase2(CRtuCamCtrlPage2::IDD){m_bInitialized = FALSE;};
	~CRtuCamCtrlPage2(){};
	LPBYTE SetStatus(LPBYTE, int, BOOL=FALSE);
	void ShowStatus();
	void Print();
	BOOL IsValid() { return (m_devInfo.GetCount()>0); }
	enum { IDD = IDD_RTU_DEVINFO_CAMSTAT };

public:
	virtual BOOL OnInitDialog();
	virtual BOOL OnSetActive();
protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	DECLARE_MESSAGE_MAP()

private:
	BOOL m_bInitialized;
	CListCtrlEx m_camCtrlList;
	CImageList m_imgList;
	CDeviceInfoData m_devInfo;

	void InitializeComponent();
};

/////////////////////////////////////////////////////////////////////////////
// CRtuElevCtrlPage2 dialog
class CRtuElevCtrlPage2 : public CRtuStatusBase2
{
	DECLARE_DYNCREATE(CRtuElevCtrlPage2)
public:
	CRtuElevCtrlPage2() : CRtuStatusBase2(CRtuElevCtrlPage2::IDD){m_bInitialized = FALSE;};
	~CRtuElevCtrlPage2(){};
	LPBYTE SetStatus(LPBYTE, int, BOOL=FALSE);
	void ShowStatus();
	void Print();
	BOOL IsValid() { return (m_devInfo.GetCount()>0); }
	enum { IDD = IDD_RTU_DEVINFO_ELEVSTAT };
	
public:
	virtual BOOL OnInitDialog();
	virtual BOOL OnSetActive();
protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	DECLARE_MESSAGE_MAP()

private:
	BOOL m_bInitialized;
	CListCtrlEx m_elevCtrlList;
	CImageList m_imgList;
	CDeviceInfoData m_devInfo;

	void InitializeComponent();
};


/////////////////////////////////////////////////////////////////////////////
// CRtuDialerPage2 dialog
class CRtuDialerPage2 : public CRtuStatusBase2
{
	DECLARE_DYNCREATE(CRtuDialerPage2)
public:
	CRtuDialerPage2() : CRtuStatusBase2(CRtuDialerPage2::IDD){m_bInitialized = FALSE;};
	~CRtuDialerPage2(){};
	LPBYTE SetStatus(LPBYTE, int, BOOL=FALSE);
	void ShowStatus();
	void Print();
	BOOL IsValid() { return (m_devInfo.GetCount()>0); }
	enum { IDD = IDD_RTU_DEVINFO_DIALERSTAT };

public:
	virtual BOOL OnInitDialog();
	virtual BOOL OnSetActive();
protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	DECLARE_MESSAGE_MAP()

private:
	BOOL m_bInitialized;
	CListCtrlEx m_dialList;
	CImageList m_imgList;
	CDeviceInfoData m_devInfo;

	void InitializeComponent();
};


/////////////////////////////////////////////////////////////////////////////
// CRtuCardRdrPage2 dialog
class CRtuCardRdrPage2 : public CRtuStatusBase2
{
	DECLARE_DYNCREATE(CRtuCardRdrPage2)
public:
	CRtuCardRdrPage2() : CRtuStatusBase2(CRtuCardRdrPage2::IDD){};
	~CRtuCardRdrPage2(){};
	LPBYTE SetStatus(LPBYTE, int, BOOL=FALSE);
	void ShowStatus();
	void Print();
	BOOL IsValid() { return m_devInfo.GetCount() > 0; }

	enum { IDD = IDD_RTU_DEVINFO_CRDRSTAT };

public:
	virtual BOOL OnInitDialog();
	virtual BOOL OnSetActive();
protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	DECLARE_MESSAGE_MAP()

private:  
	int m_nNumColumns;
	CListCtrlEx m_rdrList;
	CImageList m_imgList;
	CDeviceInfoData m_devInfo;

	CString GetDeviceTypeString(int index);
	CString GetFirmwareVersionString(int index);
	CString GetBootloaderVersionString(int index);
	void UpdateStatusList();
};


//====================================================================================//
//====================================================================================//
// CRtuInpStsPage2 dialog
class CRtuInpStsPage2 : public CRtuStatusBase2
{
	DECLARE_DYNCREATE(CRtuInpStsPage2)
// Construction
public:
	CRtuInpStsPage2();
	~CRtuInpStsPage2(){};
	LPBYTE SetStatus(LPBYTE, int, BOOL);
	void ShowStatus();
	void Print();
	void UpdateInputList();

	LPBYTE SetInpStsData(LPBYTE);
	LPBYTE SetLatchStsData(LPBYTE);
	LPBYTE SetSoakStsData(LPBYTE);
	LPBYTE SetExtendeInputData(LPBYTE);
	int GetNumInputs() {return m_numInputs;}
	BOOL IsValid() { return m_numInputs > 0; }
	
// Dialog Data
	//{{AFX_DATA(CRtuInpStsPage2)
	enum { IDD = IDD_RTU_INPSTAT_PAGE };
	CListCtrlEx	m_inputList;
	CImageList m_imgList;

		// NOTE - ClassWizard will add data members here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_DATA

// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CRtuInpStsPage2)
	public:
	virtual BOOL OnInitDialog();
	virtual BOOL OnSetActive();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CRtuInpStsPage2)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

private:
	int m_numInputs;
	int m_curInputNum;
	BYTE m_inputStatus[MAX_RTU_ALMPNTS];

	int m_numLatches;
	
	BYTE m_latchedStatus[MAX_RTU_ALMPNTS];

	int m_numSoaks;
	
	BYTE m_soakedStatus[MAX_RTU_ALMPNTS];

	BYTE m_inputExtendedStatus[MAX_RTU_ALMPNTS];
	BOOL m_hasInputExtendedStatus;
	int m_numInputExtendedStatus;
	int m_nNumColumns;
};

//====================================================================================//
//====================================================================================//
// CRtuOpStsPage2 dialog
class CRtuOpStsPage2 : public CRtuStatusBase2
{
	DECLARE_DYNCREATE(CRtuOpStsPage2)
// Construction
public:
	CRtuOpStsPage2() : CRtuStatusBase2(CRtuOpStsPage2::IDD){ m_numOutputs=0;};
	~CRtuOpStsPage2(){};
	LPBYTE SetStatus(LPBYTE, int=0, BOOL=FALSE);
	void ShowStatus();
	void Print();
	BOOL IsValid() { return m_numOutputs > 0; }

	int GetNumOutputs() {return m_numOutputs;}
// Dialog Data
	//{{AFX_DATA(CRtuOpStsPage2)
	enum { IDD = IDD_RTU_OPSTAT_PAGE };
		// NOTE - ClassWizard will add data members here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_DATA

// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CRtuOpStsPage2)
	public:
	virtual BOOL OnInitDialog();
	virtual BOOL OnSetActive();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CRtuOpStsPage2)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

private:  
	int m_numOutputs;
	
	BYTE m_outputStatus[MAX_RTU_ALMPNTS];
	CListCtrlEx	m_outputList;
	CImageList m_imgList;

};

//====================================================================================//
//====================================================================================//
// CRtuCamStsPage2 dialog
class CRtuCamStsPage2 : public CRtuStatusBase2
{
	DECLARE_DYNCREATE(CRtuCamStsPage2)
// Construction
public:
	CRtuCamStsPage2() : CRtuStatusBase2(CRtuCamStsPage2::IDD)
	{m_numCameras=0;};
	~CRtuCamStsPage2(){};
	LPBYTE SetStatus(LPBYTE, int=0, BOOL=FALSE);
	void ShowStatus();
	void Print();
	BOOL IsValid() { return m_numCameras > 0; }
	
	int GetNumCameras() {return m_numCameras;}
// Dialog Data
	//{{AFX_DATA(CRtuCamStsPage2)
	enum { IDD = IDD_RTU_CAMSTAT_PAGE };
		// NOTE - ClassWizard will add data members here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_DATA

// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CRtuCamStsPage2)
	public:
	virtual BOOL OnInitDialog();
	virtual BOOL OnSetActive();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CRtuCamStsPage2)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

private:  
	int m_numCameras;
	
	RTU_CAMSTATS m_cameraStatus[MAX_RTU_CAMPNTS];
	CListCtrlEx m_camerList;
	CImageList m_imgList;
};


//====================================================================================//
//====================================================================================//
// CRtuCctvStsPage2 dialog
class CRtuCctvStsPage2 : public CRtuStatusBase2
{
	DECLARE_DYNCREATE(CRtuCctvStsPage2)
// Construction
public:
	CRtuCctvStsPage2() : CRtuStatusBase2(CRtuCctvStsPage2::IDD){
	m_numCCTVs=0;};
	~CRtuCctvStsPage2(){};
	LPBYTE SetStatus(LPBYTE, int=0, BOOL=FALSE);
	void ShowStatus();
	void Print();
	BOOL IsValid() { return m_numCCTVs > 0; }
	
	int GetNumCctvs() {return m_numCCTVs;}
	
// Dialog Data
	//{{AFX_DATA(CRtuCctvStsPage2)
	enum { IDD = IDD_RTU_CCTVSTAT_PAGE };
		// NOTE - ClassWizard will add data members here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_DATA

// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CRtuCctvStsPage2)
	public:
	virtual BOOL OnInitDialog();
	virtual BOOL OnSetActive();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CRtuCctvStsPage2)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

private:  
	int m_numCCTVs;
	
	BYTE m_cctvStatus[MAX_RTU_ALMPNTS];
	CListCtrlEx m_cctvList;
	CImageList m_imgList;
};
/////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////
// CRtuDoorStatusPage2 dialog
class CRtuDoorStatusPage2 : public CRtuStatusBase2
{
	DECLARE_DYNCREATE(CRtuDoorStatusPage2)
// Construction
public:
	CRtuDoorStatusPage2() : CRtuStatusBase2(CRtuDoorStatusPage2::IDD)
	{
		m_numReaders=0; m_curReaderNum=0; memset(m_readerStatus, 0, sizeof(m_readerStatus));
	};
	~CRtuDoorStatusPage2(){};
	LPBYTE SetStatus(LPBYTE, int=0, BOOL=FALSE);
	void ShowStatus();
	int GetNumReaders(){return m_numReaders;}
	void Print();
	BOOL IsValid() { return m_numReaders > 0; }
// Dialog Data
	//{{AFX_DATA(CRtuDoorStatusPage2)
	enum { IDD = IDD_RTU_RDRSTATS };
	//CMyChkButton m_btnDrCont1;
		// NOTE - ClassWizard will add data members here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_DATA

// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CRtuDoorStatusPage2)
	public:
	virtual BOOL OnInitDialog();
	virtual BOOL OnSetActive();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CRtuDoorStatusPage2)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

private:
	int m_numReaders;
	int m_curReaderNum;
	BYTE m_readerStatus[MAX_RTU_RDRS];
	CListCtrlEx m_rdrList;
	CImageList m_imgList;
};



/////////////////////////////////////////////////////////////////////////////
// CRtuElevFlrPage2 dialog
class CRtuElevFlrPage2 : public CRtuStatusBase2
{
	DECLARE_DYNCREATE(CRtuElevFlrPage2)
// Construction
public:
	CRtuElevFlrPage2() : CRtuStatusBase2(CRtuElevFlrPage2::IDD)
	{
		m_numElevators=0; m_curElevatorNum=0; memset(&m_elevatorStatus[0], 0, sizeof(m_elevatorStatus));
	};
	~CRtuElevFlrPage2(){};
	LPBYTE SetStatus(LPBYTE, int=0, BOOL=FALSE);
	void ShowStatus();
	int GetNumElevators(){return m_numElevators;}
	void Print();
	BOOL IsValid() { return m_numElevators > 0; }
// Dialog Data
	//{{AFX_DATA(CRtuElevFlrPage2)
	enum { IDD = IDD_RTU_ELEVSTATS };
	// NOTE - ClassWizard will add data members here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_DATA

// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CRtuElevFlrPage2)
	public:
	virtual BOOL OnInitDialog();
	virtual BOOL OnSetActive();
	afx_msg void OnBtnFloor();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CRtuElevFlrPage2)
	afx_msg void OnUpDownElevSts(NMHDR* pNMHDR, LRESULT* pResult);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

private:
	int m_numElevators;
	int m_curElevatorNum;
	
	RTU_ELEVSTATS m_elevatorStatus[MAX_RTU_ELEVRECS];

	CChkButton m_btn1;
	CChkButton m_btn2;
	CChkButton m_btn3;
	CChkButton m_btn4;
	CChkButton m_btn5;
	CChkButton m_btn6;
	CChkButton m_btn7;
	CChkButton m_btn8;

	CStaticColor m_lblElevNum;
	CListCtrlEx m_lstOffStatus;
	CChkButton m_chkFlrAccess;
	CChkButton m_chkFlrRestore;
};

/////////////////////////////////////////////////////////////////////////////
// CRtuDriveStatusPage2 Page dialog
class CRtuDriveStatusPage2 : public CRtuStatusBase2
{
	DECLARE_DYNCREATE(CRtuDriveStatusPage2)
// Construction
public:
	CRtuDriveStatusPage2() : CRtuStatusBase2(CRtuDriveStatusPage2::IDD)
	{
		m_ptrDriveStatus = NULL;
	};
	~CRtuDriveStatusPage2(){};
	LPBYTE SetStatus(LPBYTE, int=0, BOOL=FALSE);
	void ShowStatus();
	int GetNumDrives(){return m_nNumDrives;}
	void Print();
	BOOL IsValid() { return m_nNumDrives > 0; }
// Dialog Data
	//{{AFX_DATA(CRtuDriveStatusPage2)
	enum { IDD = IDD_RTU_DRIVE_STATS };
		// NOTE - ClassWizard will add data members here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_DATA

// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CRtuDriveStatusPage2)
	public:
	virtual BOOL OnInitDialog();
	virtual BOOL OnSetActive();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CRtuDriveStatusPage2)
	afx_msg void OnUpDownCamRecTimes(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnUpDownMicRecTimes(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnUpDownDriveStatus(NMHDR* pNMHDR, LRESULT* pResult);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

private:
	int m_nNumDrives;
	int m_nCurDrive;
	int m_nNumCamRecTimes;
	int m_nCurCamRecTime;
	int m_nNumMicRecTimes;
	int m_nCurMicRecTime;
	int m_nModelNameSize;

	RTU_DRIVESTATS* m_ptrDriveStatus;

	CStaticColor m_lblDriveNum;
	CStaticColor m_lblPhysSize;
	CStaticColor m_lblPhysSizeFormatted;
	CStaticColor m_lblPhysSizeRemain;
	CStaticColor m_lblModelName;

	CStaticColor m_lblCamNum;
	CStaticColor m_lblCamOldestTime;
	CStaticColor m_lblCamYoungestTime;

	CStaticColor m_lblMicNum;
	CStaticColor m_lblMicOldestTime;
	CStaticColor m_lblMicYoungestTime;


	void GetTime(CString& str, TIME*);
	void ShowCamRecTime();
	void ShowMicRecTime();
};

/////////////////////////////////////////////////////////////////////////////
// CRtuPowerMonitorStatusPage2 Page dialog
class CRtuPowerMonitorStatusPage2 : public CRtuStatusBase2
{
	DECLARE_DYNCREATE(CRtuPowerMonitorStatusPage2)
// Construction
public:
	enum {E_TYPE_BATTERY = 0, E_TYPE_POWER = 1, E_TYPE_TEMPERATURE = 2, E_NUM_STATUS_READINGS = 11};
	CRtuPowerMonitorStatusPage2();// : CPropertyPage(CRtuPowerMonitorStatusPage::IDD){};
	~CRtuPowerMonitorStatusPage2();//{};
	LPBYTE SetStatus(LPBYTE, int=0, BOOL=FALSE);
	void ShowStatus();
	int GetNumDevices(){return m_nNumDevices;}
	void Print();
	BOOL IsValid() { return m_nNumDevices > 0; }
// Dialog Data
	//{{AFX_DATA(CRtuPowerMonitorStatusPage2)
	enum { IDD = IDD_RTU_POW_MON_STATS2 };
		// NOTE - ClassWizard will add data members here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_DATA

// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CRtuPowerMonitorStatusPage2)
	public:
	virtual BOOL OnInitDialog();
	virtual BOOL OnSetActive();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CRtuPowerMonitorStatusPage2)
	afx_msg void OnUpDownDeviceStatus(NMHDR* pNMHDR, LRESULT* pResult);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

private:
	int m_nNumDevices;
	int m_nCurDevice;
	LPPOWER_MONITOR_STATUS m_pStatus;
	BYTE m_Flag1, m_Flag2;

	CString GetStatusString(int index, int value);

	CMarkupBox	m_lblDevNum;

	CMarkupBox		m_lblFlags;
	CMarkupStatic	m_lblFlags1;
	CMarkupStatic	m_lblFlags2;
	CMarkupStatic	m_lblFlags1Text;
	CMarkupStatic	m_lblFlags2Text;

	CMarkupBox		m_lblGen;
	CMarkupBox		m_lblGenGroup1;
	CMarkupBox		m_lblGenGroup2;
	CMarkupStatic	m_lblGenStatus;
	CMarkupStatic	m_lblGenText;
	CMarkupStatic	m_lblGenStatus2;
	CMarkupStatic	m_lblGenText2;

	void ShowFlags();
	void ShowGeneralParams();
	void ShowText();

};


/////////////////////////////////////////////////////////////////////////////
// CRtuVaultControllerStatusPage2 Page dialog
class CRtuVaultControllerStatusPage2 : public CRtuStatusBase2
{
	DECLARE_DYNCREATE(CRtuVaultControllerStatusPage2)
// Construction
public:
	CRtuVaultControllerStatusPage2();
	~CRtuVaultControllerStatusPage2();
	LPBYTE SetStatus(LPBYTE, int=0, BOOL=FALSE);
	void ShowStatus();
	int GetNumDevices(){return m_nNumDevices;}
	void Print();
	BOOL IsValid() { return m_nNumDevices > 0; }
// Dialog Data
	//{{AFX_DATA(CRtuVaultControllerStatusPage2)
	enum { IDD = IDD_RTU_VAULT_CTRL_STATS2 };
		// NOTE - ClassWizard will add data members here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_DATA

// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CRtuVaultControllerStatusPage2)
	public:
	virtual BOOL OnInitDialog();
	virtual BOOL OnSetActive();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CRtuVaultControllerStatusPage2)
	afx_msg void OnUpDownDeviceStatus(NMHDR* pNMHDR, LRESULT* pResult);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

private:
	int m_nNumDevices;
	int m_nCurDevice;
	LPVAULT_CONTROLLER m_pStatus;
	BYTE m_Flag1;
	CStringArray m_strArrVaultStatus;

	CMarkupBox m_lblVaultNum;

	CMarkupBox m_lblFlags;
	CMarkupStatic m_lblFlagsCheck;
	CMarkupStatic m_lblFlagsText;

	CMarkupBox m_lblVault;
	CMarkupStatic m_lblVaultStatus;
	CMarkupStatic m_lblVaultText;

	void ShowFlags();
	void ShowGenStatus();

};

typedef struct _StatusItems
{
	CXTPPropertyPage* Pages[STATUS_PAGE_CNT]; 
	HTREEITEM Items[STATUS_PAGE_CNT];
	int Count;
} StatusItems;

class CCategoriesTreeNavigator : public CXTPPropertyPageTreeNavigator
{
public:
	CCategoriesTreeNavigator();
	BOOL CreateTree();
	BOOL RecreateTree(StatusItems* pTree);
	void OnPageSelected(CXTPPropertyPage* pPage);

private:
	CImageList m_imgList;
};

#define CRTUStatus2Base CGenDialog

/////////////////////////////////////////////////////////////////////////////////
//TT 7804: _DEVICE8501
/////////////////////////////////////////////////////////////////////////////////
#pragma region FullDeviceStatus_8501

#pragma pack(1)
// this structure will be expanded
#define MAX_EXPANSION_STS	4

struct _expansionSts
{
	BYTE size;
	BYTE properties;
};

struct _fullDvcStatusData
{
	BYTE	pacomType;
	BYTE	dvcLoopType;
	BYTE	dvcLoopAddress;
	BYTE	dvcNum;
	BYTE	cr1Num;
	BYTE	cr2Num;
	BYTE	dvcPropertyBytes;
	//--------------------
	// extended properties.
	BYTE	byte8;					//.1
	BYTE	byte9;					//.2
	BYTE	byte10;					//.3
	BYTE	byte11;					//.4
	BYTE	fwareMinorVersion;		//.5
	BYTE	fwareMajorVersion;		//.6
	BYTE	bootloadMinorVersion;	//.7
	BYTE	bootloadMajorVersion;	//.8
	BYTE	portNum;				//.9
	BYTE	offlineCount;			//.10
	BYTE	tamperCount;			//.11
	BYTE	serialNum[16];			//.12..27
	BYTE	alternatePortNum;		//.28
	BYTE	ipAddress[4];			//.29..32
	BYTE	expansionCardCount;		//.33
	
	_expansionSts expansion[MAX_EXPANSION_STS];		
};
#pragma pack()

class CRtuFullDeviceStatusPage2 : public CRtuStatusBase2
{
	DECLARE_DYNCREATE(CRtuFullDeviceStatusPage2)
// Construction
public:

	CRtuFullDeviceStatusPage2() : CRtuStatusBase2(CRtuFullDeviceStatusPage2::IDD)
	{
		m_numDevices=0; 
		m_curDeviceNum=0; 
		m_pStatus = 0;
		m_isColumnInit = 0;
		
		GetStandardColumnNameAndIDs();
	};

	~CRtuFullDeviceStatusPage2(){delete [] m_pStatus; m_pStatus = NULL;};
	
	LPBYTE SetStatus(LPBYTE, int, BOOL);
	void ShowStatus();

	int GetNumDevices(){return m_numDevices;}
	
	void Print();
	BOOL IsValid() { return m_numDevices > 0; }
// Dialog Data
	//{{AFX_DATA(CRtuFullStatusDevicePage2)
	enum { IDD = IDD_RTU_FULL_DEVICE_STS };
	//CMyChkButton m_btnDrCont1;
		// NOTE - ClassWizard will add data members here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_DATA

// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CRtuFullStatusDevicePage2)
	public:
	virtual BOOL OnInitDialog();
	virtual BOOL OnSetActive();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CRtuFullStatusDevicePage2)
	afx_msg void OnDestroy();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

private:
	CMap<int, int, CString, CString> m_IdAndNames;
	CMap<int, int, CString, CString> m_ExIdAndNames;
	
	BOOL		m_expansionSlot[MAX_EXPANSION_STS]; 
			
	BOOL	m_isColumnInit;
	
	int m_numDevices;
	int m_curDeviceNum;
	
	CStringArray m_PacomDevNames;
	CString m_strYes;
	CString m_strNo;

	LPBYTE m_pStatus;
	
	CImageList m_imgList;
	CXTListCtrl m_deviceList;

	int GetDeviceStructSize(LPBYTE pDvcStatus);
	CString GetPacomDeviceName(int deviceId);

	void AddDeviceStatus(int item, _fullDvcStatusData& dvc);
	
	CString FormatColumnText(int columnId, _fullDvcStatusData& dvc);
	
	void InitColumns();
	void InitUserColumns();
	
	void GetStandardColumnNameAndIDs();
	void AddColumn(int colParam, CString& text);
	////////////////////////////////////////////////////////////////////
	enum _colHeaderType {
		ePacomtype				= 0,
		eDeviceLoopType			= 1,
		eDeviceLoopAddress		= 2,
		eLogicalDeviceNumber	= 3,
		eCR1IndexNum = 4,
		eCR2IndexNum = 5,

		//byte 8
		eOffline	= 6,
		eOfflineReportLatched	= 7,
		eTamper					= 8,
		eTamperReportLatched	= 9,
		eIsolated				= 10,
		eCR1Isolated			= 11,
		eCR2Isolated			= 12,
		eVoltageFailed			= 13,
		
		// byte 9
		eNoBattery				= 14,
		eBatteryLow				= 15,
		eLANConnected			= 16,
		eDownLoadInProgress		= 17,
		// 18..37
		e18,
		e19,
		e20,
		e21,
		
		//byte 10
		e22,
		e23,
		e24,
		e25,
		e26,
		e27,
		e28,
		e29,
		
		//byte 11
		e30,
		e31,
		e32,
		e33,
		e34,
		e35,
		e36,
		e37,

		eFirmwareVersion = 38,
		eBootloadVersion = 39,
		
		eRtuPortNum = 40,
		eOfflineCount = 41,
		eTamperCount = 42,

		eDeviceSerialNum = 43,
		eAlternateRtuPortNum = 44,
		eIPAddress = 45,
		eNumExpansionCards = 46,
		eExpansionOffline = 47,
		eExpansionFuseFail = 48,

	};

	enum _deviceStatusType {STS_NORMAL=0, STS_TAMPERED, STS_ISOLATE, STS_ALARM};
	enum _deviceBmpType {DVC_BMP=0, KP_BMP, CR_BMP, FL_BMP, DOOR_BMP, IO_BMP, MAX_BMP_TYPE};

	int		GetDviceBmpIndex(_fullDvcStatusData& sts);
	int		GetDeviceStatus(_fullDvcStatusData& sts);
	BOOL	IsExpansionProperty(int colHeaderType);
	int		m_colIds[255];

	int		m_colCount;
};

#pragma endregion FullDeviceStatus_8501
/////////////////////////////////////////////////////////////////////
class CRTUStatus2 : public CRTUStatus2Base
{
// Construction
public:
	CRTUStatus2(); 
	~CRTUStatus2();
	virtual int GetMyDialogID() { return IDD; };
	void Init(LPPARMPROC lpps, int nOption, BYTE nMask, CWnd* pParent = NULL);
	void Reset();
	BOOL IsValid() { return m_bIsValid; }
	BOOL GetStatus(BYTE nMask);
private:
	LPBYTE SetDevInfoStatus(LPBYTE, BYTE);
	LPBYTE Copy(LPBYTE, LPBYTE, int, int, BOOL bKeypad=0);
	LPBYTE	GetStatusPtr(LPBYTE p1);
	void SetPageIcon();
	void ShowStatus();
	BOOL GetStatus();
	LPBYTE AddStatusPage(int nPage, LPBYTE pData, BOOL bAdded, ulong mask, CRtuStatusBase2* pPage, int cnt=0, BOOL inc=FALSE);
// Dialog Data
	//{{AFX_DATA(CRTUStatus2)
	enum { IDD = IDD_RTU_STATUS2 };
	//}}AFX_DATA
	
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CRTUStatus2)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CRTUStatus2)
	virtual BOOL OnInitDialog();
	afx_msg void OnClose();
	afx_msg void OnBtnRefresh();
	afx_msg LRESULT OnTextMessage(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT	OnGMS(WPARAM wParam, LPARAM lParam);
	afx_msg void OnPrintModeStatus();
	afx_msg void OnPrintPanelStatus();
	afx_msg void OnPrintInputStatus();
	afx_msg void OnPrintOutputStatus();
	afx_msg void OnPrintCameraStatus();
	afx_msg void OnPrintDevInfoKeypadStatus();
	afx_msg void OnPrintDevInfo16IOStatus();
	afx_msg void OnPrintDevInfoCamCtrlStatus();
	afx_msg void OnPrintDevInfoElevCtrlStatus();
	afx_msg void OnPrintDevInfoDialerStatus();
	afx_msg void OnPrintDevInfoCardRdrStatus();
	afx_msg void OnPrintDoorStatus();
	afx_msg void OnPrintCctvStatus();
	afx_msg void OnPrintElevatorStatus();
	afx_msg void OnPrintDriveStatus();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	enum {
		Panel57Page				= 1, 
		Panel60Page				= 2, 
		ModePage				= 4, 
		DevInfoKeypadPage		= 8, 
		DevInfoIoPage			= 0x10,
		DevInfoCameraPage		= 0x20,
		DevInfoElevatorPage		= 0x40,
		DevInfoDialerPage		= 0x80,
		DevInfoCardReaderPage	= 0x100,
		OutputPage				= 0x200,
		CameraPage				= 0x400,
		CctvPage				= 0x800,
		InputPage				= 0x1000,
		DoorPage				= 0x2000,
		ElevatorFloorPage		= 0x4000,
		DrivePage				= 0x8000,
		PowerMonitorPage		= 0x10000,
		VaultControllerPage		= 0x20000,
		FullDeviceStatusPage	= 0x40000
	};
	enum _PageIndex{
		P_MODE = 0,
		P_1057,
		P_INPUT,
		P_OUTPUT,
		P_CAMERA, //.4
		P_DEV_KEYPAD, //P_DEV_INFO, //TT 8327
		P_DEV_IO,
		P_DEV_CAM,
		P_DEV_ELEVATOR,
		P_DEV_DIALER,
		P_DEV_CRIF,
		P_READER, //.11
		P_CCTV,
		P_ELEVATOR,
		P_DRIVE,
		P_POWER,
		P_VAULT_CTRL,
		P_FULL_DEV_STS,
	};

	CWnd* m_pParent;
	BOOL m_bIsValid;
	BYTE m_nMask;
	BOOL m_bStartup;
	LPPARMPROC m_lpps;
	PARMPROC	m_pps;
	BYTE m_ParmProcData[RTU_BUFF_SIZE];
	std::unique_ptr<BYTE[]> m_StatusBuffer;
	uint  m_StatusBufferSize;
	ulong							m_pages;
	CRtuPanelPage2					m_pagePanel;
	CRtuModePage2					m_pageMode;
	CRtuKeypadPage2					m_pageKeypad;
	CRtu16IOPage2					m_page16IO;
	CRtuCamCtrlPage2				m_pageCamCtrl;
	CRtuElevCtrlPage2				m_pageElevCtrl;
	CRtuDialerPage2					m_pageDialer;
	CRtuCardRdrPage2				m_pageCardRdr;
	CRtuOpStsPage2					m_pageOpSts;
	CRtuCamStsPage2					m_pageCamSts;
	CRtuCctvStsPage2				m_pageCctvSts;
	CRtuInpStsPage2					m_pageInpSts;
	CRtuDoorStatusPage2				m_pageReader;
	CRtuElevFlrPage2				m_pageElevFlr;
	CRtuDriveStatusPage2			m_pageDriveStatus;	
	CRtuPowerMonitorStatusPage2		m_pagePowerMonitorStatus;
	CRtuVaultControllerStatusPage2	m_pageVaultCtrlStatus;
	CRtuFullDeviceStatusPage2		m_pageFullDevStatus; //TT 7804: _DEVICE8501
	CXTPPropertySheet	m_ps;
	StatusItems m_StatusItems;
};

