#pragma once


#include "HardwareConfig\cpucard\SoftVerInfo.h"
#include "Gms\CommonUse\GenericHardwareConfigDataEnvelope.h"
#include "RtuRes\Resource.h"
#include "HardwareConfig\RtuSoftwareInfo.h"

#pragma	pack(1)
typedef union _SoftVersion {
	VERSION		oVer;
	SOFTVERINFO	nVer;
	}RTUVERSION, far *LPRTUVERSION;
#pragma	pack()

/////////////////////////////////////////////////////////////////////////////
// CRtuVersion
class CRtuVersion	: public CDialog
{
// Construction
public:
	CRtuVersion(LPPARMPROC lpps, CWnd* pParent = NULL) : 
		CDialog(CRtuVersion::IDD, pParent) { 
		m_lpps = lpps;				  
	};   // standard constructor
// Dialog Data
	//{{AFX_DATA(CRtuVersion)
	enum { IDD = IDD_RTU_VERSIONNO_DLG };
	//}}AFX_DATA

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CRtuVersion)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//virtual BOOL OnCommand(WPARAM wParam, LPARAM lParam);
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CRtuVersion)
	virtual BOOL OnInitDialog();
	afx_msg LRESULT OnGms(WPARAM wParam, LPARAM lParam);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	LPPARMPROC m_lpps;
private:
	void Dis_Soft_Ver(int);

};

