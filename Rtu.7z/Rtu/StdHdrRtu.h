#pragma once

#define	__NO_USER_FNS
#define _GMS_DO_NOT_USE_GMS_RESOURCE_H_ // to prevent using GMS's own resource.h included via common.h

