///********************************************************************************************************
// *		PACOM SYSTEMS PTY LTD 	Copyright 2002
// *		File/Class Name:	GalaxyPanel.cpp	
// *		Description: 
// *		
// *		$Revision: 2 $History:
// * 
// ********************************************************************************************************/
#include "stdafx.h"

#include "GalaxyPanel.h"

/*=========================================================================*/
CRtuGalaxyID::CRtuGalaxyID(LPPARMPROC lpps, CWnd* pParent) : CDialog(CRtuGalaxyID::IDD, pParent) 
{
	memcpy(&m_lpps, lpps, sizeof(m_lpps));
	m_userType = USER_PASSWORD;
};


void CRtuGalaxyID::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CRtuGalaxyID)
	DDX_Control(pDX, IDC_TXT_USER_NUM, m_txtNumber);
	DDX_Text(pDX, IDC_TXT_USER_NUM, m_strNumber);
	DDX_Text(pDX, IDC_TXT_USER_NAME, m_strName);
	DDX_Text(pDX, IDC_TXT_USER_PASSWORD, m_strPassword);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CRtuGalaxyID, CDialog)
	//{{AFX_MSG_MAP(CRtuGalaxyID)
	ON_BN_CLICKED(IDOK, OnOK)
	ON_BN_CLICKED(IDCANCEL, OnCancel)
	ON_BN_CLICKED(IDC_RAD_USER, OnBtnUser)
	ON_BN_CLICKED(IDC_RAD_MANAGER, OnBtnManager)
	ON_BN_CLICKED(IDC_RAD_ENGINEER, OnBtnEngineer)
	ON_BN_CLICKED(IDC_RAD_REMOTE, OnBtnRemote)
	ON_BN_CLICKED(IDC_RAD_SITE, OnBtnSite)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CRtuGalaxyID message handlers
BOOL CRtuGalaxyID::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	m_lpps.heDlg = GetSafeHwnd();
	m_lpps.hmDlg = m_lpps.heDlg;

	CheckRadioButton(IDC_RAD_UPLOAD, IDC_RAD_DOWNLOAD, IDC_RAD_UPLOAD);
	CheckRadioButton(IDC_RAD_USER, IDC_RAD_REMOTE, IDC_RAD_USER);
	m_txtNumber.SetMinMaxLimit(1, 97, 2);
	SendDlgItemMessage(IDC_TXT_USER_NAME, EM_SETLIMITTEXT, 6);
	SendDlgItemMessage(IDC_TXT_USER_PASSWORD, EM_SETLIMITTEXT, 6);
	m_userType = USER_PASSWORD;
	
	GetDlgItem(IDC_TXT_USER_NUM)->SetFocus();
		// TODO: Add extra initialization here
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CRtuGalaxyID::OnBtnUser()
{
	m_userType = USER_PASSWORD;
	m_strNumber = _T("");
	m_strName = _T("");
	m_strPassword = _T("");
	SetDlgItemText(IDC_LBL_USER_NUM, _T("User Num&ber: "));
	SetDlgItemText(IDC_LBL_USER_NAME, _T("User &Name: "));
	SetDlgItemText(IDC_LBL_USER_PASSWORD, _T("User &Password: "));
	GetDlgItem(IDC_TXT_USER_NAME)->EnableWindow(TRUE);
	GetDlgItem(IDC_TXT_USER_NUM)->EnableWindow(TRUE);
	
	GetDlgItem(IDC_TXT_USER_NUM)->SetFocus();
	UpdateData(FALSE);
}

void CRtuGalaxyID::OnBtnManager()
{
	m_userType = MANAGER_PASSWORD;
	m_strNumber = _T("98");
	m_strName = _T("MGR.");
	m_strPassword = _T("");
	SetDlgItemText(IDC_LBL_USER_NUM, _T("Manager Num&ber: "));
	SetDlgItemText(IDC_LBL_USER_NAME, _T("Manager &Name: "));
	SetDlgItemText(IDC_LBL_USER_PASSWORD, _T("Manager &Password: "));
	GetDlgItem(IDC_TXT_USER_NAME)->EnableWindow(FALSE);
	GetDlgItem(IDC_TXT_USER_NUM)->EnableWindow(FALSE);
	
	GetDlgItem(IDC_TXT_USER_PASSWORD)->SetFocus();
	UpdateData(FALSE);
}

void CRtuGalaxyID::OnBtnEngineer()
{
	m_userType = ENGINEERING_PASSWORD;
	m_strNumber = _T("99");
	m_strName = _T("ENG.");
	m_strPassword = _T("");
	SetDlgItemText(IDC_LBL_USER_NUM, _T("Engineer Num&ber: "));
	SetDlgItemText(IDC_LBL_USER_NAME, _T("Engineer &Name: "));
	SetDlgItemText(IDC_LBL_USER_PASSWORD, _T("Engineer &Password: "));
	GetDlgItem(IDC_TXT_USER_NAME)->EnableWindow(FALSE);
	GetDlgItem(IDC_TXT_USER_NUM)->EnableWindow(FALSE);
	
	GetDlgItem(IDC_TXT_USER_PASSWORD)->SetFocus();
	UpdateData(FALSE);
}

void CRtuGalaxyID::OnBtnRemote()
{
	m_userType = REMOTE_PASSWORD;
	m_strNumber = _T("100");
	m_strName = _T("REMOTE");
	m_strPassword = _T("");
	SetDlgItemText(IDC_LBL_USER_NUM, _T("Remote Num&ber: "));
	SetDlgItemText(IDC_LBL_USER_NAME, _T("Remote &Name: "));
	SetDlgItemText(IDC_LBL_USER_PASSWORD, _T("Remote &Password: "));
	GetDlgItem(IDC_TXT_USER_NAME)->EnableWindow(FALSE);
	GetDlgItem(IDC_TXT_USER_NUM)->EnableWindow(FALSE);
	
	GetDlgItem(IDC_TXT_USER_PASSWORD)->SetFocus();
	UpdateData(FALSE);
}

void CRtuGalaxyID::OnBtnSite()
{
	m_userType = SITE_PASSWORD;
	m_strNumber = _T("");
	m_strName = _T("");
	m_strPassword = _T("");
	SetDlgItemText(IDC_LBL_USER_NUM, _T("Site Num&ber: "));
	SetDlgItemText(IDC_LBL_USER_NAME, _T("Site &Name: "));
	SetDlgItemText(IDC_LBL_USER_PASSWORD, _T("Site &Password: "));
	GetDlgItem(IDC_TXT_USER_NAME)->EnableWindow(FALSE);
	GetDlgItem(IDC_TXT_USER_NUM)->EnableWindow(FALSE);
	
	GetDlgItem(IDC_TXT_USER_PASSWORD)->SetFocus();
	UpdateData(FALSE);
}


void CRtuGalaxyID::OnOK()
{
	static  char data[264];
	int rtu = MAKERTUNO(m_lpps.eType, m_lpps.eNo);
	PCPCMD	pc;
	int bc=4; // bc = download byte + user number byte + password bc + name bc
	int psBC=0, nBC=0;
	memset(&pc, 0, sizeof(pc));
	memset(data, 0, sizeof(data));

	UpdateData(TRUE);

	pc.addr1 = (BYTE)GETGROUPNO(rtu);
	pc.addr2 = (BYTE)GETRTUOFFSET(rtu);
	data[1] = 35;	// Function Code
	int subfc = IsDlgButtonChecked(IDC_RAD_SITE) ? 0x02 : 0x01;	//Download
	data[5] = (BYTE)subfc;
	
	//Get User Number
	int number = 0;	// dummy number for site password
	if(m_userType != SITE_PASSWORD)
		number = GetDlgItemInt(IDC_TXT_USER_NUM) - 1;

	if(m_userType == USER_PASSWORD && number >= 97) {
		DispMessageBox2(GetSafeHwnd(), IDS_ENTER_RANGE, IDS_ERROR, MB_OK|MB_ICONSTOP, 1, 97);
		GetDlgItem(IDC_TXT_USER_NUM)->SetFocus();
		return;
	}
	data[6] = (BYTE)number;
	
	//Get Password
	if((psBC = m_strPassword.GetLength()) < 1) {
		DispMessageBox(GetSafeHwnd(), IDS_ENT_PASSWORD, IDS_ERROR, MB_OK|MB_ICONSTOP);
		GetDlgItem(IDC_TXT_USER_PASSWORD)->SetFocus();
		return;
	}

	if(psBC < 4) {
		// Add leading 0
		for(int i=0; i<4-psBC; i++)
			m_strPassword.Insert(0, _T("0"));
		psBC = 4;
	}
	wsprintfA(&data[8], "%ls", (LPCTSTR)m_strPassword);
	data[7] = (BYTE)psBC;
	bc += psBC;
	
	//Get Name
	if(m_userType != SITE_PASSWORD) {
		if((nBC = m_strName.GetLength()) > 0) {
			wsprintfA(&data[9 + psBC], "%ls", (LPCTSTR)m_strName);
			data[8 + psBC] = (BYTE)nBC;
			bc += nBC;
		}
	}

	data[0] = (BYTE)(bc + 5);	// number of byte counts

	pc.cport = 0;
	pc.lpCmd = (LPBYTE)data;
	pc.hWnd = GetSafeHwnd();
	pc.busy = 1;
	pc.errCode = 0;
	pc.bWait = 1;
	pc.msgRet = IDD_COMMOVR;
	pc.timer = 100;
	pc.bDisErr = 1;
	SendGPPcpCommand(&pc, 0);
}

void CRtuGalaxyID::OnCancel()
{
	CDialog::OnCancel();
}










/*=========================================================================*/
/*=========================================================================*/
CRtuDscID::CRtuDscID(LPPARMPROC lpps, CWnd* pParent) : CDialog(CRtuDscID::IDD, pParent) 
{
	memcpy(&m_lpps, lpps, sizeof(m_lpps));
	m_userType = USER_PASSWORD;
};


void CRtuDscID::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CRtuDscID)
	DDX_Control(pDX, IDC_TXT_USER_PASSWORD, m_txtPassword);
	DDX_Text(pDX, IDC_TXT_USER_PASSWORD, m_strPassword);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CRtuDscID, CDialog)
	//{{AFX_MSG_MAP(CRtuDscID)
	ON_BN_CLICKED(IDOK, OnOK)
	ON_BN_CLICKED(IDCANCEL, OnCancel)
	ON_BN_CLICKED(IDC_RAD_USER, OnBtnUser)
	ON_BN_CLICKED(IDC_RAD_MANAGER, OnBtnManager)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CRtuDscID message handlers
BOOL CRtuDscID::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	m_lpps.heDlg = GetSafeHwnd();
	m_lpps.hmDlg = m_lpps.heDlg;

	CheckRadioButton(IDC_RAD_USER, IDC_RAD_MANAGER, IDC_RAD_USER);
	m_txtPassword.SetMinMaxLimit(0, 999999, 6);
	m_userType = USER_PASSWORD;
	
		// TODO: Add extra initialization here
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CRtuDscID::OnBtnUser()
{
	m_userType = USER_PASSWORD;
	m_strPassword = _T("");
	SetDlgItemText(IDC_LBL_USER_PASSWORD, _T("User &Password: "));
	UpdateData(FALSE);
}

void CRtuDscID::OnBtnManager()
{
	m_userType = MANAGER_PASSWORD;
	m_strPassword = _T("");
	SetDlgItemText(IDC_LBL_USER_PASSWORD, _T("Manager &Password: "));
	UpdateData(FALSE);
}

void CRtuDscID::OnOK()
{
	static  char data[264];
	int rtu = MAKERTUNO(m_lpps.eType, m_lpps.eNo);
	PCPCMD	pc;
	int bc=1;	// user type
	int psBC=0;
	memset(&pc, 0, sizeof(pc));
	memset(data, 0, sizeof(data));

	UpdateData(TRUE);

	pc.addr1 = (BYTE)GETGROUPNO(rtu);
	pc.addr2 = (BYTE)GETRTUOFFSET(rtu);
	data[1] = 35;	// Function Code
	data[5] = (BYTE)m_userType;

	//Get Password
	if((psBC = m_strPassword.GetLength()) < 1) {
		DispMessageBox(GetSafeHwnd(), IDS_ENT_PASSWORD, IDS_ERROR, MB_OK|MB_ICONSTOP);
		GetDlgItem(IDC_TXT_USER_PASSWORD)->SetFocus();
		return;
	}

	if(psBC < 4) {
		// Add leading 0
		for(int i=0; i<4-psBC; i++)
			m_strPassword.Insert(0, _T("0"));
		psBC = 4;
	}
	wsprintfA(&data[6], "%ls", (LPCTSTR)m_strPassword);
	bc += psBC;

	data[0] = (BYTE)(bc + 5);	// number of byte counts

	pc.cport = 0;
	pc.lpCmd = (LPBYTE)data;
	pc.hWnd = GetSafeHwnd();
	pc.busy = 1;
	pc.errCode = 0;
	pc.bWait = 1;
	pc.msgRet = IDD_COMMOVR;
	pc.timer = 100;
	pc.bDisErr = 1;
	SendGPPcpCommand(&pc, 0);
}

void CRtuDscID::OnCancel()
{
	CDialog::OnCancel();
}

