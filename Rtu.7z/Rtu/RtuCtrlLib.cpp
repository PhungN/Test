#include "stdafx.h"

#include "RtuCtrlLib.h"

#pragma region CMarkupStatic class
/////////////////////////////////////////////////////////////////////////////
// CMarkupStatic
CMarkupStatic::CMarkupStatic()
{
	m_pUIElement = NULL;
	m_strContent = _T(" ");
}

CMarkupStatic::~CMarkupStatic()
{
	MARKUP_RELEASE(m_pUIElement);
}


BEGIN_MESSAGE_MAP(CMarkupStatic, CStatic)
	//{{AFX_MSG_MAP(CMarkupStatic)
	ON_WM_PAINT()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMarkupStatic message handlers

void CMarkupStatic::SetMarkupText(LPCSTR lpszMarkup)
{
	MARKUP_RELEASE(m_pUIElement);

	m_pUIElement = Parse(lpszMarkup);

	if (m_hWnd) Invalidate(FALSE);
}

void CMarkupStatic::SetMarkupText(LPCWSTR lpszMarkup)
{
	MARKUP_RELEASE(m_pUIElement);

	m_pUIElement = Parse(lpszMarkup);

	if (m_hWnd) Invalidate(FALSE);
}

void CMarkupStatic::SetMarkupText(LPCWSTR lpszMarkup, CString strContent)
{
	if(m_strContent == strContent)
		return;

	MARKUP_RELEASE(m_pUIElement);

	m_pUIElement = Parse(lpszMarkup);
	m_strContent = strContent;
	if (m_hWnd) Invalidate(FALSE);
}

void CMarkupStatic::OnPaint() 
{
	CPaintDC dcPaint(this);
	CXTPBufferDC dcBuffer(dcPaint);

	CXTPClientRect rc(this);
	dcBuffer.FillSolidRect(rc, GetSysColor(COLOR_WINDOW));
	
	if (m_pUIElement)
	{
		CXTPMarkupDrawingContext dc(dcBuffer);
		
		m_pUIElement->Measure(&dc, rc.Size());

		m_pUIElement->Arrange(rc);

		m_pUIElement->Render(&dc);
	}
}

BOOL CMarkupStatic::OnWndMsg(UINT message, WPARAM wParam, LPARAM lParam, LRESULT* pResult)
{
	// To Handle Hyperlinks:
	if (m_pUIElement)
	{
		CXTPMarkupContext::m_hContextWnd = m_hWnd;
		if (CXTPMarkupContext::OnWndMsg(m_pUIElement, message, wParam, lParam, pResult))
			return TRUE;
	}

	return CStatic::OnWndMsg(message, wParam, lParam, pResult);
}
#pragma endregion

#pragma region CMarkupLabel
CMarkupLabel::CMarkupLabel()
{
	m_strText = _T("");
	m_strTextAlignment = _T("Left");
	m_strFontWeight = _T("Normal");
	m_strBorderColor = _T("#767676");
	m_strBackgroundColor = _T("#e4ecf7");
	m_strTextColor = _T("Black");
	m_borderThickness = 0;
	m_bItalic = FALSE;
}

void CMarkupLabel::SetText(CString strText, CString strTextColor)
{
	if(strTextColor != _T("")) {
		m_strTextColor = strTextColor;
	}
	m_strText = strText;
	UpdateControl();
}

void CMarkupLabel::Render()
{
	GetWindowText(m_strText);
	UpdateControl();
}

void CMarkupLabel::SetBorderThickness(int borderThickness)
{
	m_borderThickness = borderThickness;
}

void CMarkupLabel::SetBorderColor(CString strColor)
{
	m_strBorderColor = strColor;
	UpdateControl();
}

void CMarkupLabel::SetBackgroundColor(CString strColor)
{
	m_strBackgroundColor = strColor;
	UpdateControl();
}

void CMarkupLabel::SetTextColor(CString strColor)
{
	m_strTextColor = strColor;
	UpdateControl();
}

void CMarkupLabel::Setup(int borderThickness, CString strBorderColor, CString strBackgroundColor, CString strFontWeight, BOOL bItalic)
{
	m_borderThickness = borderThickness;
	m_strBorderColor = strBorderColor;
	m_strBackgroundColor = strBackgroundColor;
	m_strFontWeight = strFontWeight;
	m_bItalic = bItalic;
}

void CMarkupLabel::Setup(int borderThickness, CString strFontWeight, BOOL bItalic)
{
	m_borderThickness = borderThickness;
	m_strFontWeight = strFontWeight;
	m_bItalic = bItalic;
}

void CMarkupLabel::SetItalic(BOOL bItalic)
{
	m_bItalic = bItalic;
	UpdateControl();
}

void CMarkupLabel::UpdateControl()
{
	CString str;
	str.Format( 
		_T("<Border Padding='1' BorderThickness='%d' BorderBrush='%s' Background='%s'>")
		_T("<StackPanel TextBlock.FontFamily='Tahoma' TextBlock.FontSize='11'>")
		_T("    %s")
		_T("</StackPanel>")
		_T("</Border>"),
		m_borderThickness,
		(LPCTSTR)m_strBorderColor,
		(LPCTSTR)m_strBackgroundColor,
		(LPCTSTR)GetTextBlock()
	);
	SetMarkupText(str);
}

CString CMarkupLabel::GetTextBlock()
{
	CString strTextBlock;
	CString strFormat = _T("<TextBlock Padding='1' TextAlignment='%s' FontWeight='%s' Foreground='%s'>%s</TextBlock>");
	if(m_bItalic) {
		strFormat = _T("<TextBlock Padding='1' TextAlignment='%s' FontWeight='%s' Foreground='%s'><Italic>%s</Italic></TextBlock>");
	}
	strTextBlock.Format(strFormat, m_strTextAlignment, m_strFontWeight, m_strTextColor, m_strText);
	return strTextBlock;
}
#pragma endregion

#pragma region CMarkupBox
CMarkupBox::CMarkupBox()
{
	m_strText = _T("");
	m_strFontWeight = _T("Bold");
	m_strBorderColor = _T("#767676");
	m_strBackgroundColor = _T("#e4ecf7");
	m_strTextColor = _T("Black");
	m_bRule = TRUE;
	m_leftBorder = 1;
	m_rightBorder = 1;
	m_topBorder = 1;
	m_bottomBorder = 1;
}

void CMarkupBox::Setup(int left, int top, int right, int bottom, BOOL bRule, CString strBorderColor, CString strBackgroundColor, CString strFontWeight)
{
	m_leftBorder = left;
	m_rightBorder = right;
	m_topBorder = top;
	m_bottomBorder = bottom;
	m_bRule = bRule;
	m_strBorderColor = strBorderColor;
	m_strBackgroundColor = strBackgroundColor;
	m_strFontWeight = strFontWeight;
}

void CMarkupBox::Setup(int borderThickness, BOOL bRule, CString strFontWeight)
{
	m_leftBorder = borderThickness;
	m_rightBorder = borderThickness;
	m_topBorder = borderThickness;
	m_bottomBorder = borderThickness;
	m_bRule = bRule;
	m_strFontWeight = strFontWeight;
}

void CMarkupBox::SetText(CString strText, BOOL bRule)
{
	m_strText = strText;
	m_bRule = bRule;
	UpdateControl();
}

void CMarkupBox::SetText(CString strText, CString strTextColor)
{
	m_strText = strText;
	m_strTextColor = strTextColor;
	UpdateControl();
}

void CMarkupBox::SetBorderColor(CString strColor)
{
	m_strBorderColor = strColor;
	UpdateControl();
}

void CMarkupBox::SetBackgroundColor(CString strColor)
{
	m_strBackgroundColor = strColor;
	UpdateControl();
}

void CMarkupBox::SetTextColor(CString strColor)
{
	m_strTextColor = strColor;
	UpdateControl();
}

void CMarkupBox::SetBorder(int left, int top, int right, int bottom)
{
	m_leftBorder = left;
	m_rightBorder = right;
	m_topBorder = top;
	m_bottomBorder = bottom;
	UpdateControl();
}

void CMarkupBox::UpdateControl()
{
	CString str;
	str.Format( 
		_T("<Border Padding='1' BorderThickness='%d,%d,%d,%d' BorderBrush='%s' Background='%s'>")
		_T("<StackPanel TextBlock.FontFamily='Tahoma' TextBlock.FontSize='11'>")
		_T("   <TextBlock Padding='1, 1, 1, 1' FontWeight='%s' Foreground='%s'>%s</TextBlock>")
		_T("   %s")
		_T("</StackPanel>")
		_T("</Border>"),
		m_leftBorder,
		m_rightBorder,
		m_topBorder,
		m_bottomBorder,
		(LPCTSTR)m_strBorderColor,
		(LPCTSTR)m_strBackgroundColor,
		(LPCTSTR)m_strFontWeight,
		(LPCTSTR)m_strTextColor,
		(LPCTSTR)m_strText, 
		m_bRule ? _T("   <Border Height='1' Background='#9ebbdd' />")
		_T("   <Border Height='1' Background='White' />") : _T("")
	);
	SetMarkupText(str);
}

#pragma endregion
