#pragma once

class CNumEditEx : public CEdit
{
public:
	CNumEditEx(){};
	CNumEditEx(__int64 min, __int64 max, int limit){
		m_nMin = min; m_nMax = max; m_nLimit = limit;
	}
	//{{AFX_VIRTUAL(CNumEditEx)
	protected:
	virtual void PreSubclassWindow();
	virtual void DoDataExchange(CDataExchange* pDX);
	//}}AFX_VIRTUAL

public:
	BOOL SetMinMaxLimit(__int64 min, __int64 max, UINT limit);
	__int64 GetValue();
	void SetValue(__int64 val);
	void DisplayRangeError(UINT nMsgID, UINT nCaptionID, int nType = MB_OK|MB_ICONEXCLAMATION);
	BOOL IsValid();
	BOOL IsValidRange();
	virtual ~CNumEditEx(){};

protected:
	//{{AFX_MSG(CNumEditEx)
	afx_msg void OnChange();
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
private:
	int m_nIDC;
	int m_nLimit;
	__int64 m_nMax;
	__int64 m_nMin;
	__int64 m_i64Val;
	BOOL m_bValid;
};
