/******************************************************************************
 *		PACOM SYSTEMS PTY LTD 	Copyright 2005
 *		File/Class Name: SetupWizard.H
 *		Description:
 *		
 *		$Revision: 1 $
 *		$History: SetupWizard.h $
 * 
 * *****************  Version 1  *****************
 * User: Phungn       Date: 4/24/12    Time: 3:51p
 * Created in $/GMS/HotFixes/V4.07/Code/WSETUP/RTU
 * TT 7451
 * 
 * *****************  Version 18  *****************
 * User: Phungn       Date: 21/08/09   Time: 5:26p
 * Updated in $/GMS/Development (Mainstream)/Code V4/WSETUP/Rtu
 * Increase rtu upload/download config size
 * 
 * *****************  Version 13  *****************
 * User: Phungn       Date: 6/02/09    Time: 1:26p
 * Updated in $/GMS/Releases/v4.00/Code v4/WSETUP/Rtu
 * Fixed problem process IDD_COMMOVR messages
 * 
 * *****************  Version 12  *****************
 * User: Phungn       Date: 29/01/09   Time: 3:31p
 * Updated in $/GMS/Releases/v4.00/Code v4/WSETUP/Rtu
 * Bug Detective
 * 
 * *****************  Version 10  *****************
 * User: Lienl        Date: 3/09/08    Time: 4:00p
 * Updated in $/GMS/Code v4/WSETUP/Rtu
 * Insure++: init member vars before used
 * 
 * *****************  Version 9  *****************
 * User: Phungn       Date: 7/24/08    Time: 5:51p
 * Updated in $/GMS/Code v4/WSETUP/Rtu
 * Add ability to view Firefly Mezzanine serial number (item #5258)
 * 
 * *****************  Version 8  *****************
 * User: Phungn       Date: 1/07/08    Time: 12:48p
 * Updated in $/GMS/Code v4/WSETUP/Rtu
 * Fixed problem getting the Dialup and Ethernet params for 8001 RTU (part
 * of item #5034)
 * 
 * *****************  Version 6  *****************
 * User: Phungn       Date: 6/09/07    Time: 12:59p
 * Updated in $/GMS/Code v3/WSETUP/Rtu
 * Added Remote Maintenance and Generic DVR Interface license (item #4926)
******************************************************************************/
#pragma once

#include "PortParm\SysParam.H"
#include "StdHdrRtu.h"
#include "portparm\StructsPortParm.H"
#include "Rtu.h"
#include "RtuLib.h"



#pragma pack(1)


typedef union _SysParams
{
	SYSPARM p1;
	SYSPARM2000 p2;
}SysParams;

typedef struct _EthParams 
{
	BYTE nPortNum;
	BYTE nPriority;
	BYTE nAppID;
	BYTE nSesID;
	BYTE nLnkID;
	ANIP_PARM appDummy;
	IP_PARM ipParams;
	MAC_PARM lnkMacParams;
	ETHDRV_PARM lnkEthParams;
	PRIORITY_PARM1 bsParam1;
	PRIORITY_PARM2 bsParam2;
}EthParams;

typedef struct _EthParams2 
{
	PRIORITY_PARM1 bsParam1;
	PRIORITY_PARM2 bsParam2;
	BYTE portParamBuff[RTU_BUFF_SIZE];
}EthParams2;

typedef struct _MsgFtrParams
{
	MSGFILTERPARM msgFtrParams;
	union {
		SYSPARM sysParams;
		SYSPARM2000 sysParams2;
	};
}MsgFtrParams;

typedef struct _DluParams
{
	BYTE nByteCount;
	SysParams sysParams;			// General System Params
	BYTE nPortNum;
	BYTE nPriority;
	BYTE nAppID;
	BYTE nSesID;
	BYTE nLnkID;
	LDIAL_PARM dluParams;			// Dialup Params
	BYTE bArrDummy[256 - sizeof(LDIAL_PARM)];
	SECONDARYPARM1 bsParams1;		// Base Station Params 1
	PRIORITYPARM2 bsParams2;		// Base Station Params 2
	MSGFILTERPARM msgFtrParams;		// Message Filter Params
}DluParams;


#pragma pack()

#define BTN_NEXT 1
#define BTN_PREVIOUS 2

// Parameters for programming dialup
#define PARAM_GEN_SYS		0
#define PARAM_DIALUP		1
#define PARAM_PRIORITY		2
#define PARAM_MSG_FILTER	3
#define PARAM_DIALUP_NEWCFG	4

// Params number
#define ETHERNET_PARAMS_BLK					PP_PORT1_PROTOCOL_BLK		//3
#define DIALUP_PARAMS_BLK					PP_PORT2_PROTOCOL_BLK		//4
#define GENERAL_SYSTEM_PARAMS_BLK			PP_GENERAL_SYSTEM_BLK			//16
#define MESSAGE_FILTER_PARAMS_BLK			PP_MESSAGE_FILTER_BLK			//23
#define PRIMARY_PRIORITY_PARAMS_BLK			PP_PRIMARY_NETWORK_BLK	//20
#define SECONDARY_PRIORITY_PARAMS_BLK		PP_SECONDARY_NETWORK_BLK	//21
#define TERTIARY_PRIORITY_PARAMS_BLK		PP_TERTIARY_NETWORK_BLK	//22
#define BACKUP_OPARATION_PARAMS_BLK			PP_DUAL_REPORT_BLK				//25

class CSWZDialog : public CGenDialog
{
public:
	CSWZDialog(){}
	CSWZDialog(int id, CWnd* pParent) : CGenDialog(id, pParent){};
	virtual BOOL StoreConfig(BOOL bStore)=0;
	virtual void ShowConfig(LPPARMPROC, BYTE, LPBYTE, BYTE, LPBYTE)=0;
};

class CEnableCodeDlg : public CSWZDialog
{
public:
	enum {E_MAX_OPTIONS = 13};
	CEnableCodeDlg();
	CEnableCodeDlg(LPPARMPROC lpps, CWnd* pParent = NULL);
	~CEnableCodeDlg(){};
    virtual int GetMyDialogID(){return IDD;};
	//BOOL IsEthernetEn(){return m_bEthernetEn;};
	int ShowParams(BYTE* ptr);
	void ChangeOption(int);
	BOOL StoreConfig(BOOL){return TRUE;};
	void ShowConfig(LPPARMPROC, BYTE, LPBYTE, BYTE, LPBYTE);

	//{{AFX_DATA(CEnableCodeDlg)
	enum { IDD = IDD_RWZ_EN_CODE_DLG };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CEnableCodeDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CEnableCodeDlg)
		// NOTE: the ClassWizard will add member functions here
	virtual BOOL OnInitDialog();
	afx_msg void OnBtnEthernet(){ChangeOption(0);};
	afx_msg void OnBtnAccessControl(){ChangeOption(1);};
	afx_msg void OnBtnAlarmOperation(){ChangeOption(2);};
	afx_msg void OnBtnElevatorHLI(){ChangeOption(3);};
	afx_msg void OnBtnIrisysProtocol(){ChangeOption(4);};
	afx_msg void OnBtnBackupOperation(){ChangeOption(5);};
	afx_msg void OnBtnMultiCardFormat(){ChangeOption(6);};
	afx_msg void OnBtnWitnessPtzDriver(){ChangeOption(7);};
	afx_msg void OnBtnInovonicsES(){ChangeOption(8);};
	afx_msg void OnBtnHostHLI(){ChangeOption(9);};
	afx_msg void OnBtnRemoteMaintenance(){ChangeOption(10);};
	afx_msg void OnBtnGenericDVRInterface(){ChangeOption(11);};
	afx_msg void OnBtnEPAP(){ChangeOption(12);};
	afx_msg LRESULT OnGms(WPARAM wParam, LPARAM lParam);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	PARMPROC m_lpps;
	CString m_strSerialNumber;
	CStaticColor m_lblLicences[E_MAX_OPTIONS];
	char m_nLicOp[16];
	BYTE m_nAddress1;
	BYTE m_nAddress2;
	int m_LicOp;
	int m_nByteCount;
	int m_nCurSel;
	BYTE data[RTU_BUFF_SIZE];

	int m_bActEn[E_MAX_OPTIONS];
	//BOOL m_bEthernetEn;

	void UpdateText(UINT id, int index, BOOL flag);
	void GetEnabledStrings(CStringArray& strEn);
	void GetDisabledStrings(CStringArray& strDis);
};



/////////////////////////////////////////////////////////////////////////////
// CSetRtuDefault dialog
class CSetRtuDefault : public CSWZDialog
{
// Construction
public:
	CSetRtuDefault(CWnd* pParent = NULL);   // standard constructor
	~CSetRtuDefault(){};
    virtual int GetMyDialogID(){return IDD;};
	BOOL StoreConfig(BOOL){return TRUE;};
	void ShowConfig(LPPARMPROC, BYTE, LPBYTE, BYTE, LPBYTE){};
// Dialog Data
	//{{AFX_DATA(CSetRtuDefault)
	enum { IDD = IDD_SET_RTU_DEF_DLG };
	//}}AFX_DATA

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSetRtuDefault)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CSetRtuDefault)
	virtual BOOL OnInitDialog();
	//virtual void OnCancel();
	//virtual void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	CStaticColor m_lblMsg;
	CStatic m_icon;
};

/////////////////////////////////////////////////////////////////////////////
// CPrgRtuAddress dialog

class CPrgRtuAddress : public CSWZDialog
{
// Construction
public:
	CPrgRtuAddress(){};
	CPrgRtuAddress(int nRtuNo, CWnd* pParent = NULL);   // standard constructor
	~CPrgRtuAddress(){};
    virtual int GetMyDialogID(){return IDD;};
	int GetNewRtuNumber(){return m_nNewRtuNo;} 
	BOOL StoreConfig(BOOL){return TRUE;};
	void ShowConfig(LPPARMPROC, BYTE, LPBYTE, BYTE, LPBYTE);
	void DisplayMessage(LPCTSTR);
// Dialog Data
	//{{AFX_DATA(CPrgRtuAddress)
	enum { IDD = IDD_PRG_RTU_ADDR_DLG };
	//}}AFX_DATA

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPrgRtuAddress)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CPrgRtuAddress)
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	afx_msg LRESULT OnGms(WPARAM wParam, LPARAM lParam);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	int m_nNewRtuNo;
	PARMPROC m_pps;
	CFont* m_pFont;
};


/////////////////////////////////////////////////////////////////////////////
// CPrgEthernetParams dialog
class CPrgEthernetParams : public CSWZDialog
{
// Construction
private:
	BYTE m_ethernetId; // TT 7516: 0: ethernet 1, 1: ethernet 2.
public:
	CPrgEthernetParams(BYTE ethernetId=0){m_ethernetId=ethernetId;}
	~CPrgEthernetParams(){};
    virtual int GetMyDialogID(){return IDD;};
	void EnableCtrls(BOOL);
	BOOL StoreConfig(BOOL);
	void ShowConfig(LPPARMPROC, BYTE, LPBYTE, BYTE, LPBYTE);
// Dialog Data
	//{{AFX_DATA(CPrgEthernetParams)
	enum { IDD = IDD_PRG_ETH_PARAMS_DLG };
	//}}AFX_DATA
	CComboBox m_cboProtocol;
	CComboBox m_cboLine1A;
	CComboBox m_cboLine2A;
	CIPAddressCtrl m_ipLocalNode;
	CIPAddressCtrl m_ipSubnetMask;
	CIPAddressCtrl m_ipRouter;
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPrgEthernetParams)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CPrgEthernetParams)
	virtual BOOL OnInitDialog();
	virtual void OnCancel();
	virtual void OnOK();
	afx_msg LRESULT OnGms(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT OnEnableWindows(WPARAM, LPARAM);
	afx_msg void OnBtnDownload();
	afx_msg void OnBtnReboot();
	afx_msg void OnBtnDefault();
	afx_msg void OnBtnDHCP();
	afx_msg void OnSelChangedProtocol();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	PARMPROC m_lpps;
	BYTE m_nByteCount;
	BYTE m_data[RTU_BUFF_SIZE];
	TCHAR m_LineAddr[36];
	BOOL m_bEthParams;
	int m_nNextBlock;
	BOOL m_bReboot;
	void ShowParams();
	void Initialize();
	CFont* m_pFont;
	LPBYTE m_pData;
	LPBYTE m_pAppData;
	LPBYTE m_pSesData;
	LPBYTE m_pLnkData;

	EthParams m_EthParams;
};

// ethernet 2
class CPrgEthernet2Params : public CPrgEthernetParams
{
public:
	CPrgEthernet2Params():CPrgEthernetParams(1){};
};

/////////////////////////////////////////////////////////////////////////////
// CPrgDialupParams dialog
class CPrgDialupParams : public CSWZDialog
{
// Construction
public:
	CPrgDialupParams();
    virtual int GetMyDialogID(){return IDD;};
	~CPrgDialupParams(){};
	BOOL IsDialerOnly(){return m_bDialerOnly;};
	BOOL IsPacomProtocol(){return m_bPacomProt;};
	BOOL StoreConfig(BOOL);
	void ShowConfig(LPPARMPROC, BYTE, LPBYTE, BYTE, LPBYTE);

// Dialog Data
	//{{AFX_DATA(CPrgDialupParams)
	enum { IDD = IDD_PRG_DIALUP_PARAMS_DLG };
	//}}AFX_DATA
	CComboBox m_cboDialerType;
	CComboBox m_cboProtocol;
	CComboBox m_cboDialupType;
	CComboBox m_cboPeriodicTstRpt;
	CComboBox m_cboDialerProt;
	CToolTipCheckListBox m_lstFlags;
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPrgDialupParams)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CPrgDialupParams)
	virtual BOOL OnInitDialog();
	afx_msg LRESULT OnGms(WPARAM wParam, LPARAM lParam);
	afx_msg void OnSelChangedDialerProtocol();
	afx_msg void OnSelChangedDialupType();
	afx_msg void OnBtnAdvanced();
	afx_msg void OnBtnReboot();
	afx_msg void OnBtnDownload();
	afx_msg void OnBtnAccCtrl();
	afx_msg void OnListBoxSelChange();
	afx_msg void OnListBoxCheckChange();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	PARMPROC m_lpps;
	LPBYTE m_pData;
	int m_nDialupType;
	TCHAR Tel[19];
	TCHAR PrePostTel[18];
	TCHAR m_ourTelNum[21];
	BYTE m_nFlags;
	BYTE m_nBlock;
	BOOL m_bSysParams;
	BOOL m_bDialerOnly;
	BOOL m_bPacomProt;
	int m_nNextBlock;
	BYTE m_nByteCount;
	UINT m_nAccountNumber;
	BYTE m_dialupBC;
	LPBYTE m_pDialupBuffer;
	
	void GetProtocolList();
	void ShowPhoneNum(LPBYTE);
	void ShowDialupType();
	void ShowParams();
	BOOL DialerOnly(LPBYTE, int, int);
	void ShowParams2();
	DluParams m_DluParams;

	CString m_strTel, m_strPredial, m_strPostdial, m_strRtuTel;
};

/////////////////////////////////////////////////////////////////////////////
// CPrgDialupMsgFilters dialog
class CPrgDialupMsgFilters : public CSWZDialog
{
// Construction
public:
	CPrgDialupMsgFilters(){};
	~CPrgDialupMsgFilters(){};
    virtual int GetMyDialogID(){return IDD;};
	BOOL StoreConfig(BOOL);
	void ShowConfig(LPPARMPROC, BYTE, LPBYTE, BYTE, LPBYTE);

// Dialog Data
	//{{AFX_DATA(CPrgDialupMsgFilters)
	enum { IDD = IDD_PRG_DIALUP_MSG_FILTERS_DLG };
	CCheckListBox m_lstIntAlm;
	CCheckListBox m_lstStatAlm;
	CCheckListBox m_lstCardAcc;
	//}}AFX_DATA
	CToolTipListBox m_lstMessageFilter;
	CToolTipListBox m_lstMessageFilter2;
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPrgDialupMsgFilters)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CPrgDialupMsgFilters)
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	afx_msg void OnBtnDefault();
	afx_msg void OnBtnAddAll();
	afx_msg void OnBtnRemoveAll();
	afx_msg void OnBtnAdd();
	afx_msg void OnBtnRemove();
	afx_msg LRESULT OnGms(WPARAM wParam, LPARAM lParam);
	afx_msg void OnLstIntAlmChange();
	afx_msg void OnLstStatAlmChange();
	afx_msg void OnLstCardAccChange();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	PARMPROC m_lpps;
	BOOL m_bSysParams;
	BOOL m_bMsgFilterParams;
	BYTE m_data[RTU_BUFF_SIZE];
	int m_nNextBlock;
	int m_nNumMsgs;
	CStringArray m_strArrMsgs;
	BYTE m_nIntAlm;
	BYTE m_nStatAlm;
	BYTE m_nCardAcc;

	void ShowParams();
	void Move(UINT desID, UINT srcID);

	MsgFtrParams m_msgFtrParams;
	LPBYTE m_pData;
};

/////////////////////////////////////////////////////////////////////////////
// CTemplateCfgDlg dialog
class CTemplateCfgDlg : public CSWZDialog
{
// Construction
public:
	CTemplateCfgDlg(){};
	CTemplateCfgDlg(LPPARMPROC lpps, CWnd* pParent = NULL);   // standard constructor
	~CTemplateCfgDlg(){};
    virtual int GetMyDialogID(){return IDD;};
	BOOL StoreConfig(BOOL){ return TRUE;};
	void ShowConfig(LPPARMPROC, BYTE, LPBYTE, BYTE, LPBYTE);

// Dialog Data
	//{{AFX_DATA(CTemplateCfgDlg)
	enum { IDD = IDD_CFG_TEMPLATE_DLG };
	//}}AFX_DATA
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTemplateCfgDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CTemplateCfgDlg)
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	afx_msg void OnBtnRAP();
	afx_msg void OnBtnAcc();
	afx_msg void OnBtnBrowse();
	afx_msg void OnPathChanged();
	afx_msg LRESULT OnGms(WPARAM wParam, LPARAM lParam);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	CComboBox m_cboDefList;
	PARMPROC m_lpps;
	BYTE m_data[RTU_BUFF_SIZE];
	void ShowParams();
	WORD	defNo;
	int m_nRtuNo;
	int m_nParmNum;
	int DefOption;
	BOOL m_bEnChangedOK;
	CFont* m_pBigFont;
	TCHAR m_lpPathName[MAX_PATH];
};

/////////////////////////////////////////////////////////////////////////////
// CRtuSetupWizard dialog
class CRtuSetupWizard : public CDialog
{
// Construction
public:
	CRtuSetupWizard(CWnd* pParent = NULL) : CDialog(CRtuSetupWizard::IDD, pParent) {};   // standard constructor
	CRtuSetupWizard(HINSTANCE hInst, HWND hSysWnd, int iblk, LPPARMPROC lpps, CWnd* pParent = NULL);   // standard constructor
	~CRtuSetupWizard();
	const int GetCurStep(){return GetCurrentSetupType()/*m_nCurrentStep*/;};
	static BOOL GetUnitSerialNumber(CString&, LPBYTE);
	static UINT UploadThread(LPVOID);
	static UINT DownloadThread(LPVOID);

// Dialog Data
	//{{AFX_DATA(CRtuSetupWizard)
	enum { IDD = IDD_RTU_WIZARD };
	//}}AFX_DATA
	PARMPROC m_glpps;
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CRtuSetupWizard)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CRtuSetupWizard)
	virtual BOOL OnInitDialog();
	virtual void OnCancel();
	virtual void OnOK();
	afx_msg void OnBtnBack();
	afx_msg void OnBtnNext();
	afx_msg LRESULT OnChangeRtuAddress(WPARAM, LPARAM);
	afx_msg LRESULT OnRtuUpload(WPARAM, LPARAM);
	//afx_msg LRESULT EnableWindows(WPARAM, LPARAM);
	afx_msg LRESULT UploadConfig(WPARAM, LPARAM);
	afx_msg LRESULT OnGms(WPARAM, LPARAM);
	afx_msg void OnTimer(UINT nIDEvent);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	PARMPROC m_lpps;
	//int m_nBlkNum;
	CStatic m_lblCfgMsg;
	CFont* m_pBigFont;
	int m_nRtuNo;
	BOOL m_bPortPrio;
	BOOL m_bMsgFilter;
	BOOL m_bSysParams;
	int m_nParams;
	BYTE m_data[RTU_BUFF_SIZE];
	BYTE m_dialupData[RTU_BUFF_SIZE];
	BYTE m_nByteCount;
	BYTE m_nDialupByteCount;
	int m_nCurrentStep;
	int m_MaxConfigSteps;

	void UpdateWindows();
	void EnableActivationCode(LPARAM lParam);
	void GetPrgEthernetParams(LPARAM lParam);
	void GetPrgDialupParams(LPARAM lParam);
	void GetPrgMsgFilterParams(LPARAM lParam);
	void SetRtuTime();
	void DisplayUploadStatus(BOOL);
	void OnConfigure();

	void SetSetupType(int index, int setupType, CSWZDialog* setupWindow)
	{
		if (index >= 8)
			return;
		
		m_cDlgs[index] = setupWindow;
		m_programIds[index] = (BYTE)setupType;
	}

	BYTE GetCurrentSetupType(BOOL paramType=TRUE) 
	{
		if (m_nCurrentStep < 0) return 0; 
		
		if (paramType)
			return m_programIds[m_nCurrentStep%8]&0xf;
		return m_programIds[m_nCurrentStep%8];
	}

	CSWZDialog* m_pCurDlg;
	CSWZDialog* m_cDlgs[8]; //TT 7516
	BYTE		m_programIds[8]; //TT 7516;
	CSetRtuDefault m_defDlg;
	CPrgRtuAddress m_addrDlg;
	CPrgDialupMsgFilters m_msgFtrDlg;
	CEnableCodeDlg m_actCodDlg;
	CPrgEthernetParams m_ethDlg;
	CPrgEthernet2Params m_ethernet2_Dlg;  // ethernet 2 for 8002
	CPrgDialupParams m_dluDlg;
	CTemplateCfgDlg m_tmpDlg;

	CProgressCtrl m_prgUpload;
	CStatic m_lblUpload;
	BOOL m_bIsValid;
	EthParams2 m_EthParams;
	DluParams m_DluParams;
	MsgFtrParams m_msgFtrParams;
	CWinThread* m_pWndUploadThread;
	CWinThread* m_pWndDownloadThread;
	//CEvent* m_pUploadEvent;

	BYTE m_fUploadStatus;
	void InitUploadStatus();
	int m_nRetries;
	//BOOL m_bBusy;
};

