#pragma once


#include <afxwin.h>
#include "StdHdrRtu.h"
#include "Rtu.h"


/////////////////////////////////////////////////////////////////////////////
// CRtuGalaxyID dialog

class CRtuGalaxyID : public CDialog
{
// Construction
public:
	
	CRtuGalaxyID(LPPARMPROC lpps, CWnd* pParent = NULL);// : CDialog(CRtuBmsConfig::IDD, pParent) {};   // standard constructor
	~CRtuGalaxyID(){};

	
// Dialog Data
	//{{AFX_DATA(CRtuGalaxyID)
	enum { IDD = IDD_GALAXY_ID_DLG };
	//}}AFX_DATA

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CRtuGalaxyID)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//virtual BOOL OnCommand(WPARAM wParam, LPARAM lParam);
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CRtuGalaxyID)
	virtual BOOL OnInitDialog();
	virtual void OnCancel();
	virtual void OnOK();
	afx_msg void OnBtnUser();
	afx_msg void OnBtnManager();
	afx_msg void OnBtnEngineer();
	afx_msg void OnBtnRemote();
	afx_msg void OnBtnSite();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	PARMPROC m_lpps;
	CString m_strNumber;
	CString m_strName;
	CString m_strPassword;
	CNumEditEx m_txtNumber;

	enum USERTYPE {USER_PASSWORD, MANAGER_PASSWORD, ENGINEERING_PASSWORD, REMOTE_PASSWORD, SITE_PASSWORD};
	USERTYPE m_userType;
};

/////////////////////////////////////////////////////////////////////////////
// CRtuDscID dialog

class CRtuDscID : public CDialog
{
// Construction
public:
	
	CRtuDscID(LPPARMPROC lpps, CWnd* pParent = NULL);// : CDialog(CRtuBmsConfig::IDD, pParent) {};   // standard constructor
	~CRtuDscID(){};

	
// Dialog Data
	//{{AFX_DATA(CRtuDscID)
	enum { IDD = IDD_DSC_ID_DLG };
	//}}AFX_DATA

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CRtuDscID)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//virtual BOOL OnCommand(WPARAM wParam, LPARAM lParam);
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CRtuDscID)
	virtual BOOL OnInitDialog();
	virtual void OnCancel();
	virtual void OnOK();
	afx_msg void OnBtnUser();
	afx_msg void OnBtnManager();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	PARMPROC m_lpps;
	CString m_strPassword;
	CNumEditEx m_txtPassword;

	enum USERTYPE {USER_PASSWORD, MANAGER_PASSWORD};
	USERTYPE m_userType;
};

typedef int (WINAPI *Rtu_FuncPtr)(LPPARMPROC, UINT, UINT);

class CRtuDefaultConfigPage : public CPropertyPage
{
	DECLARE_DYNCREATE(CRtuDefaultConfigPage)

// Construction
public:
	CRtuDefaultConfigPage(LPPARMPROC lp);
	CRtuDefaultConfigPage();
	~CRtuDefaultConfigPage(){};
	
	enum {E_DOWN_LOAD=1, E_UP_LOAD=2, E_ALM_CFG=1, E_CAC_CFG=2, E_BMS_CFG=3};
	enum {E_TEMPLATE_EDIT=0, E_TEMPLATE_DOWNLOAD=1, E_TEMPLATE_UPLOAD=2, E_TEMPLATE_BACKUP_TO_DISK=3,
		E_TEMPLATE_RESTORE_FROM_DISK=4};
	int ProcCmd();
// Dialog Data
	//{{AFX_DATA(CRtuDefaultConfigPage)
	enum { IDD = IDD_RTU_DEF_CFG };
		// NOTE - ClassWizard will add data members here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CRtuDefaultConfigPage)
	public:
	virtual BOOL OnInitDialog();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CRtuDefaultConfigPage)
	afx_msg void OnBtnBrowse();
	afx_msg void OnBtnEdit();
	afx_msg void OnBtnUpload();
	afx_msg void OnBtnDownload();
	afx_msg void OnBtnBackup();
	afx_msg void OnBtnRestore();
	afx_msg LRESULT OnGms(WPARAM wParam, LPARAM lParam);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

private:
	void StartDownloading();
	void StartUploading();
	void InitControls();
	void InitControls2();
	void UpdateControls();

	void UploadConfig();
	void DownloadConfig();

	void UploadNewRtuConfig();
	int UpdateUploadRecord();
	void DownloadNewRtuConfig();
	int UpdateDownloadRecord();
	int	FileCopy(BOOL bUp, LPBYTE lpData, UINT bc);
	UINT GetFileIndex(int nRecordNumber);
	UINT GetAlarmRecordFileIndex(int nRecordNumber);
	UINT GetCardAccessRecordFileIndex(int nRecordNumber);
	UINT GetBmsRecordFileIndex(int nRecordNumber);

	int IsValid(CString strDir, int templateNum);
	BOOL AddNewTemplateName(CString strDir, CString strTemplateName, int nTemplateNumber);
	CString GetCustomerFilesPath() const;

private:
	PARMPROC lpps;
	BYTE data[RTU_BUFF_SIZE];
	WORD	m_nDefNo;
	int m_nCurSel;
	int m_nRtuNo;
	int m_nCount;
	int m_nSelect;
	int m_nID;
	BOOL m_bDone;
	CFont* m_stsFont;

	CComboBox m_cboDefName;
	CNumEditEx m_txtDefNo;

	int m_nNumAlmBlks;
	int m_nNumCacBlks;
	int m_nNumBmsBlks;
	int m_nNumAreas;
	BOOL m_bIsNewRtuType;
	Rtu_FuncPtr m_fptr;
	int m_curCfgType;
	int m_nIndex;

	CString m_strTemplateName;
	BOOL m_bNewTemplate;
};


class CRtuCompleteConfigPage : public CPropertyPage
{
	DECLARE_DYNCREATE(CRtuCompleteConfigPage)

// Construction
public:
	CRtuCompleteConfigPage(){};
	CRtuCompleteConfigPage(LPPARMPROC lp);
	~CRtuCompleteConfigPage(){};

	int ProcCmd();
// Dialog Data
	//{{AFX_DATA(CRtuCompleteConfigPage)
	enum { IDD = IDD_RTU_CMPL_CFG };
		// NOTE - ClassWizard will add data members here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CRtuCompleteConfigPage)
	public:
	virtual BOOL OnInitDialog();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CRtuCompleteConfigPage)
	afx_msg void OnRadDownload();
	afx_msg void OnRadUpload();
	afx_msg void OnFileChanged();
	afx_msg void OnFileEdit();
	afx_msg LRESULT OnGms(WPARAM wParam, LPARAM lParam);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

private:
	void FillComboBox(CComboBox* pCB, CStringArray& strArr);
	void DisplayFileInfo();
	void DisplayFileInfo(CString&);
	void SaveFileInfo();

	int ProcNextCmd(CString);
	int GetNumChips();
	BOOL DeleteFileNum(CString strFileName, int nFileNum);
	BOOL AddNewConfig();
	DWORD GetFileSize(CString strFileName);

private:
	CComboBox m_cboFiles;

	PARMPROC lpps;
	BYTE data[RTU_BUFF_SIZE];

	CStringArray m_files;
	CStringArray m_uploadFiles;
	int m_nRtuNum;
	int m_nChipCount;
	int m_nMaxChip;
	DWORD m_nTotalSize;

	BOOL m_bUpload;
	TCHAR m_pathname[MAX_PATH];
	CString m_fileName;
	CFont* m_stsFont;
};


class CRtuTemplate : public CDialog
{
// Construction
public:
	CRtuTemplate(LPPARMPROC lp, CWnd* pParent = NULL);
	//CRtuTemplate(LPPARMPROC lp, CWnd* pParent = NULL) : CDialog (CRtuTemplate::IDD, pParent){
	//	this->lpps = lp;
	//};   // standard constructor
	~CRtuTemplate();

// Dialog Data
	//{{AFX_DATA(CRtuTemplate)
	enum { IDD = IDD_RTU_TEMPLATE_DLG };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CRtuTemplate)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	CRtuDefaultConfigPage* m_defPage;
	CRtuCompleteConfigPage* m_cmplPage;
	CPropertySheet m_sheet;
	// Generated message map functions
	//{{AFX_MSG(CRtuTemplate)
	virtual BOOL OnInitDialog();
	afx_msg void OnOK();
	afx_msg void OnCancel();
	afx_msg LRESULT OnDone(WPARAM, LPARAM);
	afx_msg LRESULT OnDisplayMessage(WPARAM, LPARAM);
	afx_msg LRESULT OnGms(WPARAM, LPARAM);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

private:
	LPPARMPROC lpps;
	CFont* m_stsFont;
	CStatusBar m_statusBar;

};

