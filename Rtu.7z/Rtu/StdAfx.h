// stdafx.h : include file for standard system include files,
//  or project specific include files that are used frequently, but
//      are changed infrequently
//

#pragma once

#include "stdafx_standard.h"


#include "gmsui\module\gmsui.h"	

#include "gms\commonuse\commonmacros.h"	
#include "gms\commonuse\pac1000.h"		
#include "hicomm\commtask.h"		
#include "gms\commonuse\gms_wm_ids.h"	
#include "gms\commonuse\rtuwinmsgdefs.h"	
#include "gms\commonuse\gms30folder.h"	
#include "mylib\mylib.h"		
#include "gms\commonuse\gmsoperatorprivs.h"		
#include "gms\commonuse\keys.h"		
#include "gms\commonuse\messages.h"	
#include "mylib\filelib.h"		
#include "hicomm\setup9.h"	
#include "hardwareconfig\rtu\rtu.h"	
#include "gms\commonuse\idds_and_idms.h"		
#include "hardwareconfig\rtu\StdHdrRtu.h"	
#include "gms\systemuserconfiguration\users.h"		
#include "gms\commonuse\rtudata.h"		
#include "hardwareconfig\rtu\panelgrf\panelcfg.h"	
#include "hardwareconfig\rtu\portparm\portparm.h"	
#include "hardwareconfig\rtu\rtulib.h"		
#include "rtures\resource.h"		
#include "mylib\mylib2.h" 
#include "hardwareconfig\menuhardwareconfig.h"		
#include "mylib\CThisGMS.h"		
#include "Mylib\Globals.h"
