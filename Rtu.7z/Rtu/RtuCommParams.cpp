///*----------------------------------------------------------------------------
//                                DLU SETUP PROGRAM
//
//    Module #5-3 - RTU configuration module         DEC 1990
//       --------------------------------------------------------------
//		COMMS PARAMETER PROGRAM.	   JAN'02,1991
//       --------------------------------------------------------------
//		Modified  for PUname					July'25,1993
//		Modified  for SDLC POLL screen			Feb'2,1994
//----------------------------------------------------------------------------*/

#include "stdafx.h"
#include <io.h>
#include "HardwareConfig\HELPID.H"
#include <WindowsX.h>

extern TCHAR		LineBuffer[]; // defined in RTULIB.cpp
extern SETUPPARM rtuSetup;

#define		cfc			35
#define		cfc1		35
#define		cfr			5
#define		clr			(cfr+11)
#define		clr1		(cfr+4)
#define		clr2		(cfr+5)
#define		clr3		(cfr+3)

#define		MAXPP	6
#define		cpfr	5
#define		cplr	(cpfr+MAXPP-1)
#define		cpfc	53

/*-----------------------------------------------------------------------*/
extern	DATAINPUT diOther;
extern	BYTE gp_dat[];
extern	HINSTANCE hrInst;
extern	int PanelType, RtuType;
extern	BYTE OldPanelType;
extern	TCHAR s_HelpFile[];

/*-----------------------------------------------------------------------*/
static UINT cp_help[] = {
	cph1, cph1, cph1, cph1, cph1, cph1, cph1, cph1, cph1,
	f3_help, opn_str, cph1+1, opn_str, cph1
	};

char NetType;

#pragma		pack(1)
typedef struct _COMM {
	BYTE	DUA,CED,HT,FR,ST,SW,RAS,MSR;				//.8
	BYTE	CTN[10],ATN[10],DTN[10];					//.30
	BYTE	DT,AT;										//.2
	BYTE	DLTN[10];									//.10
	BYTE	TT,FPD,MMR,TWP,RBA,RB,TDA,AFPD,VID1,VID2;	//.10
	BYTE	spare;
	} COMM;												//.Total = 61

static COMM DialParm;
//.............................................................
typedef struct _OCOMM {		//.Mosler Rtu2000 Dialup Parameters
	BYTE	DUA,CED,HT,FR,ST,SW,RAS,MSR;				//.8
	BYTE	CTN[10],ATN[10],DTN[10];					//.30
	BYTE	DOT;										//.1 : Dropoff time
	BYTE	DT,AT;										//.2
	BYTE	DLTN[10];									//.10
	BYTE	TT;											//.1
	} OCOMM;											//.Total = 52

static OCOMM ODialParm;
//.............................................................
typedef struct _OCOMM1 {	//.Mosler P1003 Dialup Parameters
	BYTE	DUA,CED,HT,FR,ST,SW,RAS,MSR;				//.8
	BYTE	CTN[12],ATN[12],DTN[12];					//.36
	BYTE	DOT;										//.1 : Dropoff time
	BYTE	DT,AT;										//.2
	BYTE	DLTN[12];									//.12
	} OCOMM1;											//.Total = 59

static OCOMM1 ODialParm1;

//.... This array is offset/bytes into DialParm from ODialparm1 ....
typedef struct _ODialparm1Off {
    BYTE	Offset1;		//.ODialParm1 offset
	BYTE	Offset;			//.DialParm offset 
	BYTE	Count;			//.Bytes to copy 
	}ODialParm1Off;

static ODialParm1Off Offsets[] = {
    (BYTE)FIELDOFFSET(OCOMM1, DUA), (BYTE)FIELDOFFSET(COMM, DUA), 8,  
	(BYTE)FIELDOFFSET(OCOMM1, CTN), (BYTE)FIELDOFFSET(COMM, CTN), 10,
	(BYTE)FIELDOFFSET(OCOMM1, ATN), (BYTE)FIELDOFFSET(COMM, ATN), 10,
	(BYTE)FIELDOFFSET(OCOMM1, DTN), (BYTE)FIELDOFFSET(COMM, DTN), 10,
	(BYTE)FIELDOFFSET(OCOMM1, DOT), (BYTE)FIELDOFFSET(COMM, RBA), 1,
	(BYTE)FIELDOFFSET(OCOMM1, DT),  (BYTE)FIELDOFFSET(COMM, DT),  12
	};

typedef struct tagDluComm {
	BYTE	RCM,RTF,CAS,CA1;							//.5
	BYTE	PUName[8];									//.8
	}DLUCOMM;

struct tagNewDial {
	BYTE	CTN1[10],ATN1[10];							//.23
	BYTE	A1, A2/*, CS*/;
	}nDialParm;

#pragma	pack()

#define	DLU_COMM_SIZE		sizeof(DLUCOMM)
#define	NEWDIAL_PARM_SIZE	(sizeof(COMM) + sizeof(nDialParm))

int  commSize, commData;
BYTE ncommData;

static DLUCOMM *pDluComm = (DLUCOMM *)gp_dat;

/*---------------------------- SDLC POLL Parameters ------------------------*/
#pragma	pack(1)
typedef struct tagSDLCPOLL {
	uchar	spare1, spare2, spare3;
	uchar	addr;
	uchar	winSize;
	uchar	iFrame;
	uchar	idleTime;
	uchar	ackTime;
	uchar	cpName[8];
	}SDLCPOLLCOMM;
static SDLCPOLLCOMM *pSdlcPoll = (SDLCPOLLCOMM *)gp_dat;

#define	POLL_COMM_SIZE		sizeof(SDLCPOLLCOMM)

/*---------------------------- SDLC X25 Parameters -------------------------*/
typedef	struct tagSDLCX25 {
	uchar	retryTime;
	uchar	retryLC;
	uchar	retryMain;
	uchar	ackTime;
	uchar	maxRetries;
	uchar	timerT21;
	uchar	timerT23;
	uchar	LCA1LU[9];
	uchar	LCA2LU[9];
	uchar	LCB1LU[9];
	uchar	LCB2LU[9];
	uchar	BCA1LU[9];
	uchar	BCA2LU[9];
	}SDLCX25COMM;
#pragma	pack()

#define SDLCX25_COMM_SIZE	(POLL_COMM_SIZE+sizeof(SDLCX25COMM))

static WORD SDLCX25_IDS[] = {		//.Parameter strings
	rtu_parms+12, rtu_parms+13, rtu_parms+14, rtu_parms+15, rtu_parms+16,
	rtu_parms+17, rtu_parms+18,
	xrtu_parms1, xrtu_parms1+1,	xrtu_parms1+2, xrtu_parms1+3, xrtu_parms1+4,
	xrtu_parms1+5,
	};

static WORD SDLCX25_VALUE[] = {		//.Value strings
	rtu_value1+12, rtu_value1+13, rtu_value1+14, rtu_value1+15,	rtu_value1+16,
	rtu_value1+17, rtu_value1+18,
	xrtu_value1, xrtu_value1+1,	xrtu_value1+2, xrtu_value1+3, xrtu_value1+4,
	xrtu_value1+5,
	};

static uchar SX25_BC[] = {3,3,3,3,2,3,3,16,16,16,16,16,16};
static uchar SX25_max[] = {255, 255, 255, 255, 10, 255, 255};
static uchar SX25_min[] = {10, 10, 10, 10, 1, 1, 1};

#define	MAX_SX25_PARM	(sizeof(SDLCX25_IDS)/sizeof(WORD))
#define	sx25lr			(cfr+MAX_SX25_PARM-1)
#define	sx25fc			53

#define	COMM1057_SIZE	(4+60+24+10+ 60+24+10+ 60+24+10)

/*++++++++++++++++++++++++++++++++++ ROUTINES ++++++++++++++++++++++++++++++++
			-------- ROUTINE TO PACK THE TELEPHONE STRING -------			
----------------------------------------------------------------------------*/
/*--------------------------------------------------------------------------*/
void display_tel(HDC hdc, LPBYTE tel)
{
TCHAR str[32];

	Unpack_Tel(str, (LPBYTE)tel, MAXTELDGT);
	wOutText(hdc, str);
}

/*--------------------------------------------------------------------------*/
void DisplayCPName(HDC hdc, LPBYTE p1)
{
TCHAR line_buf[16];
char  text[10];

	wSetTextColor(hdc, cNODIS);
	wSetBkColor(hdc, cNODIS+1);
	memcpy(text, p1, 8);
	text[8] = 0;
	wsprintf(line_buf, _T("%hs"), text);
	wOutText (hdc, line_buf);
}

/*---------- Get TEL from the user --------*/
 /* rp = row pointer
	fc = First column no.
	Last change:  NKM  14 Mar 99    5:03 pm
 */

int Get_Tel (HWND hWnd, char *tel, int rp, int cp) 
{
	if (lstrlen(&LineBuffer[1]) > MAXTELDGT) {
		DisplayError1(hWnd, InvTelNo, hrInst);
		DisImage(hWnd, rp, cp);
	    return -1;
	    } 
	else {
		Pack_Tel(&LineBuffer[1], (LPBYTE)tel);
		return 0;
		}
}

/*----------------------------------------------------------------------------
			--------------- DIALUP PARAMETERS -------------
----------------------------------------------------------------------------*/
void ShowRtuComms1(LPDATAINPUT pdi, HDC hdc, LPBYTE /* lpgp */)
{
UINT	c1 = 0, rows;
UINT	i;

	rows = (PanelType==RTU2000_TYPE || PanelType==SRTU_TYPE) ? 11 : 
			(RtuType==RTU_1026_TYPE || RtuType==RTU_1050_TYPE) ? 14 : 12;
	DisplayHdr(pdi->hWnd, hdc, cp_hdr, cp_hdr1, 1, cp_pars, rows, CMD_LN, hrInst);
	if (PanelType==RTU2000_TYPE || PanelType==SRTU_TYPE)
		wOutStrxy(hdc, cp_pars+14, 5+8, 1, hrInst);

	for (i=0; i<rows; i++) {
		wSetTextPosition(i+cfr,cfc);
		switch (i) {
			case 0: c1 = DialParm.DUA; break;
			case 1: c1 = DialParm.CED; break;
			case 2: c1 = DialParm.HT; break;
			case 3: c1 = DialParm.FR; break;
			case 4: c1 = DialParm.ST; break;
			case 5: c1 = DialParm.SW; break;
			case 6: c1 = DialParm.RAS; break;
			case 7: c1 = DialParm.MSR; break;
			case 8: c1 = DialParm.RBA; break;
			case 9: c1 = DialParm.DT;
					wSetTextColor(hdc, cNODIS);
					wSetBkColor(hdc, cNODIS+1);
					wOutStr(hdc, (c1>7)? 0:DT_STR+c1, hrInst);
					continue;
			case 10:
				c1 = (DialParm.AT == 1) ? 'Y' : 'N';
				Print_no(hdc, _T("%c"), c1, 0);
				break;
			case 11:
				c1 = (!(DialParm.TT&1)) ? 'P' : 'T';
				Print_no(hdc, _T("%c"), c1, 0);
				break;
				
			case 12:
				c1 = (DialParm.TT&4) ? 'Y' : 'N';
				Print_no(hdc, _T("%c"), c1, 0);
				break;
				
			case 13:	//.Listen-in time
				Print_no(hdc, _T("%d"), DialParm.TDA, 0);
				break;
			}
			
		if (i<9)
			Print_no(hdc, _T("%d"),c1,0); 
		}
		
	pdi->BC = 3;
	pdi->Clm = cfc;
	pdi->lRow = (char)(cfr+rows-1);
	if (pdi->Row > pdi->lRow)
		pdi->Row = pdi->lRow;
	if (pdi->curKeys != -1)
		DisplayHelp(pdi->hWnd, cp_help[0], hrInst);
}

void MakeRtuComms1(LPDATAINPUT pdi, LPBYTE /* lpgp */, int key)
{
uint	key1;
int		rf;
HDC		hdc;
int	rp;

	rp = pdi->Row;
	if (key != DATA_RDY) {
		switch (key) {
			case FUNC3:
				if (pdi->curKeys==-1 || (rp-cfr) != 9)
				    break;

				if ((rf = ShowFunc3Box2(pdi->hWnd, DT_STR, 8, DialParm.DT, hrInst)) == -1)
					break;

				DialParm.DT = (BYTE)rf;
				hdc = GetDC(pdi->hWnd);
				wOutStrxy (hdc, DT_STR+rf, rp, cfc, hrInst);
				ReleaseDC(pdi->hWnd, hdc);
				rp++;

				break;
			}
		}
	else {
		if (rp >= (cfr+10) && rp <= (cfr+12)) {
			key = toupper(LineBuffer[1]);
			switch (key) {
				case INPT_N:
				case INPT_Y:
					if ((rp-cfr)==10) {
				   		DialParm.AT = (BYTE)((key==INPT_Y)? 1 : 0);
						rp++;
						}
					else if ((rp-cfr)==12) {
					    DialParm.TT &= ~4;
						DialParm.TT |= (key==INPT_Y) ? 4 : 0;
						rp = cfr;
						}
					break;

				case INPT_P:
				case INPT_T:
					if ((rp-cfr)==11) {
					    DialParm.TT &= ~1;
						DialParm.TT |= (key==INPT_T) ? 1 : 0;
						rp++;
						}
					break;
				}
			}
		else {

			key1 = wGetStrInt(&LineBuffer[1]);
			if (key1 >255) {
				DisplayError1(pdi->hWnd, WrongData, Globals->hInst);
				DisImage(pdi->hWnd, rp, cfc);
				return;
				}
			else {
				switch(rp-cfr) {
					case 0: DialParm.DUA = (BYTE)key1; break;
					case 1: DialParm.CED = (BYTE)key1; break;
					case 2: DialParm.HT = (BYTE)key1; break;
					case 3: DialParm.FR = (BYTE)key1; break;
					case 4: DialParm.ST = (BYTE)key1; break;
					case 5: DialParm.SW = (BYTE)key1; break;
					case 6: DialParm.RAS = (BYTE)key1; break;
					case 7: DialParm.MSR = (BYTE)key1; break;
					case 8: DialParm.RBA = (BYTE)key1; break;
					case 13: DialParm.TDA = (BYTE)key1; break;
					}
				}
			if (++rp > pdi->lRow)
				rp = cfr;
			}
		}
	if (pdi->curKeys != -1) {
		if(rp-cfr < _COUNTOF(cp_help))
			DisplayHelp(pdi->hWnd, cp_help[rp-cfr], hrInst);
	}
	pdi->BC = (BYTE)(((rp-cfr) > 9 && (rp-cfr) <= 12) ? 1 : 3);

	pdi->Row = (char)rp;
}

/*----------------------------------------------------------------------------
			---------- Second screen to get telephone nos. -------			
----------------------------------------------------------------------------*/
#define PU_IDX	7

void ShowRtuTel(LPDATAINPUT pdi, HDC hdc, LPBYTE /* lpgp */)
{
BYTE	*p1 = NULL;
int		i, pars;

	pars = (NetType==NT_T_SDLC && (PanelType != MP1003_TYPE ||
			commSize==NEWDIAL_PARM_SIZE)) ? 8 : 7;
	DisplayHdr(pdi->hWnd, hdc, cp_hdr, cp_hdr1, 1, cp_pars1, pars, CMD_LN, hrInst);

	for (i=0; i<pars; i++) {
		wSetTextPosition(i+cfr,cfc1);
		wSetTextColor(hdc, cNODIS);
		wSetBkColor(hdc, bgCOLOR);
		switch(i) {
			case 0: p1=DialParm.CTN; break;
			case 1: p1=nDialParm.CTN1; break;
			case 2: p1=DialParm.ATN; break;
			case 3: p1=nDialParm.ATN1; break;
			case 4: p1=DialParm.DTN; break;
			case 5: p1=DialParm.DLTN; break;
			case 6: 
				if (DialParm.TT&2)
					Print_no(hdc, _T("%u"), MAKERTUNO(nDialParm.A1,
							nDialParm.A2)+1,0);
				continue;
			
			case 7:
				DisplayCPName(hdc, pDluComm->PUName);
				continue;
			}
		display_tel(hdc, p1);
		}

	if (pdi->curKeys != -1)
		DisplayHelp(pdi->hWnd, tel_help, hrInst);
	pdi->Clm = cfc1;
	pdi->BC = MAXTELDGT;
	pdi->lRow = (char)(pars+4);
	if (pdi->Row > pars+4)
		pdi->Row = (char)(pars+4);
}

void MakeRtuTel(LPDATAINPUT pdi, LPBYTE /* lpgp */, int key)
{
int		rp;
BYTE	*p1 = NULL;

	rp = pdi->Row;
	if (key != DATA_RDY) {
		switch (key) {
			case DNARR:
			case TAB_KEY:
				if (!(DialParm.TT&2) && rp==11)
					if (++rp > pdi->lRow)
					    rp = cfr;
				break;

			case UPARR:
				if (!(DialParm.TT&2) && rp==11)
				    rp--;
				break;
			}
		}
	else {
		switch (rp-5) {
			case 0: p1 = DialParm.CTN; break;
			case 1: p1 = nDialParm.CTN1; break;
			case 2: p1 = DialParm.ATN; break;
			case 3: p1 = nDialParm.ATN1; break;
			case 4: p1 = DialParm.DTN; break;
			case 5: p1 = DialParm.DLTN; break;
			case 6:
				if (!(DialParm.TT&2))
			    	return;
				break;
			case 7: p1 = pDluComm->PUName; break;
			}
			
		if (rp-5==PU_IDX) {
			if (!GetRtuLUN(LineBuffer)) {
				if(p1) 
					memcpy(p1, &LineBuffer[1], 8);
				key = 0;
				}
			else {
				DisplayError1(pdi->hWnd, WrongData, Globals->hInst);
				DisImage(pdi->hWnd, rp, cfc1);
				return;
				}
			}
		else if (rp==11) {		//.Disaster RTUNO
			key = wGetStrInt(&LineBuffer[1]);
			if (key > 10000) {
				DisplayError1(pdi->hWnd, WrongData, Globals->hInst);
				DisImage(pdi->hWnd, rp, cfc1);
				return;
				}
			key--;
			nDialParm.A1 = (BYTE)GETGROUPNO(key);
			nDialParm.A2 = (BYTE)GETRTUOFFSET(key);
			}
		else {
			if (LineBuffer[1]=='N' || LineBuffer[1]=='n') {
				if(p1) {
					*p1 = 0;
					*(p1+1) = 0xff;
					}
				key = 0;
				}
			else
				key = Get_Tel(pdi->hWnd, (LPSTR)p1, rp, cfc1);
			}

		if (key != -1)
			if (++rp > pdi->lRow) rp = cfr;
		}
		
	if (pdi->curKeys != -1)
		DisplayHelp(pdi->hWnd, (rp >= PU_IDX+cfr) ? tel_help+1 : (rp==11) ?
					RtuHelp : tel_help, hrInst);
	pdi->Row = (char)rp;
	pdi->BC = (BYTE)((rp >= PU_IDX+cfr) ? 8 : (PanelType == MP1003_TYPE && OldPanelType) ?
												12 : MAXTELDGT);
}  

/*========================== SDLC POLL Parameters ==========================*/

/*----------------------------------------------------------------------------
			-------------  First set of comms parameters ---------
----------------------------------------------------------------------------*/
void ShowPOLLRtuParms(LPDATAINPUT pdi, HDC hdc, LPBYTE lpgp)
{
int		i;

	DisplayHdr(pdi->hWnd, hdc, rtu_hdr,rtu_hdr1,1, cpp_pars, MAXPP, CMD_LN, hrInst);

	wSetTextColor(hdc, cUNITS);
	wSetBkColor(hdc, cUNITS+1);
	for (i=0; i< MAXPP;i++)
		wOutStrxy(hdc, cpp_unit+i, cpfr+i, 33, hrInst);

	for (i=0; i<MAXPP-1;i++) {
		wSetTextPosition(i+cpfr,cpfc);
		if (!i)
			Print_no(hdc, _T("%02X"),gp_dat[3+i],0);
		else
			Print_no(hdc, _T("%u"),gp_dat[3+i],0); 
		}
	wSetTextPosition(i+cpfr,cpfc);		//.Cp name
	DisplayCPName(hdc, lpgp+8);

	pdi->Clm = cpfc;
	pdi->BC = 3;
	pdi->lRow = cplr;
}

void MakePOLLRtuParms(LPDATAINPUT pdi, LPBYTE lpgp, int key)
{
UINT key1=0;
int	 rp;

	rp = pdi->Row;
	if (key != DATA_RDY) {
	  switch (key) {
			case DNARR:
			case TAB_KEY:
				if (++rp > cplr) rp = cpfr;
				break;

			case UPARR:
				if (--rp < cpfr) rp = cplr;
				break;
			}
		}
	else {
		if (rp==cpfr)
			key1 = wGetStrHex(&LineBuffer[1]);
		else if (rp==cplr) {
				if (!GetRtuLUN(LineBuffer))
					_fmemcpy(lpgp+8, &LineBuffer[1], 8);
				else key1 = 256;		//.Wrong cp name
				}
			else
				key1 = wGetStrInt(&LineBuffer[1]);

		if (key1 >255) {
			DisplayError1(pdi->hWnd, WrongData, Globals->hInst);
			DisImage(pdi->hWnd, rp, cfc1);
			return;
			}
		else {
			if (rp != cplr) gp_dat[3+rp-cpfr] = (BYTE)key1;
			}	
		if (++rp > cplr) rp = cpfr;
		}

	pdi->BC = (BYTE)((rp==cplr) ? 8 : 3);
	pdi->Row = (char)rp;
}

/*=========================== SDLC X25 Parameters ==========================*/

/*----------------------------------------------------------------------------
			-------------  First set of comms parameters ---------
----------------------------------------------------------------------------*/
void ShowSDLCX25RtuParms(LPDATAINPUT pdi, HDC hdc, LPBYTE lpgp)
{
int	  i;
UINT  c1;
TCHAR  line_buf[32];
SDLCX25COMM far *psx25;

	psx25 = (SDLCX25COMM far *)(lpgp+sizeof(SDLCPOLLCOMM));
	DisplayHdr(pdi->hWnd, hdc, rtu_hdr, rtu_hdr1, 1, 0, 0, CMD_LN, hrInst);

	wSetTextColor(hdc, cPARMS);
	wSetBkColor(hdc, bgCOLOR);
	for (i=0; i<MAX_SX25_PARM;i++)
		wOutStrxy(hdc, SDLCX25_IDS[i], cpfr+i, 1, hrInst);

	wSetTextColor(hdc, cUNITS);
	wSetBkColor(hdc, cUNITS+1);
	for (i=0; i<MAX_SX25_PARM;i++)
		wOutStrxy(hdc, SDLCX25_VALUE[i], cpfr+i, 33, hrInst);

	for (i=0; i<MAX_SX25_PARM; i++) {
		wSetTextPosition(i+cpfr, sx25fc);
		switch (i) {
			case 0: c1 = psx25->retryTime ; goto uc1;
			case 1: c1 = psx25->retryLC; goto uc1;
			case 2: c1 = psx25->retryMain; goto uc1;
			case 3: c1 = psx25->ackTime; goto uc1;
			case 4: c1 = psx25->maxRetries; goto uc1;
			case 5: c1 = psx25->timerT21; goto uc1;
			case 6: c1 = psx25->timerT23;
			  uc1:
				Print_no(hdc, _T("%u"),c1, 0);
				break;

			default:
				GetX25Str(psx25->LCA1LU + 9*(i-7), line_buf);
				line_buf[MAX_X25_LEN] = 0;
				wOutAsciiText(hdc, line_buf);
				break;
			}
		}
	pdi->Clm = sx25fc;
	if (pdi->Row > sx25lr) pdi->Row = cpfr;
	pdi->BC = SX25_BC[pdi->Row-cpfr];
	pdi->lRow = sx25lr;
}

void MakeSDLCX25RtuParms(LPDATAINPUT pdi, LPBYTE lpgp, int key)
{
UINT	key1;
int		rp, idx;
LPBYTE	p1;
SDLCX25COMM far *psx25;

	rp = pdi->Row;
	psx25 = (SDLCX25COMM far *)(lpgp+sizeof(SDLCPOLLCOMM));
	if (key != DATA_RDY) {
	  switch (key) {
			case DNARR:
			case TAB_KEY:
				if (++rp > sx25lr) rp = cpfr;
				break;

			case UPARR:
				if (--rp < cpfr) rp = sx25lr;
				break;
			}
		}
	else {
		key = 1;
		idx = rp-cpfr;
		switch (idx) {
			case 0:	p1 = &psx25->retryTime ; goto uc1;
			case 1:	p1 = &psx25->retryLC; goto uc1;
			case 2:	p1 = &psx25->retryMain; goto uc1;
			case 3:	p1 = &psx25->ackTime; goto uc1;
			case 4:	p1 = &psx25->maxRetries; goto uc1;
			case 5: p1 = &psx25->timerT21; goto uc1;
			case 6:	p1 = &psx25->timerT23;
				uc1:
				key1 = wGetStrInt(&LineBuffer[1]);
				if (key1 > SX25_max[idx] || key1 < SX25_min[idx]) key = 0;
				else *p1 = (BYTE)key1;
				break;

			default:
				p1 = psx25->LCA1LU;
				key = MakeX25Addr(&LineBuffer[1], p1+(rp-cpfr-7)*9);
				break;
			}
		if (!key) {
			DisplayError1(pdi->hWnd, WrongData, Globals->hInst);
			DisImage(pdi->hWnd, rp, sx25fc);
			return;
			}
		if (++rp > sx25lr) rp = cpfr;
		}
	pdi->Row = (char)rp;
	pdi->BC = SX25_BC[pdi->Row-cpfr];
}

/*========================== ASYNC POLL Parameters ==========================*/
#define	aplr	(5+4-1)
extern TCHAR *ParityTypes[];
extern TCHAR *Baudrate[];
/*==============================================================================
    Function - To setup the comms parameter for Async Poll linecard
    Created :  1 May 97  1:24 pm
==============================================================================*/
void ShowAsyncRtuParms(LPDATAINPUT pdi, HDC hdc, LPBYTE /* lpgp */)
{
int		i, j;

	DisplayHdr(pdi->hWnd, hdc, rtu_hdr, cp_hdr1, 1, app_pars, 4, CMD_LN, hrInst);

	for (i=0; i<4; i++) {
		wSetTextPosition(i+cpfr, cfc);
		wSetTextColor(hdc, cNODIS);
		wSetBkColor(hdc, cNODIS+1);
		switch (i) {
		    case 0:
		    	if ((j = gp_dat[0]&0xf) > 2)
		    	    j = 0;
				wOutText(hdc, ParityTypes[j]);
				break;
				
		    case 1:
		    	if ((j = gp_dat[0]>>4) > 7)
		    	    j = 0;
				wOutText(hdc, Baudrate[j]);
				break;
				
		    default :
				Print_no(hdc, _T("%u"), gp_dat[2+i], 0); 
				break;
			}
		}

	pdi->Clm = cfc;
	pdi->BC = (BYTE)((pdi->Row >= cpfr+2) ? 3 : 1);
	pdi->lRow = aplr;
	DisplayHelp(pdi->hWnd, (pdi->Row < cpfr+2) ? f3_help : 4563, hrInst);
}

//..............................................................................
void MakeAsyncRtuParms(LPDATAINPUT pdi, LPBYTE /* lpgp */, int key)
{
UINT key1=0;
int	 rp, rf;
HDC	 hdc;

	rp = pdi->Row;
	if (key != DATA_RDY) {
	  switch (key) {
			case DNARR:
			case TAB_KEY:
				if (++rp > aplr) rp = cpfr;
				break;

			case UPARR:
				if (--rp < cpfr) rp = aplr;
				break;
				
			case FUNC3:
				if (rp < cpfr+2) {
				    if (rp==cpfr) {
						if ((rf = ShowFunc3Box(pdi->hWnd, ParityTypes,
							gp_dat[0]&0xf)) != -1) {
							hdc = GetDC(pdi->hWnd);
							wSetTextColor(hdc, cNOENT);
							wSetBkColor(hdc, cNOENT+1);
							wOutTextxy(hdc, ParityTypes[rf], rp, cfc); 
							gp_dat[0] = (BYTE)(rf + (gp_dat[0]&0xf0));
							rp++;
							ReleaseDC(pdi->hWnd, hdc);
							}
						}
					else {
						if ((rf = ShowFunc3Box(pdi->hWnd, Baudrate,
							gp_dat[0]>>4)) != -1) {
							hdc = GetDC(pdi->hWnd);
							wSetTextColor(hdc, cNOENT);
							wSetBkColor(hdc, cNOENT+1);
							wOutTextxy(hdc, Baudrate[rf], rp, cfc); 
							gp_dat[0] = (BYTE)((rf<<4) + (gp_dat[0]&0xf));
							rp++;
							ReleaseDC(pdi->hWnd, hdc);
							}
						}
					break;
					}
				break;
			}
		}
	else {
		if (rp >= cpfr+2) {
			if ((key1 = wGetStrInt(&LineBuffer[1])) > 255) {
				DisplayError1(pdi->hWnd, WrongData, Globals->hInst);
				DisImage(pdi->hWnd, rp, cfc);
				return;
				}
				
		    gp_dat[2+rp-cpfr] = (BYTE)key1;
			if (++rp > aplr)
			    rp = cpfr;
			}
		}

	pdi->BC = (BYTE)((rp >= cpfr+2) ? 3 : 1);
	pdi->Row = (char)rp;
	
	DisplayHelp(pdi->hWnd, (rp < cpfr+2) ? f3_help : 4563, hrInst);
}

/*-------------------- Read comms parameter file ---------------------------*/
int ReadCommDataFile(UINT RtuNo, int nNetType)
{
FILE	*fp;
int		i;
TCHAR	filename[MAX_PATH];
TCHAR	text[32];
LPSTR	p1;
LPTSTR	p2;
BYTE	c1;

	GetRtuParmFile(filename, COM_PARM_FILE, RtuNo);
	if (RtuType==RTU_1057_TYPE) {
		memset(gp_dat, 0, COMM1057_SIZE);
		if ((fp = wfopen(filename, _T("rb"))) != NULL) {
			fread(gp_dat, 1, COMM1057_SIZE, fp);
			fclose(fp);
			return TRUE;
			}
		return FALSE;
		}

	switch (nNetType) {
		case NT_SDLC_POLL: commData = POLL_COMM_SIZE; break;
		case NT_X25: commData = X25_COMM_SIZE; break;
		case NT_SNAPU21: commData = SNA_COMM_SIZE; break;
		case NT_T_SDLC: commData = DLU_COMM_SIZE; break;
		case NT_SDLC_X25: commData = SDLCX25_COMM_SIZE; break;
		case NT_IP: commData = UDP_COMM_SIZE; break;
		case NT_ASYN_POLL: commData = ASYNC_COMM_SIZE; break;
		default : commData = 0; break;
		}

	memset(gp_dat, 0, commData);
	memset(&DialParm, 0, sizeof(DialParm));
	memset(&nDialParm, 0, sizeof(nDialParm));
	ncommData = 0;

	if ((fp = wfopen(filename, _T("rb"))) != NULL) {
		if ((commSize = (int)_filelength(_fileno(fp))) >
			(int)(sizeof(DialParm)+commData+ sizeof(nDialParm)))
			commSize = sizeof(DialParm) + commData + sizeof(nDialParm);

		if (PanelType==RTU2000_TYPE || PanelType==SRTU_TYPE) {
			fread(&ODialParm, 1, sizeof(ODialParm), fp);
			_fmemcpy(&DialParm, &ODialParm, commSize);
			DialParm.RBA = ODialParm.DOT;
			_fmemcpy(&DialParm.DT, &ODialParm.DT, 13);
			commSize = sizeof(ODialParm);
			}
		else if (PanelType==MP1003_TYPE &&
		    (commSize < (sizeof(ODialParm1)+UDP_COMM_SIZE) && commSize != NEWDIAL_PARM_SIZE
			&& commSize != (NEWDIAL_PARM_SIZE+POLL_COMM_SIZE))) {
			if (OldPanelType) {
	    		fread(&ODialParm1, 1, 8, fp);
				BYTE* pBuff = ODialParm1.CTN;
				for (i=0; i<3; i++) {
					c1 = 0;
					fread(&c1, 1, 1, fp);
					*(pBuff + i*12) = c1;
					if (c1)
		    			fread(&ODialParm1.CTN[i*12+1], 1, c1, fp);
					}
				ODialParm1.DTN[0] = 0;
	    		fread(&ODialParm1.DOT, 1, 13, fp);
				}
			else {	//.New Mosler 1003
	    		fread(&ODialParm1, 1, sizeof(ODialParm1), fp);
				for (i=0; i<4; i++) {
					p1 = (LPSTR)((i==3) ? ODialParm1.DLTN : &ODialParm1.CTN[i*12]);
					Unpack_Tel(text, (LPBYTE)p1, 22);
					p2 = lstrstr(text, _T("****"));
					if (p2) {
						*p2++ = _T('+');
						memmove(p2, p2+3, (lstrlen(p2+3)+1)*sizeof(TCHAR));
						Pack_Tel(text, (LPBYTE)p1);
						}
					}
				}

			for (i=0; i<(sizeof(Offsets)/3); i++)
    			memcpy((LPBYTE)&DialParm+Offsets[i].Offset,
						(LPBYTE)&ODialParm1+Offsets[i].Offset1,
						Offsets[i].Count
						);
			commSize = sizeof(ODialParm1);
    		}
		else {	//.Other type of RAPS (mainly PACOM RAPs)
			fread(&DialParm, 1, sizeof(DialParm), fp);
			if (nNetType==NT_SNAPU21) {
				fread(gp_dat, 1, 56, fp);	//.56th byte tells the old/new SNA
				c1 = (BYTE)((gp_dat[55]&4) ? SNA_COMM_SIZE-56 : OSNA_COMM_SIZE-56);
				commData = 56+c1;
				fread(gp_dat+56, 1, c1, fp);
				fread(&nDialParm, 1, sizeof(nDialParm), fp);	//.No CS sent
				if (fread(gp_dat+commData, 1, 2*9, fp)==18)		//.9/11/98
					ncommData = 18;		//.New SNA addresses
				}
			else {
				fread(gp_dat, 1, commData, fp);
				fread(&nDialParm, 1, sizeof(nDialParm), fp);
				}
			}

		fclose(fp);

		TCHAR s[20] = {0};
		Unpack_Tel(s, DialParm.DLTN, 20);

		return TRUE;
		}
	else {
		if (PanelType==RTU2000_TYPE || PanelType==SRTU_TYPE)
			commSize = sizeof(ODialParm);
		else if (PanelType==MP1003_TYPE)
				commSize = sizeof(ODialParm1);
			else
				commSize = sizeof(DialParm)+commData +sizeof(nDialParm);
		return FALSE;
		}
}

/*-------------------- Read comms parameter file ---------------------------*/
int WriteCommDataFile(LPTSTR lpFile)
{
FILE	*fp;
int		i, j;
TCHAR 	text[32];
LPSTR 	p1;
LPTSTR	p2;
int		k;
BYTE 	c1;

	if ((fp = wfopen(lpFile, _T("w+b"))) != NULL) {
		if (RtuType==RTU_1057_TYPE) {
			fwrite(gp_dat, 1, COMM1057_SIZE, fp);
			fclose(fp);
			return TRUE;
			}

		if (PanelType==RTU2000_TYPE || PanelType==SRTU_TYPE)
			fwrite(&ODialParm, 1, sizeof(ODialParm), fp);
		else if (PanelType==MP1003_TYPE && (commSize != NEWDIAL_PARM_SIZE &&
		    commSize < (sizeof(ODialParm1)+UDP_COMM_SIZE) && !(DialParm.TT&2))) {
			for (i=0; i<(sizeof(Offsets)/3); i++)
				memcpy((LPBYTE)&ODialParm1+Offsets[i].Offset1,
					(LPBYTE)&DialParm+Offsets[i].Offset,
					Offsets[i].Count);

			if (OldPanelType) {	//.Old mosler 1003
				fwrite(&ODialParm1, 1, 8, fp);
				BYTE* pBuff = ODialParm1.CTN;
				for (i=0; i<3; i++) {
					c1 = *(pBuff + i*12);
    				fwrite(&ODialParm1.CTN[i*12], 1, c1+1, fp);
					}
				ODialParm1.DTN[0] = 0;
				fwrite(&ODialParm1.DOT, 1, 13, fp);
				}
			else {
				for (i=0; i<4; i++) {
					p1 = (LPSTR)((i==3) ? ODialParm1.DLTN : &ODialParm1.CTN[i*12]);
					Unpack_Tel(text, (LPBYTE)p1, 22);
					p2 = lstrchr(text, _T('+'));
					if (p2) {
						memmove(p2+4, p2+1, (lstrlen(p2+1)+1)*sizeof(TCHAR));
						for (j=0; j<4; j++)
							*(p2+j) = _T('*');
						k = lstrlen(text);
						Pack_Tel(text, (LPBYTE)p1);
						if (k&1)
							k++;
						*p1 = (char)(k>>1);
						}
					}
    			fwrite(&ODialParm1, 1, sizeof(ODialParm1), fp);
				}
			}
		else {
			fwrite(&DialParm, 1, sizeof(DialParm), fp);
			fwrite(gp_dat, 1, commData, fp);
			fwrite(&nDialParm, 1, commSize-sizeof(DialParm)-commData, fp);
			if (ncommData)
				fwrite(gp_dat+commData, 1, ncommData, fp);	//.9/11/98
			}

		fclose(fp);
		return 1;
		}
	return 0;
}

/*----------------------------------------------------------------------------
			============== COMMS PARAMETER EDIT ROUTINE ==========
----------------------------------------------------------------------------*/

void (*ShowCommParm[])(LPDATAINPUT, HDC, LPBYTE) = {
	ShowRtuComms1,
	ShowRtuTel,
	ShowSNARtuParms1,
	ShowSNARtuParms2,
	};

void (*MakeCommParm[])(LPDATAINPUT, LPBYTE, int) = {
	MakeRtuComms1,
	MakeRtuTel,
	MakeSNARtuParms1,
	MakeSNARtuParms2,
	};

char CurIndex, lastIdx;
//...............................................................................
long WINAPI EditCommParms(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
int		key;
int		i;
UINT	flg, id;
UINT	RtuNo=0xffff;
LPPARMPROC lpps;
long	ret = 0;

static DATAINPUT di;

	lpps = (LPPARMPROC)GetWindowLong(hWnd, 0);
	if (!lpps)
    	return 0;
try {
switch (message) {
	case WM_COMMAND:
	case WM_GMS:
	  RtuNo = MAKERTUNO(lpps->eType, lpps->eNo);
	  id = (message==WM_GMS) ? wParam : GET_WM_COMMAND_ID(wParam, lParam);
	  switch (id) {
		case IDD_COMMOVR_ERROR:
			DestroyWindow(hWnd);
			break;
		case IDD_COMMOVR_CTRL_NUM:
		case IDD_COMMOVR_DATA:
			DisCommMsg(lpps->hmDlg, 0, 0,0);
			if (!lParam) {
				DestroyWindow(hWnd);
				break;
				}
			NetType = lpps->NetType;
			ReadCommDataFile(RtuNo, NetType);
			if (RtuType == RTU_1057_TYPE) {
				ShowCommParm[0] = Show1057RtuParms1;
				ShowCommParm[1] = Show1057RtuParms2;
				ShowCommParm[2] = Show1057RtuParms2;
				MakeCommParm[0] = Make1057RtuParms1;
				MakeCommParm[1] = Make1057RtuParms2;
				MakeCommParm[2] = Make1057RtuParms2;
				lastIdx = 2;
				goto next;
				}
			else {
				ShowCommParm[0] = ShowRtuComms1;
				ShowCommParm[1] = ShowRtuTel;
				MakeCommParm[0] = MakeRtuComms1;
				MakeCommParm[1] = MakeRtuTel;
				}

			lastIdx = 1;
			switch (lpps->NetType) {
				case NT_X25:
					ShowCommParm[2] = ShowX25RtuParms1;
					ShowCommParm[3] = ShowX25RtuParms2;
					MakeCommParm[2] = MakeX25RtuParms1;
					MakeCommParm[3] = MakeX25RtuParms2;
					lastIdx = 3;
					break;

				case NT_SNAPU21:
					ShowCommParm[2] = ShowSNARtuParms1;
					ShowCommParm[3] = ShowSNARtuParms2;
					MakeCommParm[2] = MakeSNARtuParms1;
					MakeCommParm[3] = MakeSNARtuParms2;
					lastIdx = 3;
					break;

				case NT_SDLC_POLL:
					ShowCommParm[2] = ShowPOLLRtuParms;
					MakeCommParm[2] = MakePOLLRtuParms;
					lastIdx = 2;
					break;

				case NT_SDLC_X25:
					ShowCommParm[2] = ShowPOLLRtuParms;
					MakeCommParm[2] = MakePOLLRtuParms;
					ShowCommParm[3] = ShowSDLCX25RtuParms;
					MakeCommParm[3] = MakeSDLCX25RtuParms;
					lastIdx = 3;
					break;

				case NT_IP:
					ShowCommParm[2] = ShowUDPRtuParms;
					MakeCommParm[2] = MakeUDPRtuParms;
					lastIdx = 2;
					break;
					
				case NT_ASYN_POLL:
					ShowCommParm[2] = ShowAsyncRtuParms;
					MakeCommParm[2] = MakeAsyncRtuParms;
					lastIdx = 2;
					break;
				}

			if (PanelType==RTU2000_TYPE || (PanelType==MP1003_TYPE &&
				!(DialParm.TT&2)) || PanelType==SRTU_TYPE)
				lastIdx = 1;		//.Only dialup parameters (2 screens)
		next:
			CurIndex = 0;
			di.Row = cfr;
			MoveWindow(hWnd, 30, 30, 640, (RtuType==RTU_1057_TYPE) ? 420 : 382, 0);
			ShowWindow (hWnd, SW_SHOW);
			di.hcDlg = DisCmdLine1(hWnd, CMD_LN, 0, Globals->hInst);
			break;

		case IDM_READY:
			lpps = (LPPARMPROC)lParam;
			di = diOther;
			break;

   		case HID_HELP:
			if (CurIndex != 2)
			    key = HID_RTU_DIALP1+CurIndex;
			else
				key = (lpps->NetType==NT_T_SDLC) ? HID_RTU_SDLCCP :
					((lpps->NetType==NT_SNAPU21) ? HID_RTU_SNACP : HID_RTU_X25CP);
			DisplayHelp(hWnd, GMS_HLP_FILE, HH_DISPLAY_TOPIC, NULL); // TT#3780
			break;
		}		
	  break;

	case WM_KEYDOWN:
	case WM_CHAR:
		key = GetKey(&di, message, wParam);
		if (key == DATA_ESC || key==DATA_NOTRDY)
			break;
		flg = 0;
		if (key != DATA_RDY) {
		  switch (key) {
			case DNARR:
			case TAB_KEY:
				if (CurIndex > 1 || RtuType==RTU_1057_TYPE)
				    break;
				if (++di.Row > di.lRow)
				    di.Row = cfr;
				break;

			case UPARR:
				if (CurIndex > 1 || RtuType==RTU_1057_TYPE)
				    break;
				if (--di.Row < cfr)
				    di.Row = di.lRow;
				break;

			case FUNC4: {
				LPTSTR lpFile;

				if (di.curKeys == -1)
					break;

				lpFile = Deflt_Rtn(lpps, (PanelType == P1060_TYPE || PanelType == P8001_TYPE) ? 12 :
						(PanelType==EURO_TYPE) ? 6 : 1, lpps->lpData, 0, 1);
				WriteCommDataFile(lpFile);
				flg = 1;
				break;
				}

			case FUNC9:
				if (di.curKeys == -1)
					break;
				flg = 1;
				RtuNo = MAKERTUNO(lpps->eType, lpps->eNo);
				if (wMessageBox(hWnd, ReloadStr, RES_STRING(IDS_RELOAD_PARAMS), MB_YESNO)==IDYES)
					ReadCommDataFile(RtuNo, NetType);
				break;

			case ESCAPE:
				PostMessage(hWnd, WM_CLOSE, 0, 0);
				flg = 1;
				break;

			case PGUP:
				if (--CurIndex < 0)
					CurIndex = lastIdx;
				di.Row = cfr;
				InvalidateRect(hWnd, (LPRECT)NULL, TRUE);
				flg = 1;
				break;

			case PGDN:
				if (++CurIndex > lastIdx)
					CurIndex = 0;
				di.Row = cfr;
				InvalidateRect(hWnd, (LPRECT)NULL, TRUE);
				flg = 1;
				break;
			}
		  }

		if (!flg && di.curKeys != -1)
			(MakeCommParm[CurIndex])(&di, gp_dat, key);

		if (PanelType==RTU2000_TYPE || PanelType==SRTU_TYPE) {
			memcpy(&ODialParm, &DialParm, commSize);
			ODialParm.DOT = DialParm.RBA;
			memcpy(&ODialParm.DT, &DialParm.DT, 13);
			}

		wSetTextPosition(di.Row, di.Clm);
		break;			//.End of KeyDown case

	case WM_LBUTTONDOWN:
		ProcMouseButton(&di, lParam, di.Clm, di.Clm );
		break;

	case WM_LBUTTONDBLCLK:
		PostMessage(hWnd, WM_KEYDOWN, VK_F3, 0);
		break;

	case WM_ACTIVATE:
		ProcWM_ACTIVATE(wParam, lpps, &rtuSetup.hFocus, 1);
		break;

	case WM_SIZE:
		InvalidateRect(hWnd, (LPRECT)NULL, TRUE);
		break;

	case WM_PAINT: {
		PAINTSTRUCT		ps;
		HDC		hdc;

		hdc = BeginPaint(hWnd, &ps);
		(ShowCommParm[CurIndex])(&di, hdc, gp_dat);
		wSetTextPosition(di.Row, di.Clm);
		EndPaint(hWnd, &ps);
		if (di.curKeys == -1)
			HideCaret(hWnd);
		if (IsWindow(di.hcDlg))
			DisCmdLine1(hWnd, 0, di.hcDlg, Globals->hInst);
		break;
		}

	case WM_CLOSE: {
    	TCHAR filename[MAX_PATH];

		if (RtuType != RTU_1065_TYPE) {
			DialParm.FPD = 15;
			DialParm.MMR = 3;
			DialParm.TWP = 15;
			DialParm.RB = 5;
			DialParm.AFPD = 15;
			}
		
		GetRtuParmFile(filename, COM_PARM_FILE, MAKERTUNO(lpps->eType, lpps->eNo));
		i = res_rtn(lpps, filename, &DialParm, sizeof(DialParm), di.curKeys);
		if (i != -1)

			WriteCommDataFile(filename);

		if (i==1) 
		{
			TCHAR s[20] = {0};
			Unpack_Tel(s, DialParm.DLTN, 20);

		}
		break;
		}

	case WM_DESTROY:
		DestroyCaret();
		PostMessage(lpps->hmDlg, WM_GMS, IDD_FINISH, (LPARAM)lpps);
		break;

	default:
		ret = DefWindowProc(hWnd, message, wParam, lParam);
	}
	}
  catch(...) {
	#ifdef __cplusplus
	TRACE2("Failed in EditCommsParms at lp=%1, wp=%2\n", lParam, wParam);
	#endif
	}
	return ret;
}

/*--------------------------------------------------------------------------*/

