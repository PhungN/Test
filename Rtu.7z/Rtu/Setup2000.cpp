/*******************************************************************************
    SETUP2000.C - VCU2000 Backplane Port Configuration Module

    Author: NKM
    Created: 20 Feb 95 10:57 am
	Last change:  NKM   6 Jul 98   10:46 am
				  MM	17 October 2000 15:00

	17/6/2002 - Replaced all hard coded file and folder names with the constants
   				in Gms30Folder.h

*******************************************************************************/
#include "stdafx.h"

#include "portparm\StructsPortParm.H"
#include "portparm\sysparam.h"
#include "HardwareConfig\Rtu\PortParm\PortParamBlockIds.h"

static const int PORT_ERRS = 3;

extern HINSTANCE hrInst;
extern BOOL bShowAdvancedPortParams;
extern BYTE	pblk_size[4], iblk;

static UINT	BlkSize;

BOOL	ErrorStatistics;


//----------------------------------------------------------------------------

//----------------------------------------------------------------------------
#define	P2000_DEVLOOP2_RC	130, 270, 165, 300
#define	P2000_ETHERNET_RC	55, 270, 90, 305
#define P2000_NETWORK_RC	175, 270, 245, 300
#define	P2000_ISDN_RC		275, 270, 310, 300
#define P2000_DEVLOOP1_RC	5, 120, 45, 165
#define	P2000_DIAGNOSTIC_RC	195, 1, 230, 35
#define P2000_DUALPCMCIA_RC 120, 316, 265, 338
#define PORT_CNT 7

static RECT rc2000[] = {
	P2000_ETHERNET_RC,	
	P2000_NETWORK_RC,	
	P2000_ISDN_RC,
	P2000_DEVLOOP1_RC,		
	P2000_DIAGNOSTIC_RC,
	P2000_DEVLOOP2_RC,
	P2000_DUALPCMCIA_RC
};

//----------------------------------------------------------------------------


/*---------------------- Select Panel type for an RTU ----------------------*/
BOOL WINAPI EditVCU2000Ports(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
static LPPARMPROC lpps;
static int option;
static RECT  rc;
TCHAR	filename[MAX_PATH];

int		i, id;

	switch (message) {
		case WM_INITDIALOG: {
			lpps = (LPPARMPROC)lParam;
			lpps->heDlg = hDlg;
			lpps->hmDlg = hDlg;
			lpps->lpProc = 0;
			option = 0;
			rc.left = -1;
			CheckRadioButton(hDlg, IDC_2000_RADIO_PARAMS, IDC_2000_RADIO_ERRORS, IDC_2000_RADIO_PARAMS);
			//ShowWindow(GetDlgItem(hDlg, IDC_1057_ADVANCED), bShowAdvancedPortParams ? SW_SHOW : SW_HIDE);
			return FALSE;
			}


		case WM_COMMAND:
		case WM_GMS:
			if(lpps == NULL) 
				break;
			id = (message==WM_GMS) ? wParam : GET_WM_COMMAND_ID(wParam, lParam);
			BYTE commover_data[256];

			switch (id) {
				case IDM_PORT_PRINT_CFG:
					PrintPortParams(CWnd::FromHandle(hDlg), lpps, 1);
					break;

				// provide device status for anything connected to RS485 ports
				case IDM_1057_DEVICE_STATUS:
					

					// proposed code to be used when the test rig is available
					/*
					lpps->BlkNo = 16;  // download parameter
					lpps->BC = 
					lpps->lpData[0] = 
					lpps->lpData[1] = 1;	// get current information from port
					get_rtuport_parms(lpps, 0, 0);  ????
					
					*/

					// this code simply show the proposed Port Device Status Dialog 
					ShowPortDeviceStatusDlg( CWnd::FromHandle(hDlg), lpps, 5, option );
				
					break;

				case IDM_1057_ERRORSTATS:
						lpps->BlkNo = (BYTE)option;
						ErrorStatistics = TRUE;
						//get_port_errs(lpps, RtuType, BlkSize);
						get_other_errs(lpps, PORT_ERRS, BlkSize);
					break;
				
				case IDM_1057_PSPPARAMS:
				case IDM_1057_SYSPARAMS:
				case IDM_1057_TRENDPARAMS:
				case IDM_1057_PORTPARAMS:
				case IDM_1057_MODEM1:
				case IDM_1057_MODEM2:
				case IDM_1057_MSGFILTERS:
				case IDM_1057_SNMP:
				case IDM_1057_PEER:
				case IDM_1057_SYS_PW:
				case IDM_1057_BATT_TEST:
				case IDM_1057_DATETIME_REMOTE_MAINT:
				case IDM_1057_GPIP_PARAMS:
				case IDM_1057_VAULT_CTRLS_PARAMS:
				case IDM_1057_EMCS_PARAMS:
				case IDOK: {
					switch(id) {
					case IDM_1057_PSPPARAMS:
						option = 12; break;
					case IDM_1057_SYSPARAMS:
						option = 13; break;
					case IDM_1057_TRENDPARAMS:
						option = 14; break;
					case IDM_1057_MODEM1:
						option = 15; break;
					case IDM_1057_MODEM2:
						option = 16; break;
					case IDM_1057_MSGFILTERS:
						option = 20; break;
					case IDM_1057_SNMP:
						option = 21; break;
					case IDM_1057_PEER:
						option = 23; break;
					case IDM_1057_SYS_PW:
						option = 24; break;
					case IDM_1057_BATT_TEST:
						option = 25; break;
					case IDM_1057_DATETIME_REMOTE_MAINT:
						option = 27; break;
					case IDM_1057_GPIP_PARAMS:
						option = 28; break;
					case IDM_1057_VAULT_CTRLS_PARAMS:
						option = 29; break;
					case IDM_1057_EMCS_PARAMS:
						option = 30; break;
					default:
						break;
					}

					CString str; str.Format(_T("%s-%d..."), RES_STRING(IDS_ULOADING_PORT_PARAMS), option);
					SetDlgItemText(hDlg, IDC_1057_UPLOADTEXT, str);
					if ((IsDlgButtonChecked(hDlg, IDC_2000_RADIO_PARAMS) == TRUE) || (option >= 12) || (id == IDM_1057_PORTPARAMS)) {
						ErrorStatistics = FALSE;
						lpps->BC = 6;
						lpps->lpData[0] = (BYTE)(option + 3);
						lpps->lpData[1] = 0;
						lpps->lpData[5] = 1;	//Bit0 = 1 for New GMS request
						get_rtuport_parms(lpps, 0, 0);
					}
					else {
						ErrorStatistics = TRUE;
						lpps->BlkNo = (BYTE)option;
						get_other_errs(lpps, PORT_ERRS, BlkSize);
					}
					break;
				}

				case IDCANCEL:
					EndDialog(hDlg, FALSE);
					if (lpps->lpProc) 
    					FreeProcInstance(lpps->lpProc);
					rc.left = 0;
					break;

				case IDC_2000_ADVANCED:
				{
					HMENU	PopUpMenu;
					HMENU	PopUpMenuTrack;
					RECT	Rect;

					GetWindowRect(GetDlgItem(hDlg, IDC_2000_ADVANCED), &Rect);
					int nMenuID = bShowAdvancedPortParams ? IDR_1057_SYSPOPUP : IDR_ADVANCED_PORT_MENU;
					PopUpMenu = LoadMenu(hrInst, MAKEINTRESOURCE(nMenuID));
					PopUpMenuTrack = GetSubMenu(PopUpMenu, 0);
					TrackPopupMenu(PopUpMenuTrack, TPM_LEFTALIGN | TPM_LEFTBUTTON, Rect.left - 1, Rect.top - 1, 0, hDlg, NULL);
					DestroyMenu(PopUpMenu);
					break;
				}
			case IDD_COMMOVR_ERROR:
				break;
			case IDD_COMMOVR_DATA1:
			{
				memcpy(commover_data, (LPBYTE)lParam, 256);
				delete [] (LPBYTE)lParam;
				lParam = (LPARAM)(commover_data+5);
				// note: no break;
			}
			case IDD_COMMOVR_DATA:
			case IDD_COMMOVR_CTRL_NUM:
				{
					BYTE	BC, FunctionCode, temp;

					SetDlgItemText(hDlg, IDC_1057_UPLOADTEXT, _T(""));

					if (ErrorStatistics == FALSE) {
						if (lParam == NULL)
							break;
						memcpy(lpps->lpData, (LPSTR)lParam, RTU_BUFF_SIZE);
						BC = *((LPSTR)lParam - 5);			//bytecount for protocol parameters.
						FunctionCode = *((LPSTR)lParam - 4);
						temp = *lpps->lpData;
					}
					else {
						GetRtuParmFile(filename, ALM_ERR_FILE, MAKERTUNO(lpps->eType, lpps->eNo));
						BC = (BYTE)wFileRead(filename, lpps->lpData+1, RTU_BUFF_SIZE);
						FunctionCode = 147;
						temp = 0;
					}
					switch (temp) {
					case 15:
						BC = (BYTE)(BC - 6);
						ShowPSPParamsDlg(CWnd::FromHandle(hDlg), lpps, BC);
						break;
					case 16:
						BC = (BYTE)(BC - 6);
						ShowGeneralParamsDlg(CWnd::FromHandle(hDlg), lpps, BC);
						break;
					case 17:
						BC = (BYTE)(BC - 6);		//Trend BMS Parameters
						ShowTrendBMSParamsDlg(CWnd::FromHandle(hDlg), lpps, BC);
						break;
					case 18:
						BC = (BYTE)(BC - 6);		//Modem string 1
						ShowModemParamsDlg(CWnd::FromHandle(hDlg), lpps, BC, option);
						break;
					case 19:
						BC = (BYTE)(BC - 6);		//Modem string 2
						ShowModemParamsDlg(CWnd::FromHandle(hDlg), lpps, BC, option);
						break;
					case 23:
						BC = (BYTE)(BC - 6);		//Message filter
						ShowMsgFilterParamsDlg(CWnd::FromHandle(hDlg), lpps, BC);						
						break;
					case 24:
						BC = (BYTE)(BC - 6);		//SNMP parameters
						ShowSNMPParamsDlg(CWnd::FromHandle(hDlg), lpps, BC);						
						break;

					case 26:
						BC = (BYTE)(BC - 6);		//Peer Parameters
						ShowPeerParamsDlg(CWnd::FromHandle(hDlg), lpps, BC);						
						break;

					case PP_PASSWORD_BLK:
						BC = (BYTE)(BC - 6);		//System Passwords
						ShowSystemPasswordsDlg(CWnd::FromHandle(hDlg), lpps, BC);						
						break;

					case PP_BATT_TEST_BLK:
						BC = (BYTE)(BC - 6);		//System Battery Test
						ShowSystemBatteryTestDlg(CWnd::FromHandle(hDlg), lpps, BC);						
						break;

					case PP_REMOTE_MAINT_DT_BLK:
						BC = (BYTE)(BC - 6);		//System Date Time for Remote Maintenance
						ShowRemoteMaintenanceDateTimeDlg(CWnd::FromHandle(hDlg), lpps, BC);						
						break;
						
					case PP_GPIP_PARAMS_BLK:
						BC = (BYTE)(BC - 6);
						ShowGPIPParamsDlg(CWnd::FromHandle(hDlg), lpps, BC);
						break;

					case PP_VAULT_CTRLS_BLK:
						BC = (BYTE)(BC - 6);
						ShowVaultControllerInterlocksDlg(CWnd::FromHandle(hDlg), lpps, BC);
						break;

					case PP_EMCS_PARAMS_BLK:
						BC = (BYTE)(BC - 6);
						ShowEMCSParamsDlg(CWnd::FromHandle(hDlg), lpps, BC);
						break;

					default:
						//wsprintf(str, _T("fc: %d blk: %d app %d sess %d link %d BC %d"), FunctionCode, lpps->lpData[0], lpps->lpData[1], lpps->lpData[2], lpps->lpData[3], BC);
						//MessageBox(NULL, str, NULL, MB_OK);
						
						if (FunctionCode == 139) {
							BC = (BYTE)(BC - 10); //-9
							ShowVCUPortParamsDlg(CWnd::FromHandle(hDlg), lpps, BC);
						}
						else if (FunctionCode == 147) {
							BC = (BYTE)(BC - 4);
							ShowVCUPortErrorDlg(CWnd::FromHandle(hDlg), lpps, BC);
						}
						break;
					}
					lpps->hmDlg = hDlg;
					lpps->BC = pblk_size[iblk];			//.Block Size
					break;
				}
			}
			break;

		case WM_RBUTTONDOWN:
		case WM_LBUTTONDOWN: {
			POINT pt;
			//int count = PORT_CNT;
			MAKEPOINTX(pt, lParam);
			for (i=0; i<PORT_CNT; i++) {
				CopyRect(&rc, &rc2000[i]);
				if (PtInRect(&rc, pt)) {
					if (message == WM_RBUTTONDOWN) {
						HMENU	PopUpMenu;
						HMENU	PopUpMenuTrack;
						RECT	Rect;
						GetWindowRect(hDlg, &Rect);
						PopUpMenu = LoadMenu(hrInst, MAKEINTRESOURCE(IDR_1057_PORTPOPUP));
						PopUpMenuTrack = GetSubMenu(PopUpMenu, 0);
						TrackPopupMenu(PopUpMenuTrack, TPM_LEFTALIGN | TPM_LEFTBUTTON, pt.x + Rect.left, pt.y + Rect.top, 0, hDlg, NULL);
						DestroyMenu(PopUpMenu);
						option = i;
						return(TRUE);
					}
					/* HDC hdc = GetDC(hDlg);
					HBRUSH hbr = SelectObject(hdc, CreateSolidBrush(PALETTEINDEX (0)));
					PatBlt(hdc, rc.left, rc.top, rc.right-rc.left,
							rc.bottom-rc.top, DSTINVERT);
					DeleteObject(SelectObject(hdc, hbr));
					ReleaseDC(hDlg, hdc);
					//FocusRect(hDlg, &rc, 2, 2);
					*/
					break;
				}
			}
			if (i >= PORT_CNT)
				MessageBeep(0);
			else {
				option = i;
				PostMessage(hDlg, WM_GMS, IDOK, 0);
				}
			break;
			}

		case WM_PAINT: {
			PAINTSTRUCT ps;
			POINT pt1, pt2;
			HDC hdc;

			pt1.x = pt1.y = 0;
			pt2.x = pt2.y = 0;
			hdc = BeginPaint(hDlg, &ps);
			DrawFileBitmap (hdc, pt1, pt2, P2000REAR_BMP_FILE, 0, 0, 0);
			//if (rc.left)
			//	PatBlt(hdc, rc.left, rc.top, rc.right-rc.left,
			//			rc.bottom-rc.top, DSTINVERT);
			EndPaint(hDlg, &ps);
			break;
			}
		}
	return FALSE;
}

