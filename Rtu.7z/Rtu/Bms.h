#pragma once

#include "StdHdrRtu.h"
#include "PortParm\StructsPortParm.h"
#include "HardwareConfig\Rtu\RDRCFG\RDRHDR.H"


using namespace Rtu;

#define MAX_BMS_GEN		8
#define MAX_BMS_PCNT	32
#define MAX_BMS_BACNET	2048
#define MAX_BMS_MODBUS	256
#define MAX_BMS_MACROS	1024

#define MAX_BMS_BACNET_DEVCFG 32
#define MAX_BMS_BACNET_ACTION 64

#define MODBUS_TX_MODE_RTU		0x01
#define MODBUS_TX_MOD_ASCII		0x02
#define MODBUS_BUS_MODE_MASTER	0x01
#define MODBUS_BUS_MODE_LISTEN	0x02

#define MODBUS_MAX_DIGITAL_INPUTS	32
#define MODBUS_MAX_ANALOG_INPUTS	16
#define MODBUS_MAX_DIGITAL_OUTPUTS	16

#define MODBUS_MAX_DIGITAL_INPUTS_LARGE		256
#define MODBUS_MAX_ANALOG_INPUTS_LARGE		16
#define MODBUS_MAX_DIGITAL_OUTPUTS_LARGE	64

#define BMS_UPLOAD			0
#define BMS_DOWNLOAD		1
#define BMS_PORT_UPLOAD		2
#define BMS_PORT_DOWNLOAD 	3

#define IDD_BMS_GET_PORT_PARAMS WM_USER
#define NUM_BMS_MACROS	170

typedef struct PULSE_CNT_DEF			PULSECNTDEF;
typedef struct BMS_CFG_MEMORY			BMSCFGMEMORY;
typedef struct BACnetProtocolConfig		BACnetProtocolCfg;
typedef struct BACnetInputConfig		BACnetInputCfg;
typedef struct BACnetActionConfig		BACnetActionCfg;		
typedef struct BACnetConfig				BACnetCfg;
typedef struct BMS_GENCFG_DEF			BmsGenCfg;
typedef struct Modbus_Param				ModbusPortCfg;
typedef struct ModbusIoConfig			ModbusIoCfg;
typedef struct ModbusPointConfig		ModbusPointCfg;
typedef struct ModbusPointConfigLarge	ModbusPointCfgLarge;
typedef struct MacroConfig				MacroCfg;

struct PULSE_CNT_DEF 
{
	uchar area;			// area number from 1 to 256
	uchar category;	
	uchar trigger;
	uchar flags;
	uchar spare[4];
};

struct BMS_CFG_MEMORY 
{
	uchar genCfg[MAX_BMS_GEN];
	PULSECNTDEF pcnt[MAX_BMS_PCNT];
	uchar bacNet[MAX_BMS_BACNET];
	uchar modBus[MAX_BMS_MODBUS];
	uchar bmsMacros[MAX_BMS_MACROS];
	uchar spare[500];
};

struct BMS_GENCFG_DEF {
     uchar tftpTime;
     uchar flags;
     uchar spare[6];
};

#pragma pack(1)
struct BACnetProtocolConfig 
{
	ulong myBacnetAddress;					// BACnet address of this device.
	uchar linkLayerProtocol;
	uchar numberOfApduRetries;
	uchar apduTimeOut;
	uchar apduSegmentTimeOut;
	uchar txSegmentWindowSize;
	uchar rxSegmentWindowSize;
	uchar alarmEnrollmentTime;
	uchar rtuPortNumber;
	ushort udpPortNumber;
	ushort spare1;
	ulong bbmdIpAddress;
	ushort networkNumber;
	ushort spare2;
	ulong spare3;
	ulong spare4;
	ulong spare5;
};

struct BACnetInputConfig	
{
	uchar notifyType_objectType;
	uchar eventType_pointType;
	uchar pointNumber;
	uchar spare1;
	ulong deviceNumber;
	ulong notificationClass;
	ulong objectInstance;
	ulong spare2;
};

struct BACnetActionConfig
{
	uchar serviceRequest_objectType;
	uchar newPresentValue;
	uchar pointNumber;
	uchar spare1;
	ulong deviceNumber;
	ulong objectInstance;
	ulong spare2;
};

#define BMS_BACNET_TOTAL_CFG_SIZE 2048
#define BMS_BACNET_VERSION_SIZE 2
#define BMS_BACNET_PROTOCOL_SIZE  sizeof(BACnetProtocolCfg)
#define BMS_BACNET_INPUTS_SIZE  (MAX_BMS_BACNET_DEVCFG*sizeof(BACnetInputCfg))
#define BMS_BACNET_ACTIONS_SIZE  (MAX_BMS_BACNET_ACTION*sizeof(BACnetActionCfg))
#define BMS_BACNET_SPARE_SIZE  (BMS_BACNET_TOTAL_CFG_SIZE - (4 + BMS_BACNET_PROTOCOL_SIZE + BMS_BACNET_INPUTS_SIZE + BMS_BACNET_ACTIONS_SIZE))
struct BACnetConfig
{
	ushort configStoreVersion;
	ushort spare1;
	BACnetProtocolCfg protocolCfg;
	BACnetInputCfg input[MAX_BMS_BACNET_DEVCFG];
	BACnetActionCfg action[MAX_BMS_BACNET_ACTION];
	uchar spare[BMS_BACNET_SPARE_SIZE];
};
#pragma pack()

//struct BACnetConfig
//{
//	ushort configStoreVersion;
//	ushort spare1;
//	BACnetProtocolCfg protocolCfg;
//	BACnetInputCfg input[MAX_BMS_BACNET_DEVCFG];
//	BACnetActionCfg action[MAX_BMS_BACNET_ACTION];
//	uchar spare[344];
//};


struct Modbus_Param
{
	uchar transmissionMode;			// Layer 2 transmission encoding mode
	uchar busInterfaceMode;			// Bus master (or just listening in)
	uchar devicePollReate;			// Poll rate (secs) for all device on this port
	uchar responseTime;				// Timeout period for polled device to respond
	SERCFG cfg;
};

struct ModbusIoConfig
{
	uchar portNumber;				// Port to which Modbus device is attached
	uchar deviceType;				// Type of modbus device
	uchar deviceAddress;			// Address of the device
	uchar dataType;					// Type of input, analog input or output
};

struct ModbusPointConfig
{
	ModbusIoCfg digitalInput[MODBUS_MAX_DIGITAL_INPUTS];
	ModbusIoCfg analogInput[MODBUS_MAX_ANALOG_INPUTS];
	ModbusIoCfg digitalOutput[MODBUS_MAX_DIGITAL_OUTPUTS];
};

struct ModbusPointConfigLarge
{
	ModbusIoCfg digitalInput[MODBUS_MAX_DIGITAL_INPUTS_LARGE];
	ModbusIoCfg analogInput[MODBUS_MAX_ANALOG_INPUTS_LARGE];
	ModbusIoCfg digitalOutput[MODBUS_MAX_DIGITAL_OUTPUTS_LARGE];
};

struct MacroConfig
{
	uchar con_devType;				// Condition and bms device type
	uchar countHi;					// Count to compare condition with (Hi byte)
	uchar countLo;					// Count to compare condition with (Lo byte)
	uchar areaNo;					// Area number from 1 to 32
	uchar opType_Num;				// Output type and number
	uchar actTime;					// Time in seconds to activate output (bit 7: min)
};

typedef struct _MACRO_CFG 
{
	MacroCfg cfg[NUM_BMS_MACROS];
	uchar spare[MAX_BMS_MACROS - NUM_BMS_MACROS*sizeof(MacroCfg)];
} BmsMacroCfg;

HWND ProcBmsConfig(HINSTANCE hrInst, HWND hSysWnd, HWND hParent, int iblk, LPPARMPROC lpps, int nShowCmd=SW_SHOW);

/////////////////////////////////////////////////////////////////////////////
// CRtuBmsConfig dialog

class CRtuBmsConfig : public CDialog
{
// Construction
public:
	
	//CRtuBmsConfig(CWnd* pParent = NULL) : CDialog(CRtuBmsConfig::IDD, pParent) {};   // standard constructor
	CRtuBmsConfig(HINSTANCE hInst, HWND hSysWnd, int iblk, LPPARMPROC lpps, BOOL bMsgToParent, CWnd* pParent = NULL);   // standard constructor
	~CRtuBmsConfig(){};

	void GetBmsConfig(LPPARMPROC lpps, int num);
	int SendBmsConfig(LPPARMPROC lpps, int num);
	void Upload(int blkNum);
	
	void UpdateMenu();
// Dialog Data
	//{{AFX_DATA(CRtuBmsConfig)
	enum { IDD = IDD_RTU_BMS_CFG_DLG };
	//}}AFX_DATA

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CRtuBmsConfig)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CRtuBmsConfig)
	virtual BOOL OnInitDialog();
	afx_msg LRESULT OnGms(WPARAM wParam, LPARAM lParam);
	afx_msg void OnConfigueGeneral();
	afx_msg void OnConfiguePulseCount();
	afx_msg void OnConfigueBacNet();
	afx_msg void OnConfigueModBus();
	afx_msg void OnConfigueMacros();
	afx_msg void OnConfigueExit();
	afx_msg void OnClose();
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnPrintGeneral();
	afx_msg void OnPrintPulseCounter();
	afx_msg void OnPrintBACNet();
	afx_msg void OnPrintModbus();
	afx_msg void OnPrintMacros();

	afx_msg void OnPaint();
	afx_msg LRESULT OnTextMessage(WPARAM, LPARAM);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	CWnd* m_pParent;
	LPPARMPROC m_lpps;
	int m_nBlkNum;
	int m_fDirn;
	int m_nRtuNumber;
	HINSTANCE m_hInst;
	HWND m_hRtuSysWnd;
	BOOL m_bStart;
	BOOL m_bIsValidParam;
	BOOL m_bPrintConfig;
	BOOL m_bMessageToParent;

	int m_nPortCnt;
	BOOL m_bCtrlKey;

	void GetPortConfig(LPPARMPROC lpps, LPBYTE pData);

	void ShowGeneralConfig(LPPARMPROC);
	void ShowPulseCounterConfig(LPPARMPROC);
	void ShowBACnetConfig(LPPARMPROC);
	void ShowModbusConfig(LPPARMPROC);
	void ShowMacroConfig(LPPARMPROC);

	void PrintGeneralConfg();
	void PrintPulseCounter();
	void PrintBACnet();
	void PrintModbus();
	void PrintMacros();
};


/////////////////////////////////////////////////////////////////////////////
// CRtuBmsGenCfg dialog
class CRtuBmsGenCfg : public CDialog
{
// Construction
public:
	enum {EN_PROT_NONE, EN_PROT_BACNET_ONLY, EN_PROT_MODBUS_ONLY, EN_PROT_BACNET_MODBUS};
	CRtuBmsGenCfg(int* dirn, LPPARMPROC lpps, CWnd* pParent = NULL);   // standard constructor
	~CRtuBmsGenCfg(){};
	 
	void ShowParams ();
	void StoreParams ();
	BOOL CheckParams ();

// Dialog Data
	//{{AFX_DATA(CRtuBmsGenCfg)
	enum { IDD = IDD_RTU_BMS_GEN_CFG_DLG };
	//}}AFX_DATA
	CNumEditEx m_txtGenTime;

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CRtuBmsGenCfg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CRtuBmsGenCfg)
	virtual BOOL OnInitDialog();
	virtual void OnCancel();
	virtual void OnOK();
	afx_msg void OnMidnight();
	afx_msg void OnSelchangeEnableProtocol();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	CComboBox  m_cboEnProtocol;
	LPPARMPROC m_lpps;
	int* m_fDirn;
	BYTE m_nEnableProtocol;
	BmsGenCfg m_genCfg;
};


/////////////////////////////////////////////////////////////////////////////
// CRtuBmsPulseCounter dialog

class CRtuBmsPulseCounter : public CDialog
{
// Construction
public:
	CRtuBmsPulseCounter(int* dirn, LPPARMPROC lpps, CWnd* pParent = NULL);   // standard constructor
	~CRtuBmsPulseCounter(){};
	 
	void ShowParams (int );
	void StoreParams (int );
	BOOL CheckParams ();

// Dialog Data
	//{{AFX_DATA(CRtuBmsPulseCounter)
	enum { IDD = IDD_RTU_BMS_PCNT_DLG };
	//}}AFX_DATA
   CComboBox m_cboCategory;
   CNumEditEx m_txtArea;
   CNumEditEx m_txtTrigger;

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CRtuBmsPulseCounter)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CRtuBmsPulseCounter)
	virtual BOOL OnInitDialog();
	virtual void OnCancel();
	virtual void OnOK();
	afx_msg void OnChangeCategory();
	afx_msg void OnPrevNext(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnPcntNumber();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	int m_nPcntNum;
	LPPARMPROC m_lpps;
	PULSECNTDEF m_bmsPcnt;	int* m_fDirn;
};



/////////////////////////////////////////////////////////////////////////////
// CRtuBmsBACnetDevCfg dialog
class CRtuBmsBACnetDevCfg : public CPropertyPage
{
	DECLARE_DYNCREATE(CRtuBmsBACnetDevCfg)

// Construction
public:
	CRtuBmsBACnetDevCfg() : CPropertyPage(CRtuBmsBACnetDevCfg::IDD){
		};
	~CRtuBmsBACnetDevCfg(){};

	void ShowConfig();
	void StoreConfig();
	BOOL CheckConfig();

// Dialog Data
	//{{AFX_DATA(CRtuBmsBACnetDevCfg)
	enum { IDD = IDD_RTU_BMS_BNET_DEV_CFG_DLG };
	CComboBox m_cboNotifyType;
	CComboBox m_cboObjectType;
	CComboBox m_cboEventType;
	CComboBox m_cboPointType;
	CNumEditEx m_txtDevAddr;
	CNumEditEx m_txtNotifyClass;
	CNumEditEx m_txtObjInstance;
	CNumEditEx m_txtPointNum;
		// NOTE - ClassWizard will add data members here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CRtuBmsBACnetDevCfg)
	public:
	virtual BOOL OnInitDialog();
	virtual BOOL OnKillActive();
	virtual BOOL OnSetActive();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CRtuBmsBACnetDevCfg)
	afx_msg void OnDeviceNumber();
	afx_msg void OnPrevNext(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnBtnDelete();
	afx_msg void OnBtnCopy();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	int m_nDevNum;
};

/////////////////////////////////////////////////////////////////////////////
// CRtuBmsBACnetProtocol dialog

class CRtuBmsBACnetProtocol : public CPropertyPage
{
	DECLARE_DYNCREATE(CRtuBmsBACnetProtocol)

// Construction
public:
	CRtuBmsBACnetProtocol() : CPropertyPage(CRtuBmsBACnetProtocol::IDD){};
	~CRtuBmsBACnetProtocol(){};

	void ShowConfig();
	void StoreConfig();
	BOOL CheckConfig();
	int GetPortNumber();

// Dialog Data
	//{{AFX_DATA(CRtuBmsBACnetProtocol)
	enum { IDD = IDD_RTU_BMS_BNET_PROT_PARM_DLG };

	CComboBox m_cboLinkLayer;
	CComboBox m_cboRtuPortNum;
	CIPAddressCtrl m_ipBbmdAddr;
	CNumEditEx m_txtBACnetDevInstance;
	CNumEditEx m_txtBACnetNwNumber;
	CNumEditEx m_txtNumAPDUretries;
	CNumEditEx m_txtAPDUsegTimeOut;
	CNumEditEx m_txtAPDUTimeOut;
	CNumEditEx m_txtTxSegWinSize;
	CNumEditEx m_txtRxSegWinSize;
	CNumEditEx m_txtAlmEnrolTime;
	CNumEditEx m_txtBACnetUDPport;
	// NOTE - ClassWizard will add data members here.
	//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CRtuBmsBACnetProtocol)
	public:
	virtual BOOL OnInitDialog();
	virtual BOOL OnKillActive();
	virtual BOOL OnSetActive();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CRtuBmsBACnetProtocol)
	//virtual BOOL OnCommand(WPARAM wParam, LPARAM lParam);
	//afx_msg void OnReboot();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	//BACnetProtocolCfg m_protCfg;
	int GetPortIndexFromPortNumber(int portNumber);
	int GetPortNumberFromPortIndex(int portIndex);
};

/////////////////////////////////////////////////////////////////////////////
// CRtuBmsBACnetAction dialog
class CRtuBmsBACnetAction : public CPropertyPage
{
	DECLARE_DYNCREATE(CRtuBmsBACnetAction)

// Construction
public:
	CRtuBmsBACnetAction() : CPropertyPage(CRtuBmsBACnetAction::IDD){};
	~CRtuBmsBACnetAction(){};

	void ShowConfig();
	void StoreConfig();
	BOOL CheckConfig();

// Dialog Data
	//{{AFX_DATA(CRtuBmsBACnetAction)
	enum { IDD = IDD_RTU_BMS_BNET_ACT_DLG };
	CComboBox m_cboServReqType;
	CComboBox m_cboObjType;
	CNumEditEx m_txtDeviceNumber;
	CNumEditEx m_txtObjectInstance;
	CNumEditEx m_txtPresentValue;
	CNumEditEx m_txtOutputPntNum;
		// NOTE - ClassWizard will add data members here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CRtuBmsBACnetAction)
	public:
	virtual BOOL OnInitDialog();
	virtual BOOL OnKillActive();
	virtual BOOL OnSetActive();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CRtuBmsBACnetAction)
	afx_msg void OnActionNumber();
	afx_msg void OnPrevNext(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnBtnDelete();
	afx_msg void OnBtnCopy();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	//BACnetActionCfg m_actCfg;
	int m_nActNum;
};



/////////////////////////////////////////////////////////////////////////////
// CRtuBmsBACnet dialog

class CRtuBmsBACnet : public CDialog
{
// Construction
public:
	CRtuBmsBACnet(int* dirn, LPPARMPROC lpps, CWnd* pParent = NULL);// : 
	  ~CRtuBmsBACnet(){}

// Dialog Data
	//{{AFX_DATA(CRtuBmsBACnet)
	enum { IDD = IDD_RTU_BMS_BNET_DLG };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CRtuBmsBACnet)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	CRtuBmsBACnetDevCfg m_pageDevCfg;
	CRtuBmsBACnetProtocol m_pageProtocol;
	CRtuBmsBACnetAction m_pageAction;
	CPropertySheet m_sheet;
	// Generated message map functions
	//{{AFX_MSG(CRtuBmsBACnet)
	virtual BOOL OnInitDialog();
	afx_msg void OnOK();
	afx_msg void OnCancel();
	afx_msg void OnReboot();
	afx_msg LRESULT OnGms(WPARAM wParam, LPARAM lParam);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

private:
	//LPPARMPROC m_lpps;
	int* m_fDirn;

	PARMPROC m_lpps;
	BYTE data[RTU_BUFF_SIZE];

	HWND m_hmWnd;
	CFont m_wndFont;
};


/////////////////////////////////////////////////////////////////////////////
// CRtuBmsBACnetActCopy dialog
class CRtuBmsBACnetActCopy : public CDialog
{
// Construction
public:
	CRtuBmsBACnetActCopy(CWnd* pParent = NULL) : 
	  CDialog(CRtuBmsBACnetActCopy::IDD, pParent){};   // standard constructor
	CRtuBmsBACnetActCopy(int max, int i, int type, CWnd* pParent = NULL) : 
	  CDialog(CRtuBmsBACnetActCopy::IDD, pParent){
		  num=i; m_nMax=max; m_nCfg=type;};   // standard constructor

	BOOL CheckParams();
	void StoreParams();
	void ShowParams();
	
// Dialog Data
	//{{AFX_DATA(CRtuBmsBACnetActCopy)
	enum { IDD = IDD_RTU_BMS_BNET_COPY_DLG };
	//}}AFX_DATA

	CNumEditEx m_txtFrom;
	CNumEditEx m_txtStart;
	CNumEditEx m_txtEnd;
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CRtuBmsBACnetActCopy)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CRtuBmsBACnetActCopy)
	virtual BOOL OnInitDialog();
	afx_msg void OnCancel();
	afx_msg void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	int num;
	int m_nMax;
	int m_nCfg;
};


/////////////////////////////////////////////////////////////////////////////
// CRtuBmsModbusDigitalInput dialog
class CRtuBmsModbusDigitalInput : public CPropertyPage
{
	DECLARE_DYNCREATE(CRtuBmsModbusDigitalInput)

// Construction
public:
	CRtuBmsModbusDigitalInput() : CPropertyPage(CRtuBmsModbusDigitalInput::IDD){};
	~CRtuBmsModbusDigitalInput(){};

	void ShowConfig();
	void StoreConfig();
	BOOL CheckConfig();
	void EnableInputBox();
	ModbusIoCfg m_inpCfg[MODBUS_MAX_DIGITAL_INPUTS_LARGE];

// Dialog Data
	//{{AFX_DATA(CRtuBmsModbusDigitalInput)
	enum { IDD = IDD_MODBUS_DIG_INP_DLG };
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CRtuBmsModbusDigitalInput)
	public:
	virtual BOOL OnInitDialog();
	virtual BOOL OnKillActive();
	virtual BOOL OnSetActive();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CRtuBmsModbusDigitalInput)
	afx_msg void OnInputNumber();
	afx_msg void OnPrevNext(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnSelChangePort();
	afx_msg void OnSelChangeDeviceType();
	afx_msg void OnSelChangeInputType();
	afx_msg void OnBtnDelete();
	afx_msg void OnBtnCopy();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	int m_nInpNum;

	CNumEditEx m_txtDevAddr;
	CComboBoxDisabledItem m_cboModbusPort;
	CComboBox m_cboDevType;
	CComboBoxDisabledItem m_cboInpType;
	BOOL m_bInputEn[255];
};

/////////////////////////////////////////////////////////////////////////////
// CRtuBmsModbusDigitalOutput dialog
class CRtuBmsModbusDigitalOutput : public CPropertyPage
{
	DECLARE_DYNCREATE(CRtuBmsModbusDigitalOutput)

// Construction
public:
	CRtuBmsModbusDigitalOutput() : CPropertyPage(CRtuBmsModbusDigitalOutput::IDD){};
	~CRtuBmsModbusDigitalOutput(){};

	void ShowConfig();
	void StoreConfig();
	BOOL CheckConfig();
	void EnableOutputBox();
	ModbusIoCfg m_outCfg[MODBUS_MAX_DIGITAL_OUTPUTS_LARGE];

// Dialog Data
	//{{AFX_DATA(CRtuBmsModbusDigitalOutput)
	enum { IDD = IDD_MODBUS_DIG_OUT_DLG };
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CRtuBmsModbusDigitalOutput)
	public:
	virtual BOOL OnInitDialog();
	virtual BOOL OnKillActive();
	virtual BOOL OnSetActive();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CRtuBmsModbusDigitalOutput)
	afx_msg void OnOutputNumber();
	afx_msg void OnPrevNext(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnSelChangePort();
	afx_msg void OnSelChangeDeviceType();
	afx_msg void OnSelChangeOutputType();
	afx_msg void OnBtnDelete();
	afx_msg void OnBtnCopy();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	int m_nOutNum;

	CNumEditEx m_txtDevAddr;
	CComboBoxDisabledItem m_cboModbusPort;
	CComboBox m_cboDevType;
	CComboBoxDisabledItem m_cboOutType;
	BOOL m_bOutputEn[255];
};

/////////////////////////////////////////////////////////////////////////////
// CRtuBmsModbusAnalogInput dialog
class CRtuBmsModbusAnalogInput : public CPropertyPage
{
	DECLARE_DYNCREATE(CRtuBmsModbusAnalogInput)

// Construction
public:
	CRtuBmsModbusAnalogInput() : CPropertyPage(CRtuBmsModbusAnalogInput::IDD){};
	~CRtuBmsModbusAnalogInput(){};

	void ShowConfig();
	void StoreConfig();
	BOOL CheckConfig();
	void EnableInputBox();
	ModbusIoCfg m_inpCfg[MODBUS_MAX_ANALOG_INPUTS_LARGE];

// Dialog Data
	//{{AFX_DATA(CRtuBmsModbusAnalogInput)
	enum { IDD = IDD_MODBUS_ANAL_INP_DLG };
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CRtuBmsModbusAnalogInput)
	public:
	virtual BOOL OnInitDialog();
	virtual BOOL OnKillActive();
	virtual BOOL OnSetActive();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CRtuBmsModbusAnalogInput)
	afx_msg void OnInputNumber();
	afx_msg void OnPrevNext(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnSelChangePort();
	afx_msg void OnSelChangeDeviceType();
	afx_msg void OnSelChangeInputType();
	afx_msg void OnBtnDelete();
	afx_msg void OnBtnCopy();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	int m_nInpNum;

	CNumEditEx m_txtDevAddr;
	CComboBoxDisabledItem m_cboModbusPort;
	CComboBox m_cboDevType;
	CComboBoxDisabledItem m_cboInpType;
	BOOL m_bInputEn[255];
};



/////////////////////////////////////////////////////////////////////////////
// CRtuBmsModbus dialog
class CRtuBmsModbus : public CDialog
{
// Construction
public:
	CRtuBmsModbus(int* dirn, LPPARMPROC lpps, CWnd* pParent = NULL);// : 
	  ~CRtuBmsModbus(){}
   
// Dialog Data
	//{{AFX_DATA(CRtuBmsModbus)
	enum { IDD = IDD_MODBUS_DLG };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CRtuBmsModbus)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	CRtuBmsModbusDigitalInput m_pageDigInp;
	CRtuBmsModbusDigitalOutput m_pageDigOut;
	CRtuBmsModbusAnalogInput m_pageAnalInp;

	CPropertySheet m_sheet;
	// Generated message map functions
	//{{AFX_MSG(CRtuBmsModbus)
	virtual BOOL OnInitDialog();
	afx_msg void OnOK();
	afx_msg void OnCancel();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

private:
	int* m_fDirn;
	BYTE data[RTU_BUFF_SIZE];
	PARMPROC m_lpps;
	HWND m_hmWnd;
	CFont m_wndFont;
};


/////////////////////////////////////////////////////////////////////////////
// CRtuBmsMacroConfig dialog

class CRtuBmsMacroConfig : public CDialog
{
// Construction
public:
	CRtuBmsMacroConfig(int* dirn, LPPARMPROC lpps, CWnd* pParent = NULL);   // standard constructor
	~CRtuBmsMacroConfig(){};
	 
	void ShowParams ();
	void StoreParams ();
	BOOL CheckParams ();

// Dialog Data
	//{{AFX_DATA(CRtuBmsMacroConfig)
	enum { IDD = IDD_BMS_MACRO_DLG };
	//}}AFX_DATA

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CRtuBmsMacroConfig)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CRtuBmsMacroConfig)
	virtual BOOL OnInitDialog();
	virtual void OnCancel();
	virtual void OnOK();
	afx_msg void OnPrevNext(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnBtnMacroNumber();
	afx_msg void OnSelChangeOutputType();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	LPPARMPROC m_lpps;
	MacroCfg m_cfg;	
	int* m_fDirn;
	int m_nCount;

	int m_nMacroNum;
	CNumEditEx m_txtCount;
	CNumEditEx m_txtAreaNum;
	CNumEditEx m_txtOutputNum;
	CNumEditEx m_txtActTime;
	CComboBox m_cboDevType;
	CComboBox m_cboCond;
	CComboBox m_cboOpType;
};

