#pragma once


#include "StdHdrRtu.h"
#include "PortParm\StructsPortParm.h"
#include "PORTPARM\PORTPARM.H"
#include "PORTPARM\PortErrs.h"
#include "GalaxyPanel.h"
#include "PanelGrf\PanelCfg.h"
#include "RtuStatus.h"

/////////////////////////////////////////////////////////////////////////////

typedef enum _SYSTEM_COMMANDS
{
	SofwareResetCMD = 0,
	GoOnlineCMD = 1,
	GoOfflineCMD = 2,
	GotoDayModeCMD = 3,
	GotoNightModeCMD = 4,
	RequestSetPanelCMD = 5,
	RequestDialupTestOnSecondAndTertiaryPortsCMD = 7,
	RequestSerialNumberCMD = 8,
	ResetLatchAlarmsCMD = 10,
	ResetLatchOutputsCMD = 11,
	WriteEEPROMParametersCMD = 12,
	ResetAllPortErrorStatisticsCMD = 14,
	ResetAlarmPanelErrorStatisticsCMD = 15,
	ResetPrimaryPortErrorStatisticsCMD = 16,
	ResetSecondaryTertiaryBackupPortErrorStatisticsCMD = 17,
	RequestRtuBlockSizesCMD = 18,
	LockoutKeypadCMD = 19,
	ResetLockoutKeypadCMD = 20,
	ForceExitModeCMD = 22,
	ForceEntryModeCMD = 23,
	ForceOffDialupCMD = 24,
	ResetToIdleCMD = 29,
	ChangeLineConnectionCMD = 30,
	ResetInputCMD = 31,
	RequestSummaryStatusCMD = 32,
	IsolateDeisolatePointsCMD = 33,
	SetTimeZoneReferenceCMD = 34,
	RequestTimeZoneDataCMD = 35,
	AccessControlCommandCMD = 36,
	DownloadFacilityCMD = 37,
	DialoutCommandCMD = 38,
	RemotePanelCommandCMD = 39,
	CCTVCommandCMD = 40,
	ResetAccessControlErrorsCMD = 41,
	GetZoneStatusCMD = 42,
	ResetPortErrorStatisticsCMD = 43,
	DownloadHolidayChangeCMD = 44,
	RequestBMSConfigCMD = 45,
	RequestBatteryTestCMD = 47,
	RequestElevatorStatusCMD = 53,
	RequestPeopleCountDataCMD = 54,
	SendInovonicsCommandCMD = 55,
	ShutdownWitnessHardDiskCMD = 56,
	EnableDisableRemoteCommandCMD = 58,
	PerformFirePowerBatteryTestCMD = 59,
	PerformPowerMonitorLoadTestCMD = 60,
	VaultControllerCommandCMD = 61,
	RequestMultipleInputPointStatusReportsCMD = 62
} E_SYSTEM_COMMANDS;

typedef enum _COMMAND_RESPONSE_FC
{
	SystemCommandsFC = 21,
	TimesetCommandFC = 22,
	ExternalPointIsolateFC = 23,
	ExternalPointDeisolateFC = 24,
	InternalPointIsolateFC = 25,
	InternalPointDeisolateFC = 26,
	RequestParametersFC = 29,
	DownloadParametersFC = 30,
	OutputOnIsolateFC = 31,
	OutputOffDeisolateFC = 32,
	RequestRtuVersionInfoFC = 33,
	RequestUserIDsFC = 34,
	DownloadUserIDsFC = 35,
	DiagnosticFC = 46,
	RequestPointStatusFC = 47,
	HeartbeatMessgeFC = 48,
	RequestConfigUsingStreamFC = 49,
	DownloadConfigUsingStreamFC = 50,
	RequestSoftwareDownloadUsingStreamFC = 51,
	DownloadSoftwareUsingStreamFC = 52,
	MasterModeFC = 53,
	MessageToKeypadFC = 54,
	StoreIDFC = 55,
	RemotePanelCommandFC = 56,
	RequestStatusUsingStreamFC = 60,
	ProgramNewRtuAddressFC = 61,
	PSPCommandResponseFC = 62,
	RequestSetTimezoneFC = 63,
	RequestConfigDataFC = 67,
	DownloadConfigDataFC = 68

}E_COMMAND_RESPONSE_FC;

typedef enum CONTROLLER_STATUS 
{
	E_CTRL_STAT_IDLE = 0,
	E_CTRL_STAT_UPLOADING = 1,
	E_CTRL_STAT_DOWNLOADING = 2
}E_CONTROLLER_STATUS;

class CPropertyPageTaskPanelNavigator : public CXTPTaskPanel, public CXTPPropertyPageControlNavigator
{
public:
	CPropertyPageTaskPanelNavigator();

public:
	virtual BOOL Create();
	virtual void OnPageSelected(CXTPPropertyPage* pPage);
	virtual HWND GetSafeHwnd() const { return m_hWnd; }

protected:
	virtual void SetFocusedItem(CXTPTaskPanelItem* pItem, BOOL bDrawFocusRect = FALSE, BOOL bSetFocus = TRUE);
};

/////////////////////////////////////////////////////////////////////////////
// CRtuSystemCommands window
class CRtuSystemCommands : public CWnd
{
public:
	CRtuSystemCommands(CWnd* pParent=NULL);
	virtual ~CRtuSystemCommands();

protected:
	afx_msg void OnDestroy();
	afx_msg LRESULT OnGms(WPARAM, LPARAM);
	afx_msg LRESULT OnTextMessage(WPARAM wParam, LPARAM lParam);

	DECLARE_MESSAGE_MAP()

private:
	PARMPROC m_pps;
	BYTE m_ppsData[100];
	CWnd* m_pParent;
	int m_nRtuNumber;
	int m_nTimezone;
	TCHAR m_strTimeZone[80];

	void ShowControllerTimeZone(LPBYTE pData);
	void CopyParam(LPPARMPROC lpps);
	int GetCommandOption(int nMenuOption);
	int GetCommand(int nMenuOption);
	int GetRtuSystemCommand(int nOption);

	void ChangeMode(int nRtuCommand);
	void ChangeMode2(int nRtuCommand, int nMode=-1);
	void ExecuteModeCommand(ulong nSelectedAreas, int nRtuCommand, UINT dbyte);
	void ResetAllAlarms(int nRtuCommand, UINT dbyte);
	void RestoreInput();
	void Isolate_DeisolateGroupPoints();
	void PutRtuOffline();
	ulong GetAreas();

public:
	void ExecuteSystemCommand(LPPARMPROC lpps, UINT nCommandID, int nDByte=-1, int nMode=-1);

	void GetControllerTimezone();
	void SetControllerTimezone();
	//void GetControllerTimezone(LPPARMPROC lpps);
	//void SetControllerTimezone(LPPARMPROC lpps);
	
};

// CRtuPortParamsConfig window
class CRtuPortParamsConfig : public CWnd
{
public:
	CRtuPortParamsConfig(CWnd* pParent=NULL);

public:
	enum { E_GET_PROT_STATE = 1, E_GET_ACC_NUM_SIZE_STATE = 2 };
	enum { E_PORT_ERROR = 1, E_PRIORITY_ERROR = 2 };
	virtual ~CRtuPortParamsConfig();

protected:
	afx_msg void OnDestroy();
	afx_msg LRESULT OnGms(WPARAM, LPARAM);
	afx_msg LRESULT OnTextMessage(WPARAM wParam, LPARAM lParam);

	DECLARE_MESSAGE_MAP()

private:
	//static CRtuPortParamsConfig* m_pSingleton; // a singleton

	PARMPROC m_pps;
	BYTE m_ppsData[RTU_BUFF_SIZE];
	CWnd* m_pParent;
	int m_nOption;
	int m_nCommandID;
	int m_rxState;
	int m_nError;
	//int m_nProtNum;

	void ShowAdvancedPortConfig(LPBYTE pData);
	void ShowPortError();
	void ShowPortPriorityError();

public:

	void GetPortConfig(LPPARMPROC lpps, int nCommandID, int nOption, BOOL bError=FALSE);
	void GetNetworkError(LPPARMPROC lpps);
};

// CDialogSampleDlg dialog
class CRtuCtrlTemplate : public CWnd
{
public:
	typedef struct tagHeaderInfo{
		BYTE nNumChips;
		BYTE nRtuType;
		BYTE nPanelType;
		BYTE reserved[5];
	} _HeaderInfo;
	CRtuCtrlTemplate(LPPARMPROC lpps, CWnd* pParent=NULL);
	virtual ~CRtuCtrlTemplate();

	enum { E_MAX_FILE_INFO = 6, E_MAX_CHIP_COUNT = 256, E_BUFF_SIZE = 250 };
protected:
	afx_msg void OnDestroy();
	afx_msg LRESULT OnGms(WPARAM, LPARAM);
	afx_msg LRESULT OnTextMessage(WPARAM wParam, LPARAM lParam);
	DECLARE_MESSAGE_MAP()

private:
	PARMPROC m_pps;
	BYTE m_ppsData[E_BUFF_SIZE];
	CWnd* m_pParent;

	CStringArray m_uploadFiles;
	CStringArray m_strArrTempFiles;
	int m_nRtuNum;
	BYTE m_nChipCount;
	int m_nMaxChip;
	E_CONTROLLER_STATUS m_eStatus;
	DefaultLocation m_fName;
	CString m_fileName;
	CString m_strTemplateName;

public:
	void UploadConfig(LPTSTR szFileName);
	void DownloadConfig(LPTSTR szFileName);
	E_CONTROLLER_STATUS GetStatus() { return m_eStatus; }
private:
	void SaveFileInfo();
	int ProcNextCmd(CString);
	DWORD GetFileSize(CString strFileName);
	void SaveConfig();
	void SaveHeader(CFile* pFile);
	BOOL GetHeaderInfo(CFile* pFile, _HeaderInfo* pInfo);
	BOOL ShowControllerInfo(LPBYTE pBuffer, _HeaderInfo* pInfo);
	void DeleteTempFiles(CStringArray& strArrTempFiles);
	CString GetNewTemplateName();
};


//====================================================================================//
//====================================================================================//


#define CRtuCtrlCfgDlgBase CXTPDialogBase<CXTResizeDialog>
class CRtuCtrlCfgDlg : public CRtuCtrlCfgDlgBase
{
// Construction
public:
	CRtuCtrlCfgDlg(SETUPPARM* lpSetupParam, HWND hpWnd, CWnd* pParent = NULL); // standard constructor
	virtual ~CRtuCtrlCfgDlg();
	enum { E_PRINT_ALL_ALARM = 1, E_PRINT_ALL_CARD_ACCESS = 2 };
// Dialog Data
	//{{AFX_DATA(CRtuCtrlCfgDlg)
	enum { IDD = IDD_RTU_CTRL_CFG_DLG };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CRtuCtrlCfgDlg)
	public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual BOOL OnCommand(WPARAM wParam, LPARAM lParam);
	//}}AFX_VIRTUAL

// Implementation
protected:
	//HICON m_hIcon;
	CXTPStatusBar m_wndStatusBar;
	void RepositionControls();
	CRect m_rcBorders;
	BOOL m_bInRepositionControls, m_bInitDone;
	//XTPPaintTheme m_eTheme;
	
	// Generated message map functions
	//{{AFX_MSG(CRtuCtrlCfgDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnDestroy();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnClose();
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnRButtonDown(UINT nFlags, CPoint point);
	afx_msg int OnCreateControl(LPCREATECONTROLSTRUCT lpCreateStruct);
	//}}AFX_MSG

	//
	// File...
	afx_msg void OnFileRtuTemplate();
	afx_msg void OnFileLoadTemplateFromFile();
	afx_msg void OnFileSaveTemplateToFile();
	afx_msg void OnFileSaveTemplateToDongle();
	afx_msg void OnFileSetupWizard();
	afx_msg void OnFileOptions();
	afx_msg void OnFileExportAllConfigurations();
	afx_msg void OnFileExportAlarmsAll();
	afx_msg void OnFileExportAlarms(UINT nCommandID);
	afx_msg void OnFileExportAlarmsHardware(UINT nCommandID);
	afx_msg void OnFileExportAlarmsSystems(UINT nCommandID);
	afx_msg void OnFileExportAlarmsHours(UINT nCommandID);
	afx_msg void OnFileExportAccessControl(UINT nCommandID);
	afx_msg void OnFileUploadConfiguration();
	afx_msg void OnFileDownloadConfiguration();
	afx_msg void OnFileExit();

	//
	// view...
	afx_msg void OnViewControllerLicences();
	afx_msg void OnViewControllerAccountDetails();
	afx_msg void OnViewControllerStatus(UINT nCommandID);
	afx_msg void OnViewCardAccessDiagnostics();
	afx_msg void OnViewAccessControlCards();
	afx_msg void OnViewSingleCard();
	afx_msg void OnViewDataLineErrors();
	afx_msg void OnViewDialupErrors();
	afx_msg void OnViewPortErrors(UINT nCommandID);
	afx_msg void OnViewModemString1();
	afx_msg void OnViewModemString2();
	afx_msg void OnViewAlarmVocab();
	afx_msg void OnViewNetworkDiagnostics();

	
	// Commands...
	afx_msg void OnCommandFirmware(UINT nCommandID);
	afx_msg void OnCommandController(UINT nCommandID);
	afx_msg void OnCommandShutdownHardDrive(UINT nCommandID);
	afx_msg void OnCommandControllerWriteToEEPROM(UINT nCommandID);
	afx_msg void OnCommandMode(UINT nCommandID);
	afx_msg void OnCommandKeypad(UINT nCommandID);
	afx_msg void OnCommandErrorStatistics(UINT nCommandID);
	afx_msg void OnCommandTest(UINT nCommandID);
	afx_msg void OnCommandTestFirePowerBattery(UINT nCommandID);
	afx_msg void OnCommandAccessControl();
	afx_msg void OnCommandResetAllAlarms();
	afx_msg void OnCommandResetAllOutputs();
	afx_msg void OnCommandResetAllAlarmsAndOutputs();
	afx_msg void OnCommandRestoreInput();
	afx_msg void OnCommandIsolateInput();
	afx_msg void OnCommandDeisolateInput();
	afx_msg void OnCommandGroupCommand();
	afx_msg void OnCommandRestoreOutput();
	afx_msg void OnCommandActivateOutput();
	afx_msg void OnCommandDeactivateOutput();
	afx_msg void OnCommandIsolateOutput();
	afx_msg void OnCommandDeisolateOutput();
	afx_msg void OnCommandOpenVault();
	afx_msg void OnCommandProgramInovonicsTransmitter();
	afx_msg void OnCommandUserDefineCommand();
	afx_msg void OnCommandUserDefineCommandRange(UINT nCommandID);
	afx_msg void OnCommandResetPspToIdle();
	afx_msg void OnCommandEnableTriggerEvents();
	afx_msg void OnCommandDisableTriggerEvents();
	afx_msg void OnCommandProgramEOLResistor();
	afx_msg void OnCommandEnableRemoteCommands();
	afx_msg void OnCommandDisableRemoteCommands();

	// Generals...
	afx_msg void OnGeneralControllerType();
	afx_msg void OnGeneralControllerPasswords();
	afx_msg void OnGeneralPeerToPeerSettings();
	afx_msg void OnGeneralTFTPServerSettings();
	afx_msg void OnGeneralAlarmEventsFilter();
	afx_msg void OnGeneralYearlyCalendarAlarms();
	afx_msg void OnGeneralYearlyCalendarCardAccess();
	afx_msg void OnGeneralControllerSettings();
	afx_msg void OnGeneralPortSettings();
	afx_msg void OnGeneralSNMPSettings();
	afx_msg void OnGeneralPowerSupplySettings();
	afx_msg void OnGeneralRemoteMaintenanceSettings();
	afx_msg void OnGeneralPSPSettings();
	afx_msg void OnGeneralGPIPSettings();
	afx_msg void OnGeneralEMCSSettings();
	
	// Alarm...
	afx_msg void OnAlarmHardware();
	afx_msg void OnAlarmHardwareConfigure(UINT nCommandID);
	afx_msg void OnAlarmHardwareVaultController();
	afx_msg void OnAlarmArea();
	afx_msg void OnAlarmAccessHours(UINT nCommandID);
	afx_msg void OnAlarmCounterSettings();
	afx_msg void OnAlarmSystemParamters();
	afx_msg void OnAlarmSystemFlags();
	afx_msg void OnAlarmUsers();
	afx_msg void OnAlarmTemporarySchedule();
	afx_msg void OnAlarmTimeSchedules();
	afx_msg void OnAlarmGlobalResistorSettings(); //TT 8120
	
	// Access control...
	//afx_msg void OnAccessControlCommand(UINT nCommandID);
	afx_msg void OnAccessControlAddReader();
	afx_msg void OnAccessControlReaders();
	afx_msg void OnAccessControlAreaProfiles();
	afx_msg void OnAccessControlElevatorSettings();
	afx_msg void OnAccessControlUnlockedFloors();
	afx_msg void OnAccessControlCardTypeSettings();
	afx_msg void OnAccessControlCardFormats();
	afx_msg void OnAccessControlTimeSchedules();
	afx_msg void OnAccessControlOpenCloseSchedule();
	afx_msg void OnAccessControlOverallSettings();

	// Building management...
	afx_msg void OnbuildingManagementTFPTServerUpdate();
	afx_msg void OnbuildingManagementTrendBmsSettings();
	afx_msg void OnbuildingManagementModbusSettings();
	afx_msg void OnbuildingManagementBacnetSettings();
	afx_msg void OnbuildingManagementGeneralSettings();
	
	// Macros...
	afx_msg void OnMacroAlarmEvents();
	afx_msg void OnMacroAlarmMacros();
	afx_msg void OnMacroReaderMacros();
	afx_msg void OnMacroBmsMacros();

	//
	afx_msg LRESULT OnGms(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT OnTextMessage(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT OnRtuStatusMessage(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT OnAlarmHardwareConfigUploaded(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT OnAlarmHardwareConfigDownloaded(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT OnConfigUploaded(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT OnConfigDownloaded(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT OnConfigDownloading(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT OnConfigChanged(WPARAM wParam, LPARAM lParam);
	afx_msg void OnChangeID();
	afx_msg void OnSelChangeView();
	afx_msg void OnHelpContents(); // TT#3780
	afx_msg BOOL OnHelpInfo(HELPINFO* lpHelpInfo); // TT#3780

	DECLARE_MESSAGE_MAP()

private:

	PARMPROC	m_rtups;
	PARMPROC	m_lpps2; 
	PARMPROC	m_ppsBms; 
	BYTE		m_lpps2Data[100];
	BYTE		m_ppsBmsData[100];
	uchar		m_bCommovr;
	int			m_option;
	int			m_rtuno;
	LPPARMPROC	m_lpps;
	LPPARMPROC	m_lpaps;
	BOOL		m_bIsValidAlarmCfg;
	UINT		m_nCommandID;
	int			m_nRtuNumber;
	int			m_nPanelType;
	BOOL		m_bRequestGenBmsCfg;
	int			m_nReqRtuNumber;
	int			m_nPrintCfg;
	BOOL		m_bRtuStatus;
	BOOL		m_bWaitDownload;
	BOOL		m_bReqChangeID;
	BYTE		m_nCurStatus;
	BOOL		m_bConfigDownloading;
	BOOL		m_bReqCloseWindow;
	BOOL		m_bStatusPrivilege;
	HWND		m_hpWnd;

	CXTPPropertySheet	m_ps;
	CRTUStatus2			m_rtuStatusPage2;
	CControllerDevicesPage m_rtuDevicesPage;
	CXTPControlEdit*   m_pControllerID;
	CXTPControlButton* m_pDownloadMenu;
	CXTPControlComboBox* m_pCboView;
	CAnimateCtrl  m_wndAnimCtrl2;
	//CAnimateCtrl  m_wndAnimCtrl;

	CXTPControlButton* m_pMaskedStatusMenu;
	CXTPControlButton* m_pUnmaskedStatusMenu;
	CXTPControlButton* m_pHardDrivePrimaryMenu;
	CXTPControlButton* m_pHardDriveSecondaryMenu;
	CXTPControlButton* m_pHardDriveFlashMenu;
	CXTPControlButton* m_pBmsBACnetMenu;
	CXTPControlButton* m_pBmsModbusMenu;


private:
	CRtuSystemCommands* m_pSystemCommandsObj;
	CRtuPortParamsConfig* m_pPortParamObj;
	CRtuCtrlTemplate* m_pRtuTemplate;
	BOOL m_bCustomVocabUploadSent; // added for TT#5950

	void InitRtuParam();
	void InitializeComponent();
	void SetControllerInfo();
	void SetTheme(XTPPaintTheme paintTheme);
	BOOL ProcessAlarmCommand(int nID);
	BOOL ProcessAccessControlCommand(int nID);
	BOOL ProcessBmsCommand(int nID);
	void UploadConfiguration();
	void ViewStatus(UINT nID, int nOption, BYTE nBlkNo);
	void DisplaySerialNumber(LPBYTE pData, BYTE addr1, BYTE addr2);
	int GetRtuSystemCommand(int nOption);
	int GetCommandOption(int nMenuOption);
	void ExecuteSystemCommand(UINT nCommandID);
	void ExecuteSystemCommand(LPPARMPROC lpps, int nRtuCommandID);
	void GetPortConfig(int nCommandID, int nPortConfig, BOOL bError=FALSE);
	void GetNetworkError();
	int GetInputNumber();
	void EnableMenuBar(BOOL bEnabled);
	void GetRtuStatus(BYTE nMask=0);
	BOOL GetGeneralBmsConfig();
	void ProcessGenBmsConfig();

	void Do_LoadOrSaveCommandBars (BOOL load, const CString& cmdBarsIniPath);
	HRESULT GetCommandBarsIniPath (CString& cmdBarsIniPath) const;
	void GmsLoadCommandBars();
	void GmsSaveCommandBars();

	void GetControllerConfig();

	void AddAnimation();
	BOOL WantToDestroyNow();
	void PlayAnimation();
	void EnableStatusMenu(BOOL bEnable);
	void EnableHardDriveMenu(BOOL bEnable);
	void GetControllerCfg(int nID);

	void UploadCustomVocab(); // written for TT#5950
	void CustomVocabUploaded(BOOL bSaveIt); // written for TT#5950
};

class CControllerTimezoneDlg : public CDialog
{
public:
	CControllerTimezoneDlg(CWnd* pParent=NULL);
	virtual ~CControllerTimezoneDlg(){}
	int GetTimeZone();
	BOOL GetTimeZoneString(LPTSTR szTimeZone);

	enum { IDD = IDD_RTU_SYSCMD_TIMEZONE_DLG };
protected:
	virtual void DoDataExchange(CDataExchange *pDX);

	virtual BOOL OnInitDialog();
	afx_msg void OnSelchangeTimezone();
	DECLARE_MESSAGE_MAP()

private:
	CComboBox m_cboTimezone;
	int	m_nSelected;
	CString m_strTimeZone;
};

#define ShowTemplateOnly 1
#if ShowTemplateOnly
#define CControllerTemplateBase CDialog
#else
#define CControllerTemplateBase CXTPPropertyPage
#endif

class CControllerTemplate : public CControllerTemplateBase
{
public:
	CControllerTemplate(LPBYTE pParams, BYTE nRtuType, CWnd* pParent=NULL);
	virtual ~CControllerTemplate();
	enum {IDD = IDD_CONTROLLER_TEMPLATE};
	void Download() { OnBtnOK(); }
protected:
	virtual void DoDataExchange(CDataExchange* pDX);
	virtual BOOL OnInitDialog();
	afx_msg void OnBtnOK();
	DECLARE_MESSAGE_MAP()

private:
	void ShowParams();
	void StoreParams();
	BOOL CheckParams();
	DWORD GetIpAddress(LPBYTE pIpAddress);
	void SetIpAddress(LPBYTE pIpAddress, DWORD dwIpAddress);
private:
	LPBYTE m_pParams;
	int m_nControllerID;
	BYTE m_nRtuType;
	BOOL m_bShowTelephone;

	DWORD m_controllerIpAddress;
	DWORD m_controllerSubnetMask;
	DWORD m_controllerDefaultGateway1;
	DWORD m_controllerDefaultGateway2;
	DWORD m_basestationIpAddress1;
	DWORD m_basestationIpAddress2;
	DWORD m_secondaryLine1IpAddress;
	BYTE m_telephoneNumber[9];

	//CMarkupBox		m_lblGroup;
	CMarkupLabel	m_lblControls[8];
};

#define CLicensePageBase CXTPPropertyPage

/*==========================================================================*/
// CLicensePage
class CLicensePage : public CLicensePageBase
{
public:
	enum {E_NUM_OPTIONS = 13, E_NUM_MEZZ = 6};
	CLicensePage(LPBYTE pLicenceData, BYTE addr1, BYTE addr2, int nDlgID);
	void SetLicenceOption(char* ptr);
	void ShowLicenceOption(void);

protected:
	virtual void DoDataExchange(CDataExchange* pDX);

	virtual BOOL OnInitDialog();
	afx_msg void OnBtnEthernet(){ChangeOption(0);};
	afx_msg void OnBtnAccess(){ChangeOption(1);};
	afx_msg void OnBtnAlmPanel(){ChangeOption(2);};	
	afx_msg void OnBtnElevator(){ChangeOption(3);};
	afx_msg void OnBtnIriProt(){ChangeOption(4);};
	afx_msg void OnBtnDualRpt(){ChangeOption(5);};
	afx_msg void OnBtnMultiFormat(){ChangeOption(6);};
	afx_msg void OnBtnPtzDriver(){ChangeOption(7);};
	afx_msg void OnBtnInnovonics(){ChangeOption(8);};
	afx_msg void OnBtnHostHLI(){ChangeOption(9);};
	afx_msg void OnBtnRemoteMaint(){ChangeOption(10);};
	afx_msg void OnBtnGenDVRInterface(){ChangeOption(11);};
	afx_msg void OnBtnEPAP(){ChangeOption(12);};

	afx_msg void OnBtnUpdateNumberOfAperioReaders(){ m_nLicenceLimitNumber = 1; ChangeLicenceLimit();};
	afx_msg LRESULT OnGms(WPARAM wParam, LPARAM lParam);

	DECLARE_MESSAGE_MAP()
private:
	CString m_str;
	char m_licence[16];
	ushort m_licenceLimits[16];
	int m_nCurOp;
	int m_bOpStat;
	BYTE m_nAddress1;
	BYTE m_nAddress2;
	int m_nByteCount;
	BOOL m_bChangeLicenceLimit;
	BOOL m_bLicenceLimit;
	BYTE m_nLicenceLimitNumber;
	ushort m_nLimits;

	void UpdateOption(UINT id1, UINT id2, int index, BOOL flag);
	void ChangeOption(int opNum);
	void ChangeLicenceLimit();
	void GetEnabledStrings(CStringArray& strEn);
	void GetDisabledStrings(CStringArray& strDis);
	void InitializeComponent();

	CMarkupBox		m_lblSerialNumber;
	CMarkupBox		m_lblLicenseOptions;
	CMarkupBox		m_lblLicenseLimits;
	CMarkupLabel	m_lblAperioLimit;

	//CStaticColor m_lblLicences[E_NUM_OPTIONS];
	CMarkupLabel	m_lblLicences[E_NUM_OPTIONS];
};

class CControllerTemplateMain : public CDialog
{
public:
	CControllerTemplateMain(LPPARMPROC lpps, LPBYTE pParams, BYTE nRtuType, CWnd* pParent=NULL);
	virtual ~CControllerTemplateMain();
	enum {IDD = IDD_CONTROLLER_TEMPLATE_MAIN};
protected:
	virtual void DoDataExchange(CDataExchange* pDX);
	virtual BOOL OnInitDialog();
	afx_msg void OnBtnOK();
	afx_msg LRESULT OnGms(WPARAM, LPARAM);
	afx_msg LRESULT OnPageSelected(WPARAM, LPARAM);
	DECLARE_MESSAGE_MAP()

private:
	CXTPPropertySheet m_sheet;
	CControllerTemplate* pPageControllerTemplate;
	CLicensePage* pPageLicense;

	LPBYTE m_pParams;
	BYTE m_nRtuType;
	PARMPROC	m_pps; 
	BYTE		m_lppsData[100];

	void UploadLicense();
	void ShowConfig(LPBYTE pSerialData, BYTE addr1, BYTE addr2);
};
//====================================================================================//
//						Select Areas ...											==//
//====================================================================================//
class CSelectAreasDlg : public CDialog
{
public:
	CSelectAreasDlg(BOOL bShowMode=FALSE, BOOL bShowFlags=FALSE, int nOption=-1, CWnd* pParent = NULL);
	~CSelectAreasDlg();
	ulong GetSelectedAreas() { return m_nSelectedAreas; }
	BYTE GetSelectedMode() { return m_nSelectedMode; }
	BYTE GetSelectedModeState() { return m_nSelectedModeState; }
	BYTE GetScheduleNumber() { return (BYTE)m_nScheduleNumber; }
	BYTE GetFlagByte() { return m_nFlags; }
	//{{AFX_DATA(CSelectAreasDlg)
	enum { IDD = IDD_SELECT_AREAS_DLG };
	//}}AFX_DATA

	//{{AFX_VIRTUAL(CSelectAreasDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

protected:

	//{{AFX_MSG(CSelectAreasDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnBtnSelectAll();
	afx_msg void OnBtnClearAll();
	afx_msg void OnOK();
	afx_msg void OnSelChangedMode();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	CComboBox m_cboMode;
	CComboBox m_cboModeState;
	CCheckDlg* m_pAreas;
	int m_nMaxAreas;
	int m_nOption;
	ulong m_nSelectedAreas;
	BYTE m_nSelectedMode;
	BYTE m_nSelectedModeState;
	BOOL m_bShowMode;
	BOOL m_bShowFlags;
	BYTE m_nFlags;
	int m_nScheduleNumber;

	void UpdateModeState();
};


//====================================================================================//
//						Select Option ...											==//
//====================================================================================//
class CSysCmdSelectOptionDlg : public CDialog
{
public:
	CSysCmdSelectOptionDlg(int nOption=-1, CWnd* pParent = NULL);
	~CSysCmdSelectOptionDlg();
	BYTE GetSelectedOption() { return m_nSelectedOption; }
	BYTE GetSelectedOption2() { return m_nSelectedOption2; }
	BYTE GetFlags() { return m_nFlags; }

	//{{AFX_DATA(CSysCmdSelectOptionDlg)
	enum { IDD = IDD_SYS_CMD_SEL_OP_DLG };
	//}}AFX_DATA

	//{{AFX_VIRTUAL(CSysCmdSelectOptionDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

protected:

	//{{AFX_MSG(CSysCmdSelectOptionDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnOK();
	afx_msg void OnSelChangeOptions();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	CComboBox m_cboOption;
	CComboBox m_cboVaultNumber;
	int m_nOption;
	BYTE m_nSelectedOption;
	BYTE m_nSelectedOption2;
	BYTE m_nFlags;
	void ShowOption();
};

//====================================================================================//
//						Keypad Message  ...											==//
//====================================================================================//
class CKeypadMessageDlg : public CDialog
{
public:
	enum {KPD_MSG_LEN = 40};
	CKeypadMessageDlg(CWnd* pParent = NULL);
	~CKeypadMessageDlg();
	BYTE GetKeypadNumber() { return m_nKeypadNumber; }
	LPSTR GetKeypadMessage() { return m_strKeypadMessage; }

	//{{AFX_DATA(CKeypadMessageDlg)
	enum { IDD = IDD_KEYPAD_MESSAGE_DLG };
	//}}AFX_DATA

	//{{AFX_VIRTUAL(CKeypadMessageDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

protected:

	//{{AFX_MSG(CKeypadMessageDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	BYTE m_nKeypadNumber;
	char m_strKeypadMessage[KPD_MSG_LEN + 1];
};

//====================================================================================//
//						RTU User Defined Commands ...								==//
//====================================================================================//
class CRtuUserDefinedCmdDlg : public CDialog
{
public:
	CRtuUserDefinedCmdDlg(int nRtuNumber, CWnd* pParent = NULL);
	~CRtuUserDefinedCmdDlg();
	static void SendCommand(HWND hDlg, int nRtuNumber, BYTE nFunctionCode, CString strData);
	//{{AFX_DATA(CRtuUserDefinedCmdDlg)
	enum { IDD = IDD_RTU_USER_DEFINED_CMD_DLG };
	//}}AFX_DATA

	//{{AFX_VIRTUAL(CRtuUserDefinedCmdDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

protected:

	//{{AFX_MSG(CRtuUserDefinedCmdDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnDestroy();
	afx_msg void OnClose();
	afx_msg void OnBtnSend();
	afx_msg void OnBtnSave();
	afx_msg void OnSelChangedCommand();
	afx_msg void OnDeleteCommand();
	afx_msg void OnSaveCommand();
	afx_msg void OnEditChangeAvailableCommand();
	afx_msg void OnEditChangeFunctionCode();
	afx_msg void OnEditChangeCommandData();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	CComboBox m_cboAvailableCommand;
	CXTPButton m_btnSave;
	int m_nRtuNumber;
	BYTE m_data[264];

	void FillAvailableCommand();

	void DeleteCommand();
	void EnableSendCommand();
};

class CControlPortErrors : public CXTPControlButton
{
	DECLARE_XTP_CONTROL(CControlPortErrors)

protected:
	virtual void OnCalcDynamicSize(DWORD dwMode);
	virtual BOOL IsCustomizeDragOverAvail(CXTPCommandBar* pCommandBar, CPoint point, DROPEFFECT& dropEffect);
};

class CControlFirepowerBatteryTest : public CXTPControlButton
{
	DECLARE_XTP_CONTROL(CControlFirepowerBatteryTest)

protected:
	virtual void OnCalcDynamicSize(DWORD dwMode);
	virtual BOOL IsCustomizeDragOverAvail(CXTPCommandBar* pCommandBar, CPoint point, DROPEFFECT& dropEffect);
};

class CControlUserDefinedCommands : public CXTPControlButton
{
public:
	DECLARE_XTP_CONTROL(CControlUserDefinedCommands)

protected:
	virtual void OnCalcDynamicSize(DWORD dwMode);
	virtual BOOL IsCustomizeDragOverAvail(CXTPCommandBar* pCommandBar, CPoint point, DROPEFFECT& dropEffect);
};

class CControlHardwareCommands : public CXTPControlButton
{
public:
	DECLARE_XTP_CONTROL(CControlHardwareCommands)

protected:
	virtual void OnCalcDynamicSize(DWORD dwMode);
	virtual BOOL IsCustomizeDragOverAvail(CXTPCommandBar* pCommandBar, CPoint point, DROPEFFECT& dropEffect);
};

//====================================================================================//
//						Reader Commands ...											==//
//====================================================================================//
class CReaderCommandDlg : public CDialog
{
public:
	enum { E_TIME_IN_SECOND=1, E_TIME_IN_MINUTE=2, E_TIME_INC_MIN_CHK=3, E_AREA_RANGE=4, E_TIME_LO_HI=5,
		E_AREA_RANGE_EXTRA=6, E_PIN_OVERRIDE=7 };
	CReaderCommandDlg(int nRtuNumber, CWnd* pParent = NULL);
	~CReaderCommandDlg();

	int GetData(LPBYTE pData) { pData = m_data; return m_nByteCount; }
	CString ToString();
	//{{AFX_DATA(CReaderCommandDlg)
	enum { IDD = IDD_SYS_RDR_CMD_DLG };
	//}}AFX_DATA

	//{{AFX_VIRTUAL(CReaderCommandDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

protected:

	//{{AFX_MSG(CReaderCommandDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnOK();
	afx_msg void OnSelChangedCommandType();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	CComboBox m_cboCmdType;
	CComboBox m_cboPinOverride;
	BYTE m_data[5];		// [0]=BC, [1]=Command Type, [2]=Reader Number, [3]=Time, [4]=Extra
	int m_nByteCount;
	int m_nFlags;
	int m_nRtuNumber;
	CNumEditEx m_txtReaderNumber;
	CNumEditEx m_txtTime;
	CNumEditEx m_txtSecurityLevel;
};




/////////////////////////////////////////////////////////////////////////////
// CNetworkErrorDlg dialog

class CNetworkErrorDlg : public CDialog
{
// Construction
public:
	CNetworkErrorDlg(LPPARMPROC lpps, LPBYTE pData, CWnd* pParent = NULL);// : m_lpps(lpps m_pData(pData), CDialog (CNetworkErrorDlg::IDD, pParent){};   // standard constructor
	virtual ~CNetworkErrorDlg() {
		if(m_pagePrimary) { delete m_pagePrimary; m_pagePrimary = NULL; }
		if(m_pageSecondary) { delete m_pageSecondary; m_pageSecondary = NULL; }
		if(m_pageTertiary) { delete m_pageTertiary; m_pageTertiary = NULL; }
	}
// Dialog Data
	//{{AFX_DATA(CNetworkErrorDlg)
	enum { IDD = IDD_NETWORK_ERRS_DLG };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CNetworkErrorDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	CPropertySheet m_sheet;
	// Generated message map functions
	//{{AFX_MSG(CNetworkErrorDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

private:
	PARMPROC m_pps; BYTE m_data[RTU_BUFF_SIZE];
	LPBYTE m_pData;
	CNetworkParams_Err* m_pagePrimary;
	CNetworkParams_Err* m_pageSecondary;
	CNetworkParams_Err* m_pageTertiary;
};

//====================================================================================//
//						Inovonics Commands ...										==//
//====================================================================================//
class CInovonicsCommandDlg : public CDialog
{
public:
	CInovonicsCommandDlg(int nRtuNumber, CWnd* pParent = NULL);
	~CInovonicsCommandDlg();

	//{{AFX_DATA(CInovonicsCommandDlg)
	enum { IDD = IDD__PROGRAM_INOVONICS_DLG };
	//}}AFX_DATA

	//{{AFX_VIRTUAL(CInovonicsCommandDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

protected:

	//{{AFX_MSG(CInovonicsCommandDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnOK();
	afx_msg void OnSelChangedCommandType();
	afx_msg void OnEnUpdateTxOption();
	afx_msg void OnEnUpdateTxAddress();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	CComboBox m_cboCmdType;
	int m_nRtuNumber;
	CString m_strTxOp;
	CString m_strTxAddr;
	int m_nTxOpLen;
	int m_nTxAddrLen;
};

