// GlobalResistorSettings.cpp : implementation file
//

//#include "..\stdhdr.h"
//#include "panelhdr.h"
//#include "panelcfg.h"
#include "stdafx.h"

//#include "resource\Resource.h"
//#include "mylib\GmsMyLibUtil.h"
//#include "mylib\CustomVocabUploadMgmt.h"
//#include "KeypadLcdCodepage.h"
//#include "Gms\CommonUse\CommonDefs.h"
//#include "GMS\CommonUse\SysColorIdxs.h"
//#include "HardwareConfig\Rtu\PANELGRF\DeviceCoordinates.h"


#include "GlobalResistorSettings.h"

using namespace Rtu;

// CGlobalResistorSettings dialog

IMPLEMENT_DYNAMIC(CGlobalResistorSettings, CDialog)

CGlobalResistorSettings::CGlobalResistorSettings(CWnd* pParent /*=NULL*/, GLOBAL_RESISTOR_SETTING_CFG* settings)
	: CDialog(CGlobalResistorSettings::IDD, pParent)
{
	m_pSettings = settings;
}

CGlobalResistorSettings::~CGlobalResistorSettings()
{
	
}

void CGlobalResistorSettings::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	if (m_pSettings == NULL)
		return;
		
	if (pDX->m_bSaveAndValidate == FALSE)
	{
		//float alarmVal = (float) m_pSettings->alarmResistorValue / (float)10.0;
		//float secureVal = (float) m_pSettings->secureResistorValue / (float) 10.0;
		
		//DDX_Text(pDX, IDC_RESISTOR_ALARM_VALUE, alarmVal);
		//DDX_Text(pDX, IDC_RESISTOR_SECURE_VALUE, secureVal);
		
		CString alarmVal, secureVal;
		alarmVal.Format(L"%u.%u", m_pSettings->alarmResistorValue / 10, m_pSettings->alarmResistorValue%10);
		secureVal.Format(L"%u.%u", m_pSettings->secureResistorValue / 10, m_pSettings->secureResistorValue%10);
		
		SetDlgItemText(IDC_RESISTOR_ALARM_VALUE, alarmVal);
		SetDlgItemText(IDC_RESISTOR_SECURE_VALUE, secureVal);
	}
	else
	{
		float alarmVal = 0;
		float secureVal = 0;
		
		DDX_Text(pDX, IDC_RESISTOR_ALARM_VALUE, alarmVal);
		DDV_MinMaxFloat(pDX, alarmVal, 0.0, 25.5);
		
		DDX_Text(pDX, IDC_RESISTOR_SECURE_VALUE, secureVal);
		DDV_MinMaxFloat(pDX, secureVal, 0.0, 25.5);
		
		// need to add 0.01 to the value, because it is always short of 1/100 value.!
		// only 0.5 gives exact value.
		m_pSettings->alarmResistorValue = (BYTE)((alarmVal+0.01) * 10.0);
		m_pSettings->secureResistorValue = (BYTE) ((secureVal+0.01) * 10.0);
		
		int hitCount = 0;
		DDX_Text(pDX, IDC_RESISTOR_HITCOUNT, hitCount);
		DDV_MinMaxInt(pDX, hitCount, 0, 255);
		
		m_pSettings->globalHitCountValue = (BYTE) hitCount;
	}
	
	DDX_Text(pDX, IDC_RESISTOR_HITCOUNT, m_pSettings->globalHitCountValue);
	RtuLib::DDX_Check(pDX, IDC_CHK_RESISTOR_TOLERANCE, m_pSettings->globalToleranceValue, 0);
	
}


BEGIN_MESSAGE_MAP(CGlobalResistorSettings, CDialog)
	ON_BN_CLICKED(IDOK, &CGlobalResistorSettings::OnBnClickedOk)
END_MESSAGE_MAP()


// CGlobalResistorSettings message handlers

void CGlobalResistorSettings::OnBnClickedOk()
{
	if (UpdateData(1) == TRUE)
	{
		EndDialog(IDOK);
	}
}

BOOL CGlobalResistorSettings::OnInitDialog()
{
	CDialog::OnInitDialog();
	if (m_pSettings == NULL)
		GetDlgItem(IDOK)->EnableWindow(0);
	
	UINT ids[] = {IDC_RESISTOR_ALARM_VALUE, IDC_RESISTOR_SECURE_VALUE, IDC_RESISTOR_HITCOUNT};
	int  lens[] = {4,4,3};
	for (int ind = 0; ind < 3; ind++)
		SendDlgItemMessage(ids[ind], EM_SETLIMITTEXT, lens[ind], 0);
		
	return TRUE;
}