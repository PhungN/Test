/*-------------------------------------------------------------------------*/
/*-------------------------------------------------------------------------*/
/*			Constants for graphics ....									   */	
/*-------------------------------------------------------------------------*/
/*-------------------------------------------------------------------------*/

#pragma region _1030

#define LEFT_16IO       0
#define TOP_16IO        0
#define RIGHT_16IO      0 
#define BOTTOM_16IO     0

#define PT_GAP			10
#define PT_SIZE			10
#define OUTPUT_CONN_1	32
#define CONN_Y			190
#define INPUT_CONN_1	(OUTPUT_CONN_1 + (3 * PT_GAP) + (2 * PT_SIZE))
#define INPUT_CONN_2	135
#define INPUT_CONN_3	245
#define INPUT_CONN_4	313

#define DIP_LEFT_1030       225 + LEFT_16IO  
#define DIP_TOP_1030        36 + TOP_16IO   
#define DIP_RIGHT_1030      267 + RIGHT_16IO 
#define DIP_BOTTOM_1030     56 + BOTTOM_16IO

// 16IO

#define PT_16IO_0_X		INPUT_CONN_1
#define PT_16IO_1_X		PT_16IO_0_X + PT_SIZE + PT_GAP
#define PT_16IO_2_X		PT_16IO_1_X + PT_SIZE + PT_GAP
#define PT_16IO_3_X		INPUT_CONN_2 + PT_GAP
#define PT_16IO_4_X		PT_16IO_3_X + PT_SIZE + PT_GAP
#define PT_16IO_5_X		PT_16IO_4_X + PT_SIZE + PT_GAP
#define PT_16IO_6_X		PT_16IO_5_X + PT_SIZE + PT_GAP
#define PT_16IO_7_X		INPUT_CONN_3 + PT_GAP
#define PT_16IO_8_X		PT_16IO_7_X + PT_SIZE + PT_GAP
#define PT_16IO_9_X		PT_16IO_8_X + PT_SIZE + PT_GAP
#define PT_16IO_10_X	INPUT_CONN_4 + PT_GAP
#define PT_16IO_11_X	PT_16IO_10_X + PT_SIZE + PT_GAP
#define PT_16IO_12_X	PT_16IO_11_X + PT_SIZE + PT_GAP
#define PT_16IO_13_X	PT_16IO_12_X + PT_SIZE + PT_GAP
#define PT_16IO_14_X	PT_16IO_13_X + PT_SIZE + PT_GAP
#define PT_16IO_15_X	PT_16IO_14_X + PT_SIZE + PT_GAP

#define PT_16IO_O_0_X	OUTPUT_CONN_1 + PT_GAP
#define PT_16IO_O_1_X	PT_16IO_O_0_X + PT_SIZE + PT_GAP	

#pragma endregion _1030

// Input card
#define CONN_X_004		PCB_MEZZ_X + 18
#define PT_004_GAP		8
#define INPUT_Y			29
#define PCB_MEZZ_X      35


#define PT_004_0_Y		INPUT_Y
#define PT_004_1_Y		PT_004_0_Y + PT_004_GAP	+ (PT_SIZE * 2)
#define PT_004_2_Y		PT_004_1_Y + PT_004_GAP	+ PT_SIZE - 1
#define PT_004_3_Y		PT_004_2_Y + PT_004_GAP	+ (PT_SIZE * 2)
#define PT_004_4_Y		PT_004_3_Y + PT_004_GAP	+ PT_SIZE + 3
#define PT_004_5_Y		PT_004_4_Y + PT_004_GAP	+ (PT_SIZE * 2)
#define PT_004_6_Y		PT_004_5_Y + PT_004_GAP	+ PT_SIZE - 1
#define PT_004_7_Y		PT_004_6_Y + PT_004_GAP	+ (PT_SIZE * 2)
#define PT_004_8_Y		PT_004_7_Y + PT_004_GAP	+ PT_SIZE + 3
#define PT_004_9_Y		PT_004_8_Y + PT_004_GAP	+ (PT_SIZE * 2)
#define PT_004_10_Y		PT_004_9_Y + PT_004_GAP	+ PT_SIZE - 2
#define PT_004_11_Y		PT_004_10_Y + PT_004_GAP + (PT_SIZE * 2)
#define PT_004_12_Y		PT_004_11_Y + 32
#define PT_004_13_Y		PT_004_12_Y
#define PT_004_14_Y		PT_004_12_Y
#define PT_004_15_Y		PT_004_12_Y

#define PT_004_12_X     PCB_MEZZ_X + 82
#define PT_004_13_X		PT_004_12_X + PT_004_GAP + (PT_SIZE * 2) + 1
#define PT_004_14_X 	PT_004_13_X + PT_004_GAP + PT_SIZE - 2
#define PT_004_15_X		PT_004_14_X + PT_004_GAP + (PT_SIZE * 2) + 3

// Output card
#define OUTPUT_Y        286
#define PT_003_GAP		21
#define CONN_X  		PCB_MEZZ_X + 4

#define PT_003_0_Y		OUTPUT_Y
#define PT_003_1_Y		PT_003_0_Y - PT_003_GAP	- PT_SIZE
#define PT_003_2_Y		PT_003_1_Y - PT_003_GAP	- PT_SIZE
#define PT_003_3_Y		PT_003_2_Y - PT_003_GAP	- PT_SIZE
#define PT_003_4_Y		PT_003_3_Y - PT_003_GAP	- PT_SIZE - 8  
#define PT_003_5_Y		PT_003_4_Y - PT_003_GAP	- PT_SIZE
#define PT_003_6_Y		PT_003_5_Y - PT_003_GAP	- PT_SIZE
#define PT_003_7_Y		PT_003_6_Y - PT_003_GAP	- PT_SIZE

#define CAMERA_Y        292
#define PT_010_GAP		22
#define DUMMY_PHONE     12
#define CAMERA_ONE      65
#define CAMERA_TWO      50

#define PT_010_0_Y		CAMERA_Y
#define PT_010_1_Y		PT_010_0_Y - PT_010_GAP	- PT_SIZE
#define PT_010_2_Y		PT_010_1_Y - PT_010_GAP	- PT_SIZE
#define PT_010_3_Y		PT_010_2_Y - PT_010_GAP	- PT_SIZE
#define PT_010_4_Y		DUMMY_PHONE
#define PT_010_5_Y		CAMERA_ONE
#define PT_010_6_Y		CAMERA_TWO

#pragma region _1065

#define PCB_1065_X      100
#define PCB_1065_Y      30

#define PT_1065_GAP     6

#define PT_65_4_GAP     4
#define PT_65_3_GAP     5

#define CONN_1065_Y     28

// P1065
#define DIP_LEFT_1065       (PCB_1065_X + 61)
#define DIP_TOP_1065        (PCB_1065_Y + 244)
#define DIP_RIGHT_1065      (PCB_1065_X + 85)
#define DIP_BOTTOM_1065     (PCB_1065_Y + 299)

#define MEZZ_1065_X     (PCB_1065_X + 100)
#define MEZZ_1065_Y     (PCB_1065_Y + 30)
#define MEZZ_1065_OFF   145

#define PT_1065_0_X		(PCB_1065_X + 35)
#define PT_1065_1_X		PT_1065_0_X + (PT_SIZE * 2) + PT_1065_GAP
#define PT_1065_2_X		PT_1065_1_X + PT_SIZE + PT_1065_GAP
#define PT_1065_3_X		PT_1065_2_X + (PT_SIZE * 2) + PT_1065_GAP
#define PT_1065_4_X		PT_1065_3_X + PT_SIZE + PT_1065_GAP+ 5
#define PT_1065_5_X		PT_1065_4_X + (PT_SIZE * 2) + PT_1065_GAP
#define PT_1065_6_X		PT_1065_5_X + PT_SIZE + PT_1065_GAP
#define PT_1065_7_X		PT_1065_6_X + (PT_SIZE * 2) + PT_1065_GAP
#define PT_1065_8_X		PT_1065_7_X + PT_SIZE + PT_1065_GAP+ 5
#define PT_1065_9_X		PT_1065_8_X + (PT_SIZE * 2) + PT_1065_GAP
#define PT_1065_10_X	PT_1065_9_X + PT_SIZE + PT_1065_GAP
#define PT_1065_11_X	PT_1065_10_X + (PT_SIZE * 2) + PT_1065_GAP
#define PT_1065_12_X	PT_1065_11_X + PT_SIZE + PT_1065_GAP+ 5
#define PT_1065_13_X	PT_1065_12_X + (PT_SIZE * 2) + PT_1065_GAP
#define PT_1065_14_X	PT_1065_13_X + PT_SIZE + PT_1065_GAP
#define PT_1065_15_X	PT_1065_14_X + (PT_SIZE * 2) + PT_1065_GAP

#define PT_1065_O2_X	PT_1065_15_X + PT_SIZE + PT_1065_GAP
#define PT_1065_O3_X	PT_1065_O2_X + PT_SIZE + PT_1065_GAP


#define PT_1065_X	    MEZZ_1065_X + 116
#define PT_1065_16_Y    MEZZ_1065_Y + 237
#define PT_1065_17_Y    PT_1065_16_Y - PT_65_4_GAP - (PT_SIZE * 2) + 2
#define PT_1065_18_Y	PT_1065_17_Y - PT_65_4_GAP - PT_SIZE + 1
#define PT_1065_19_Y    PT_1065_18_Y - PT_65_4_GAP - (PT_SIZE * 2) 
#define PT_1065_20_Y	PT_1065_19_Y - PT_65_4_GAP - PT_SIZE - 2
#define PT_1065_21_Y    PT_1065_20_Y - PT_65_4_GAP - (PT_SIZE * 2) + 2
#define PT_1065_22_Y	PT_1065_21_Y - PT_65_4_GAP - PT_SIZE + 1
#define PT_1065_23_Y    PT_1065_22_Y - PT_65_4_GAP - (PT_SIZE * 2) + 2
#define PT_1065_24_Y	PT_1065_23_Y - PT_65_4_GAP - PT_SIZE - 2
#define PT_1065_25_Y    PT_1065_24_Y - PT_65_4_GAP - (PT_SIZE * 2) + 2
#define PT_1065_26_Y	PT_1065_25_Y - PT_65_4_GAP - PT_SIZE + 1
#define PT_1065_27_Y    PT_1065_26_Y - PT_65_4_GAP - (PT_SIZE * 2) + 2
#define PT_1065_28_Y    MEZZ_1065_Y + 6
#define PT_1065_29_Y    PT_1065_28_Y 
#define PT_1065_30_Y    PT_1065_28_Y 
#define PT_1065_31_Y    PT_1065_28_Y 

#define PT_1065_31_X    MEZZ_1065_X + 3
#define PT_1065_30_X    PT_1065_31_X + PT_65_4_GAP + (PT_SIZE * 2)
#define PT_1065_29_X    PT_1065_30_X + PT_65_4_GAP + PT_SIZE - 1
#define PT_1065_28_X    PT_1065_29_X + PT_65_4_GAP + (PT_SIZE * 2)


#define PT_1065_O_X	    (460 + PCB_1065_X)
#define PT_1065_O_0_Y	24 + PCB_1065_Y
#define PT_1065_O_1_Y	PT_1065_O_0_Y + (PT_SIZE * 3) + PT_1065_GAP + 5
#define PT_1065_O_2_Y	CONN_1065_Y
#define PT_1065_O_3_Y	CONN_1065_Y

#define PT_1065_O_5_X   MEZZ_1065_X + 127
#define PT_1065_O_5_Y   MEZZ_1065_Y + 215
#define PT_1065_O_6_Y   PT_1065_O_5_Y - PT_65_3_GAP - (PT_SIZE * 2)
#define PT_1065_O_7_Y   PT_1065_O_6_Y - PT_65_3_GAP - (PT_SIZE * 2)
#define PT_1065_O_8_Y   PT_1065_O_7_Y - PT_65_3_GAP - (PT_SIZE * 2)
#define PT_1065_O_9_Y   PT_1065_O_8_Y - PT_65_3_GAP - (PT_SIZE * 2) - 6
#define PT_1065_O_10_Y  PT_1065_O_9_Y - PT_65_3_GAP - (PT_SIZE * 2)
#define PT_1065_O_11_Y  PT_1065_O_10_Y - PT_65_3_GAP - (PT_SIZE * 2)
#define PT_1065_O_12_Y  PT_1065_O_11_Y - PT_65_3_GAP - (PT_SIZE * 2)

#pragma endregion _1065
// P1061
#pragma region _1061

#define PCB_1061_X      0
#define PCB_1061_Y      0

#define PT_1061_GAP     3
#define CONN_1061_Y     5 + PCB_1061_Y

#define PT_1061_I_X	    445
#define PT_1061_I_0_Y	156 + PCB_1061_Y
#define PT_1061_I_1_Y	PT_1061_I_0_Y + PT_SIZE + PT_1061_GAP
#define PT_1061_I_2_Y	PT_1061_I_0_Y - PT_SIZE - PT_1061_GAP

#define PT_1061_O_X	    445
#define PT_1061_O_0_Y	PT_1061_I_1_Y + PT_SIZE + (PT_1061_GAP * 2)
#define PT_1061_O_1_Y	PT_1061_O_0_Y + PT_SIZE + PT_1061_GAP
#define PT_1061_O_2_Y	PT_1061_O_1_Y + (PT_SIZE * 2) + PT_1061_GAP
#define PT_1061_O_3_Y	PT_1061_O_2_Y + PT_SIZE + PT_1061_GAP
#define PT_1061_O_4_X	PCB_1061_X + 41
#define PT_1061_O_4_Y	PCB_1061_Y + 272

#pragma endregion _1061
// P1064
#pragma region _1064

#define PCB_1064_X      120
#define PCB_1064_Y      40

#define PT_1064_I_1_X   (PCB_1064_X + 173)
#define PT_1064_I_2_X   (PT_1064_I_1_X - PT_SIZE - 44)
#define PT_1064_I_3_X   (PT_1064_I_2_X - PT_SIZE - 18)
#define PT_1064_I_4_X   (PT_1064_I_3_X - PT_SIZE - 44)
#define PT_1064_I_5_X   (PT_1064_I_1_X + 61)
#define PT_1064_I_6_X   (PT_1064_I_5_X + PT_SIZE + 18)

#define PT_1064_O_1_X   (PT_1064_I_6_X + PT_SIZE + 18)
#define PT_1064_O_2_X   (PT_1064_O_1_X + PT_SIZE + 18)
#define PT_1064_O_3_X   (PT_1064_I_1_X + PT_SIZE + 140)
#define PT_1064_O_4_X   (PT_1064_O_2_X + PT_SIZE + 18)

#define PT_1064_I_0_Y   (PCB_1064_Y + 4)
#define PT_1064_I_1_Y   (PCB_1064_Y + 259)

#pragma endregion _1064
// P1068
#pragma region _1068

#define PCB_1068_X      190
#define PCB_1068_Y      80

#define PT_1068_I_1_X	(PCB_1068_X + 8)
#define PT_1068_I_2_X	(PCB_1068_X + 8)

#define PT_1068_I_1_Y	(PCB_1068_Y + 145)
#define PT_1068_I_0_Y	(PT_1068_I_1_Y + PT_SIZE + 26)

#define PT_1068_O_1_X1	(PT_1068_I_2_X + PT_SIZE + 169)
#define PT_1068_O_1_X2	(PT_1068_O_1_X1 + PT_SIZE + 6)

#pragma endregion _1068

// P2000
#pragma region _2000

#define PCB_2000_X      10
#define PCB_2000_Y      0

#define PT_2000_GAP     4

#define CONN_2000_Y     327
#define CONN_2000_Y1    75

#define PT_2000_0_X		PCB_2000_X + 146
#define PT_2000_1_X		PT_2000_0_X + (PT_SIZE * 2) + PT_2000_GAP
#define PT_2000_2_X		PT_2000_1_X + PT_SIZE + PT_2000_GAP
#define PT_2000_3_X		PT_2000_2_X + (PT_SIZE * 2) + PT_2000_GAP
#define PT_2000_4_X		PT_2000_3_X + PT_SIZE + PT_2000_GAP+ 4
#define PT_2000_5_X		PT_2000_4_X + (PT_SIZE * 2) + PT_2000_GAP
#define PT_2000_6_X		PT_2000_5_X + PT_SIZE + PT_2000_GAP
#define PT_2000_7_X		PT_2000_6_X + (PT_SIZE * 2) + PT_2000_GAP
#define PT_2000_8_X		PCB_2000_X + 285
#define PT_2000_9_X		PT_2000_8_X + (PT_SIZE * 2) + PT_2000_GAP
#define PT_2000_10_X	PT_2000_9_X + (PT_SIZE * 2) + PT_2000_GAP
#define PT_2000_11_X	PT_2000_10_X + (PT_SIZE * 2) + PT_2000_GAP
#define PT_2000_12_X	PT_2000_11_X + (PT_SIZE * 2) + PT_2000_GAP
#define PT_2000_13_X	PT_2000_12_X + (PT_SIZE * 2) + PT_2000_GAP
#define PT_2000_14_X	PT_2000_13_X + (PT_SIZE * 2) + PT_2000_GAP
#define PT_2000_15_X	PT_2000_14_X + (PT_SIZE * 2) + PT_2000_GAP

#define PT_2000_O_1_X	PCB_2000_X + 63
#define PT_2000_O_2_X	PT_2000_O_1_X + (PT_SIZE * 2) + PT_2000_GAP + 2
#define PT_2000_O_3_X	PT_2000_O_2_X + PT_SIZE + PT_2000_GAP
#define PT_2000_O_4_X   PT_2000_O_3_X + (PT_SIZE *2) + PT_2000_GAP

#pragma endregion _2000

// P1067
#pragma region _1067

#define PCB_1067_X      50
#define PCB_1067_Y      70

#define PT_1067_GAP     5

#define CONN2_1067_Y    229
#define CONN8_1067_Y    75

#define LEFT_1067       PCB_1067_X 
#define TOP_1067        PCB_1067_Y 
#define RIGHT_1067      PCB_1067_X  
#define BOTTOM_1067     PCB_1067_Y 

#define DIP_LEFT_1067       78 + LEFT_1067
#define DIP_TOP_1067        48 + TOP_1067   
#define DIP_RIGHT_1067      107 + RIGHT_1067
#define DIP_BOTTOM_1067     106 + BOTTOM_1067

#define PT_1067_Y1 229
#define PT_1067_Y2 75
#define PT_1067_I_1_X	PCB_1067_X + 276
#define PT_1067_I_2_X	PT_1067_I_1_X + (PT_SIZE * 2) + PT_1067_GAP
#define PT_1067_I_3_X	PT_1067_I_1_X - (PT_SIZE * 2) - 3
#define PT_1067_I_4_X	PT_1067_I_3_X - (PT_SIZE * 2) - PT_1065_GAP
#define PT_1067_I_5_X	PCB_1067_X + 228
#define PT_1067_I_6_X	PCB_1067_X + 260
#define PT_1067_I_7_X	PT_1067_I_2_X
#define PT_1067_I_8_X	PT_1067_I_1_X

#define PT_1067_O_1_X	PCB_1067_X + 400
#define PT_1067_O_2_X	PCB_1067_X + 387
#define PT_1067_O_3_X	PCB_1067_X + 204
#define PT_1067_O_4_X   PCB_1067_X + 75

#pragma endregion _1067
// P1076
#pragma region _1076

#define PCB_1076_X      50
#define PCB_1076_Y      70

#define DIP_LEFT_1076       28 + PCB_1076_X
#define DIP_TOP_1076        40 + PCB_1076_Y   
#define DIP_RIGHT_1076      60 + PCB_1076_X
#define DIP_BOTTOM_1076     110 + PCB_1076_Y

#define PT_1076_I_1_X	PCB_1076_X + 218
#define PT_1076_I_2_X	PCB_1076_X + 252
#define PT_1076_I_3_X	PCB_1076_X + 269
#define PT_1076_I_4_X	PCB_1076_X + 301
#define PT_1076_I_5_X	PCB_1076_X + 301
#define PT_1076_I_6_X	PCB_1076_X + 269
#define PT_1076_I_7_X	PCB_1076_X + 252
#define PT_1076_I_8_X	PCB_1076_X + 218

#define PT_1076_O_1_X	PCB_1076_X + 347
#define PT_1076_O_2_X	PCB_1076_X + 401
#define PT_1076_O_3_X	PCB_1076_X + 330
#define PT_1076_O_4_X   PCB_1076_X + 385

#pragma endregion _1076

// New Bitmap
#pragma region _1074

#define PCB_1074_X      40
#define PCB_1074_Y      50

#define PT_1074_GAP     5
#define CONN_1074_Y     75

#define PT_1074_I_1_X	358	+ PCB_1074_X
#define PT_1074_I_2_X	311	+ PCB_1074_X
#define PT_1074_I_3_X	287	+ PCB_1074_X
#define PT_1074_I_4_X	239	+ PCB_1074_X
#define PT_1074_I_5_X	212	+ PCB_1074_X
#define PT_1074_I_6_X	164	+ PCB_1074_X

#define PT_1074_O_1_X	409	+ PCB_1074_X

#define PT_1074_I_Y		12 + PCB_1074_Y
#define PT_1074_I_1_Y	PT_1074_I_Y + 2
#define PT_1074_I_2_Y	PT_1074_I_Y + 1
#define PT_1074_I_3_Y	PT_1074_I_Y 
#define PT_1074_I_4_Y	PT_1074_I_Y
#define PT_1074_I_5_Y	PT_1074_I_Y
#define PT_1074_I_6_Y	PT_1074_I_Y

#define PT_1074_O_1_Y	PT_1074_I_Y + 4

#pragma endregion _1074
 
// PX8
#pragma region _PX8

#define PCB_PX8_X		160
#define PCB_PX8_Y		20

#define PT_PX8_X		PCB_PX8_X - 5
#define PT_PX8_I_1_X	115	+ PT_PX8_X
#define PT_PX8_I_2_X	140	+ PT_PX8_X
#define PT_PX8_I_3_X	153	+ PT_PX8_X
#define PT_PX8_I_4_X	179	+ PT_PX8_X
#define PT_PX8_I_5_X	193	+ PT_PX8_X
#define PT_PX8_I_6_X	218	+ PT_PX8_X
#define PT_PX8_I_7_X	231	+ PT_PX8_X
#define PT_PX8_I_8_X	256	+ PT_PX8_X

#define PT_PX8_O_1_X	283	+ PT_PX8_X
#define PT_PX8_O_2_X	320	+ PT_PX8_X
#define PT_PX8_O_3_X	234	+ PT_PX8_X
#define PT_PX8_O_4_X	247	+ PT_PX8_X
#define PT_PX8_O_5_X	260	+ PT_PX8_X

#define PT_PX8_Y		PCB_PX8_Y - 10
#define PT_PX8_I_1_Y	PT_PX8_Y + 13
#define PT_PX8_I_2_Y	PT_PX8_Y + 13
#define PT_PX8_I_3_Y	PT_PX8_Y + 13
#define PT_PX8_I_4_Y	PT_PX8_Y + 13
#define PT_PX8_I_5_Y	PT_PX8_Y + 13
#define PT_PX8_I_6_Y	PT_PX8_Y + 13
#define PT_PX8_I_7_Y	PT_PX8_Y + 13
#define PT_PX8_I_8_Y	PT_PX8_Y + 13

#define PT_PX8_O_1_Y	PT_PX8_Y + 13
#define PT_PX8_O_2_Y	PT_PX8_Y + 13
#define PT_PX8_O_3_Y	PT_PX8_Y + 377
#define PT_PX8_O_4_Y	PT_PX8_Y + 377
#define PT_PX8_O_5_Y	PT_PX8_Y + 377

#pragma endregion _PX8
// P1058
#pragma region _1058
#define PCB_1058_X	20
#define PCB_1058_Y  20

#define PT_1058_I_0_X	30
#define PT_1058_O_0_X	30

#define PT_1058_I_0_Y	388 + PCB_1058_Y
#define PT_1058_I_1_Y	357 + PCB_1058_Y
#define PT_1058_I_2_Y	342 + PCB_1058_Y
#define PT_1058_I_3_Y	311 + PCB_1058_Y
#define PT_1058_I_4_Y	280 + PCB_1058_Y
#define PT_1058_I_5_Y	249 + PCB_1058_Y
#define PT_1058_I_6_Y	234 + PCB_1058_Y
#define PT_1058_I_7_Y	203 + PCB_1058_Y

#define PT_1058_O_0_Y	167 + PCB_1058_Y
#define PT_1058_O_1_Y	120 + PCB_1058_Y
#define PT_1058_O_2_Y	39  + PCB_1058_Y
#define PT_1058_O_3_Y	23  + PCB_1058_Y

#pragma endregion _1058
// P1062	
#pragma region _1062

#define PCB_1062_X      260
#define PCB_1062_Y      20

#define PT_1062_GAP     9

#define CONN3_1062_Y    187
#define CONN4_1062_Y    204

#define PT_1062_I_1_X	PCB_1062_X + 139
#define PT_1062_I_2_X	PT_1062_I_1_X + PT_SIZE + PT_1062_GAP

#define PT_1062_I_X1	PCB_1062_X + 297
#define PT_1062_I_X2	PT_1062_I_X1
#define PT_1062_I_Y1	274
#define PT_1062_I_Y2	PT_1062_I_Y1 - PT_SIZE - PT_1062_GAP

#define PT_1062_O_1_X	PT_1062_I_2_X + PT_SIZE + PT_1062_GAP
#define PT_1062_O_2_X	PT_1062_O_1_X + PT_SIZE + PT_1062_GAP
#define PT_1062_O_3_X	PT_1062_O_2_X + PT_SIZE + PT_1062_GAP
#define PT_1062_O_4_X	PT_1062_O_3_X + (PT_SIZE * 8) + PT_1061_GAP

#define PT_1062_O_5_X	PT_1062_O_4_X - 12
#define PT_1062_O_5_Y	172

#pragma endregion _1062
// P8501
#pragma region _8501

#define PCB_8501_X		100
#define PCB_8501_Y		30
#define MEZZ_8501_X     (100 + PCB_8501_X)
#define MEZZ_8501_Y     PCB_8501_Y + 30
#define MEZZ_8501_OFF   145
#define P8501_DIP_POS_X 420
#define P8501_DIP_POS_Y 235

// P8501 main inputs
#define P8501_X_OFFSET  95
#define P8501_Y_OFFSET  19

// 16 inboard inputs
#define PT_8501_MI_01_X		445 + P8501_X_OFFSET
#define PT_8501_MI_02_X		415 + P8501_X_OFFSET
#define PT_8501_MI_03_X		400 + P8501_X_OFFSET
#define PT_8501_MI_04_X		370 + P8501_X_OFFSET
#define PT_8501_MI_05_X		348 + P8501_X_OFFSET
#define PT_8501_MI_06_X		318 + P8501_X_OFFSET
#define PT_8501_MI_07_X		302 + P8501_X_OFFSET
#define PT_8501_MI_08_X		272 + P8501_X_OFFSET
#define PT_8501_MI_09_X		250 + P8501_X_OFFSET
#define PT_8501_MI_10_X		220 + P8501_X_OFFSET
#define PT_8501_MI_11_X		205 + P8501_X_OFFSET
#define PT_8501_MI_12_X		173 + P8501_X_OFFSET
#define PT_8501_MI_13_X		152 + P8501_X_OFFSET
#define PT_8501_MI_14_X		122 + P8501_X_OFFSET
#define PT_8501_MI_15_X		107 + P8501_X_OFFSET
#define PT_8501_MI_16_X		76  + P8501_X_OFFSET

#define PT_8501_E1I_X		468 + P8501_X_OFFSET
#define PT_8501_E2I_X		9	+ P8501_X_OFFSET

#define PT_8501_E1O_X		475 + P8501_X_OFFSET
#define PT_8501_E2O_X		9	+ P8501_X_OFFSET

// P8501 expansion1 inputs
#define PT_8501_MI_Y		10  + P8501_Y_OFFSET
#define PT_8501_E1I_01_Y	264  + P8501_Y_OFFSET
#define PT_8501_E1I_02_Y	230  + P8501_Y_OFFSET
#define PT_8501_E1I_03_Y	212  + P8501_Y_OFFSET
#define PT_8501_E1I_04_Y	179  + P8501_Y_OFFSET
#define PT_8501_E1I_05_Y	158  + P8501_Y_OFFSET
#define PT_8501_E1I_06_Y	125  + P8501_Y_OFFSET
#define PT_8501_E1I_07_Y	106  + P8501_Y_OFFSET
#define PT_8501_E1I_08_Y	73 + P8501_Y_OFFSET

// P8501 expansion2 inputs
#define PT_8501_E2I_01_Y	70  + P8501_Y_OFFSET
#define PT_8501_E2I_02_Y	104  + P8501_Y_OFFSET
#define PT_8501_E2I_03_Y	121  + P8501_Y_OFFSET
#define PT_8501_E2I_04_Y	155  + P8501_Y_OFFSET
#define PT_8501_E2I_05_Y	177  + P8501_Y_OFFSET
#define PT_8501_E2I_06_Y	210  + P8501_Y_OFFSET
#define PT_8501_E2I_07_Y	227  + P8501_Y_OFFSET
#define PT_8501_E2I_08_Y	262  + P8501_Y_OFFSET

// P8501 main outputs
#define PT_8501_MO_01_X		37 + P8501_X_OFFSET
#define PT_8501_MO_02_X		85 + P8501_X_OFFSET
#define PT_8501_MO_03_X		62 + P8501_X_OFFSET
#define PT_8501_MO_04_X		47 + P8501_X_OFFSET
#define PT_8501_MO_05_X		32 + P8501_X_OFFSET
#define PT_8501_MO_Y1		320 + P8501_Y_OFFSET
#define PT_8501_MO_Y2		10 + P8501_Y_OFFSET

// P8501 expansion1 outputs
#define PT_8501_E1O_01_Y	244 + P8501_Y_OFFSET		
#define PT_8501_E1O_02_Y	192 + P8501_Y_OFFSET		
#define PT_8501_E1O_03_Y	138 + P8501_Y_OFFSET		
#define PT_8501_E1O_04_Y	86 +  P8501_Y_OFFSET	

// P8501 expansion2 outputs
#define PT_8501_E2O_01_Y	91 +  P8501_Y_OFFSET		
#define PT_8501_E2O_02_Y	142 + P8501_Y_OFFSET		
#define PT_8501_E2O_03_Y	196 + P8501_Y_OFFSET		
#define PT_8501_E2O_04_Y	247 + P8501_Y_OFFSET	

#pragma endregion _8501
