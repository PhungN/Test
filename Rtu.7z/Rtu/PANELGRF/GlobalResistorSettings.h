#pragma once
//#include "RtuRes\resource.h"

#pragma pack(1)
typedef struct tagGlobalResistorSetting
{
	BYTE	alarmResistorValue;
	BYTE	secureResistorValue;
	BYTE	globalHitCountValue;
	BYTE	globalToleranceValue;
	
} GLOBAL_RESISTOR_SETTING_CFG;

#pragma pack()

// CGlobalResistorSettings dialog

class CGlobalResistorSettings : public CDialog
{
	DECLARE_DYNAMIC(CGlobalResistorSettings)

	GLOBAL_RESISTOR_SETTING_CFG* m_pSettings;
public:
	CGlobalResistorSettings(CWnd* pParent, GLOBAL_RESISTOR_SETTING_CFG* settings);   // standard constructor
	virtual ~CGlobalResistorSettings();

// Dialog Data
	enum { IDD = IDD_GLOBAL_RESISTOR_SETTINGS };

	
	
protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual BOOL OnInitDialog();
	
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedOk();
};
