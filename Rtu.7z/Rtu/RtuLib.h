#pragma once

#include <map>
#include "RtuRes\resource.h"
#include "GMS\CommonUse\GenericHardwareConfigDataEnvelope.h"
#include <memory>

#define UWM_RTU_STATUS_MSG		_T("UWM_RTU_STATUS-{5E013DC3-2133-42a0-9D23-30F9201F6E5C}")

#define REGISTER_USER_MESSAGE(name) \
const UINT name = ::RegisterWindowMessage(name##_MSG);

REGISTER_USER_MESSAGE(UWM_RTU_STATUS)


#define L_YELLOW	RGB(255,255,238)
#define LL_YELLOW   RGB(255,255,240)
#define L_RED		RGB(255,0,0)
#define L_BLUE		RGB(0,0,192)
#define LL_BLUE		RGB(0,0,128)

#define Bit0(f) ((f & 0x01) ? TRUE : FALSE)
#define Bit1(f) ((f & 0x02) ? TRUE : FALSE)
#define Bit2(f) ((f & 0x04) ? TRUE : FALSE)
#define Bit3(f) ((f & 0x08) ? TRUE : FALSE)
#define Bit4(f) ((f & 0x10) ? TRUE : FALSE)
#define Bit5(f) ((f & 0x20) ? TRUE : FALSE)
#define Bit6(f) ((f & 0x40) ? TRUE : FALSE)
#define Bit7(f) ((f & 0x80) ? TRUE : FALSE)

#define MAX_BUFF 256

#define RES_STRING(id) (LPCTSTR)CString((LPTSTR)(id))
#define RES_CSTRING(id) CString((LPTSTR)(id))

typedef unsigned long ulong;
typedef unsigned short ushort;
typedef double DOUBLE;

void InitRtuOptions(HWND hWnd, PPARMPROC pps);
int InitRtuParms(HWND hWnd, PPARMPROC pps, LPBYTE p1);
LPPARMPROC GetLPPARMPROC(HWND hDlg, int& nOption, PARMPROC rtups, BOOL bDestroyWnd=TRUE);
void InitRtuParam2();

void EditAccessParams(LPPARMPROC, int nCmdShow = SW_SHOW);
BOOL WINAPI Edit1057Ports(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);
BOOL WINAPI Edit1058Ports(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);
BOOL WINAPI EditVCU2000Ports(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);
BOOL WINAPI Edit8001Ports(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);
BOOL _IsSoftProcActive();

//------------------------------------------------------------------------
BOOL IsRtu8002Type(); //TT 7516
//------------------------------------------------------------------------

void RemoveFileIndex(CStringArray& strArr, BOOL bRemoved=TRUE);
int DispMessageBox(HWND hWnd, UINT nMsgID, UINT nCaptionID, UINT nType);
int DispMessageBox1(HWND hWnd, UINT nMsgID, UINT nCaptionID, UINT nType, int nNum);
int DispMessageBox2(HWND hWnd, UINT nMsgID, UINT nCaptionID, UINT nType, int nNum1, int nNum2);
int DispMessageBox3(HWND hWnd, UINT nMsgID, UINT nCaptionID, UINT nType, int nNum1, int nNum2, int nNum3);

void GetMonthStr(CStringArray& strMonths, BOOL bUnused=TRUE);
void GetUserTypeList(CStringArray& strUserTypes, BOOL bUndefined=TRUE);
void GetPortList(CStringArray& strPorts, int rtuType, BOOL bAddInternalPort=FALSE);
void GetRtuPortList(CStringArray& strPorts, int rtuType, BOOL bIsRtu8002);
void GetRtuInternalPortList(CStringArray& strPorts);

int GetRtuModeCount();
int GetRtuMode(int nIndex);
void DoBatteryTest(HWND hDlg, int rtuno, int nOption);
void DoShutdownHDD(HWND hDlg, int rtuno, int nOption);
void DoPacomVaultCommand(HWND hDlg, int rtuno, int nCommand, int nVaultNumber, int nFlags);
void ShowPacomVaultControls(HWND hDlg, int cmdNum);
void DoProgInovTransmitter(HWND hDlg, int rtuno, int nTxOption, int nAddress);
void AdjustPropertySheetLocation(CWnd *pParent, CWnd *psWnd, BOOL initRequired); //TT 8345

namespace Rtu
{
	class RtuLib
	{
	public:
		static void DDX_CBIndex  (CDataExchange *pDX, int cid, BYTE &dataByte); 
		static void DDX_CBIndex  (CDataExchange *pDX, int cid, BYTE &point, BYTE BitMask);
		static void DDX_CBIndexEx(CDataExchange *pDX, int cid, BYTE &point, int numBits, int sBit);

		static void DDX_Check(CDataExchange *pDX, int cid, BYTE  &dataByte, BYTE BitNumber);
		static void DDX_Check(CDataExchange *pDX, int cid, WORD  &dataByte, BYTE BitNumber);
		static void DDX_Check(CDataExchange *pDX, int cid, ulong &dataByte, BYTE BitNumber);


		static void DDX_Text(CDataExchange *pDX, int cid, WORD &point, WORD BitMask); 
		static void DDX_Text(CDataExchange *pDX, int cid, BYTE &point, BYTE BitMask);
		static void DDX_Text(CDataExchange *pDX, int cid, BYTE &point, BYTE BitMask, BYTE offset); 
		static void DDX_Text(CDataExchange *pDX, int cid, WORD &point);
		static void DDX_Text(CDataExchange *pDX, int cid, BYTE &value);
		static void DDX_Text(CDataExchange *pDX, int cid, TCHAR *string);

		static void DDX_Radio(CDataExchange *pDX, int cid, int &point, int BitMask, int offset); 

		static void DDX_TimeHHMM(CDataExchange *pDX, int cid, BYTE& hour, BYTE& minute);

		static void SwapByteOrder(ushort &val);
		static void SwapByteOrder(ulong &val);

		static void ChangeDialogFont(CWnd* pWnd, CFont* pFont);
		static void FileExecute(HWND hWnd, TCHAR* fname, TCHAR* opMode);
		static BOOL GetPrintFileName(TCHAR* fname, TCHAR* defExt);
		static BOOL GetFileName(TCHAR* fname, TCHAR* defExt, TCHAR* szFilter, BOOL bOpen=FALSE);
		static BOOL GetFileStrings(LPCTSTR fileName, CStringArray& strArray, BOOL bRemoveIndex=FALSE);
		static BOOL LineFromFileA(FILE* f, CString& s);
		static BOOL LineFromFileW(FILE* f, CString& s);
		static BOOL IsUnicodeFile(LPCTSTR fileName);

		static BOOL WriteFileStrings(LPCTSTR fileName, CStringArray& strArray, bool bWriteAsUnicode, int numbering);

		static void GetResourceStrings(HINSTANCE hInst, CStringArray& strArr, UINT ids[], int nSize);
		static void FillComboBox(HINSTANCE hInst, CComboBox* pCB, UINT ids[], int nSize);
		static void FillComboBox(HINSTANCE hInst, CWnd* pParent, UINT id, UINT ids[], int nSize);
		static BOOL ReadGMS32Registry(LPTSTR lpVersion, LPTSTR lpDir);
		static BOOL AddStringToFile(LPCTSTR lpszFileName, LPTSTR lpszText);

		static int GetInputNumber(int nLabelID=-1, int nTitleID=IDS_INPUT_DLG_TITLE);
		static BOOL GetInputNumber2(int& in1, int& in2, int nLabelID1=-1, int nLabelID2=-1, int nTitleID=IDS_INPUT_DLG_TITLE);
		static BOOL IsConfigChanged(LPBYTE pConfig, int nCfgSize, LPCTSTR szFileName);
		static BOOL IsFileExist(LPTSTR szFileName);
		static BOOL IsNewControllerType(int nRtuType);

		static void SendPcpCommand(HWND hDlg, int nRtuNumber, LPBYTE pData, UINT msgID = 0);

		static CString ToString(int value);
		static CString IpAddressToString(LPBYTE pIPA);
		static CString PhonetoString(LPBYTE pData, int size);
		static int GetRtuPhysicalPortNumber(int portIndex, int rtuType);
		static int GetRtuPortIndex(int physicalPortNumber, int rtuType);
		static CString GetRtuPortString(int physicalPortNumber, int rtuType);
		static UINT GetGmsCodePage();
		
		static WORD SwapByte(WORD value);
	};

}

namespace Rtu
{
	class CNumEdit : public CEdit
	{
	public:
		CNumEdit(){};
		CNumEdit(int min, int max, int limit){
			m_nMin = min; m_nMax = max; m_nLimit = limit;
		}
		// Overrides
		// ClassWizard generated virtual function overrides
		//{{AFX_VIRTUAL(CNumEdit)
		protected:
		virtual void PreSubclassWindow();
		virtual void DoDataExchange(CDataExchange* pDX);
		//}}AFX_VIRTUAL

	// Implementation
	public:
		BOOL SetMinMaxLimit(int min, int max, UINT limit);
		virtual ~CNumEdit(){};

		// Generated message map functions
	protected:
		//{{AFX_MSG(CNumEdit)
		afx_msg void OnChange();
		//}}AFX_MSG

		DECLARE_MESSAGE_MAP()
	private:
		int m_nIDC;
		int m_nLimit;
		int m_nMax;
		int m_nMin;
	};
}

namespace Rtu
{
	class CNameKeyBitmapMap
	{
		typedef std::map<CString, HBITMAP> DeviceBitmapList;

		static DeviceBitmapList	s_deviceBmps;
		
		private:
			void DeleteBitmaps();
		
		public:
			CNameKeyBitmapMap()
			{
				DeleteBitmaps();				
			};
			~CNameKeyBitmapMap() 
			{
				DeleteBitmaps();
			}

			// don't call DeleteObject after obtaining the HBITMAP
			static HBITMAP GetBitmap(CString bmpName);
	};

};
/////////////////////////////////////////////////////////////////////////////

//====================================================================================//
//						Generic Child dialog									    ==//
//====================================================================================//
class CGenDialog : public CDialog  
{
public:
	CGenDialog();
	CGenDialog(UINT nIDTemplate, CWnd* pParent=NULL);
	//virtual ~CGenDialog();
	virtual int GetMyDialogID() = 0;  // must be provided by derived classes
	void CreateChildDialog(CWnd *pParent, 
		int PlaceMarkerCtrlID,  int Id=0,  CRect *ABorderRect = NULL) {
		CreateGenericChildDialog(pParent, PlaceMarkerCtrlID, Id, ABorderRect);
		}
	CSize CreateGenericChildDialog(CWnd *pParent, 
		int PlaceMarkerCtrlID,  int Id,  CRect *ABorderRect = NULL);

	void CreateChildDialog(CWnd *Parent, CWnd* pCtrl, CRect& PlaceMarkerRect);
	CSize GetDlgSize();
	// Dialog Data
	//{{AFX_DATA(CGenDialog)
	//}}AFX_DATA

// Overrides
	//{{AFX_VIRTUAL(CGenDialog)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

protected:
	//{{AFX_MSG(CGenDialog)
		// NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

protected:
	void PostMessageToParent(UINT message, LPARAM lParam);
private:
        WPARAM m_ID;
        CWnd* m_pParent;

};

#define MAX_LB_ITEM 256

/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////
// CComboBoxDisabledItem window
class CComboBoxDisabledItem : public CComboBox
{
// Construction
public:
	CComboBoxDisabledItem(){}
	void SetCurItem(UINT uIndex, BOOL flag){m_bCurItemStus[uIndex] = flag;}
	virtual ~CComboBoxDisabledItem(){};
	virtual BOOL IsItemEnabled(UINT nIndex) const{ return m_bCurItemStus[nIndex];}

// Operations
public:
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CComboBoxDisabledItem)
	public:
	virtual void DrawItem(LPDRAWITEMSTRUCT lpDrawItemStruct);
	virtual void MeasureItem(LPMEASUREITEMSTRUCT lpMeasureItemStruct);
	protected:
	virtual void PreSubclassWindow();
	//}}AFX_VIRTUAL

	// Generated message map functions
protected:
	//{{AFX_MSG(CComboBoxDisabledItem)
	afx_msg int OnCharToItem(UINT nchar, CListBox* pListBox, UINT nIndex);
	afx_msg void OnSelendok();
	afx_msg LRESULT OnRealSelEndOK(WPARAM,LPARAM);
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
private:
	//BOOL m_bCurItemStus[12];
	BOOL m_bCurItemStus[MAX_LB_ITEM];
	CString m_strSavedText;	// saves text between OnSelendok and OnRealSelEndOK calls
};




namespace Rtu
{

	class CPropPageFrame
	{
	// Construction/Destruction
	public:
		CPropPageFrame();
		virtual ~CPropPageFrame();

	// Operations
	public:
		virtual BOOL Create(DWORD dwWindowStyle, const RECT &rect, CWnd *pwndParent, UINT nID) = 0;
		virtual CWnd* GetWnd() = 0;
		virtual void ShowCaption(BOOL bEnable);
		BOOL GetShowCaption() const;
		virtual void SetCaptionHeight(int nCaptionHeight);
		int GetCaptionHeight() const;
		virtual void SetCaption(LPCTSTR lpszCaption, HICON hIcon = NULL);
		CString GetCaption(HICON *pIcon = NULL) const;
		virtual void SetMsgText(LPCTSTR lpszMsg);
		CString GetMsgText() const;
		virtual void SetMsgFormat(DWORD dwFormat);
		DWORD GetMsgFormat() const;

	// Overridable implementation helpers
	protected:
		virtual void Draw(CDC *pDc);
		virtual CRect CalcMsgArea();
		virtual void DrawMsg(CDC *pDc, CRect rect, LPCTSTR lpszMsg, DWORD dwFormat);
		virtual CRect CalcCaptionArea();
		virtual void DrawCaption(CDC *pDc, CRect rect, LPCTSTR lpszCaption, HICON hIcon);

	// Implementation helpers
	protected:
		void SafeUpdateWindow(LPCRECT lpRect = NULL);

	// Properties
	private:
		BOOL m_bShowCaption;
		int m_nCaptionHeight;
		CString m_strCaption;
		HICON m_hCaptionIcon;
		CString m_strMsg;
		DWORD m_dwMsgFormat;
	};

} //namespace Rtu

namespace Rtu
{
	class CPropPageFrameDefault : public CWnd,
												public CPropPageFrame
	{
	// construction/destruction
	public:
		CPropPageFrameDefault();
		virtual ~CPropPageFrameDefault();
	// operations
	public:

	// overridings
	public:
		virtual BOOL Create(DWORD dwWindowStyle, const RECT &rect, CWnd *pwndParent, UINT nID);
		virtual CWnd* GetWnd();
		virtual void SetCaption(LPCTSTR lpszCaption, HICON hIcon = NULL);
		
	protected:
		virtual CRect CalcMsgArea();
		virtual CRect CalcCaptionArea();
		virtual void DrawCaption(CDC *pDc, CRect rect, LPCTSTR lpszCaption, HICON hIcon);

	// Implementation helpers
	protected:
		void FillGradientRectH(CDC *pDc, const RECT &rect, COLORREF clrLeft, COLORREF clrRight);
		BOOL ThemeSupport() const;

	protected:
		//{{AFX_VIRTUAL(CPropPageFrameDefault)
		//}}AFX_VIRTUAL

	// message handlers
	protected:
		//{{AFX_MSG(CPropPageFrameDefault)
		afx_msg void OnPaint();
		afx_msg BOOL OnEraseBkgnd(CDC* pDC);
		//}}AFX_MSG
		DECLARE_MESSAGE_MAP()

	// attributes
	protected:
		CImageList m_Images;
	};
} //namespace Rtu


namespace Rtu
{

	class CTreePropSheet : public CPropertySheet
	{
		DECLARE_DYNAMIC(CTreePropSheet)

	// Construction/Destruction
	public:
		CTreePropSheet();
		CTreePropSheet(UINT nIDCaption, CWnd* pParentWnd = NULL, UINT iSelectPage = 0);
		CTreePropSheet(LPCTSTR pszCaption, CWnd* pParentWnd = NULL, UINT iSelectPage = 0);
		virtual ~CTreePropSheet();

	// Operations
	public:
		BOOL SetTreeViewMode(BOOL bTreeViewMode = TRUE, BOOL bPageCaption = FALSE, BOOL bTreeImages = FALSE);
		BOOL SetTreeWidth(int nWidth);
		void SetEmptyPageText(LPCTSTR lpszEmptyPageText);
		DWORD SetEmptyPageTextFormat(DWORD dwFormat);
		BOOL SetTreeDefaultImages(CImageList *pImages);
		BOOL SetTreeDefaultImages(UINT unBitmapID, int cx, COLORREF crMask);
		CTreeCtrl* GetPageTreeControl();
	// Public helpers
	public:
		static BOOL SetPageIcon(CPropertyPage *pPage, HICON hIcon);
		static BOOL SetPageIcon(CPropertyPage *pPage, UINT unIconId);
		static BOOL SetPageIcon(CPropertyPage *pPage, CImageList &Images, int nImage);
		static BOOL DestroyPageIcon(CPropertyPage *pPage);

	// Overridable implementation helpers
	protected:
		virtual CString GenerateEmptyPageMessage(LPCTSTR lpszEmptyPageMessage, LPCTSTR lpszCaption);
		virtual CTreeCtrl* CreatePageTreeObject();
		virtual CPropPageFrame* CreatePageFrame();

	// Implementation helpers
	protected:
		void MoveChildWindows(int nDx, int nDy);
		void RefillPageTree();
		HTREEITEM CreatePageTreeItem(LPCTSTR lpszPath, HTREEITEM hParent = TVI_ROOT);
		CString SplitPageTreePath(CString &strRest);
		BOOL KillActiveCurrentPage();
		HTREEITEM GetPageTreeItem(int nPage, HTREEITEM hRoot = TVI_ROOT);
		BOOL SelectPageTreeItem(int nPage);
		BOOL SelectCurrentPageTreeItem();
		void UpdateCaption();
		void ActivatePreviousPage();
		void ActivateNextPage();

	// Overridings
	protected:
		//{{AFX_VIRTUAL(CTreePropSheet)
		public:
		virtual BOOL OnInitDialog();
		//}}AFX_VIRTUAL

	// Message handlers
	protected:
		//{{AFX_MSG(CTreePropSheet)
		afx_msg void OnDestroy();
		//}}AFX_MSG
		afx_msg LRESULT OnAddPage(WPARAM wParam, LPARAM lParam);
		afx_msg LRESULT OnRemovePage(WPARAM wParam, LPARAM lParam);
		afx_msg LRESULT OnSetCurSel(WPARAM wParam, LPARAM lParam);
		afx_msg LRESULT OnSetCurSelId(WPARAM wParam, LPARAM lParam);
		afx_msg LRESULT OnIsDialogMessage(WPARAM wParam, LPARAM lParam);

		afx_msg void OnPageTreeSelChanging(NMHDR *pNotifyStruct, LRESULT *plResult);
		afx_msg void OnPageTreeSelChanged(NMHDR *pNotifyStruct, LRESULT *plResult);
		DECLARE_MESSAGE_MAP()

	// Properties
	private:
		BOOL m_bTreeViewMode;
		CTreeCtrl *m_pwndPageTree;
		CPropPageFrame *m_pFrame;
		BOOL m_bPageTreeSelChangedActive;
		BOOL m_bPageCaption;
		BOOL m_bTreeImages;
		CImageList m_Images;
		CImageList m_DefaultImages;
		CString m_strEmptyPageMessage;
		int m_nPageTreeWidth;

	// Static Properties
	private:
		static const UINT s_unPageTreeId;
	};


} //namespace Rtu

//
//typedef struct tagNameAndID 
//{
//	int ID;
//	CString Name;
//} NameAndID;
//
//#include <vector>
//class CIdNameKeyValueMap
//{
//private:
//	std::vector<NameAndID> m_IdNameKeyValueMap;
//
//public:
//	int Size() const { return m_IdNameKeyValueMap.size(); }
//	void Add(const int id, CString name)
//	{
//		for( WORD ind=0; ind < m_IdNameKeyValueMap.size(); ind++)
//		{
//			if( m_IdNameKeyValueMap[ind].ID == id)
//			{
//				m_IdNameKeyValueMap[ind].Name = name;
//				return;
//			}
//		}
//
//		NameAndID newOne;
//		newOne.ID = id;
//		newOne.Name = name;
//		m_IdNameKeyValueMap.push_back(newOne);
//
//	}
//
//	CString GetValue(const int& key)
//	{
//		for( WORD ind=0; ind < m_IdNameKeyValueMap.size(); ind++)
//		{
//			if( m_IdNameKeyValueMap[ind].ID == key)
//			{
//				return m_IdNameKeyValueMap[ind].Name;
//			}
//		}
//		return _T("");
//	}
//
//	CString operator [] (const int& key)
//	{
//		return GetValue(key);
//	}
//
//};
//
//class CNameIdKeyValueMap
//{
//private:
//	std::vector<NameAndID> m_NameIdKeyValueMap;
//
//public:
//	int Size() const { return m_NameIdKeyValueMap.size(); }
//	void Add(const int id, CString name)
//	{
//		for( WORD ind=0; ind < m_NameIdKeyValueMap.size(); ind++)
//		{
//			if( m_NameIdKeyValueMap[ind].Name == name)
//			{
//				m_NameIdKeyValueMap[ind].ID = id;
//				return;
//			}
//		}
//
//		NameAndID newOne;
//		newOne.ID = id;
//		newOne.Name = name;
//		m_NameIdKeyValueMap.push_back(newOne);
//
//	}
//
//	int GetValue(const CString& key)
//	{
//		for( WORD ind=0; ind < m_NameIdKeyValueMap.size(); ind++)
//		{
//			if( m_NameIdKeyValueMap[ind].Name == key)
//			{
//				return m_NameIdKeyValueMap[ind].ID;
//			}
//		}
//		return -1;
//	}
//
//	int operator [] (const CString& name)
//	{
//		return GetValue(name);
//	}
//
//};
//
///////////////////////////////////////////////////////////////////////////
// The CListCtrlEx class definition
///////////////////////////////////////////////////////////////////////////
class CListCtrlEx : public CListCtrl
{
// Construction
public:
	CListCtrlEx();
	virtual ~CListCtrlEx();

	// List extended styles
	void SetGridLines(BOOL bSet = TRUE);			// Show grid lines.
	void SetSubItemImage(BOOL bSet = TRUE);			// Show subitem image
	void SetTrackSelect(BOOL bSet = TRUE);			
	void SetHeaderDragDrop(BOOL bSet = TRUE);		
	void SetFullRowSelect(BOOL bSet = TRUE);		// Use full row selection style.
	void SetCheckboxes(BOOL bSet = TRUE);			// Show checkboxes.
		
	BOOL SetHeadings(UINT uiStringID);				// Set columns and their formats.
	BOOL SetHeadings(const CString& strHeadings);	// Set columns and their formats.

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CListCtrlEx)
	protected:
	virtual void PreSubclassWindow();
	//}}AFX_VIRTUAL

protected:
	// Wizzard generated stuff
	//{{AFX_MSG(CListCtrlEx)
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};

///////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////
#define TB_HEADER		1
#define TB_DATA			2
#define COL_SPAN		0x8000	// BIT15
#define ROW_SPAN		0x4000	// BIT14
#define TB_ROW_MASK		0x7f
#define TB_COL_MASK		0x7f
#define TB_RC_SPAN_MASK 0x3fff

class CHtmlFile
{
public:
	CHtmlFile (HINSTANCE hInst, CString strFileName);
	~CHtmlFile ();

	int SetBgColor(CString color);
	int SetThAlign(CString align) {m_thAlign = align; return 1;};
	int SetTdAlign(CString align) {m_tdAlign = align; return 1;};

	void SetColSpan(int thColSpan, int tdColSpan){m_nThColSpan=thColSpan; m_nTdColSpan=tdColSpan;};
	void SetRowSpan(int thRowSpan, int tdRowSpan){m_nThRowSpan=thRowSpan; m_nTdRowSpan=tdRowSpan;};

	int StartTags(CString lpszTitle, CString lpszCaption);
	int StartTags(int rtuType, int rtuNo, UINT cfgID, UINT paramID);
	int StartTags(int rtuType, int rtuNo, CString cfgTxt, CString paramTxt);
	int StartTagsP(int rtuType, int rtuNo, UINT cfgID, int portNum, CString portProt);
	int EndTags();
	int AddRow(int th, CString hTxt, int td, CString dTxt);
	int AddRow(int th, CString hTxt, int td, int dData);
	int AddRow(CString hTxt, CString dTxt);
	int AddRow(CString hTxt, int td);
	int AddRow(int hCnt, int dCnt, ...);

	int AddRowResID2(UINT hID, UINT dID);
	int AddRowResID1(UINT hID, CString dTxt);
	int AddRowResID1(UINT hID, int td);
	int AddRowResID(int th, UINT hID, int td, UINT dID);
	int AddRowResID(int th, UINT hID, int td, CString dTxt);
	int AddRow(HINSTANCE hInst, int hCnt, int dCnt, ...);

	int AddTH(int hCnt, ...);
	int AddTD(int hCnt, ...);
	int AddTD(CString txt, int rspan=1);
	int AddTDColor(CString txt, int rspan=1);
	int WriteStr(CString& str);

private:
	CString bgcolor;
	CString m_thAlign;
	CString m_tdAlign;
	int m_nThColSpan;
	int m_nThRowSpan;
	int m_nTdColSpan;
	int m_nTdRowSpan;

	CString m_strFileName;
	//CFile* m_pFile;

	CStringArray m_strArr;
	HINSTANCE m_hInst;
};

//moved to Mylib
//
//class CTextFile
//{
//
//public:
//
//	// ctor( s )
//	CTextFile( const CString& ext = _T( "" ), const CString& eol = _T( "\r\n" ) );
//
//	// dtor
//	virtual ~CTextFile();
//
//	// File operations
//	//BOOL	ReadTextFile( CString& filename, CStringArray& contents );
//	BOOL	ReadTextFile( LPCTSTR filename, CStringArray& contents, TCHAR delimit=_T('\0'));
//	BOOL	ReadTextFile( CString& filename, CString& contents );
//
//	BOOL	WriteTextFile( CString& filename, const CStringArray& contents );
//	BOOL	WriteTextFile( CString& filename, const CStringArray contents[], int count );
//	BOOL	WriteTextFile( CString& filename, const CString& contents );
//
//	BOOL	AppendFile( CString& filename, const CString& contents );
//	BOOL	AppendFile( CString& filename, const CStringArray& contents );
//
//	// Window operations
//	BOOL	Load( CString& filename, CEdit* edit );
//	BOOL	Load( CString& filename, CListBox* list );
//	BOOL	Save( CString& filename, CEdit* edit );
//	BOOL	Save( CString& filename, CListBox* list );
//
//	// Error handling
//	CString GetErrorMessage();
//
//protected:
//
//	virtual BOOL GetFilename( BOOL save, CString& filename );
//	CString GetExtension();
//
//private:
//
//	CString m_error;
//	CString m_extension;
//	CString m_eol;
//
//	void	ClearError();
//	BOOL	ValidParam( CWnd* wnd );
//
//};

/////////////////////////////////////////////////////////////////////////////
// CGradientStatic window
typedef UINT (CALLBACK* LPFNDLLFUNC1)(HDC,CONST PTRIVERTEX,DWORD,CONST PVOID,DWORD,DWORD);

class CGradientStatic : public CStatic
{
// Construction
public:
	CGradientStatic();
	virtual ~CGradientStatic();
	void SetWindowText(LPCSTR a_lpstr);
	void SetColor(long cl);
	void SetGradientColor(long cl);
	void SetTextColor(long cl) {clText=cl;};
	void SetReverseGradient();
	void SetLeftSpacing(int iNoOfPixels) { m_iLeftSpacing = iNoOfPixels; };
	void SetTextAlign(int iAlign ) { m_iAlign = iAlign; };
	void SetVerticalGradient(BOOL a_bVertical = TRUE) { m_bVertical = a_bVertical; };

	static void DrawGradRect(CDC *pDC, CRect r, COLORREF cLeft, COLORREF cRight, BOOL a_bVertical);

	// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CGradientStatic)
	protected:
		virtual void PreSubclassWindow();
	//}}AFX_VIRTUAL


	// Generated message map functions
protected:
	CString m_csLinkText;
	CString m_sTEXT;
	int m_iLeftSpacing;
	long clLeft;
	long clRight;
	long clText;
	int m_iAlign;
	HINSTANCE hinst_msimg32;
	BOOL m_bCanDoGradientFill;
	BOOL m_bVertical;
	LPFNDLLFUNC1 GradientFill;
	
	//{{AFX_MSG(CGradientStatic)
	afx_msg void OnPaint();
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
private:
	TRIVERTEX rcVertex[2];
	GRADIENT_RECT grdRect;
};

/////////////////////////////////////////////////////////////////////////////
// CToolTipListBox window
class CToolTipListBox : public CListBox
{
// Construction
public:
	CToolTipListBox();

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CToolTipListBox)
	public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	//}}AFX_VIRTUAL

// Implementation
public:
	void SetToolTipText (CString* text, BOOL activate=TRUE);
	virtual ~CToolTipListBox();

	// Generated message map functions
protected:
	//BOOL m_bMouseOver;
	//{{AFX_MSG(CToolTipListBox)
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()

private:
	void InitToolTip(void);
	CToolTipCtrl m_toolTip;
	TOOLINFO m_ToolInfo;
};


/////////////////////////////////////////////////////////////////////////////
// CToolTipCheckListBox window
class CToolTipCheckListBox : public CCheckListBox
{
// Construction
public:
	CToolTipCheckListBox();

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CToolTipCheckListBox)
	public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	//}}AFX_VIRTUAL

// Implementation
public:
	void SetToolTipText (CString* text, BOOL activate=TRUE);
	virtual ~CToolTipCheckListBox();

	// Generated message map functions
protected:
	//BOOL m_bMouseOver;
	//{{AFX_MSG(CToolTipCheckListBox)
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()

private:
	void InitToolTip(void);
	CToolTipCtrl m_toolTip;
	TOOLINFO m_ToolInfo;
};

#include <windowsx.h>

typedef struct tagSlideMarker
{
	float m_pos;
	BOOL m_bColor;
	RECT m_mainRect;
	RECT m_rightRect;
	RECT m_leftRect;
} SliderMarker;

class CMultiSlider : public CSliderCtrl
{
// Construction
public:
	CMultiSlider();
	virtual ~CMultiSlider();

	void Initialize();
	void SetMinMaxValue(float fMin, float fMax);
	void SetMinMaxRange(float fMin, float fMax);

	float GetMinValue();
	float GetMaxValue();
	void SetText(CString str);
	void SetText(UINT resourceID);
	void SetTickCount(int tickCount) { m_nTickCount = tickCount;}

	void SetDisplayValueInfo(float nDispRange, CString strDispText);
// Implementation
protected:
	//HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CMultiSlider)
	afx_msg void OnPaint();
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	//}}AFX_MSG

	
	DECLARE_MESSAGE_MAP()

private:
	SliderMarker m_thumb[2];
	SliderMarker* m_pDraggedMarker;
	RECT m_sliderRect, m_thumbRect, m_channelRect, m_clientRect;
	float m_fMin, m_fMax, m_fRange; // rangeMin, rangeMax, rangeWidth;
	BOOL m_bInit, m_bDragBoth;
	CString m_strDispText;
	CString m_strWndText;
	float m_nDispRange;
	int m_nTickCount;

	void SetThumbRect(SliderMarker* marker);
	void GetSliderValues(float* min, float* width);
	void AvoidCrossing(SliderMarker* pMarker, float* position);
	SliderMarker* MarkerHitTest(POINT pt);
	SliderMarker* GetMarker(POINT pt);
	float RoundTo(float value, short decimal);
	CString GetDisplayString(float fValue);

	void UpdateSlider(SliderMarker* pMarker, UINT nFlags, CPoint point);

	void DrawSliders(HDC cdc, float sliderMin, float sliderWidth);
	void DrawTicks(HDC cdc, float sliderMin, float sliderWidth);
	void DrawStrings(HDC cdc, HFONT hFont);
	void DrawThumbs(HDC cdc);
};

/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////
// CInputBoxDlg dialog
class CInputBoxDlg : public CDialog
{
// Construction
public:
	CInputBoxDlg(int nTitleID, int nNameID, CWnd* pParent = NULL) : 
	  m_nTitleID(nTitleID), m_nNameID(nNameID), m_strName(_T("")), CDialog(CInputBoxDlg::IDD, pParent){};   // standard constructor
	
// Dialog Data
	//{{AFX_DATA(CInputBoxDlg)
	enum { IDD = IDD_INPUT_BOX_DLG };
	//}}AFX_DATA

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CInputBoxDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CInputBoxDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnCancel();
	afx_msg void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	int m_nTitleID;
	int m_nNameID;
	CString m_strName;

public:
	CString GetInputString() { return m_strName; }
};


/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////
// CInputBox2Dlg dialog
class CInputBox2Dlg : public CDialog
{
// Construction
public:
	CInputBox2Dlg(int nTitleID, int nNameID1, int nNameID2, CWnd* pParent = NULL) : 
	  m_nTitleID(nTitleID), m_nNameID1(nNameID1), m_nNameID2(nNameID2), m_strName1(_T("")), m_strName2(_T("")), CDialog(CInputBox2Dlg::IDD, pParent){};   // standard constructor
	
// Dialog Data
	//{{AFX_DATA(CInputBox2Dlg)
	enum { IDD = IDD_INPUT_BOX2_DLG };
	//}}AFX_DATA

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CInputBox2Dlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CInputBox2Dlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnCancel();
	afx_msg void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	int m_nTitleID;
	int m_nNameID1;
	int m_nNameID2;
	CString m_strName1;
	CString m_strName2;

public:
	CString GetInputString1() { return m_strName1; }
	CString GetInputString2() { return m_strName2; }
};

template <typename T>
class CMemData
{
public:
	CMemData(int nSize) : mSize(nSize) { mData.reset(new T[nSize]()); }
	T* GetData() { return mData.get(); }
	T* GetData(int index) { return index < mSize ? (T*)&mData[index] : nullptr; }
private:
	int mSize;
	std::unique_ptr<T[]> mData;
};
/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////
