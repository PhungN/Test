// Machine generated IDispatch wrapper class(es) created with ClassWizard
/////////////////////////////////////////////////////////////////////////////
// _Class1 wrapper class
#pragma once


//#include <afxole.h>         // MFC OLE classes
//#include <afxodlgs.h>       // MFC OLE dialog classes
//#include <afxdisp.h>        // MFC OLE automation classes


class _Class1 : public COleDispatchDriver
{
public:
	_Class1() {}		// Calls COleDispatchDriver default constructor
	_Class1(LPDISPATCH pDispatch) : COleDispatchDriver(pDispatch) {}
	_Class1(const _Class1& dispatchSrc) : COleDispatchDriver(dispatchSrc) {}

// Attributes
public:

// Operations
public:
	VARIANT NullFunction(BSTR* x);
	CString BMSRespond(BSTR* x);
	long comm_receive();
	void Main();
	long parenthandle(long* x);
};

