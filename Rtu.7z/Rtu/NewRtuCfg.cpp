/********************************************************************
 *		Description:  DLU Setup Program, RTU configuration Module
 ********************************************************************/

#include "stdafx.h"
#include "NewRtuCfg.h"
#include "SetupWizard.h"
#include "Bms.h"
#include "GmsUI\CommandBars.h"
#include "HardwareConfig\ProtocolIds.h"
#include "HardwareConfig\Rtu\PANELGRF\PANELHDR1.H"
#include "Gms\CommonUse\GmsCommandLineParams.h"	
#include "GMS\CommonUse\CommonDefs.h"
#include "HardwareConfig\PSPDefs.h"
#include "HardwareConfig\Rtu\PortParm\PortParamBlockIds.h"

extern SETUPPARM rtuSetup;
extern RTUDATA_ g_rtuPanelData;
/*--------------------------------------------------------------------------*/

#define SIZE_OF_TIMEZONE_DATA 7
static UINT indicators2[] =
{
	ID_SEPARATOR,           // status line indicator
};

#pragma region external ref
extern HINSTANCE hrInst;

extern int realRtuType;
extern int RtuType;
extern int PanelType;
extern int RAPType;
extern int nAccNumSize;
extern BOOL	EPW_FLAG;
extern BOOL	bObj;
extern PARMPROC Rtups[RTU_OPNCNT];
extern HWND	g_hRtuWnd;
extern MEMALLOC RtuMem;
extern HWND hPortParamWnd;
extern WORD AlmCnt;

extern BYTE	pblk_size[4], iblk, bsize;
extern int gRtuNo;
extern int DefOption;
extern UINT Demof;
extern LPTSTR svp;
extern BYTE s_CfgTypes[];
extern BYTE	rtuSoftwareType;
extern int gHSoftCmdsDlg;
extern CString gAlarmPanelTypeStr;
extern CString gPrimaryConnectionStr;
extern FARPROC lpRtuProc;
extern TCHAR s_HelpFile[];
extern BOOL bDisplayNewScreen;
extern BOOL bShowAdvancedPortParams;
extern CRtuCtrlCfgDlg* pRtuCtrlCfgDlg;
extern BOOL bIsValidHardwareCfg;

#pragma endregion

/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////
#pragma region Global variables...

BOOL bResetSoftwareRequest = FALSE;
CStringArray strArrUserDefinedCommands;
static BOOL bAlarmHardwareUploaded = FALSE;
static char rtu_command[] = {
	GO_OFFLINE_CMD,			//.0
	GO_ONLINE_CMD,
	GO_DAY_CMD,
	GO_NIGHT_CMD,
	FORCE_ENTRY_CMD,
	FORCE_EXIT_CMD,			//.5
	DRP_DIALUP_CMD,
	RES_SYS_ALM_CMD,
	RES_OUTPUTS_CMD,
	RES_ALL_ERR_CMD,
	RES_ALM_ERR_CMD,		//.10
	RES_DATA_ERR_CMD,
	RES_DIAL_ERR_CMD,
	LOCK_KPO_CMD,
	RESET_KPO_CMD,
	RTU_IDLE_CMD,			//.15
	RES_EXT_POINT_CMD,
	ISOLATE_PIRS_CMD,
	SW_RESET_CMD,
	SW_RESET_CMD,
	SW_RESET_CMD,			//.20
	GET_TIMEZONE_CMD,
	SET_TIMEZONE_CMD,
	WR_EEPROM_CMD,
	CHANGE_LCC_CMD,
	FIND_CNTLR_ADD_CMD,		//.25
	REQ_DUP_TEST_CMD,
	REQ_SRNO_CMD,
	DOWN_FACILITY_CMD,
	DOWN_LISTENIN_CMD,
	USER_DEF_CMD,			//.30
	TIME_SCHEDULE_CMD,
	DIALBKUP_CHANGE_CMD,
	SET_NORMAL_MODE_CMD,
	SET_LOCAL_MODE_CMD,
	BATTERY_TEST_CMD,		//.35
	PROG_INOV_TX_CMD,
	SHUTDOWN_HDD_CMD,
	PACOM_VAULT_CTRL_CMD,
};

#define HWND_MESSAGE     ((HWND)-3)

#pragma endregion

//--------------------------------------------------------------------------
int RTU8001_GetPortNumberFromPortIndex(int portIndex);
int RTU8001_GetPortIndexFromPortNumber(int portNumber);
//--------------------------------------------------------------------------
/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////
#pragma region CSysCmdSelectOptionDlg class
CSysCmdSelectOptionDlg::CSysCmdSelectOptionDlg(int nOption, CWnd* pParent)
	: m_nSelectedOption(0), m_nSelectedOption2(0), m_nOption(nOption), m_nFlags(0), CDialog(CSysCmdSelectOptionDlg::IDD, pParent)
{
}

CSysCmdSelectOptionDlg::~CSysCmdSelectOptionDlg()
{
}

void CSysCmdSelectOptionDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CSysCmdSelectOptionDlg)
	DDX_Control(pDX, IDC_CBO_OPTION, m_cboOption);
	DDX_Control(pDX, IDC_CBO_VAULT_NUMBER, m_cboVaultNumber);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CSysCmdSelectOptionDlg, CDialog)
	//{{AFX_MSG_MAP(CSysCmdSelectOptionDlg)
	ON_BN_CLICKED(IDOK, OnOK)
	ON_CBN_SELCHANGE(IDC_CBO_OPTION, OnSelChangeOptions)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


BOOL CSysCmdSelectOptionDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	ShowOption();
	CenterWindow();

	return TRUE;
}

void CSysCmdSelectOptionDlg::OnOK()
{
	m_nSelectedOption = (BYTE)m_cboOption.GetCurSel();

	if(m_nOption == PACOM_VAULT_CTRL_CMD) {
		m_nFlags = IsDlgButtonChecked(IDC_SYSCMD_RADIO2) ? 1 : 0;
		m_nSelectedOption2 = (BYTE)m_cboVaultNumber.GetCurSel();
	}
	EndDialog(TRUE);
}

void CSysCmdSelectOptionDlg::OnSelChangeOptions()
{
	int nIndex = m_cboOption.GetCurSel();
	if(m_nOption == PACOM_VAULT_CTRL_CMD) {
		m_cboVaultNumber.ResetContent();
		if(nIndex == 1) {
			m_cboVaultNumber.AddString(RES_STRING(IDS_ALL_VAULTS));
		}
		for(int i=1; i<=16; i++) {
			CString s; s.Format(_T("%d"), i);
			m_cboVaultNumber.AddString(s);
		}
		m_cboVaultNumber.SetCurSel(0);
	}
	
}

void CSysCmdSelectOptionDlg::ShowOption()
{
	HWND hOpCtrl = GetDlgItem(IDC_CBO_OPTION)->GetSafeHwnd();

	switch(m_nOption) {
		case BATTERY_TEST_CMD:
			SetDlgItemText(IDC_LBL_OPTION, RES_STRING(IDS_TEST_OPTIONS));
			InitControlBox(hrInst, hOpCtrl, CB_ADDSTRING, IDS_BATT_TEST_OP, 2);
			m_cboOption.SetCurSel(0);
			break;
		case PACOM_VAULT_CTRL_CMD:
			SetDlgItemText(IDC_LBL_OPTION, RES_STRING(IDS_COMMAND));
			GetDlgItem(IDC_SYSCMD_RADIO1)->ShowWindow(SW_SHOW);
			GetDlgItem(IDC_SYSCMD_RADIO2)->ShowWindow(SW_SHOW);
			GetDlgItem(IDC_LBL_VAULT_NUMBER)->ShowWindow(SW_SHOW);
			m_cboVaultNumber.ShowWindow(SW_SHOW);
			m_cboOption.ResetContent();
			m_cboOption.AddString(RES_STRING(IDS_PACOM_VAULT_CTRL_CMD));
			m_cboOption.AddString(RES_STRING(IDS_PACOM_VAULT_CTRL_CMD + 1));
			m_cboOption.SetCurSel(0);

			OnSelChangeOptions();
			CheckDlgButton(IDC_SYSCMD_RADIO1, TRUE);
			break;
	}
}
#pragma endregion


/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////
#pragma region CSelectAreasDlg class
CSelectAreasDlg::CSelectAreasDlg(BOOL bShowMode, BOOL bShowFlags, int nOption, CWnd* pParent)
	: CDialog(CSelectAreasDlg::IDD, pParent)
{
	m_pAreas = NULL;
	m_nSelectedAreas = 0;
	m_nMaxAreas = GetNumAreas();
	m_bShowMode = bShowMode;
	m_bShowFlags = bShowFlags;
	m_nOption = nOption;
	m_nSelectedMode = 0;
	m_nSelectedModeState = 0;
	m_nScheduleNumber = 0;
	m_nFlags = 0;
}

CSelectAreasDlg::~CSelectAreasDlg()
{
	if(m_pAreas != NULL) {
		delete m_pAreas; m_pAreas = NULL;
	}
}

void CSelectAreasDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CSelectAreasDlg)
	DDX_Control(pDX, IDC_CBO_MODE, m_cboMode);
	DDX_Control(pDX, IDC_CBO_MODE_STATE, m_cboModeState);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CSelectAreasDlg, CDialog)
	//{{AFX_MSG_MAP(CSelectAreasDlg)
	ON_BN_CLICKED(IDC_BTN_SELECT_ALL, OnBtnSelectAll)
	ON_BN_CLICKED(IDC_BTN_CLEAR_ALL, OnBtnClearAll)
	ON_BN_CLICKED(IDOK, OnOK)
	ON_CBN_SELCHANGE(IDC_CBO_MODE, OnSelChangedMode)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


BOOL CSelectAreasDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();

	m_nMaxAreas = GetNumAreas();
	
	m_pAreas = new CCheckDlg(m_nMaxAreas, 0, m_nMaxAreas == MAX_AREAS_32 ? 0xffffffff : 0xff);
	if(m_pAreas) { // Always evaluates to true
		m_pAreas->CreateGenericChildDialog(this, IDC_PLACE_HOLDER, 0, NULL);
		m_pAreas->ShowWindow(SW_SHOW);

		if(m_bShowMode) {
			GetDlgItem(IDC_LBL_MODE)->ShowWindow(SW_SHOW);
			GetDlgItem(IDC_CBO_MODE)->ShowWindow(SW_SHOW);
			HWND hCboMode = GetDlgItem(IDC_CBO_MODE)->GetSafeHwnd();
			if(m_nOption == ISOLATE_PIRS_CMD) {
				SetDlgItemText(IDC_LBL_MODE, RES_STRING(IDS_POINT_TYPE));
				InitControlBox(hrInst, hCboMode, CB_ADDSTRING, IDS_PointTypes, 5);
			}
			else {
				InitControlBox(hrInst, hCboMode, CB_ADDSTRING, rtu_mode, GetRtuModeCount());
			}
			m_cboMode.SetCurSel(0);
		}

		if(m_bShowFlags) {
			GetDlgItem(IDC_RAD_ISOLATE)->ShowWindow(SW_SHOW);
			GetDlgItem(IDC_RAD_DEISOLATE)->ShowWindow(SW_SHOW);
			CheckRadioButton(IDC_RAD_ISOLATE, IDC_RAD_DEISOLATE, IDC_RAD_ISOLATE);
		}
	}
	CenterWindow();

	return TRUE;
}

void CSelectAreasDlg::OnBtnSelectAll()
{
	m_pAreas->SelectAll();
}

void CSelectAreasDlg::OnBtnClearAll()
{
	m_pAreas->ClearAll();
}

void CSelectAreasDlg::OnOK()
{
	m_nSelectedAreas = m_pAreas->GetData();
	m_nSelectedMode = (BYTE)m_cboMode.GetCurSel();
	m_nSelectedModeState = (BYTE)m_cboModeState.GetCurSel();
	m_nScheduleNumber = GetDlgItemInt(IDC_TXT_SCH_NUM);
	m_nFlags = IsDlgButtonChecked(IDC_RAD_ISOLATE) ? 1 : 0;

	EndDialog(TRUE);
}

void CSelectAreasDlg::OnSelChangedMode()
{
	int nIndex = m_cboMode.GetCurSel();
	int c1 = GetRtuMode(nIndex);
	int nShowCmd = SW_HIDE;
	if (c1==SCHEDULE_OFF_MODE) {
		nShowCmd = SW_SHOW;
		UpdateModeState();
		m_cboModeState.SetCurSel(0);
	}

	GetDlgItem(IDC_LBL_SCH_NUM)->ShowWindow(nShowCmd);
	GetDlgItem(IDC_TXT_SCH_NUM)->ShowWindow(nShowCmd);
	GetDlgItem(IDC_LBL_MODE_STATE)->ShowWindow(nShowCmd);
	GetDlgItem(IDC_CBO_MODE_STATE)->ShowWindow(nShowCmd);
}

void CSelectAreasDlg::UpdateModeState()
{
	m_cboModeState.ResetContent();
	if(m_nOption == FORCE_ENTRY_CMD) {
		m_cboModeState.AddString(RES_STRING(IDS_OFF));
		m_cboModeState.AddString(RES_STRING(IDS_BEGIN_OFF_GRACE));
		m_cboModeState.AddString(RES_STRING(IDS_BEGIN_ON_GRACE));

	} else if(m_nOption == FORCE_EXIT_CMD){
		m_cboModeState.AddString(RES_STRING(IDS_ON));
		m_cboModeState.AddString(RES_STRING(IDS_END_OFF_GRACE));
		m_cboModeState.AddString(RES_STRING(IDS_END_ON_GRACE));
		m_cboModeState.AddString(RES_STRING(IDS_MANDATORY_ON));
	}
}
#pragma endregion

/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////
#pragma region CControllerTimezoneDlg class

CControllerTimezoneDlg::CControllerTimezoneDlg(CWnd* pParent) : 
	m_nSelected(0), CDialog(CControllerTimezoneDlg::IDD, pParent)
{
	m_strTimeZone = _T("");
}

void CControllerTimezoneDlg::DoDataExchange(CDataExchange *pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_CBO_TIMEZONE, m_cboTimezone);
}

BEGIN_MESSAGE_MAP(CControllerTimezoneDlg, CDialog)
	ON_CBN_SELCHANGE(IDC_CBO_TIMEZONE, OnSelchangeTimezone)
END_MESSAGE_MAP()

BOOL CControllerTimezoneDlg::OnInitDialog()
{
	CDialog::OnInitDialog();
	InitTimeZone(GetSafeHwnd(), IDC_CBO_TIMEZONE);
	m_cboTimezone.SetCurSel(0);
	m_cboTimezone.GetLBText(0, m_strTimeZone);
	return TRUE;
}

void CControllerTimezoneDlg::OnSelchangeTimezone()
{
	m_nSelected = m_cboTimezone.GetCurSel();
	m_cboTimezone.GetLBText(m_nSelected, m_strTimeZone);
}

int CControllerTimezoneDlg::GetTimeZone()
{
	return m_nSelected;
}

BOOL CControllerTimezoneDlg::GetTimeZoneString(LPTSTR szTimeZone)
{
	if(m_strTimeZone.GetLength() == 0)
		return FALSE;
	_stprintf(szTimeZone, _T("%s"), (LPCTSTR)m_strTimeZone);
	return TRUE;
}

#pragma endregion

/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////
#pragma region CKeypadMessageDlg class

CKeypadMessageDlg::CKeypadMessageDlg(CWnd* pParent)
	: m_nKeypadNumber(0), CDialog(CKeypadMessageDlg::IDD, pParent)
{
	memset(m_strKeypadMessage, 0, sizeof(m_strKeypadMessage));
}

CKeypadMessageDlg::~CKeypadMessageDlg()
{
}

void CKeypadMessageDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CKeypadMessageDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CKeypadMessageDlg, CDialog)
	//{{AFX_MSG_MAP(CKeypadMessageDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


BOOL CKeypadMessageDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();

	SendDlgItemMessage(IDC_TXT_KEYPAD_NUMBER, EM_SETLIMITTEXT, 2, 0);
	SendDlgItemMessage(IDC_TXT_KEYPAD_MESSAGE, EM_SETLIMITTEXT, 40, 0);
	SetDlgItemText(IDC_TXT_KEYPAD_NUMBER, _T("1"));
	GetDlgItem(IDC_TXT_KEYPAD_MESSAGE)->SetFocus();
	CenterWindow();

	return TRUE;
}


void CKeypadMessageDlg::OnOK()
{
	m_nKeypadNumber = (BYTE)GetDlgItemInt(IDC_TXT_KEYPAD_NUMBER);
	::GetDlgItemTextA(GetSafeHwnd(), IDC_TXT_KEYPAD_MESSAGE, m_strKeypadMessage, KPD_MSG_LEN+1);

	EndDialog(TRUE);
}
#pragma endregion

/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////
#pragma region CRtuUserDefinedCmdDlg class

CRtuUserDefinedCmdDlg::CRtuUserDefinedCmdDlg(int nRtuNumber, CWnd* pParent)
	: m_nRtuNumber(nRtuNumber), CDialog(CRtuUserDefinedCmdDlg::IDD, pParent)
{
	memset(m_data, 0, sizeof(m_data));
}

CRtuUserDefinedCmdDlg::~CRtuUserDefinedCmdDlg()
{
}

void CRtuUserDefinedCmdDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CRtuUserDefinedCmdDlg)
	DDX_Control(pDX, IDC_CBO_AVAIL_CMD, m_cboAvailableCommand);
	DDX_Control(pDX, IDC_BTN_SAVE, m_btnSave);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CRtuUserDefinedCmdDlg, CDialog)
	//{{AFX_MSG_MAP(CRtuUserDefinedCmdDlg)
	ON_WM_DESTROY()
	ON_WM_CLOSE()
	ON_BN_CLICKED(IDOK, OnBtnSend)
	ON_BN_CLICKED(IDC_BTN_SAVE, OnBtnSave)
	ON_CBN_SELCHANGE(IDC_CBO_AVAIL_CMD, OnSelChangedCommand)
	ON_COMMAND(ID__SAVE, OnSaveCommand)
	ON_COMMAND(ID__DELETE, OnDeleteCommand)
	ON_CBN_EDITCHANGE(IDC_CBO_AVAIL_CMD, OnEditChangeAvailableCommand)
	ON_EN_CHANGE(IDC_TXT_FC, OnEditChangeFunctionCode)
	ON_EN_CHANGE(IDC_TXT_CMD_DATA, OnEditChangeCommandData)

	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

void CRtuUserDefinedCmdDlg::OnClose()
{

	::SendMessage(Globals->hSysWnd, WM_GMS, IDM_DLGCLOSE, UDC_DLG);
	
	EndDialog(TRUE);
}

void CRtuUserDefinedCmdDlg::OnDestroy()
{
	//::SendMessage(Globals->hSysWnd, WM_GMS, IDM_UPDATE, MAKELONG(m_hWnd,UCMD_WIN));	
		if (::IsIconic(m_hWnd) == FALSE && ::IsMaximized(m_hWnd) == FALSE)
	{
		WINPOS wp;
		wp.hWnd = m_hWnd;
		wp.idx = CA_WIN;
		::SendMessage(Globals->hSysWnd, WM_GMS, IDM_UPDATE, (LPARAM)&wp);
	}
}

BOOL CRtuUserDefinedCmdDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();

	FillAvailableCommand();

	GetDlgItem(IDC_BTN_SAVE)->EnableWindow(FALSE);
	GetDlgItem(IDOK)->EnableWindow(FALSE);

	CenterWindow();

	return TRUE;
}

void CRtuUserDefinedCmdDlg::SendCommand(HWND hDlg, int nRtuNumber, BYTE nFunctionCode, CString strData)
{
	if (!CheckDLPriv(A_USER_CMDS))
    	return;

	BYTE data[264];
	memset(data, 0, sizeof(data));
	data[1] = nFunctionCode;
	int idx = FormatCommandData(strData.GetBuffer(strData.GetLength()), &data[5]);
	data[0] = (BYTE)(idx + 5);

	RtuLib::SendPcpCommand(hDlg, nRtuNumber - 1, data);
}

void CRtuUserDefinedCmdDlg::OnBtnSend()
{
	TCHAR 	str[262];
	GetDlgItemText(IDC_TXT_CMD_DATA, str, 260);
	CRtuUserDefinedCmdDlg::SendCommand(m_hWnd, m_nRtuNumber, (BYTE)GetDlgItemInt(IDC_TXT_FC), str);
}

void CRtuUserDefinedCmdDlg::EnableSendCommand()
{
	BOOL bEnable = TRUE;
	CString str = _T("");
	GetDlgItemText(IDC_TXT_CMD_DATA, str);
	if(str == _T("")) {
		bEnable = FALSE;
	}
	GetDlgItemText(IDC_TXT_FC, str);
	if(str == _T("")) {
		bEnable = FALSE;
	}
	
	GetDlgItem(IDOK)->EnableWindow(bEnable);

	GetDlgItemText(IDC_CBO_AVAIL_CMD, str);
	if(str != _T("")) {
		GetDlgItem(IDC_BTN_SAVE)->EnableWindow(TRUE);
	}
}

void CRtuUserDefinedCmdDlg::OnEditChangeFunctionCode()
{
	EnableSendCommand();
}

void CRtuUserDefinedCmdDlg::OnEditChangeCommandData()
{
	EnableSendCommand();
}

void CRtuUserDefinedCmdDlg::OnEditChangeAvailableCommand()
{
	BOOL bEnable = TRUE;
	CString str = _T("");
	GetDlgItemText(IDC_CBO_AVAIL_CMD, str);
	if(str == _T("")) {
		bEnable = FALSE;
	}
	GetDlgItemText(IDC_TXT_CMD_DATA, str);
	if(str == _T("")) {
		bEnable = FALSE;
	}
	GetDlgItemText(IDC_TXT_FC, str);
	if(str == _T("")) {
		bEnable = FALSE;
	}
	
	GetDlgItem(IDC_BTN_SAVE)->EnableWindow(bEnable);
}

void CRtuUserDefinedCmdDlg::OnSaveCommand()
{
	TCHAR 	str[262], str1[32];

	TCHAR text[240];
	if (!GetDlgItemText(IDC_CBO_AVAIL_CMD, str1, 32)) {
		wMessageBox1(m_hWnd, IDS_RTU_TEXT_REQUIRED, 0, MB_OK|MB_ICONINFORMATION);
		return;
	}
		
	if(m_cboAvailableCommand.FindStringExact(0, str1) == CB_ERR)
		m_cboAvailableCommand.AddString(str1);

	GetDlgItemText(IDC_TXT_CMD_DATA, text, 220);
	wsprintf(str, _T("8, %u, %c, %u, 0, (%s)"), m_nRtuNumber, _T('A'), GetDlgItemInt(IDC_TXT_FC), text);

	WritePrivateProfileString(_T("User Commands"), str1, str, DefaultLocation(USERCMD_CFG_FILE).Path);	
}

void CRtuUserDefinedCmdDlg::OnDeleteCommand()
{
	int nIndex = m_cboAvailableCommand.GetCurSel();
	if(nIndex < 0) {
		return;
	}
	
	CString strCommand;
	m_cboAvailableCommand.GetLBText(nIndex, strCommand);
	CStringArray strArrCommands;
	
	TCHAR str[256] = { 0 };
	BOOL bDelete = FALSE;
	if(RtuLib::GetFileStrings(DefaultLocation(USERCMD_CFG_FILE).Path, strArrCommands)) {
		for(int i=0; i<strArrCommands.GetCount(); i++) {
			_stprintf_s(str, _T("%s"), (LPCTSTR)strArrCommands.GetAt(i));
			UINT fc, etype, eno, fn=0; 
			TCHAR text[240]={0}, name[64]={0}, port=0;
			if(sscanfx(str, _T("%[^'=']=%u, %u, %c, %u, %u, (%[^')']"), name, &etype, &eno, &port, &fc, &fn, text)) {}
			if(strCommand == name) {
				strArrCommands.RemoveAt(i);
				bDelete = TRUE;
				break;
			}

		}
	}
	
	if(bDelete)
	{
		RtuLib::WriteFileStrings(DefaultLocation(USERCMD_CFG_FILE).Path, strArrCommands, false /*MZ I'm not sure if Unicode is supported for user-defined commands*/, -1 /*no numbering*/);
		m_cboAvailableCommand.DeleteString(nIndex);

		SetDlgItemText(IDC_TXT_CMD_DATA, _T(""));
		SetDlgItemText(IDC_TXT_FC, _T(""));
		GetDlgItem(IDC_BTN_SAVE)->EnableWindow(FALSE);
	}
}

void CRtuUserDefinedCmdDlg::OnBtnSave()
{
	CString strCommandName = _T("");
	GetDlgItemText(IDC_CBO_AVAIL_CMD, strCommandName);
	if(strCommandName == _T(""))
		return;

	CRect rc; GetDlgItem(IDC_BTN_SAVE)->GetWindowRect(&rc);
	HMENU hPopupMenu = LoadMenu(hrInst, MAKEINTRESOURCE(IDR_USER_DEFINED_CMD_MENU));
	HMENU hPopupMenuTrack = GetSubMenu(hPopupMenu, 0);
	TrackPopupMenu(hPopupMenuTrack, TPM_LEFTALIGN | TPM_LEFTBUTTON, rc.right, rc.top, 0, GetSafeHwnd(), NULL);
	DestroyMenu(hPopupMenu);
}

void CRtuUserDefinedCmdDlg::DeleteCommand()
{
	
}

void CRtuUserDefinedCmdDlg::OnSelChangedCommand()
{
	TCHAR 	str[262], str1[32];
	UINT fc, etype, eno, fn=0;
	TCHAR text[240], port=0;

	int i = m_cboAvailableCommand.GetCurSel();
	m_cboAvailableCommand.GetLBText(i, str1);
	if (GetPrivateProfileString(_T("User Commands"), str1, NULL, str, 260, DefaultLocation(USERCMD_CFG_FILE).Path))
	{
		if (sscanfx(str, _T("%u, %u, %c, %u, %u, (%[^')']"), &etype, &eno, &port, &fc, 	&fn, text) >= 6)
		{
			SetDlgItemInt(IDC_TXT_FC, fc, 0);
			SetDlgItemText(IDC_TXT_CMD_DATA, text);
		}
	}

	GetDlgItem(IDC_BTN_SAVE)->EnableWindow(TRUE);
	GetDlgItem(IDOK)->EnableWindow(TRUE);
}

void CRtuUserDefinedCmdDlg::FillAvailableCommand()
{
	int 	idx=-1, i, j, cp;
	TCHAR 	str[262];
	TCHAR   strLastCommand[100];
	LPTSTR 	p1;

	CMyFile file;
	m_cboAvailableCommand.ResetContent();

	if (file.Open(DefaultLocation(USERCMD_CFG_FILE), FILE_READ|FILE_DENYNONE, 0)) {
	    file.IsUnicodeFile();
		j = 0;								//.SECTION index
		idx = -1;
		_stprintf(strLastCommand, _T("%s"), RES_STRING(IDS_LAST_COMMAND));
		while (1 ) {
			if ((i = file.GetFileString(str, 260)) > 0) {
				if (str[0] == _T('['))		//.Is it string header?
					continue;

				UINT fc, etype, eno, fn=0; TCHAR text[240], name[64], port=0;
				if(sscanfx(str, _T("%[^'=']=%u, %u, %c, %u, %u, (%[^')']"), name, &etype, &eno, &port, &fc, &fn, text)){}

				if ((p1 = lstrchr(str, _T('='))) != NULL) {
					*p1 = _T('\0');
					if(etype == 8) {
						cp = m_cboAvailableCommand.AddString(str); 
						if (!lstrcmp(str, strLastCommand))
							idx = cp;
					}
					j++;
				}
			}
			else if (i==-1)
				break;			//.End of file
		}
		file.Close();
	}

	if (idx >= 0) {
		m_cboAvailableCommand.SetCurSel(idx);
		OnSelChangedCommand();
	}
	
	::SendMessage(Globals->hSysWnd, WM_GMS, IDM_SETWINPOS, MAKELONG(m_hWnd, UCMD_WIN));

}
#pragma endregion

/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////
#pragma region CReaderCommandDlg class

CReaderCommandDlg::CReaderCommandDlg(int nRtuNumber, CWnd* pParent)
	: m_nRtuNumber(nRtuNumber), CDialog(CReaderCommandDlg::IDD, pParent)
{
	memset(m_data, 0, sizeof(m_data));
	m_nByteCount = 0;
	m_nFlags = 0;
}

CReaderCommandDlg::~CReaderCommandDlg()
{
}

void CReaderCommandDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CReaderCommandDlg)
	DDX_Control(pDX, IDC_CBO_CMD_TYPE, m_cboCmdType);
	DDX_Control(pDX, IDC_TXT_RDR_NUM, m_txtReaderNumber);
	DDX_Control(pDX, IDC_TXT_TIME, m_txtTime);
	DDX_Control(pDX, IDC_TXT_SECURITY_LEVEL, m_txtSecurityLevel);
	DDX_Control(pDX, IDC_CBO_PIN_OVERRIDE, m_cboPinOverride);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CReaderCommandDlg, CDialog)
	//{{AFX_MSG_MAP(CReaderCommandDlg)
	ON_BN_CLICKED(IDOK, OnOK)
	ON_CBN_SELCHANGE(IDC_CBO_CMD_TYPE, OnSelChangedCommandType)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


BOOL CReaderCommandDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();

	int nIndex = 0;
	for(int i=0; i<39; i++) {
		if(i == 11 || i == 12 || i == 17)
			continue;
		m_cboCmdType.AddString(RES_STRING(IDS_LOCK_READER + i));
		m_cboCmdType.SetItemData(nIndex++, i);
	}

	m_cboCmdType.SetCurSel(0);

	m_txtReaderNumber.SetMinMaxLimit(1, 256, 3);
	m_txtTime.SetMinMaxLimit(1, 256, 3);
	m_txtSecurityLevel.SetMinMaxLimit(0, 255, 3);

	OnSelChangedCommandType();

	for(int i=0; i<6; i++) {
		m_cboPinOverride.AddString(RES_STRING(IDS_PIN_OVERRIDE + i));
	}
	m_cboPinOverride.SetCurSel(0);

	CenterWindow();

	return TRUE;
}

void CReaderCommandDlg::OnOK()
{
	memset(m_data, 0, sizeof(m_data));
	int n1 = GetDlgItemInt(IDC_TXT_RDR_NUM);
	if(m_nFlags != E_TIME_LO_HI) {
		n1 -= 1;
	}
	int n2 = GetDlgItemInt(IDC_TXT_TIME);
	if(m_nFlags == E_AREA_RANGE || m_nFlags == E_AREA_RANGE_EXTRA) {
		n2 -= 1;
	}

	m_data[1] = (BYTE)m_cboCmdType.GetItemData(m_cboCmdType.GetCurSel());
	m_data[2] = (BYTE)n1;
	m_data[3] = (BYTE)n2;
	if((m_nFlags == E_TIME_INC_MIN_CHK) && (IsDlgButtonChecked(IDC_RAD_MINUTES)))
		m_data[3] |= (BYTE)(0x80);
	m_nByteCount = 3;
	if(m_nFlags == E_AREA_RANGE_EXTRA) {
		m_data[4] = (BYTE)GetDlgItemInt(IDC_TXT_SECURITY_LEVEL);
		m_nByteCount += 1;
	}
	else if(m_nFlags == E_PIN_OVERRIDE) {
		int nPinOp = m_cboPinOverride.GetCurSel();
		if(IsDlgButtonChecked(IDC_CHK_ALLOW_OUTSIDE_TIME_MODE)) {
			nPinOp |= 0x08;
		}
		m_data[3] = (BYTE)(nPinOp);
	}
	else if(m_nFlags == E_TIME_LO_HI) {
		m_data[2] = 0xff;		// all reader
		m_data[4] = (BYTE)(n2 >> 8);
		m_nByteCount = 4;
	}

	m_data[0] = (BYTE)m_nByteCount;
	SendSystemCmd(m_nRtuNumber-1, 36, m_data, 1, NULL);


	//EndDialog(TRUE);
}

void CReaderCommandDlg::OnSelChangedCommandType()
{
	int nIndex = m_cboCmdType.GetCurSel();
	int nItem = m_cboCmdType.GetItemData(nIndex);
	int nFlag = 0;
	CString s1 = _T("Reader Number: ");
	CString s2 = _T("");

	SetDlgItemInt(IDC_TXT_RDR_NUM, 1);
	SetDlgItemInt(IDC_TXT_TIME, 1);
	SetDlgItemInt(IDC_TXT_SECURITY_LEVEL, 0);

	switch(nItem) {
		case 0:
		case 1:
			s2 = _T("Time (0-255) <x Minutes>: ");
			m_txtTime.SetMinMaxLimit(0, 255, 3);
			nFlag = E_TIME_IN_MINUTE; break;
		case 2:
			s2 = _T("Time (0-255) <x Seconds>: ");
			m_txtTime.SetMinMaxLimit(0, 255, 3);
			nFlag = E_TIME_IN_SECOND; break;
		case 4:
		case 5:
		case 6:
		case 18:
		case 20:
		case 22:
		case 34:
			s2 = _T("Time (0-127): ");
			m_txtTime.SetMinMaxLimit(0, 127, 3);
			nFlag = E_TIME_INC_MIN_CHK; break;
		case 10:
			s1 = _T("From Area: ");
			s2 = _T("To Area: ");
			m_txtTime.SetMinMaxLimit(1, 256, 3);
			nFlag = E_AREA_RANGE; break;
		case 32:
			s1 = _T("Area Number: ");
			s2 = _T("Count To: ");
			m_txtTime.SetMinMaxLimit(1, 256, 3);
			nFlag = E_AREA_RANGE; break;
		case 11:
		case 12:
		case 17:
			s1 = _T("");
			s2 = _T("Time (0-65535) <x Seconds>: ");
			m_txtTime.SetMinMaxLimit(0, 65535, 5);
			nFlag = E_TIME_LO_HI; break;
		case 29:
			s1 = _T("From Area: ");
			s2 = _T("To Area: ");
			m_txtTime.SetMinMaxLimit(1, 256, 3);
			nFlag = E_AREA_RANGE_EXTRA; break;
			break;
		case 33:
			s2 = _T("PIN Operation: ");
			nFlag = E_PIN_OVERRIDE; break;
	}

	int ids[] = {IDC_LBL_READER, IDC_TXT_RDR_NUM, IDC_LBL_TIME, IDC_TXT_TIME, IDC_RAD_SECONDS, IDC_RAD_MINUTES, 
		IDC_LBL_SECURITY_LEVEL, IDC_TXT_SECURITY_LEVEL, IDC_CBO_PIN_OVERRIDE, IDC_CHK_ALLOW_OUTSIDE_TIME_MODE};
	for(int i=0; i<_countof(ids); i++) {
		GetDlgItem(ids[i])->ShowWindow(SW_HIDE);
	}

	SetDlgItemText(IDC_LBL_READER, s1);
	switch(nFlag) {
		case E_TIME_IN_MINUTE:
		case E_TIME_IN_SECOND:
			GetDlgItem(IDC_LBL_READER)->ShowWindow(SW_SHOW);
			GetDlgItem(IDC_TXT_RDR_NUM)->ShowWindow(SW_SHOW);
			GetDlgItem(IDC_LBL_TIME)->ShowWindow(SW_SHOW);
			GetDlgItem(IDC_TXT_TIME)->ShowWindow(SW_SHOW);
			SetDlgItemText(IDC_LBL_TIME, s2);
			break;
		case E_TIME_INC_MIN_CHK: 
			GetDlgItem(IDC_LBL_READER)->ShowWindow(SW_SHOW);
			GetDlgItem(IDC_TXT_RDR_NUM)->ShowWindow(SW_SHOW);
			GetDlgItem(IDC_LBL_TIME)->ShowWindow(SW_SHOW);
			GetDlgItem(IDC_TXT_TIME)->ShowWindow(SW_SHOW);
			GetDlgItem(IDC_RAD_SECONDS)->ShowWindow(SW_SHOW);
			GetDlgItem(IDC_RAD_MINUTES)->ShowWindow(SW_SHOW);
			CheckRadioButton(IDC_RAD_SECONDS, IDC_RAD_MINUTES, IDC_RAD_SECONDS);
			SetDlgItemText(IDC_LBL_TIME, s2);
			break;
		case E_AREA_RANGE: 
			GetDlgItem(IDC_LBL_READER)->ShowWindow(SW_SHOW);
			GetDlgItem(IDC_TXT_RDR_NUM)->ShowWindow(SW_SHOW);
			GetDlgItem(IDC_LBL_TIME)->ShowWindow(SW_SHOW);
			GetDlgItem(IDC_TXT_TIME)->ShowWindow(SW_SHOW);
			SetDlgItemText(IDC_LBL_TIME, s2);
			break;
		case E_TIME_LO_HI: 
			GetDlgItem(IDC_LBL_TIME)->ShowWindow(SW_SHOW);
			GetDlgItem(IDC_TXT_TIME)->ShowWindow(SW_SHOW);
			SetDlgItemText(IDC_LBL_TIME, s2);
			break;
		case E_AREA_RANGE_EXTRA: 
			GetDlgItem(IDC_LBL_READER)->ShowWindow(SW_SHOW);
			GetDlgItem(IDC_TXT_RDR_NUM)->ShowWindow(SW_SHOW);
			GetDlgItem(IDC_LBL_TIME)->ShowWindow(SW_SHOW);
			GetDlgItem(IDC_TXT_TIME)->ShowWindow(SW_SHOW);
			GetDlgItem(IDC_LBL_SECURITY_LEVEL)->ShowWindow(SW_SHOW);
			GetDlgItem(IDC_TXT_SECURITY_LEVEL)->ShowWindow(SW_SHOW);
			SetDlgItemText(IDC_LBL_TIME, s2);
			break;
		case E_PIN_OVERRIDE:
			GetDlgItem(IDC_LBL_READER)->ShowWindow(SW_SHOW);
			GetDlgItem(IDC_TXT_RDR_NUM)->ShowWindow(SW_SHOW);
			GetDlgItem(IDC_LBL_TIME)->ShowWindow(SW_SHOW);
			GetDlgItem(IDC_CBO_PIN_OVERRIDE)->ShowWindow(SW_SHOW);
			GetDlgItem(IDC_CHK_ALLOW_OUTSIDE_TIME_MODE)->ShowWindow(SW_SHOW);
			SetDlgItemText(IDC_LBL_TIME, s2);
		default:
			GetDlgItem(IDC_LBL_READER)->ShowWindow(SW_SHOW);
			GetDlgItem(IDC_TXT_RDR_NUM)->ShowWindow(SW_SHOW);
			break;
	}

	m_nFlags = nFlag;
}

CString CReaderCommandDlg::ToString()
{
	CString strResult;
	strResult.Format(_T("<%2X><%2X><%2X><%2X>"), m_data[0], m_data[1], m_data[2], m_data[3]);

	return strResult;
}
#pragma endregion

/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////
#pragma region CRtuSystemCommands class

CRtuSystemCommands::CRtuSystemCommands(CWnd* pParent)
{
	m_pParent = pParent;
	CString wnd_class_name = ::AfxRegisterWndClass(NULL);
	this->CreateEx(0, wnd_class_name, _T("CRtuSystemCommands"), 0, 0,
		0, 0, 0, HWND_MESSAGE, 0, 0);
	m_nRtuNumber = 0;
}
CRtuSystemCommands::~CRtuSystemCommands()
{
}

BEGIN_MESSAGE_MAP(CRtuSystemCommands, CWnd)
	ON_WM_DESTROY()
	ON_MESSAGE(WM_GMS, OnGms)
	ON_REGISTERED_MESSAGE(UWM_TEXT, OnTextMessage)
END_MESSAGE_MAP()

void CRtuSystemCommands::OnDestroy()
{
}

LRESULT CRtuSystemCommands::OnTextMessage(WPARAM wParam, LPARAM lParam)
{
	if(m_pParent) {
		m_pParent->SendMessage(UWM_TEXT, wParam, lParam);
	}
	return 0;
}

LRESULT CRtuSystemCommands::OnGms(WPARAM wParam, LPARAM lParam)
{
	HWND hDlg = GetSafeHwnd();
	UINT id = GET_WM_COMMAND_ID(wParam, lParam);

	switch(id) {
		case IDD_COMMOVR_ERROR:   
			break;
		case IDD_COMMOVR_DATA:
			DisCommMsg(GetSafeHwnd(), 0, 0, 0);
			if ((m_pps.Id==GET_TIMEZONE_CMD)) {
				if(AfxIsValidAddress((LPBYTE)lParam, SIZE_OF_TIMEZONE_DATA)) {
					ShowControllerTimeZone((LPBYTE)lParam);
				}
				break;
			}

			break;
		
		case IDD_HIRESP:
			DisCommMsg(hDlg, 0, 0, 0);
			if (m_pps.Id==SET_TIMEZONE_CMD) 
    			SendRTZBcastCmd2(m_nTimezone, m_strTimeZone, &m_pps);
			break;

		default:
			break;
	}
	
	SendMessage(UWM_TEXT, (WPARAM)_T(""));
	return(0);

}

void CRtuSystemCommands::CopyParam(LPPARMPROC lpps)
{
	memset(m_ppsData, 0, sizeof(m_ppsData));
	memcpy(&m_pps, lpps, sizeof(m_pps));
	if(lpps->lpData != NULL) {
		memcpy(m_ppsData, lpps->lpData, sizeof(m_ppsData));
	}

	m_pps.heDlg = this->m_hWnd;
	m_nRtuNumber = (m_pps.eType * 50) + m_pps.eNo + 1;
	//m_pps.hmDlg = this->m_hWnd;
}

void CRtuSystemCommands::GetControllerTimezone()
{
	//m_pps.CommsErr = 0;
	//m_pps.hEvent = m_pps.hMem = m_pps.lpProc = 0;
	//m_pps.Ret = 0;
	GetRtuTimeZone(&m_pps, 0);
}
void CRtuSystemCommands::ShowControllerTimeZone(LPBYTE pData)
{
	LPBYTE	p = pData;

	DisCommMsg(GetSafeHwnd(), 0, 0, 0);
	if(p == NULL)
		return;

	CString str1 = RES_STRING(rtu_gen_str);
	CString str; str.Format(str1, *p+1, *(p+3), *(p+2), *(p+5), *(p+4));

	int s1 = *(p+1);
	int h1 = (s1&0x7f)*30;
	int m1 = h1%60;
	h1 /= 60;
	if (s1&0x80) h1 = -h1;

	s1 = *(p+6);
	int h2 = (s1&0x7f)*30;
	int m2 = h2%60;
	h2 /= 60;
	if (s1&0x80) h2 = -h2;

	CString str2 = RES_STRING((rtu_gen_str+1));
	str1.Format(str2, h1, m1, h2, m2);
	str += str1;
	::MessageBox(m_pParent->GetSafeHwnd(), str, RES_STRING(IDS_RTU_TZ_DAT), MB_OK);
	SendMessage(UWM_TEXT, (WPARAM)_T(""));
}

void CRtuSystemCommands::SetControllerTimezone()
{
	CControllerTimezoneDlg dlg;
	if(dlg.DoModal() == IDOK) {
		m_nTimezone = dlg.GetTimeZone();
		if(dlg.GetTimeZoneString(m_strTimeZone)) {
			m_pps.heDlg = m_hWnd;
			send_rtu_cmd(&m_pps, SET_TIMEZONE_CMD, m_nTimezone, HIRESP, 0, FALSE, 0);
		}
	}
}
int CRtuSystemCommands::GetRtuSystemCommand(int nOption)
{
	int nCommand = 0;

	if(nOption == BATTERY_TEST_CMD)
		nCommand = BATTERY_TEST_CMD;
	else if(nOption == PROG_INOV_TX_CMD)
		nCommand = PROG_INOV_TX_CMD;
	else if(nOption == SHUTDOWN_HDD_CMD)
		nCommand = SHUTDOWN_HDD_CMD;
	else if(nOption == PACOM_VAULT_CTRL_CMD)
		nCommand = PACOM_VAULT_CTRL_CMD;
	else
		nCommand = rtu_command[nOption];
	return nCommand;
}

int CRtuSystemCommands::GetCommand(int nMenuOption)
{
	int nCommand = -1;
	
	switch(nMenuOption) {
		// Controller Commands...
		case ID_CONTROLLERCOMMANDS_DIALCONTROLLER:				nCommand = -1;	break;
		case ID_CONTROLLERCOMMANDS_FORCEOFFDIALUP:				nCommand = ForceOffDialupCMD;		break;
		case ID_CONTROLLERCOMMANDS_CHANGELINECARDCONNECTION: 	nCommand = ChangeLineConnectionCMD;	break;
		case ID_CONTROLLERCOMMANDS_GETCONTROLLERTIMEZONES: 		nCommand = RequestTimeZoneDataCMD;	break;
		case ID_CONTROLLERCOMMANDS_SETCONTROLLERTIMEZONE: 		nCommand = SetTimeZoneReferenceCMD;	break;
		case ID_CONTROLLERCOMMANDS_FORCECONTROLLEROFFLINE: 		nCommand = GoOfflineCMD;		break;
		case ID_CONTROLLERCOMMANDS_FORCECONTROLLERONLINE: 		nCommand = GoOnlineCMD;		break;
		//case ID_CONTROLLERCOMMANDS_WRITETOEEPROM: 				nCommand = WriteEEPROMParametersCMD;	break;
		case ID_WRITETOEEPROM_INTERNAL:							nCommand = WriteEEPROMParametersCMD;	break;
		case ID_WRITETOEEPROM_EXTERNAL:							nCommand = WriteEEPROMParametersCMD;	break;
		case ID_CONTROLLERCOMMANDS_SETLISTEN:					nCommand = DialoutCommandCMD;	break;
		case ID_CONTROLLERCOMMANDS_SETFACILITYCODE: 			nCommand = DownloadFacilityCMD;	break;
		case ID_CONTROLLERCOMMANDS_SHUTDOWNHARDDRIVE: 			nCommand = ShutdownWitnessHardDiskCMD;	break;
		
		// Mode Commands...
		case ID_MODECOMMANDS_DAYMODE:							nCommand = GotoDayModeCMD;		break; 
		case ID_MODECOMMANDS_NIGHTMODE:							nCommand = GotoNightModeCMD;		break; 
		case ID_MODECOMMANDS_RESTRICTEDMODE:					nCommand = ForceEntryModeCMD;		break; 
		case ID_MODECOMMANDS_ENTERMODE:							nCommand = ForceEntryModeCMD;		break; 
		case ID_MODECOMMANDS_EXITMODE:							nCommand = ForceExitModeCMD;		break; 

		// Keypad Commands...
		case ID_KEYPADCOMMANDS_ENABLEKEYPAD:					nCommand = ResetLockoutKeypadCMD;	break;
		case ID_KEYPADCOMMANDS_DISABLEKEYPAD:					nCommand = LockoutKeypadCMD;	break;
		case ID_KEYPADCOMMANDS_RESETKEYPADTOIDLE:				nCommand = ResetToIdleCMD;	break;
		case ID_CONTROLLERCOMMANDS_RESETPSPTOIDLE:				nCommand = ResetToIdleCMD;	break;

		// Error Statistics Commands...
		case ID_ERRORSTATISTICS_RESETALLERRORSTATISTICS:		nCommand = ResetAllPortErrorStatisticsCMD;		break;
		case ID_ERRORSTATISTICS_RESETALARMERRORSTATISTICS:		nCommand = ResetAlarmPanelErrorStatisticsCMD;	break; 
		case ID_ERRORSTATISTICS_RESETCOMMSERRORSTATISTICS:		nCommand = ResetPrimaryPortErrorStatisticsCMD;	break; 
		case ID_ERRORSTATISTICS_RESETDIALUPERRORSTATISTICS:		nCommand = ResetSecondaryTertiaryBackupPortErrorStatisticsCMD;	break; 

		// Test Commands...
		case ID_TEST_PERFORMDIALUPTEST:							nCommand = RequestDialupTestOnSecondAndTertiaryPortsCMD;	break; 
		case ID_TEST_PERFORMBATTERYTEST:						nCommand = RequestBatteryTestCMD;	break; 
		case ID_TEST_PERFORMSEISMICTEST:						nCommand = VaultControllerCommandCMD;	break; 
		case ID_TEST_PERFORMREMOTEMAINTENANCETEST:				nCommand = PerformPowerMonitorLoadTestCMD;	break;
		case ID_POWER_MONITOR_ALL:
		case ID_POWER_MONITOR_1:
		case ID_POWER_MONITOR_2:
		case ID_POWER_MONITOR_3:
		case ID_POWER_MONITOR_4:
																nCommand = PerformFirePowerBatteryTestCMD;	break;
		// Other Commands...
		case ID_COMMANDS_RESETALLALARMS:						nCommand = ResetLatchAlarmsCMD;	break;
		case ID_COMMANDS_RESESALLOUTPUTS:						nCommand = ResetLatchAlarmsCMD;	break;
		case ID_COMMANDS_SYSTEMRESET:							nCommand = ResetLatchAlarmsCMD;	break;
		case ID_COMMANDS_RESTOREINPUT:							nCommand = ResetInputCMD;	break;
		case ID_COMMANDS_ISOLATEINPUT:							nCommand = -1;	break;
		case ID_COMMANDS_DEISOLATEINPUT:						nCommand = -1;	break;
		case ID_COMMANDS_GROUPCOMMANDS:							nCommand = IsolateDeisolatePointsCMD; break;
		case ID_COMMANDS_RESTOREOUTPUT:							nCommand = -1;	break;
		case ID_COMMANDS_ISOLATEOUTPUT:							nCommand = -1;	break;
		case ID_COMMANDS_DEISOLATEOUTPUT:						nCommand = -1;	break;
		case ID_COMMANDS_OPENVAULT:								nCommand = -1;	break;
		case ID_COMMANDS_PROGRAMINOVONICSTRANSMITTER:			nCommand = -1;	break;
		case ID_COMMANDS_USERDEFINECOMMANDS:					nCommand = -1;	break;

		default: break;
	}

	return nCommand;
}

int CRtuSystemCommands::GetCommandOption(int nMenuOption)
{
	int nCommandOption = -1;
	
	switch(nMenuOption) {
		// Controller Commands...
		case ID_CONTROLLERCOMMANDS_DIALCONTROLLER:				nCommandOption = -1;	break;
		case ID_CONTROLLERCOMMANDS_FORCEOFFDIALUP:				nCommandOption = 6;		break;
		case ID_CONTROLLERCOMMANDS_CHANGELINECARDCONNECTION: 	nCommandOption = 24;	break;
		case ID_CONTROLLERCOMMANDS_GETCONTROLLERTIMEZONES: 		nCommandOption = 21;	break;
		case ID_CONTROLLERCOMMANDS_SETCONTROLLERTIMEZONE: 		nCommandOption = 22;	break;
		case ID_CONTROLLERCOMMANDS_FORCECONTROLLEROFFLINE: 		nCommandOption = 0;		break;
		case ID_CONTROLLERCOMMANDS_FORCECONTROLLERONLINE: 		nCommandOption = 1;		break;
		case ID_CONTROLLERCOMMANDS_WRITETOEEPROM: 				nCommandOption = 23;	break;
		case ID_CONTROLLERCOMMANDS_SETLISTEN:					nCommandOption = 29;	break;
		case ID_CONTROLLERCOMMANDS_SETFACILITYCODE: 			nCommandOption = 28;	break;
		case ID_CONTROLLERCOMMANDS_SHUTDOWNHARDDRIVE: 			nCommandOption = 56;	break;
		
		// Mode Commands...
		case ID_MODECOMMANDS_DAYMODE:							nCommandOption = 2;		break; 
		case ID_MODECOMMANDS_NIGHTMODE:							nCommandOption = 3;		break; 
		case ID_MODECOMMANDS_RESTRICTEDMODE:					nCommandOption = 4;		break; 
		case ID_MODECOMMANDS_ENTERMODE:							nCommandOption = 4;		break; 
		case ID_MODECOMMANDS_EXITMODE:							nCommandOption = 5;		break; 

		// Keypad Commands...
		case ID_KEYPADCOMMANDS_ENABLEKEYPAD:					nCommandOption = 14;	break;
		case ID_KEYPADCOMMANDS_DISABLEKEYPAD:					nCommandOption = 13;	break;
		case ID_KEYPADCOMMANDS_RESETKEYPADTOIDLE:				nCommandOption = 15;	break;
		case ID_CONTROLLERCOMMANDS_RESETPSPTOIDLE:				nCommandOption = 15;	break;
		case ID_KEYPADCOMMANDS_DISPLAYKEYPADMESSAGE:			nCommandOption = -1;	break;
		case ID_KEYPADCOMMANDS_ISOLATEKEYPAD:					nCommandOption = -1;	break;
		case ID_KEYPADCOMMANDS_DEISOLATEKEYPAD:					nCommandOption = -1 ;	break;

		// Error Statistics Commands...
		case ID_ERRORSTATISTICS_RESETALLERRORSTATISTICS:		nCommandOption = 9;		break;
		case ID_ERRORSTATISTICS_RESETALARMERRORSTATISTICS:		nCommandOption = 10;	break; 
		case ID_ERRORSTATISTICS_RESETCOMMSERRORSTATISTICS:		nCommandOption = 11;	break; 
		case ID_ERRORSTATISTICS_RESETDIALUPERRORSTATISTICS:		nCommandOption = 12;	break; 

		// Test Commands...
		case ID_TEST_PERFORMDIALUPTEST:							nCommandOption = 26;	break; 
		case ID_TEST_PERFORMBATTERYTEST:						nCommandOption = 47;	break; 
		case ID_TEST_PERFORMSEISMICTEST:						nCommandOption = 61;	break; 
		case ID_TEST_PERFORMREMOTEMAINTENANCETEST:				nCommandOption = -1;	break; 

		// Other Commands...
		case ID_COMMANDS_RESETALLALARMS:						nCommandOption = -1;	break;
		case ID_COMMANDS_RESTOREINPUT:							nCommandOption = 16;	break;
		case ID_COMMANDS_ISOLATEINPUT:							nCommandOption = -1;	break;
		case ID_COMMANDS_DEISOLATEINPUT:						nCommandOption = -1;	break;
		case ID_COMMANDS_RESTOREOUTPUT:							nCommandOption = -1;	break;
		case ID_COMMANDS_ISOLATEOUTPUT:							nCommandOption = -1;	break;
		case ID_COMMANDS_DEISOLATEOUTPUT:						nCommandOption = -1;	break;
		case ID_COMMANDS_OPENVAULT:								nCommandOption = -1;	break;
		case ID_COMMANDS_PROGRAMINOVONICSTRANSMITTER:			nCommandOption = -1;	break;
		case ID_COMMANDS_USERDEFINECOMMANDS:					nCommandOption = -1;	break;

		default: break;
	}

	return nCommandOption;
}

void CRtuSystemCommands::ResetAllAlarms(int nRtuCommand, UINT dbyte)
{
	ulong areas = GetAreas();
	if(areas) {
		if (((areas == 0xff) && (GetNumAreas() != MAX_AREAS_32)) || (areas == 0xffffffff)) {
			m_pps.BC = (BYTE)dbyte;
			dbyte = 0xff;
			send_rtu_cmd(&m_pps, nRtuCommand, dbyte, HIRESP, 0, FALSE, 0);
		}
		else if (areas){
			BYTE areaNumber = 0;
			while(areas) {
				if(areas & 1) {
					m_pps.BC = (BYTE)dbyte;
					dbyte = areaNumber;
					send_rtu_cmd(&m_pps, nRtuCommand, dbyte, HIRESP, 0, FALSE, 0);

				}
				areas >>= 1;
				areaNumber++;
			}

		}
	}
}

void CRtuSystemCommands::ExecuteModeCommand(ulong nSelectedAreas, int nRtuCommand, UINT dbyte)
{
	if (((nSelectedAreas == 0xff) && (GetNumAreas() != MAX_AREAS_32)) || (nSelectedAreas == 0xffffffff))
	{
		m_pps.BC = 0xff;
		send_rtu_cmd(&m_pps, nRtuCommand, dbyte, HIRESP, 0, FALSE, 0);
	}
	else if (nSelectedAreas)
	{
		BYTE areaNumber = 0;
		while(nSelectedAreas)
		{
			if(nSelectedAreas & 1)
			{
				m_pps.BC = (BYTE)areaNumber;
				send_rtu_cmd(&m_pps, nRtuCommand, dbyte, HIRESP, 0, FALSE, 0);
			}
			nSelectedAreas >>= 1;
			areaNumber++;
		}

	}
}

ulong CRtuSystemCommands::GetAreas()
{
	ulong selectedAreas = 0;
	CSelectAreasDlg* pDlg = new CSelectAreasDlg();
	if(pDlg) { // Always evaluates to true
		if(pDlg->DoModal() == IDOK) {
			selectedAreas = pDlg->GetSelectedAreas();
		}		
		delete pDlg; pDlg = NULL;
	}

	return selectedAreas;
}

void CRtuSystemCommands::ChangeMode(int nRtuCommand)
{
	CSelectAreasDlg* pDlg = new CSelectAreasDlg(FALSE, FALSE, nRtuCommand);
	if(pDlg) { // Always evaluates to true
		if(pDlg->DoModal() == IDOK) {
			ulong selectedAreas = pDlg->GetSelectedAreas();
			ExecuteModeCommand(selectedAreas, nRtuCommand, 0);			
		}		
		delete pDlg; pDlg = NULL;
	}
}

void CRtuSystemCommands::ChangeMode2(int nRtuCommand, int nMode)
{
	HWND hDlg = GetSafeHwnd();
	CSelectAreasDlg* pDlg = new CSelectAreasDlg(nMode == -1 ? TRUE : FALSE, FALSE, nRtuCommand);
	if(pDlg) { // Always evaluates to true
		if(pDlg->DoModal() == IDOK) {
			ulong selectedAreas = pDlg->GetSelectedAreas();
			int dbyte = nMode;
			if(dbyte == -1) {
				nMode = pDlg->GetSelectedMode();
				dbyte = GetRtuMode(nMode);
				if(dbyte == -1) {
					delete pDlg; pDlg = NULL;
					return;
				}
			}

			dbyte = (nRtuCommand==FORCE_EXIT_CMD) ? ((dbyte==DAY_MODE) ? NIGHT_MODE :
					((dbyte==NIGHT_MODE) ? DAY_MODE : dbyte)) : dbyte;
			int id = (dbyte==DAY_MODE) ? PL_DAYMODECMD : (dbyte==NIGHT_MODE) ? 
								PL_NIGHTMODECMD : A_MODE_CMDS;

			if (!CheckAccess(id, EXEC_MODE, 1)) {
				delete pDlg; pDlg = NULL;
				return;
			}

			if (!::SendMessage(Globals->hSysWnd, WM_GMS, IDM_CHECKPIN, 1)) {
				delete pDlg; pDlg = NULL;
    			return;
			}

			if (selectedAreas == 0xff) {
				m_pps.BC = 0xff;
			}

			dbyte = GetRtuMode(nMode);
			if (dbyte==0xff) {		//.ATM Key command
				dbyte = ATM_MODE;
				m_pps.BC = 0xff;
			}
			else if (dbyte==SCHEDULE_OFF_MODE) {
				dbyte |= (pDlg->GetSelectedModeState() << 16);
				m_pps.BlkNo = 1;
				int i = pDlg->GetScheduleNumber();
				if (!i || i > 15) {
					DisplayError1(hDlg, WrongData, Globals->hInst);
					delete pDlg; pDlg = NULL;
					return;
				}
				i--;
				dbyte |= i<<8;
			}
			
			ExecuteModeCommand(selectedAreas, nRtuCommand, dbyte);
		}

		delete pDlg; pDlg = NULL;
	}
}

void CRtuSystemCommands::RestoreInput()
{
	int inputNumber = -1;
	if((inputNumber = RtuLib::GetInputNumber(IDS_INPUT_NUMBER)) != -1)
	{
		if(inputNumber)
		{
			send_rtu_cmd(&m_pps, ResetInputCMD, inputNumber-1, HIRESP, 0, FALSE, 0);	
		}
	}
}

void CRtuSystemCommands::Isolate_DeisolateGroupPoints()
{
	CSelectAreasDlg* pDlg = new CSelectAreasDlg(TRUE, TRUE, IsolateDeisolatePointsCMD, this);
	if(pDlg) { // Always evaluates to true
		if(pDlg->DoModal() == IDOK) {
			BYTE flag = pDlg->GetFlagByte();
			ulong areas = pDlg->GetSelectedAreas();
			BYTE pointType = pDlg->GetSelectedMode();
			UINT dbyte = flag | (pointType << 8);
			ExecuteModeCommand(areas, IsolateDeisolatePointsCMD, dbyte);
		}

		delete pDlg; pDlg = NULL;
	}
}

void CRtuSystemCommands::PutRtuOffline()
{
	if (!CheckAccess(A_MISC_CMDS, EXEC_MODE, 1)) 
		return;
	if (!::SendMessage(Globals->hSysWnd, WM_GMS, IDM_CHECKPIN, 1))
		return;

	int time = RtuLib::GetInputNumber(IDS_TIME_X_MINUTES);
	if(time < 0)
		return;

	m_pps.BC = 0xff;
	send_rtu_cmd(&m_pps, GoOfflineCMD, time, HIRESP, 0, FALSE, 0);
}

void CRtuSystemCommands::ExecuteSystemCommand(LPPARMPROC lpps, UINT nCommandID, int nDByte, int nMode)
{
	HWND hDlg = NULL;
	if(m_pParent) {
		//hDlg = m_pParent->GetSafeHwnd();
	}
	CopyParam(lpps);

	int nRtuCommand = GetCommand(nCommandID);
	m_pps.Id = (BYTE)nRtuCommand;

	UINT dbyte = 0;
	switch(nRtuCommand) {
		case ForceEntryModeCMD:
		case ForceExitModeCMD:
			ChangeMode2(nRtuCommand, nMode);
			break;

		case GotoDayModeCMD:
			if (!CheckAccess(PL_DAYMODECMD, EXEC_MODE, 1)) 
				break;
			ChangeMode(nRtuCommand);	
			break;

		case GotoNightModeCMD: 
			if (!CheckAccess(PL_NIGHTMODECMD, EXEC_MODE, 1)) 
				break;
			ChangeMode(nRtuCommand);
			break;

		case GoOfflineCMD:
			PutRtuOffline();
			break;

		case GoOnlineCMD:											// Force Controller Online
		case ForceOffDialupCMD:										// Force Off Dialup
		case ChangeLineConnectionCMD:								// Change Line Card Connection
		case LockoutKeypadCMD:										// Disable Keypad
		case ResetLockoutKeypadCMD:									// Enable Keypad
		case ResetToIdleCMD:										// Reset Keypad to Idle
		case ResetAllPortErrorStatisticsCMD:						// Reset All Error Statistics
		case ResetAlarmPanelErrorStatisticsCMD:						// Reset Alarm Error Statistics
		case ResetPrimaryPortErrorStatisticsCMD:					// Reset Comms Error Statistics
		case ResetSecondaryTertiaryBackupPortErrorStatisticsCMD:	// Reset Dialup Error Statistics
		case RequestDialupTestOnSecondAndTertiaryPortsCMD:			// Perform Dialup Test
		case PerformPowerMonitorLoadTestCMD:
			if((nRtuCommand == ForceOffDialupCMD) || (nRtuCommand == GoOnlineCMD)) {
				if (!CheckAccess(A_MISC_CMDS, EXEC_MODE, 1)) 
					break;
				if (!::SendMessage(Globals->hSysWnd, WM_GMS, IDM_CHECKPIN, 1))
					break;
			}
			
			lpps->BC = 0;
			send_rtu_cmd(lpps, nRtuCommand, dbyte, HIRESP, 0, FALSE, 0);
			break;
		case PerformFirePowerBatteryTestCMD:
			lpps->BC = 1;
			send_rtu_cmd(lpps, nRtuCommand, nDByte, HIRESP, 0, FALSE, 0);
			break;
		case RequestTimeZoneDataCMD:								//.Get current time zone
			m_pps.BC = 0;
			GetControllerTimezone();
			break;

		case SetTimeZoneReferenceCMD: 
			m_pps.BC = 0;
			SetControllerTimezone();
			break;
		case DownloadFacilityCMD: {
			TCHAR text[16]; memset(text, 0, sizeof(text));
		    BYTE  data[8];
			TCHAR strFacilityCode[256]; _stprintf(strFacilityCode, _T("%s"), RES_STRING(IDS_ENT_FACILITY_CODE));
			int c1;
			if (GetAString(hDlg, 5, strFacilityCode, text)) {
				if ((c1 = xtoi(text)) > 999) {
				    DisplayError1(hDlg, WrongData, NULL);
    				break;
	    		}
	    		data[0] = DOWN_FACILITY_CMD;
				for (int i=0; i<3; i++) {
		    		data[1+i] = (BYTE)(text[i]-_T('0'));
				}
			    m_pps.lpData = data;
			    m_pps.BC = 4;
				send_rtu_cmd1(&m_pps, HIRESP, 0, 0);
				}
			}
			break;
		case DialoutCommandCMD:
			EditListeninParms(hDlg, &m_pps);
			break;
		case  RequestBatteryTestCMD:	{
			CSysCmdSelectOptionDlg* pDlg = new CSysCmdSelectOptionDlg(nRtuCommand, this);
			if(pDlg) { // Always evaluates to true
				if(pDlg->DoModal() == IDOK) {
					DoBatteryTest(hDlg, m_nRtuNumber-1, pDlg->GetSelectedOption());	
				}
				delete pDlg; pDlg = NULL;
			}
			}
			break;

		case ResetLatchAlarmsCMD:
			ResetAllAlarms(nRtuCommand, nDByte);			
			break;

		case ResetInputCMD:
			RestoreInput();
			break;

		case IsolateDeisolatePointsCMD:
			Isolate_DeisolateGroupPoints();
			break;

		case WriteEEPROMParametersCMD:	//.Type of write command
			//dbyte = nDbyte;
			lpps->BC = 0;
			dbyte = (nCommandID == ID_WRITETOEEPROM_INTERNAL) ? 1 : 2;
			send_rtu_cmd(lpps, nRtuCommand, dbyte, HIRESP, 0, FALSE, 0);
			break;

		default:
			break;
	}

	if(m_pParent) {
		m_pParent->SendMessage(UWM_TEXT, (WPARAM)_T(""));
	}
}
#pragma endregion

/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////
#pragma region CRtuPortParamsConfig class
 
CRtuPortParamsConfig::CRtuPortParamsConfig(CWnd* pParent)
{
	m_nError = -1;
	m_rxState = 0;
	m_nOption = 0;
	m_nCommandID = 0;
	memset(m_ppsData, 0, sizeof(m_ppsData));
	m_pParent = pParent;
	CString wnd_class_name = ::AfxRegisterWndClass(NULL);
	this->CreateEx(0, wnd_class_name, _T("CRtuPortParamsConfig"), 0, 0,
		0, 0, 0, HWND_MESSAGE, 0, 0);
}
CRtuPortParamsConfig::~CRtuPortParamsConfig()
{	
}

BEGIN_MESSAGE_MAP(CRtuPortParamsConfig, CWnd)
	ON_WM_DESTROY()
	ON_MESSAGE(WM_GMS, OnGms)
	ON_REGISTERED_MESSAGE(UWM_TEXT, OnTextMessage)
END_MESSAGE_MAP()

void CRtuPortParamsConfig::OnDestroy()
{
}

LRESULT CRtuPortParamsConfig::OnTextMessage(WPARAM wParam, LPARAM lParam)
{
	if(m_pParent) {
		m_pParent->SendMessage(UWM_TEXT, wParam, lParam);
	}
	return 0;
}

LRESULT CRtuPortParamsConfig::OnGms(WPARAM wParam, LPARAM lParam)
{
	UINT id = GET_WM_COMMAND_ID(wParam, lParam);
	SendMessage(UWM_TEXT, (WPARAM)_T(""));

	switch(id) {
		case IDD_COMMOVR_ERROR:   
			break;
		case IDD_COMMOVR_CTRL_NUM:
			if(m_nError == E_PORT_ERROR) {
				ShowPortError();
			} else if(m_nError == E_PRIORITY_ERROR) {
				ShowPortPriorityError();
				m_nError = -1;
			}
			break;

		case IDD_COMMOVR_DATA: // TT 6842. IDD_COMMOVR_DATA should not be called anymore in this case. IDD_COMMOVR_DATA1 is used instead.
			if(m_nError == 0 && lParam != 0){
				ShowAdvancedPortConfig((LPBYTE)lParam);
			}
			break;
		case IDD_COMMOVR_DATA1: // the message is posted from CheckPcpRtuPort(), RTUCOMMS.CPP. LPARAM points to a buffer which contains entire LPPCPCMD->lpData. The buffer must be delete[]
			if(m_nError == 0 && lParam != 0){
				BYTE data[256];
				memcpy(data, (LPBYTE)lParam, 256);
				delete[] (LPBYTE)lParam;
				//ShowAdvancedPortConfig((LPBYTE)lParam);
				ShowAdvancedPortConfig(data+5);
			}
			break;
		
		case IDD_HIRESP:
			break;

		default:
			break;
	}
	
	return(0);

}

static int GetAccountNumberSize(LPPARMPROC lpps)
{
	const int CONTACT_ID = 2;

	SECONDARYPARM1 Param; memset(&Param, 0, sizeof(Param));
	memcpy(&Param.commsTel1En, &lpps->lpData[1], sizeof(Param));
	int rcode = 6;
	if(Param.commsTel1En == CONTACT_ID)
		rcode = 4;
	else if(Param.commsTel2En == CONTACT_ID)
		rcode = 4;
	else if(Param.alarmTel1En == CONTACT_ID)
		rcode = 4;
	else if(Param.alarmTel2En == CONTACT_ID)
		rcode = 4;
	else if(Param.disasterTel1En == CONTACT_ID)
		rcode = 4;
	else if(Param.disasterTel2En == CONTACT_ID)
		rcode = 4;

	return rcode;
}

void CRtuPortParamsConfig::ShowAdvancedPortConfig(LPBYTE pData)
{
	BYTE  BC = 0;
	BYTE FunctionCode = 0;
	BYTE temp = 0;

	if(m_pParent) {
		m_pParent->SendMessage(UWM_TEXT, (WPARAM)_T(""));
	}
	if(pData == NULL)
		return ;
	try {
		memcpy(m_ppsData, pData, sizeof(m_ppsData));
		m_pps.lpData = m_ppsData;
		BC = *(pData - 5);			//bytecount for protocol parameters.
		FunctionCode = *(pData - 4);
		temp = m_pps.lpData[0];
	} catch(...) {
	}

	if(m_rxState) {
		m_pps.BC = 2;
		m_pps.lpData[1] = 0;

		if(m_rxState == E_GET_PROT_STATE) {
			if(m_pps.lpData[4] == 28) {
				m_rxState = E_GET_ACC_NUM_SIZE_STATE;
				int nOption = 18;
				if(realRtuType == RTU_1058_TYPE)
					nOption = 19;
				m_pps.lpData[0] = (BYTE)(nOption + 3);
			}
			else {
				m_rxState = 0;
				nAccNumSize = 6;
				m_pps.lpData[0] = (BYTE)(PP_MESSAGE_FILTER_BLK);
			}
		}
		else if(m_rxState == E_GET_ACC_NUM_SIZE_STATE) {
			m_rxState = 0;
			nAccNumSize = GetAccountNumberSize(&m_pps);
			m_pps.lpData[0] = (BYTE)(PP_MESSAGE_FILTER_BLK);
		}
		
		get_rtuport_parms(&m_pps, 0, 0);
		return;
	}

	BC = (BYTE)(BC - 6);
	switch (temp) {
	case PP_PSP_BLK:
		ShowPSPParamsDlg(0, &m_pps, BC);
		break;
	case PP_GENERAL_SYSTEM_BLK:
		ShowGeneralParamsDlg(0, &m_pps, BC);
		break;
	case PP_TREND_BMS_BLK:
		ShowTrendBMSParamsDlg(0, &m_pps, BC);
		break;
	case PP_MODEM_STRING1_BLK:
		ShowModemParamsDlg(0, &m_pps, BC, m_nOption-3);
		break;
	case PP_MODEM_STRING2_BLK:
		ShowModemParamsDlg(0, &m_pps, BC, m_nOption-3);
		break;
	case PP_MESSAGE_FILTER_BLK:
		ShowMsgFilterParamsDlg(0, &m_pps, BC);						
		break;
	case PP_SNMP_BLK:
		ShowSNMPParamsDlg(0, &m_pps, BC);						
		break;
	case PP_PORT_PEER_BLK:
		if(m_nCommandID == ID_GENERAL_PEERTOPEERSETTINGS) {
			ShowPeerParams2Dlg(0, &m_pps, BC);			
		}
		else if(m_nCommandID == ID_GENERAL_TFTPSETTINGS) {
			ShowTFTPServerDlg(0, &m_pps, BC);
		}
		break;
	case PP_PASSWORD_BLK:
		ShowSystemPasswordsDlg(0, &m_pps, BC);						
		break;
	case PP_BATT_TEST_BLK:
		ShowSystemBatteryTestDlg(0, &m_pps, BC);						
		break;
	case PP_REMOTE_MAINT_DT_BLK:
		ShowRemoteMaintenanceDateTimeDlg(0, &m_pps, BC);						
		break;
	case PP_GPIP_PARAMS_BLK:
		ShowGPIPParamsDlg(0, &m_pps, BC);
		break;
	case PP_VAULT_CTRLS_BLK:
		ShowVaultControllerInterlocksDlg(0, &m_pps, BC);
		break;
	case PP_EMCS_PARAMS_BLK:
		ShowEMCSParamsDlg(0, &m_pps, BC);
		break;
	default:
		break;
	}

	m_nError = -1;
}

void CRtuPortParamsConfig::ShowPortError()
{
	TCHAR filename[MAX_PATH];
	 GetRtuParmFile(filename, ALM_ERR_FILE, MAKERTUNO(m_pps.eType, m_pps.eNo));
	BYTE BC = (BYTE)wFileRead(filename, m_pps.lpData+1, sizeof(m_ppsData));
	 

	ShowPortErrorDlg(NULL, &m_pps, BC-4);
	SendMessage(UWM_TEXT, (WPARAM)_T(""));
}

void CRtuPortParamsConfig::ShowPortPriorityError()
{
	TCHAR filename[MAX_PATH];
	 GetRtuParmFile(filename, ALM_ERR_FILE, MAKERTUNO(m_pps.eType, m_pps.eNo));
	
	BYTE pBuffer[RTU_BUFF_SIZE];
	memset(pBuffer, 0, sizeof(pBuffer));
	int BC = (BYTE)wFileRead(filename, pBuffer, sizeof(pBuffer));
	 

	if(BC) {
		CNetworkErrorDlg* pDlg = new CNetworkErrorDlg(&m_pps, pBuffer);
		if(pDlg) { // Always evaluates to true
			if(pDlg->DoModal() == IDOK) {
				//send_rtu_cmd(&m_pps, RESET_ERRS_CMD, m_pps.lpData[1], 0, 0);
			}
			delete pDlg; pDlg = NULL;
		}
	}
}

void CRtuPortParamsConfig::GetNetworkError(LPPARMPROC lpps)
{
	m_nError = E_PRIORITY_ERROR;
	memcpy(&m_pps, lpps, sizeof(m_pps));
	memcpy(m_ppsData, lpps->lpData, sizeof(m_ppsData));
	m_pps.lpData = m_ppsData;
	m_pps.heDlg = m_pps.hmDlg = GetSafeHwnd();	
	get_other_errs(&m_pps, 1, 0);
}

void CRtuPortParamsConfig::GetPortConfig(LPPARMPROC lpps, int nCommandID, int nOption, BOOL bError)
{
	TRACE2("CRtuPortParamsConfig::GetPortConfig(nCommandID=%d, nOption=%d)\n", nCommandID,nOption);
	m_nError = bError ? E_PORT_ERROR : 0;

	memcpy(&m_pps, lpps, sizeof(m_pps));
	memcpy(m_ppsData, lpps->lpData, sizeof(m_ppsData));
	m_pps.lpData = m_ppsData;
	m_pps.heDlg = m_pps.hmDlg = GetSafeHwnd();
	m_nOption = nOption;
	m_nCommandID = nCommandID;

	if(m_nError == E_PORT_ERROR) {
		m_pps.BlkNo = (BYTE)m_nOption;
		get_other_errs(&m_pps, 3, 0);
	}
	else {
		if(m_nOption == PP_MESSAGE_FILTER_BLK) {
			m_rxState = E_GET_PROT_STATE;
			m_pps.BC = 2;
			int nOption2 = 1;
			if(realRtuType == RTU_8001_TYPE)
				nOption2 = 0;
			m_pps.lpData[0] = (BYTE)(nOption2 + 3);
			m_pps.lpData[1] = 0;
			get_rtuport_parms(&m_pps, 0, 0);
		}
		else {
			m_rxState = 0;
			m_pps.BC = 6;
			m_pps.lpData[0] = (BYTE)nOption;
			m_pps.lpData[1] = 0;
			m_pps.lpData[5] = 1;
			get_rtuport_parms(&m_pps, 0, 0);
		}
	}
	
}
#pragma endregion

/////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////
#pragma region CControlPortErrors class

IMPLEMENT_XTP_CONTROL( CControlPortErrors, CXTPControlButton)
void CControlPortErrors::OnCalcDynamicSize(DWORD /*dwMode*/)
{
	if (GetParent()->GetType() !=xtpBarTypePopup)
		return;

	ASSERT(m_pControls->GetAt(m_nIndex) == this);

	while (m_nIndex + 1 < m_pControls->GetCount())
	{
		CXTPControl* pControl = m_pControls->GetAt(m_nIndex + 1);
		if (pControl->GetID() >= ID_VIEW_PORTERRORS_PORT1 && pControl->GetID() <= ID_VIEW_PORTERRORS_PORT12)
		{
			m_pControls->Remove(pControl);
		}
		else break;
	}

	m_dwHideFlags = 0;

	if (m_pParent->IsCustomizeMode())
		return;

	m_dwHideFlags |= xtpHideGeneric;

	CStringArray strArrPorts;
	GetRtuPortList(strArrPorts, realRtuType, IsRtu8002Type());
	int nCount = strArrPorts.GetSize();
	for (int i = 0; i < nCount; i++)
	{
		CXTPControl* pControl = m_pControls->Add(xtpControlButton, ID_VIEW_PORTERRORS_PORT1 + i, _T(""), m_nIndex + 1 + i, TRUE);
		pControl->SetCaption(strArrPorts.GetAt(i));
		pControl->SetFlags(xtpFlagManualUpdate);
		if (GetBeginGroup() && (i == 0))
			pControl->SetBeginGroup(TRUE);
	}

}

BOOL CControlPortErrors::IsCustomizeDragOverAvail(CXTPCommandBar* pCommandBar, CPoint /*point*/, DROPEFFECT& dropEffect)
{
	if (pCommandBar->GetType() != xtpBarTypePopup)
	{
		dropEffect = DROPEFFECT_NONE;
		return FALSE;
	}
	return TRUE;
}
#pragma endregion

/////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////
#pragma region CControlFirepowerBatteryTest class

IMPLEMENT_XTP_CONTROL( CControlFirepowerBatteryTest, CXTPControlButton)
void CControlFirepowerBatteryTest::OnCalcDynamicSize(DWORD /*dwMode*/)
{
	if (GetParent()->GetType() !=xtpBarTypePopup)
		return;

	ASSERT(m_pControls->GetAt(m_nIndex) == this);

	while (m_nIndex + 1 < m_pControls->GetCount())
	{
		CXTPControl* pControl = m_pControls->GetAt(m_nIndex + 1);
		if (pControl->GetID() >= ID_POWER_MONITOR_ALL && pControl->GetID() <= ID_POWER_MONITOR_4)
		{
			m_pControls->Remove(pControl);
		}
		else break;
	}

	m_dwHideFlags = 0;

	if (m_pParent->IsCustomizeMode())
		return;

	m_dwHideFlags |= xtpHideGeneric;

	CString strPowerMonitor = RES_STRING(IDS_POWER_MONITOR);
	for (int i = 0; i < 5; i++) {
		CString strTitle;
		if(i == 0)
			strTitle = RES_STRING(IDS_ALL_POWER_MONITORS);
		else
			strTitle.Format(_T("%s %d"), (LPCTSTR)strPowerMonitor, i);
		CXTPControl* pControl = m_pControls->Add(xtpControlButton, ID_POWER_MONITOR_ALL + i, _T(""), m_nIndex + 1 + i, TRUE);

		pControl->SetCaption(strTitle);
		pControl->SetFlags(xtpFlagManualUpdate);

		if (GetBeginGroup() && (i == 0))
			pControl->SetBeginGroup(TRUE);

	}
}

BOOL CControlFirepowerBatteryTest::IsCustomizeDragOverAvail(CXTPCommandBar* pCommandBar, CPoint /*point*/, DROPEFFECT& dropEffect)
{
	if (pCommandBar->GetType() != xtpBarTypePopup)
	{
		dropEffect = DROPEFFECT_NONE;
		return FALSE;
	}
	return TRUE;
}
#pragma endregion

/////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////
#pragma region CControlHardwareCommands class

IMPLEMENT_XTP_CONTROL( CControlHardwareCommands, CXTPControlButton)
void CControlHardwareCommands::OnCalcDynamicSize(DWORD /*dwMode*/)
{
	if (GetParent()->GetType() !=xtpBarTypePopup)
		return;

	ASSERT(m_pControls->GetAt(m_nIndex) == this);

	int nIDs[] = {
		ID_ALARM_HARDWARE,
		ID_ALARM_HARDWARE_ADDDEVICE,
		ID_ALARM_HARDWARE_ADDKEYPAD,   
		ID_ALARM_HARDWARE_IODEVICES,    
		ID_ALARM_HARDWARE_INPUTS,   
		ID_ALARM_HARDWARE_ANALOGINPUTS,
		ID_ALARM_HARDWARE_OUTPUTS,
		ID_ALARM_HARDWARE_FILMCAMERAS,
		ID_ALARM_HARDWARE_CCTVCAMERAS, 
		ID_ALARM_HARDWARE_PULSECOUNTERS,
		ID_ALARM_HARDWARE_KEYPADS,
		ID_HARDWARE_VAULT_CONTROLLER,
	};

	int i=0;
	while (m_nIndex + 1 < m_pControls->GetCount())
	{
		CXTPControl* pControl = m_pControls->GetAt(m_nIndex + 1);
		if ((pControl->GetID() >= nIDs[i]))
		{
			m_pControls->Remove(pControl);
		}
		else break;
		i++;
	}

	m_dwHideFlags = 0;

	if (m_pParent->IsCustomizeMode())
		return;

	m_dwHideFlags |= xtpHideGeneric;

	CStringArray strArr;
	for(i=0; i<12; i++) {
		strArr.Add(RES_STRING(IDS_HARDWARE + i));
	}

	if(!bAlarmHardwareUploaded) {
		CXTPControl* pControl = m_pControls->Add(xtpControlButton, ID_ALARM_HARDWARE, _T(""), m_nIndex + 1, TRUE);
		pControl->SetCaption(strArr.GetAt(0));
		pControl->SetFlags(xtpFlagManualUpdate);
		if (GetBeginGroup())
			pControl->SetBeginGroup(TRUE);

		// Adding vault controller
		pControl = m_pControls->Add(xtpControlButton, ID_HARDWARE_VAULT_CONTROLLER, _T(""), m_nIndex + 2, TRUE);
		pControl->SetCaption(strArr.GetAt(11));
		pControl->SetFlags(xtpFlagManualUpdate);
		pControl->SetBeginGroup(TRUE);
	}
	else {
		int nCount = strArr.GetSize();
		for (i = 0; i < nCount; i++)
		{
			int nID = nIDs[i];
			CXTPControl* pControl = m_pControls->Add(xtpControlButton, nID, _T(""), m_nIndex + 1 + i, TRUE);

			pControl->SetCaption(strArr.GetAt(i));
			pControl->SetFlags(xtpFlagManualUpdate);

			if (GetBeginGroup() && (i == 0))
				pControl->SetBeginGroup(TRUE);
			else if(nID == ID_ALARM_HARDWARE_ADDDEVICE || 
				nID == ID_ALARM_HARDWARE_IODEVICES || 
				nID == ID_ALARM_HARDWARE_KEYPADS ||
				nID == ID_HARDWARE_VAULT_CONTROLLER)
				pControl->SetBeginGroup(TRUE);
		}
	}
}

BOOL CControlHardwareCommands::IsCustomizeDragOverAvail(CXTPCommandBar* pCommandBar, CPoint /*point*/, DROPEFFECT& dropEffect)
{
	if (pCommandBar->GetType() != xtpBarTypePopup)
	{
		dropEffect = DROPEFFECT_NONE;
		return FALSE;
	}
	return TRUE;
}
#pragma endregion

/////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////
#pragma region CControlUserDefinedCommands class

void GetUserDefinedCommands(UINT nRtuNumber, CStringArray& strArrCommands)
{
	int 	idx=-1, i, j, cp;
	TCHAR 	str[262];
	LPTSTR 	p1;

	CMyFile file;
	
	if (file.Open(DefaultLocation(USERCMD_CFG_FILE), FILE_READ|FILE_DENYNONE, 0)) {
	    file.IsUnicodeFile();
		j = 0;								//.SECTION index
		idx = -1;
		while (1 ) {
			if ((i = file.GetFileString(str, 260)) > 0) {
				if (str[0] == _T('['))		//.Is it string header?
					continue;

				UINT fc, etype = 0, eno, fn = 0; TCHAR text[240], name[64], port{};
				if (sscanfx(str, _T("%[^'=']=%u, %u, %c, %u, %u, (%[^')']"), name, &etype, &eno, &port, &fc, &fn, text)) {}

				if ((p1 = lstrchr(str, _T('='))) != NULL) {
					*p1 = _T('\0');
					if( (etype == 8) && (eno == nRtuNumber) ) {
						cp = strArrCommands.Add(str); 
						if (!lstrcmp(str, RES_STRING(IDS_LAST_COMMAND)))
							idx = cp;
					}
					j++;
				}
			}
			else if (i==-1)
				break;			//.End of file
		}
		file.Close();
	}

}

IMPLEMENT_XTP_CONTROL( CControlUserDefinedCommands, CXTPControlButton)
void CControlUserDefinedCommands::OnCalcDynamicSize(DWORD /*dwMode*/)
{
	if (GetParent()->GetType() !=xtpBarTypePopup)
		return;

	ASSERT(m_pControls->GetAt(m_nIndex) == this);

	while (m_nIndex + 1 < m_pControls->GetCount())
	{
		CXTPControl* pControl = m_pControls->GetAt(m_nIndex + 1);
		if (pControl->GetID() >= ID_USER_DEFINED_COMMAND_1 && pControl->GetID() <= ID_USER_DEFINED_COMMAND_1 + 100)
		{
			m_pControls->Remove(pControl);
		}
		else break;
	}

	m_dwHideFlags = 0;

	if (m_pParent->IsCustomizeMode())
		return;

	m_dwHideFlags |= xtpHideGeneric;

	strArrUserDefinedCommands.RemoveAll();
	GetUserDefinedCommands(gRtuNo+1, strArrUserDefinedCommands);
	int nCount = strArrUserDefinedCommands.GetSize();
	for (int i = 0; i < nCount; i++)
	{
		CXTPControl* pControl = m_pControls->Add(xtpControlButton, ID_USER_DEFINED_COMMAND_1 + i, _T(""), m_nIndex + 1 + i, TRUE);
		pControl->SetCaption(strArrUserDefinedCommands.GetAt(i));
		pControl->SetFlags(xtpFlagManualUpdate);
		if (GetBeginGroup() && (i == 0))
			pControl->SetBeginGroup(TRUE);
	}

}

BOOL CControlUserDefinedCommands::IsCustomizeDragOverAvail(CXTPCommandBar* pCommandBar, CPoint /*point*/, DROPEFFECT& dropEffect)
{
	if (pCommandBar->GetType() != xtpBarTypePopup)
	{
		dropEffect = DROPEFFECT_NONE;
		return FALSE;
	}
	return TRUE;
}
#pragma endregion

/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////
// CRtuCtrlCfgDlg dialog

CRtuCtrlCfgDlg::CRtuCtrlCfgDlg(SETUPPARM* lpSetupParam, HWND hpWnd, CWnd* pParent /*=NULL*/)
	: CRtuCtrlCfgDlgBase(CRtuCtrlCfgDlg::IDD, pParent)
{
	m_hpWnd = hpWnd;
	m_rcBorders.SetRectEmpty();
	m_bInRepositionControls = FALSE;
	m_bInitDone = FALSE;
	m_bIsValidAlarmCfg = FALSE;
	m_nCommandID = 0;
	m_nPanelType = 0;
	m_nPrintCfg = 0;
	m_lpps = NULL;
	memset(&m_lpps2, 0, sizeof(m_lpps2));
	memset(m_lpps2Data, 0, sizeof(m_lpps2Data));
	memset(m_ppsBmsData, 0, sizeof(m_ppsBmsData));
	memset(&m_rtups, 0, sizeof(m_rtups));
	m_pSystemCommandsObj = NULL;
	m_pPortParamObj = NULL;
	m_bRequestGenBmsCfg = FALSE;
	rtuSetup = *((SETUPPARM*)lpSetupParam); // local setup parameters for download & upload
	m_pRtuTemplate = NULL;
	m_bRtuStatus = FALSE;
	bAlarmHardwareUploaded = FALSE;
	m_bWaitDownload = FALSE;
	m_bReqChangeID = FALSE;
	m_pDownloadMenu = NULL;
	bResetSoftwareRequest = FALSE;
	m_lpaps = NULL;
	m_nCurStatus = 0;
	m_pCboView = NULL;
	m_bConfigDownloading = FALSE;
	m_bReqCloseWindow = FALSE;
	m_bStatusPrivilege = FALSE;

	m_bCustomVocabUploadSent = FALSE; // TT#5950

	m_nReqRtuNumber = 0;
	m_nRtuNumber = 0;
	m_rtuno = 0;
	m_bCommovr = 0;

	m_pMaskedStatusMenu = NULL;
	m_pUnmaskedStatusMenu = NULL;
	m_pHardDrivePrimaryMenu = NULL;
	m_pHardDriveSecondaryMenu = NULL;
	m_pHardDriveFlashMenu = NULL;
	m_pBmsBACnetMenu = NULL;	
	m_pBmsModbusMenu = NULL;
	m_pControllerID = NULL;
	bIsValidHardwareCfg = FALSE;
}

CRtuCtrlCfgDlg::~CRtuCtrlCfgDlg()
{
}

void CRtuCtrlCfgDlg::DoDataExchange(CDataExchange* pDX)
{
	CRtuCtrlCfgDlgBase::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CRtuCtrlCfgDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


#pragma region Message Map
BEGIN_MESSAGE_MAP(CRtuCtrlCfgDlg, CRtuCtrlCfgDlgBase)
	//{{AFX_MSG_MAP(CRtuCtrlCfgDlg)
	ON_WM_PAINT()
	ON_WM_DESTROY()
	ON_WM_SYSCOMMAND()
	ON_WM_CLOSE()
	ON_WM_SIZE()
	ON_WM_LBUTTONDOWN()
	ON_WM_RBUTTONDOWN()
	//}}AFX_MSG_MAP

	ON_XTP_CREATECONTROL()

	ON_MESSAGE(WM_GMS, OnGms)
	ON_REGISTERED_MESSAGE(UWM_TEXT, OnTextMessage)
	ON_REGISTERED_MESSAGE(UWM_RTU_STATUS, OnRtuStatusMessage)
	ON_MESSAGE(UWM_ALARM_HARDWARE_CFG_UPLOADED, OnAlarmHardwareConfigUploaded)
	ON_MESSAGE(UWM_ALARM_HARDWARE_CFG_DWLOADED, OnAlarmHardwareConfigDownloaded)
	ON_MESSAGE(UWM_CONFIG_UPLOADED, OnConfigUploaded)
	ON_MESSAGE(UWM_CONFIG_DOWNLOADED, OnConfigDownloaded)
	ON_MESSAGE(UWM_CONFIG_DOWNLOADING, OnConfigDownloading)
	ON_MESSAGE(UWM_CONFIG_CHANGED, OnConfigChanged)

	// File...
	ON_COMMAND(ID_FILE_LOADTEMPLATEFROMFILE, OnFileLoadTemplateFromFile)
	ON_COMMAND(ID_FILE_SAVETEMPLATETOFILE, OnFileSaveTemplateToFile)
	ON_COMMAND(ID_FILE_SETUPWIZARD, OnFileSetupWizard)
	ON_COMMAND(ID_FILE_EXPORT_ALLCONFIGURATIONS, OnFileExportAllConfigurations)
	ON_COMMAND(ID_ALARM_ALL, OnFileExportAlarmsAll)
	ON_COMMAND_RANGE(ID_FILE_EXPORT_ALARM_AREAS, ID_FILE_EXPORT_ALARM_MACROS, OnFileExportAlarms)
	ON_COMMAND_RANGE(ID_HARDWARE_DEVICES, ID_HARDWARE_PULSECOUNTERS, OnFileExportAlarmsHardware)
	ON_COMMAND_RANGE(ID_SYSTEMS_SYSTEMPARAMETERS, ID_SYSTEMS_SYSTEMFLAGS, OnFileExportAlarmsSystems)
	ON_COMMAND_RANGE(ID_HOURS_NORMALHOURS, ID_HOURS_SERVICEACCESSHOURS, OnFileExportAlarmsHours)
	ON_COMMAND_RANGE(ID_ACCESSCONTROL_ALL, ID_ACCESSCONTROL_OPENCLOSESCH, OnFileExportAccessControl)
	ON_COMMAND(ID_FILE_UPLOADCONFIGURATION, OnFileUploadConfiguration)
	ON_COMMAND(ID_FILE_DOWNLOADCONFIGURATION, OnFileDownloadConfiguration)
	ON_COMMAND(ID_FILE_EXIT2, OnFileExit)

	// View...
	ON_COMMAND(ID_VIEW_CONTROLLERLICENCES, OnViewControllerLicences)
	ON_COMMAND(ID_VIEW_CONTROLLERACCOUNTDETAILS, OnViewControllerAccountDetails)
	ON_COMMAND_RANGE(ID_VIEW_CONTROLLERSTATUS_UNMASKSTATUS, ID_VIEW_CONTROLLERSTATUS_MASKSTATUS, OnViewControllerStatus)
	ON_COMMAND(ID_VIEW_CARDACCESSDIAGNOSTICS, OnViewCardAccessDiagnostics)
	ON_COMMAND(ID_VIEW_ACCESSCONTROLCARDS, OnViewAccessControlCards)
	ON_COMMAND(ID_VIEW_SINGLECARDS, OnViewSingleCard)
	ON_COMMAND_RANGE(ID_VIEW_PORTERRORS_PORT1, ID_VIEW_PORTERRORS_PORT12, OnViewPortErrors)
	ON_COMMAND(ID_VIEW_MODEMSTRING1,  OnViewModemString1)
	ON_COMMAND(ID_VIEW_MODEMSTRING2, OnViewModemString2)
	ON_COMMAND(ID_VIEW_ALARMVOCAB,  OnViewAlarmVocab)
	ON_COMMAND(ID_VIEW_NETWORKDIAGNOSTICS,  OnViewNetworkDiagnostics)

	// Commands...
	ON_COMMAND_RANGE(ID_FIRMWARECOMMANDS_VIEWFIRMWAREVERSION, ID_FIRMWARECOMMANDS_OTHERFIRMWARECOMMANDS, OnCommandFirmware)
	ON_COMMAND_RANGE(ID_CONTROLLERCOMMANDS_DIALCONTROLLER, ID_CONTROLLERCOMMANDS_SHUTDOWNHARDDRIVE, OnCommandController)
	ON_COMMAND_RANGE(ID_WRITETOEEPROM_INTERNAL, ID_WRITETOEEPROM_EXTERNAL, OnCommandControllerWriteToEEPROM)
	ON_COMMAND_RANGE(ID_MODECOMMANDS_DAYMODE, ID_MODECOMMANDS_EXITMODE, OnCommandMode)
	ON_COMMAND_RANGE(ID_KEYPADCOMMANDS_ENABLEKEYPAD, ID_KEYPADCOMMANDS_DEISOLATEKEYPAD, OnCommandKeypad)
	ON_COMMAND_RANGE(ID_ERRORSTATISTICS_RESETALLERRORSTATISTICS, ID_ERRORSTATISTICS_RESETDIALUPERRORSTATISTICS, OnCommandErrorStatistics)
	ON_COMMAND_RANGE(ID_TEST_PERFORMDIALUPTEST, ID_TEST_PERFORMREMOTEMAINTENANCETEST, OnCommandTest)
	ON_COMMAND_RANGE(ID_POWER_MONITOR_ALL, ID_POWER_MONITOR_4, OnCommandTestFirePowerBattery)
	ON_COMMAND_RANGE(ID_SHUTDOWN_HARDDRIVE_PRIMARY, ID_SHUTDOWN_HARDDRIVE_FLASH, OnCommandShutdownHardDrive)
	ON_COMMAND(ID_COMMANDS_ACCESSCONTROLCOMMANDS, OnCommandAccessControl)
	ON_COMMAND(ID_COMMANDS_RESETALLALARMS, OnCommandResetAllAlarms)
	ON_COMMAND(ID_COMMANDS_RESESALLOUTPUTS, OnCommandResetAllOutputs)
	ON_COMMAND(ID_COMMANDS_SYSTEMRESET, OnCommandResetAllAlarmsAndOutputs)
	ON_COMMAND(ID_COMMANDS_RESTOREINPUT, OnCommandRestoreInput)
	ON_COMMAND(ID_COMMANDS_ISOLATEINPUT, OnCommandIsolateInput)
	ON_COMMAND(ID_COMMANDS_DEISOLATEINPUT, OnCommandDeisolateInput)
	ON_COMMAND(ID_COMMANDS_GROUPCOMMANDS, OnCommandGroupCommand)
	//ON_COMMAND(ID_COMMANDS_RESTOREOUTPUT, OnCommandRestoreOutput)
	ON_COMMAND(ID_COMMANDS_ACTIVATEOUTPUT, OnCommandActivateOutput)
	ON_COMMAND(ID_COMMANDS_DEACTIVATEOUTPUT, OnCommandDeactivateOutput)
	ON_COMMAND(ID_COMMANDS_ISOLATEOUTPUT, OnCommandIsolateOutput)
	ON_COMMAND(ID_COMMANDS_DEISOLATEOUTPUT, OnCommandDeisolateOutput)
	ON_COMMAND(ID_COMMANDS_OPENVAULT, OnCommandOpenVault)
	ON_COMMAND(ID_COMMANDS_PROGRAMINOVONICSTRANSMITTER, OnCommandProgramInovonicsTransmitter)
	ON_COMMAND(ID_USERDEFINECOMMANDS_DEFINECOMMANDS, OnCommandUserDefineCommand)
	ON_COMMAND_RANGE(ID_USER_DEFINED_COMMAND_1, ID_USER_DEFINED_COMMAND_1 + 100, OnCommandUserDefineCommandRange)
	ON_COMMAND(ID_CONTROLLERCOMMANDS_RESETPSPTOIDLE, OnCommandResetPspToIdle)
	ON_COMMAND(ID_CONTROLLERCOMMANDS_ENABLELOGTRIGGEREVENTS, OnCommandEnableTriggerEvents)
	ON_COMMAND(ID_CONTROLLERCOMMANDS_DISABLELOGTRIGGEREVENTS, OnCommandDisableTriggerEvents)
	ON_COMMAND(ID_CONTROLLERCOMMANDS_PROGRAMEOLRESISTOR, OnCommandProgramEOLResistor)
	ON_COMMAND(ID_CONTROLLERCOMMANDS_ENABLEREMOTECOMMANDS, OnCommandEnableRemoteCommands)
	ON_COMMAND(ID_CONTROLLERCOMMANDS_DISABLEREMOTECOMMANDS, OnCommandDisableRemoteCommands)

	// Generals...
	ON_COMMAND(ID_GENERAL_CONTROLLERTYPE, OnGeneralControllerType)
	ON_COMMAND(ID_GENERAL_CONTROLLERPASSWORD, OnGeneralControllerPasswords)
	ON_COMMAND(ID_GENERAL_PEERTOPEERSETTINGS, OnGeneralPeerToPeerSettings)
	ON_COMMAND(ID_GENERAL_TFTPSETTINGS, OnGeneralTFTPServerSettings)
	ON_COMMAND(ID_GENERAL_ALARMEVENTSFILTER, OnGeneralAlarmEventsFilter)
	ON_COMMAND(ID_YEARLYCALENDAR_ALARMS, OnGeneralYearlyCalendarAlarms)
	ON_COMMAND(ID_YEARLYCALENDAR_CARDACCESS, OnGeneralYearlyCalendarCardAccess)
	ON_COMMAND(ID_GENERAL_CONTROLLERSETTINGS, OnGeneralControllerSettings)
	ON_COMMAND(ID_GENERAL_PORTSETTINGS, OnGeneralPortSettings)
	ON_COMMAND(ID_GENERAL_SNMPSETTINGS, OnGeneralSNMPSettings)
	ON_COMMAND(ID_GENERAL_POWERSUPPLYSETTINGS, OnGeneralPowerSupplySettings)
	ON_COMMAND(ID_GENERAL_REMOTEMAINTENANCESETTINGS, OnGeneralRemoteMaintenanceSettings)
	ON_COMMAND(ID_GENERAL_PSPSETTINGS, OnGeneralPSPSettings)
	ON_COMMAND(ID_GENERAL_GPIPSETTINGS, OnGeneralGPIPSettings)
	ON_COMMAND(ID_GENERAL_EMCSSETTINGS, OnGeneralEMCSSettings)

	// Alarm...
	ON_COMMAND(ID_ALARM_HARDWARE, OnAlarmHardware)
	ON_COMMAND_RANGE(ID_ALARM_HARDWARE_ADDDEVICE, ID_ALARM_HARDWARE_KEYPADS, OnAlarmHardwareConfigure)
	ON_COMMAND(ID_HARDWARE_VAULT_CONTROLLER, OnAlarmHardwareVaultController)
	ON_COMMAND(ID_ALARM_AREASETTINGS, OnAlarmArea)
	ON_COMMAND_RANGE(ID_ALARM_AREAACCESS_NORMALHOURS, ID_ALARM_AREAACCESS_SERVICEHOURS, OnAlarmAccessHours)
	ON_COMMAND(ID_ALARM_COUNTERSETTINGS, OnAlarmCounterSettings)
	ON_COMMAND(ID_ALARM_ALARMSYSTEMPARAMETERS, OnAlarmSystemParamters)
	ON_COMMAND(ID_ALARM_ALARMSYSTEMFLAGS, OnAlarmSystemFlags)
	ON_COMMAND(ID_ALARM_ALARMUSERS, OnAlarmUsers)
	ON_COMMAND(ID_ALARM_TEMPORARYSCHEDULE, OnAlarmTemporarySchedule)
	ON_COMMAND(ID_ALARM_ALARMTIMESCHEDULES, OnAlarmTimeSchedules)

	ON_COMMAND(ID_GLOBAL_RESISTOR_SETTINGS, OnAlarmGlobalResistorSettings) //TT 8120
	// Access control...
	ON_COMMAND(ID_ACCESSCONTROL_HARDWARE_ADDREADER, OnAccessControlAddReader)
	ON_COMMAND(ID_ACCESSCONTROL_HARDWARE_READERS, OnAccessControlReaders)
	ON_COMMAND(ID_ACCESSCONTROL_AREAPROFILES, OnAccessControlAreaProfiles)
	ON_COMMAND(ID_ACCESSCONTROL_ELEVATORS_ELEVATORSETTINGS, OnAccessControlElevatorSettings)
	ON_COMMAND(ID_ACCESSCONTROL_ELEVATORS_UNLOCKFLOORS, OnAccessControlUnlockedFloors)
	ON_COMMAND(ID_ACCESSCONTROL_CARDTYPESETTINGS, OnAccessControlCardTypeSettings)
	ON_COMMAND(ID_ACCESSCONTROL_CARDFORMATS, OnAccessControlCardFormats)
	ON_COMMAND(ID_ACCESSCONTROL_ACCESSCONTROLTIMESCHEDULES, OnAccessControlTimeSchedules)
	ON_COMMAND(ID_ACCESSCONTROL_OPENCLOSESCHEDULES, OnAccessControlOpenCloseSchedule)
	ON_COMMAND(ID_ACCESSCONTROL_OVERALL_SETTINGS, OnAccessControlOverallSettings)

	// Building management...
	//ON_COMMAND(ID_BUILDINGMANAGEMENT_TFTP, OnbuildingManagementTFPTServerUpdate)
	ON_COMMAND(ID_BUILDINGMANAGEMENT_TRENDBMSSETTINGS, OnbuildingManagementTrendBmsSettings)
	ON_COMMAND(ID_BUILDINGMANAGEMENT_MODBUSSETTINGS, OnbuildingManagementModbusSettings)
	ON_COMMAND(ID_BUILDINGMANAGEMENT_BACNETSETTINGS, OnbuildingManagementBacnetSettings)
	ON_COMMAND(ID_BUILDINGMANAGEMENT_GENERALSETTING, OnbuildingManagementGeneralSettings)

	// Macros...
	ON_COMMAND(ID_MACROS_ALARMEVENTS, OnMacroAlarmEvents)
	ON_COMMAND(ID_MACROS_ALARMMACROS, OnMacroAlarmMacros)
	ON_COMMAND(ID_MACROS_READERMACROS, OnMacroReaderMacros)
	ON_COMMAND(ID_MACROS_BMSMACROS, OnMacroBmsMacros)

	//
	ON_COMMAND(IDS_CTRL_ID_CHANGE, OnChangeID)
	ON_COMMAND(IDS_RTU, OnSelChangeView)

	ON_COMMAND(ID_HELP_CONTENTS, OnHelpContents)
	ON_WM_HELPINFO()

	// Help
	ON_COMMAND(ID_HELP_CONTENTS, OnHelpContents)
	ON_WM_HELPINFO()
END_MESSAGE_MAP()

#pragma endregion

/////////////////////////////////////////////////////////////////////////////
// CRtuCtrlCfgDlg message handlers
BOOL CRtuCtrlCfgDlg::OnInitDialog()
{
	SetFlag(xtResizeNoSizeIcon);
	
	CRtuCtrlCfgDlgBase::OnInitDialog();
	//ShowWindow(SW_HIDE);
	
 	InitRtuParam();
	InitializeComponent();

	if(m_pControllerID) {
		m_pControllerID->SetFocused(TRUE);
	}

	return TRUE;  // return TRUE  unless you set the focus to a control
}

int CRtuCtrlCfgDlg::OnCreateControl(LPCREATECONTROLSTRUCT lpCreateStruct)
{
	if(lpCreateStruct->nID == ID_VIEW_PORTERRORS) {
		lpCreateStruct->pControl = new CControlPortErrors();
		return TRUE;
	}

	if(lpCreateStruct->nID == ID_POWER_DEVICE_BATTERY_TEST) {
		lpCreateStruct->pControl = new CControlFirepowerBatteryTest();
		return TRUE;
	}
	
	if(lpCreateStruct->nID == ID_USERDEFINECOMMANDS_AVAILABLECOMMANDS) {
		lpCreateStruct->pControl = new CControlUserDefinedCommands();
		return TRUE;
	}

	if(lpCreateStruct->nID == ID_CONTROLLERCOMMANDS_SHUTDOWNHARDDRIVE && realRtuType != RTU_2000_TYPE) {
		CXTPControlButton* pControl = new CXTPControlButton();
		pControl->SetEnabled(FALSE);
		lpCreateStruct->pControl = pControl;
		return TRUE;
	}

	if(lpCreateStruct->nID == ID_ALARM_HARDWARE) {
		lpCreateStruct->pControl = new CControlHardwareCommands();
		return TRUE;
	}

	if(lpCreateStruct->nID == ID_FILE_DOWNLOADCONFIGURATION) {
		CXTPControlButton* pControl = new CXTPControlButton();
		pControl->SetEnabled(FALSE);
		m_pDownloadMenu = pControl;
		lpCreateStruct->pControl = pControl;
		return TRUE;
	}

	if(lpCreateStruct->nID == ID_VIEW_CONTROLLERSTATUS_UNMASKSTATUS) {
		CXTPControlButton* pControl = new CXTPControlButton();
		pControl->SetEnabled(FALSE);
		m_pUnmaskedStatusMenu = pControl;
		lpCreateStruct->pControl = pControl;
		return TRUE;
	}
	if(lpCreateStruct->nID == ID_VIEW_CONTROLLERSTATUS_MASKSTATUS) {
		CXTPControlButton* pControl = new CXTPControlButton();
		pControl->SetEnabled(FALSE);
		m_pMaskedStatusMenu = pControl;
		lpCreateStruct->pControl = pControl;	
		return TRUE;
	}

	if(lpCreateStruct->nID == ID_SHUTDOWN_HARDDRIVE_PRIMARY) {
		m_pHardDrivePrimaryMenu = new CXTPControlButton();
		lpCreateStruct->pControl = m_pHardDrivePrimaryMenu;
		return TRUE;
	}

	if(lpCreateStruct->nID == ID_SHUTDOWN_HARDDRIVE_SECONDARY) {
		m_pHardDriveSecondaryMenu = new CXTPControlButton();
		lpCreateStruct->pControl = m_pHardDriveSecondaryMenu;
		return TRUE;
	}

	if(lpCreateStruct->nID == ID_SHUTDOWN_HARDDRIVE_FLASH) {
		m_pHardDriveFlashMenu = new CXTPControlButton();
		lpCreateStruct->pControl = m_pHardDriveFlashMenu;
		return TRUE;
	}

	if(lpCreateStruct->nID == ID_BUILDINGMANAGEMENT_BACNETSETTINGS) {
		CXTPControlButton* pControl = new CXTPControlButton();
		pControl->SetEnabled(FALSE);
		m_pBmsBACnetMenu = pControl;
		lpCreateStruct->pControl = pControl;
		return TRUE;
	}
	if(lpCreateStruct->nID == ID_BUILDINGMANAGEMENT_MODBUSSETTINGS) {
		CXTPControlButton* pControl = new CXTPControlButton();
		pControl->SetEnabled(FALSE);
		m_pBmsModbusMenu = pControl;
		lpCreateStruct->pControl = pControl;
		return TRUE;
	}

	return FALSE;
}

void CRtuCtrlCfgDlg::RepositionControls()
{
	if (m_bInRepositionControls || !m_bInitDone)
		return;

	CRect rcClientStart;
	CRect rcClientNow;
	GetClientRect(rcClientStart);

	if ((GetStyle() & WS_MINIMIZE) || (rcClientStart.IsRectEmpty()))
		return;

	m_bInRepositionControls = TRUE;

	RepositionBars(AFX_IDW_CONTROLBAR_FIRST, AFX_IDW_CONTROLBAR_LAST, 0, reposQuery, rcClientNow);

	CRect rcBorders(rcClientNow.left - rcClientStart.left, rcClientNow.top - rcClientStart.top,  rcClientStart.right - rcClientNow.right, 
		rcClientStart.bottom - rcClientNow.bottom);

	if (rcBorders != m_rcBorders)
	{
		
		CPoint ptOffset(rcBorders.left - m_rcBorders.left, rcBorders.top - m_rcBorders.top);
		CSize szOffset(rcBorders.left + rcBorders.right - m_rcBorders.left - m_rcBorders.right,
			rcBorders.top + rcBorders.bottom - m_rcBorders.top - m_rcBorders.bottom);

		CRect rcWindow;
		GetWindowRect(rcWindow);
		rcWindow.BottomRight() += szOffset;

		Offset(ptOffset);
		m_szWindow += szOffset;
		m_szMin += szOffset;
	
		MoveWindow(rcWindow, TRUE);
	}

	m_rcBorders = rcBorders;
	//if(m_ps && m_ps.GetSafeHwnd() != NULL)
	//	m_ps.MoveWindow(rcClientNow.left, rcClientNow.top, rcClientNow.Width(), rcClientNow.Height());
	if(m_rtuDevicesPage.GetSafeHwnd() != NULL) {
		m_rtuDevicesPage.MoveWindow(rcClientNow.left, rcClientNow.top, rcClientNow.Width(), rcClientNow.Height());
	}
	if(m_rtuStatusPage2.GetSafeHwnd() != NULL) {
		m_rtuStatusPage2.MoveWindow(rcClientNow.left, rcClientNow.top, rcClientNow.Width(), rcClientNow.Height());
	}

	RepositionBars(AFX_IDW_CONTROLBAR_FIRST, AFX_IDW_CONTROLBAR_LAST, 0);

	// Reposition toolbar control
	CXTPCommandBars* pCommandBars = GetCommandBars();
	if(pCommandBars) {
		CXTPToolBar* pToolBar = pCommandBars->GetToolBar(IDR_CTRL_CFG_TOOL_BAR);
		if(pToolBar) {
			CRect rcTB; pToolBar->GetWindowRect(&rcTB);
			rcTB.right = rcTB.left + rcClientStart.Width();
			ScreenToClient(&rcTB);
			pToolBar->MoveWindow(&rcTB);
		}
	}

	m_bInRepositionControls = FALSE;
}

void CRtuCtrlCfgDlg::OnPaint()
{
	CRtuCtrlCfgDlgBase::OnPaint();

	if(m_bIsValidAlarmCfg) {
		//CPanelWnd::DrawTopology(GetDC()->m_hDC);
	}
}


void CRtuCtrlCfgDlg::PlayAnimation()
{
	if(m_wndAnimCtrl2) {
		CRect rc; GetWindowRect(&rc);
		m_rtuDevicesPage.GetWindowRect(&rc);
		ScreenToClient(&rc);
		m_wndAnimCtrl2.MoveWindow(&rc);

		if(m_rtuDevicesPage.m_hWnd != NULL)
			m_rtuDevicesPage.ShowWindow(SW_HIDE);
		if(m_rtuStatusPage2.m_hWnd != NULL)
			m_rtuStatusPage2.ShowWindow(SW_HIDE);

		m_wndAnimCtrl2.ShowWindow(TRUE);
		m_wndAnimCtrl2.Open(IDR_HEARTBEAT);
		m_wndAnimCtrl2.Play(0, (UINT)-1, (UINT)-1);
	}
}

BOOL CRtuCtrlCfgDlg::WantToDestroyNow()
{
	if (_IsSoftProcActive()) {
		wMessageBox(GetSafeHwnd(), SoftProcActive, RES_STRING(IDS_RTU_OPTIONS), MB_OK|MB_ICONSTOP);
		return FALSE;
	}

	if(!m_bWaitDownload) {
		if(m_rtuDevicesPage.m_hWnd && m_rtuDevicesPage.IsConfigChange()) {
			if(DispMessageBox(GetSafeHwnd(), IDS_WANT_TO_DOWNLOAD, IDS_RTU_PARAMS, MB_YESNO | MB_ICONEXCLAMATION) == IDYES) {
				m_bWaitDownload = TRUE;
				OnFileDownloadConfiguration();
				EnableMenuBar(FALSE);
				if(m_rtuDevicesPage) {
					m_rtuDevicesPage.EnableWindow(FALSE);
				}
				//PlayAnimation();
				return FALSE;
			}
		}
	}
	
	if(m_bConfigDownloading) {
		if(DispMessageBox(GetSafeHwnd(), IDS_WANT_TERMINATE, IDS_RTU_PARAMS, MB_YESNO) == IDNO) {
			m_bReqCloseWindow = TRUE;
			EnableMenuBar(FALSE);
			if(m_rtuDevicesPage) {
				m_rtuDevicesPage.EnableWindow(FALSE);
			}
			//PlayAnimation();
			return FALSE;
		}
	}

	if(m_pRtuTemplate) {
		E_CONTROLLER_STATUS sts = m_pRtuTemplate->GetStatus();
		if(sts == E_CTRL_STAT_UPLOADING || sts == E_CTRL_STAT_DOWNLOADING) {
			int strID = sts == E_CTRL_STAT_UPLOADING ? IDS_TEMPLATE_UPLOADING : IDS_TEMPLATE_DOWNLOADING;
			if(DispMessageBox(GetSafeHwnd(), strID, IDS_RTU_PARAMS, MB_YESNO) == IDNO) {
				m_bReqCloseWindow = TRUE;
				EnableMenuBar(FALSE);
				if(m_rtuDevicesPage) {
					m_rtuDevicesPage.EnableWindow(FALSE);
				}
				//PlayAnimation();
				return FALSE;
			}
		}
	}
	return TRUE;
}

void CRtuCtrlCfgDlg::OnSysCommand(UINT nID, LPARAM lParam)
{	
	if ((nID & 0xFFF0) == SC_CLOSE) {
		if(WantToDestroyNow()) {
			OnDestroy();
		}
	} else {
		CDialog::OnSysCommand(nID, lParam);
	}
}

void CRtuCtrlCfgDlg::OnDestroy()
{
int nDegPos = 0;

try {
	if(m_bReqChangeID) {
		m_bReqChangeID = FALSE;
		return;
	}
nDegPos = 1;
	if(m_pPortParamObj) {
		delete m_pPortParamObj; m_pPortParamObj = NULL;
	}

nDegPos = 2;
	if(m_pSystemCommandsObj) {
		delete m_pSystemCommandsObj; m_pSystemCommandsObj = NULL;
	}

nDegPos = 3;
	if(m_pRtuTemplate) {
		delete m_pRtuTemplate; m_pRtuTemplate = NULL;
	}

nDegPos = 4;
	if (EPW_FLAG) {
		send_wr_eeprom(&m_rtups);
  		EPW_FLAG = FALSE;
	}

nDegPos = 5;
	bObj = 0;

nDegPos = 6;
	GmsSaveCommandBars();

nDegPos = 7;
	CRtuCtrlCfgDlgBase::OnDestroy();

nDegPos = 8;


nDegPos = 9;
	if(pRtuCtrlCfgDlg) {
		delete pRtuCtrlCfgDlg; pRtuCtrlCfgDlg = NULL;
	}
nDegPos = 10;

}
catch(...) {
	CString ttt; ttt.Format(L"Exception caught in CRtuCtrlCfgDlg::OnDestroy() %d\n", nDegPos); GmsOutputDebugString(__FUNCTIONW__, __LINE__, ttt);
}

	bIsValidHardwareCfg = 0;
}

void CRtuCtrlCfgDlg::OnClose()
{
	HWND hDlg = GetSafeHwnd();
	try {
		if (EPW_FLAG) {
			DispMessageBox(hDlg, IDS_DLOAD_WAIT, IDS_RTU_OPTIONS, MB_OK | MB_ICONSTOP);
			return;
		}
		if (_IsSoftProcActive()) {
			wMessageBox(hDlg, SoftProcActive, RES_STRING(IDS_RTU_OPTIONS), MB_OK|MB_ICONSTOP);
			return;
		}
		else {
			for (int i=0; i<RTU_OPNCNT; i++) {
				if (IsWindow(Rtups[i].heDlg))
					::DestroyWindow(Rtups[i].heDlg);
			}
		}

		::DestroyWindow(hDlg);
    }
	catch(...) {
		#ifdef __cplusplus
		TRACE0("Failed in RtuOptions at WM_CLOSE\n");
		#endif
    }
}

BOOL CRtuCtrlCfgDlg::PreTranslateMessage(MSG* pMsg)
{
	return CRtuCtrlCfgDlgBase::PreTranslateMessage(pMsg);
}

void CRtuCtrlCfgDlg::OnSize(UINT nType, int cx, int cy) 
{
	CRtuCtrlCfgDlgBase::OnSize(nType, cx, cy);
	RepositionControls();
}

void CRtuCtrlCfgDlg::OnLButtonDown(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	LONG lParam = MAKELONG(point.x, point.y);
	CPanelWnd::CheckMouseClick(GetSafeHwnd(), WM_LBUTTONDOWN, 0, lParam);

	CRtuCtrlCfgDlgBase::OnLButtonDown(nFlags, point);
}

void CRtuCtrlCfgDlg::OnRButtonDown(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	
	CRtuCtrlCfgDlgBase::OnRButtonDown(nFlags, point);
}
void CRtuCtrlCfgDlg::InitRtuParam()
{
	HWND hDlg = GetSafeHwnd();
	
	memset(Rtups, 0, RTU_OPNCNT*sizeof(PARMPROC));
	m_rtups.eType = 0xff;

	g_hRtuWnd = hDlg;
	if (RtuMem.lpMem==NULL || !FindAccPriv(RTU_CONFIG, CHK_ACCESS,0)) {
		PostMessage(WM_CLOSE, 0, 0);
		return;
	}
	else {
		m_rtups.hmDlg = hDlg;
	}

	InitRtuParam2();
	m_bCommovr = 1;

	memset(&m_lpps2, 0, sizeof(m_lpps2));
	memset(m_lpps2Data, 0, sizeof(m_lpps2Data));
	m_lpps2.lpData = m_lpps2Data;

	hPortParamWnd = NULL;
}

void CRtuCtrlCfgDlg::InitializeComponent()
{
	int dbgPositionCounter = 0;
	try {
	if (!m_wndStatusBar.Create(this) ||
		!m_wndStatusBar.SetIndicators(indicators2,
		sizeof(indicators2)/sizeof(UINT)))
	{
		GmsOutputDebugString(__FUNCTIONW__, __LINE__, _T("Failed to create controller's status bar\n"));
		return;      // fail to create
	}
dbgPositionCounter = 1;
	m_wndStatusBar.SetPaneInfo(0, ID_SEPARATOR, SBPS_STRETCH, 100);

dbgPositionCounter = 2;
	VERIFY(InitCommandBars(RUNTIME_CLASS(GmsUI::CCommandBars)));

dbgPositionCounter = 3;
	CXTPCommandBars* pCommandBars = GetCommandBars();

dbgPositionCounter = 4;
	// create men bar
	CXTPMenuBar* pMenu = pCommandBars->SetMenu(_T("Menu Bar"), IDR_CTRL_CFG_MENU);
dbgPositionCounter = 5;
	if(pMenu) {
		pMenu->EnableWindow(FALSE);
		pMenu->SetShowGripper(FALSE);
dbgPositionCounter = 6;
		pMenu->EnableDocking(0);
dbgPositionCounter = 7;
		pMenu->EnableDocking(xtpFlagAlignTop);
dbgPositionCounter = 8;
		// In RTU Connect mode (cmd line param /MR) remove the "View > Controller Account Details" menu item.
		if (ThisGMS->GetCmdLine() & RTU_CONNECT) {
			CXTPControl* pControl = pCommandBars ? pCommandBars->FindControl(xtpControlButton, ID_VIEW_CONTROLLERACCOUNTDETAILS, TRUE, TRUE) : 0;
dbgPositionCounter = 9;
			if (pControl)
				pControl->SetVisible(FALSE);
		}
	}
	
dbgPositionCounter = 10;
	CXTPToolBar* pToolBarRtuCmds = pCommandBars->Add(_T("Rtu Commands"), xtpBarTop);
	if(pToolBarRtuCmds) {
dbgPositionCounter = 11;
		pToolBarRtuCmds->SetBarID(IDR_CTRL_CFG_TOOL_BAR);
		pToolBarRtuCmds->SetShowGripper(TRUE);
		pToolBarRtuCmds->EnableDocking(0);
		pToolBarRtuCmds->EnableDocking(xtpFlagAlignTop);

		pToolBarRtuCmds->GetControls()->Add(xtpControlLabel, 0)->SetCaption(RES_STRING(IDS_CTRL_ID));
dbgPositionCounter = 12;
		m_pControllerID = (CXTPControlEdit*)pToolBarRtuCmds->GetControls()->Add(xtpControlEdit, IDS_CTRL_ID);
		if(m_pControllerID) {
dbgPositionCounter = 13;
			m_pControllerID->SetWidth(m_pControllerID->GetWidth() / 2);
			m_pControllerID->ShowSpinButtons(FALSE);
		}

		CXTPControlButton* pBtn = (CXTPControlButton*)pToolBarRtuCmds->GetControls()->Add(xtpControlButton, IDS_CTRL_ID_CHANGE);
dbgPositionCounter = 14;
		if(pBtn) {
			pBtn->SetCaption(RES_STRING(IDS_CHANGE));
			pBtn->SetStyle(xtpButtonIconAndCaption);
			pBtn->SetTooltip(RES_STRING(IDS_CTRL_ID_CHANGE));
			pBtn->SetPressed(TRUE);
		}
		
		CXTPControl* pCtrl = pToolBarRtuCmds->GetControls()->Add(xtpControlLabel, IDS_CTRL_TYPE);
dbgPositionCounter = 15;
		if(pCtrl) {
			pCtrl->SetBeginGroup(TRUE);
			CString strCaption; strCaption.Format(_T("%s:                     "), RES_STRING(IDS_CTRL_TYPE));
			pCtrl->SetCaption(strCaption);
			pCtrl->SetTooltip(_T(""));
		}

		// Alarm Panel Type
		pCtrl = pToolBarRtuCmds->GetControls()->Add(xtpControlLabel, IDS_ALARM_PANEL_TYPE);
dbgPositionCounter = 16;
		if(pCtrl) {
			pCtrl->SetBeginGroup(TRUE);
			CString strCaption; strCaption.Format(_T("%s: "), RES_STRING(IDS_ALARM_PANEL_TYPE));
			pCtrl->SetCaption(strCaption);
			pCtrl->SetTooltip(_T(""));
		}

		// Primary connection
		pCtrl = pToolBarRtuCmds->GetControls()->Add(xtpControlLabel, IDS_PRIMARY_CONNECTION);
dbgPositionCounter = 17;
		if(pCtrl) {
			pCtrl->SetBeginGroup(TRUE);
			CString strCaption; strCaption.Format(_T("%s: "), RES_STRING(IDS_PRIMARY_CONNECTION));
			pCtrl->SetCaption(strCaption);
			pCtrl->SetTooltip(_T(""));
		}

		// View Option
		pCtrl = pToolBarRtuCmds->GetControls()->Add(xtpControlLabel, IDS_RTU+1);
dbgPositionCounter = 18;
		if(pCtrl) {
			pCtrl->SetBeginGroup(TRUE);
			pCtrl->SetCaption(RES_CSTRING(IDS_VIEW) + _T(": "));

			m_pCboView = (CXTPControlComboBox*)pToolBarRtuCmds->GetControls()->Add(xtpControlComboBox, IDS_RTU);// , IDS_PRIMARY_CONNECTION);
dbgPositionCounter = 19;
			if(m_pCboView) {
				m_pCboView->AddString(RES_STRING(IDS_RTU_STATUS));
				m_pCboView->AddString(RES_STRING(IDS_HARDWARE));
				m_pCboView->SetCurSel(0);
				m_pCboView->SetEnabled(FALSE);
				//m_pCboView->SetWidth(120);	// This may not be suitable for other languages
				m_pCboView->SetWidth(m_pCboView->GetWidth() + 10);
			}
		}
		
	}
	

dbgPositionCounter = 20;
	pCommandBars->GetCommandBarsOptions()->ShowKeyboardCues(xtpKeyboardCuesShowWindowsDefault);
	pCommandBars->GetToolTipContext()->SetStyle(xtpToolTipOffice);
	pCommandBars->GetCommandBarsOptions()->bDisableCommandIfNoHandler = FALSE;


dbgPositionCounter = 21;
	if(m_rtuStatusPage2.GetSafeHwnd() == NULL) {
		m_rtuStatusPage2.CreateGenericChildDialog(this, IDC_PLACE_HOLDER, 0);
		m_rtuStatusPage2.ShowWindow(SW_HIDE);
	}

dbgPositionCounter = 22;
	if(m_rtuDevicesPage.GetSafeHwnd() == NULL) {
		m_rtuDevicesPage.CreateGenericChildDialog(this, IDC_PLACE_HOLDER, 1);
		m_rtuDevicesPage.SetMyParent(this);
		m_rtuDevicesPage.ShowWindow(SW_HIDE);
	}

dbgPositionCounter = 23;
	AddAnimation();

	GmsLoadCommandBars();
dbgPositionCounter = 24;
	m_bInitDone = TRUE;
	RepositionControls();
	m_szMin = m_szWindow;
dbgPositionCounter = 25;
	AutoLoadPlacement(_T("Placement"));

	}
	catch(...) {
		CString ttt; ttt.Format(L"Exception caught in InitializeComponent %d\n",dbgPositionCounter); GmsOutputDebugString(__FUNCTIONW__, __LINE__, ttt);
	}
}

void CRtuCtrlCfgDlg::AddAnimation()
{
	if (!m_wndAnimCtrl2.Create(WS_CHILD|ACS_CENTER, CRect(0,0,0,0), this, 0))
	{
		TRACE0("Failed to create avi control.\n");
		return;
	}

}

static const TCHAR s_XtpPropBase[]    = _T("RtuSettingsWnd");
static const TCHAR s_XtpPropSection[] = _T("RtuCommandBars");

void CRtuCtrlCfgDlg::Do_LoadOrSaveCommandBars (BOOL load, const CString& cmdBarsIniPath)
{
	CXTPCommandBars* pCommandBars = GetCommandBars();
	if (! pCommandBars)
		return;

	XTP_COMMANDBARS_PROPEXCHANGE_PARAM param;
	param.bSerializeLayout = TRUE;
	param.bSerializeOptions = TRUE;

	if (load)
	{
		CXTPPropExchangeIniFile px (load, 0, s_XtpPropBase);
		if (px.LoadFromFile (cmdBarsIniPath))
		{
			CXTPPropExchangeSection pxCommandBars (px.GetSection (s_XtpPropSection));
			pCommandBars->DoPropExchange (&pxCommandBars, &param);
		}
	}
	else
	{
		CXTPPropExchangeIniFile px (load, 0, s_XtpPropBase);
		CXTPPropExchangeSection pxCommandBars (px.GetSection (s_XtpPropSection));
		px.EmptySection();
		pCommandBars->DoPropExchange (&pxCommandBars, &param);
		px.SaveToFile (cmdBarsIniPath);
	}
}

#include <shlwapi.h>

HRESULT CRtuCtrlCfgDlg::GetCommandBarsIniPath (CString& cmdBarsIniPath) const
{
	static const TCHAR version[] = _T("V40501");

	// Current user number is not accessible: Globals->m_pUsers->GetUserNo()+1.
	TCHAR filename[MAX_PATH] = {0};
	_stprintf_s(filename, _COUNTOF(filename), _T("CmdBars%s%s.gmscbs"), s_XtpPropBase, version);

	TCHAR relativePath[MAX_PATH*2] = {0};
	PathCombine(relativePath, CUSTOMER_DATA_FOLDER, filename);
	
	cmdBarsIniPath = CString(LocalFile(relativePath).Path);

	return S_OK;
}

void CRtuCtrlCfgDlg::GmsLoadCommandBars()
{
	try
	{
		CString cmdBarsIniPath;
		const HRESULT hr = GetCommandBarsIniPath (cmdBarsIniPath);
		if (FAILED (hr) || ! PathFileExists (cmdBarsIniPath))
			return;

		Do_LoadOrSaveCommandBars (/*load:*/TRUE, cmdBarsIniPath);
	}
	catch (...)
	{
		AfxMessageBox (L"WARNING: Failed to load custom command bars settings.");
	}
}

void CRtuCtrlCfgDlg::GmsSaveCommandBars()
{
	try
	{
		CString cmdBarsIniPath;
		const HRESULT hr = GetCommandBarsIniPath (cmdBarsIniPath);
		if (FAILED (hr)) // if the file does not exist it will be created
			return;

		Do_LoadOrSaveCommandBars (/*load:*/FALSE, cmdBarsIniPath);
	}
	catch (...)
	{
		AfxMessageBox (L"WARNING: Failed to save custom command bars settings.");
	}
}

void CRtuCtrlCfgDlg::OnChangeID()
{
	int nID = 0;
	if(m_pControllerID) {
		CString strID = m_pControllerID->GetEditText();
		if(strID.GetLength() == 0) {
			DisplayError1(GetSafeHwnd(), InvRtuNo, Globals->hInst);
			m_pControllerID->SetFocused(TRUE);
			return;
		}
		nID = wGetStrInt(strID.GetBuffer());
		if(nID <= 0 || nID > MAX_SITES) {
			DisplayError1(GetSafeHwnd(), InvRtuNo, Globals->hInst);
			m_pControllerID->SetFocused(TRUE);
			return;
		}
	}

	if(!m_bReqChangeID && m_rtuDevicesPage.m_hWnd) {
		if(m_rtuDevicesPage.IsConfigChange()) {
			if(MessageBox(RES_STRING(IDS_WANT_DLOAD), RES_STRING(IDS_WANT_DLOAD), MB_YESNO) == IDYES) {
				m_bReqChangeID = TRUE;
				OnFileDownloadConfiguration();
				return;
			}
		}
	}

	GetControllerCfg(nID);
}

void CRtuCtrlCfgDlg::GetControllerCfg(int nID)
{
	CXTPCommandBars* pCommandBars = GetCommandBars();
	if(pCommandBars) {
		CXTPToolBar* pToolBar = pCommandBars->GetToolBar(IDR_CTRL_CFG_TOOL_BAR);
		if(pToolBar) {
			if(m_pControllerID) {
				m_pControllerID->SetEnabled(TRUE);
				m_nReqRtuNumber = nID;
				GetControllerConfig();
				m_wndStatusBar.SetPaneText(0, _T(""));
				EnableMenuBar(FALSE);
				CString s; s.Format(_T("%s - ???"), RES_STRING(IDS_CTRL_ID));
				SetWindowText(s);
			}

			// Controller Type
			CXTPControl* pCtrlType = pToolBar->GetControls()->FindControl(IDS_CTRL_TYPE);
			if(pCtrlType) {
				CString s; s.Format(_T("%s: %s"), RES_STRING(IDS_CTRL_TYPE), RES_STRING(IDS_UNDEFINED));
				pCtrlType->SetCaption(s);
			}

			// Alarm Panel Type
			CXTPControl* pAlarmPanelType = pToolBar->GetControls()->FindControl(IDS_ALARM_PANEL_TYPE);
			if(pAlarmPanelType) {
				CString s; s.Format(_T("%s: %s"), RES_STRING(IDS_ALARM_PANEL_TYPE), RES_STRING(IDS_UNDEFINED));
				pAlarmPanelType->SetCaption(s);
			}

			// Primary Connection
			CXTPControl* pPrimaryConnection = pToolBar->GetControls()->FindControl(IDS_PRIMARY_CONNECTION);
			if(pAlarmPanelType) {
				CString s; s.Format(_T("%s: %s"), RES_STRING(IDS_PRIMARY_CONNECTION), RES_STRING(IDS_UNDEFINED));
				pPrimaryConnection->SetCaption(s);
			}
		}
	}

	if(m_pCboView) {
		m_pCboView->SetEnabled(FALSE);
		m_pCboView->SetCurSel(0);
		//m_pCboView->SetVisible(FALSE);
	}

	if(m_rtuStatusPage2.m_hWnd) {
		m_rtuStatusPage2.ShowWindow(SW_HIDE);
		if(m_bStatusPrivilege)	
			m_rtuStatusPage2.Reset();
	}
	if(m_rtuDevicesPage.m_hWnd)
		m_rtuDevicesPage.ShowWindow(SW_HIDE);	 
	
	bIsValidHardwareCfg = FALSE;
	bAlarmHardwareUploaded = FALSE;
	m_bIsValidAlarmCfg = FALSE;
	m_bRequestGenBmsCfg = FALSE;
	m_bRtuStatus = FALSE;

	if(m_pDownloadMenu) {
		m_pDownloadMenu->SetEnabled(FALSE);
	}
	if(m_pRtuTemplate) {
		delete m_pRtuTemplate; m_pRtuTemplate = NULL;
	}
}

void CRtuCtrlCfgDlg::OnSelChangeView()
{	
	int nIndex = -1;
	CXTPCommandBars* pCmdBars = GetCommandBars();
	if(pCmdBars) {
		CXTPToolBar* pTB = (CXTPToolBar*)pCmdBars->GetToolBar(IDR_CTRL_CFG_TOOL_BAR);
		if(pTB) {
			CXTPControlComboBox* pCBO = (CXTPControlComboBox*)pTB->GetControls()->FindControl(IDS_RTU);
			if(pCBO) {
				nIndex = pCBO->GetCurSel();
			}
		}
	}

	switch(nIndex) {
		case 0:
			if(m_rtuDevicesPage.m_hWnd)
				m_rtuDevicesPage.ShowWindow(SW_HIDE);
			if(m_rtuStatusPage2.m_hWnd) {
				m_rtuStatusPage2.ShowWindow(SW_SHOW);
				if(m_bStatusPrivilege)
					m_rtuStatusPage2.GetStatus(m_nCurStatus);
			}

			break;
		case 1:
			OnAlarmHardware();
			break;
		default:
			break;
	}
}

void CRtuCtrlCfgDlg::OnHelpContents()
{
	DisplayHelp(NULL, GMS_HLP_FILE, HH_DISPLAY_TOPIC, NULL); // TT#3780
}

BOOL CRtuCtrlCfgDlg::OnHelpInfo(HELPINFO* /*lpHelpInfo*/)
{
	DisplayHelp(NULL, GMS_HLP_FILE, HH_DISPLAY_TOPIC, NULL); // TT#3780
	return TRUE;
}

void CRtuCtrlCfgDlg::EnableMenuBar(BOOL bEnabled)
{
	CXTPCommandBars* pCommandBars = GetCommandBars();
	if(pCommandBars) {
		CXTPMenuBar* pMenu = pCommandBars->GetMenuBar();
		if(pMenu) {
			pMenu->EnableWindow(bEnabled);
			pMenu->SetShowGripper(bEnabled);
		}
	}
}

void CRtuCtrlCfgDlg::SetControllerInfo()
{
	BOOL bEnableMenu = TRUE;
	CXTPCommandBars* pCommandBars = GetCommandBars();
	if(pCommandBars) {
		CXTPToolBar* pToolBar = pCommandBars->GetToolBar(IDR_CTRL_CFG_TOOL_BAR);
		if(pToolBar) {
			CString s; 
			if(m_pControllerID) {
				s.Format(_T("%d"), m_nReqRtuNumber);
				m_pControllerID->SetEditText(s);
			}

			// Controller Type
			CXTPControl* pCtrlType = pToolBar->GetControls()->FindControl(IDS_CTRL_TYPE);
			if(pCtrlType) {
				CString sRtuType = RES_STRING(IDS_RTU_TYPE_TXT);
				if ((m_nPanelType==RTU2000_TYPE || m_nPanelType==SRTU_TYPE) && m_lpps->NetType==NT_ASYN_POLL) {
					s.Format(_T("%s: %s"), RES_STRING(IDS_CTRL_TYPE), RES_STRING(IDS_MOSLER) );
				}
				else {
					s.Format(_T("%s: %s"), RES_STRING(IDS_CTRL_TYPE), GetRTUType(IsRtu8002Type() ? RTU_8002_TYPE: realRtuType));//TT 7516
					
					if (m_nPanelType == MP1003_TYPE) {
						CString s2; s2.Format(_T("(%s)"), RES_STRING(IDS_OLD));
						s += s2;
					}
				}			
				pCtrlType->SetCaption(s);
			}

			// Alarm Panel Type
			CXTPControl* pAlarmPanelType = pToolBar->GetControls()->FindControl(IDS_ALARM_PANEL_TYPE);
			if(pAlarmPanelType) {
				s.Format(_T("%s: %s"), RES_STRING(IDS_ALARM_PANEL_TYPE), (LPCTSTR)gAlarmPanelTypeStr);
				pAlarmPanelType->SetCaption(s);
				if(gAlarmPanelTypeStr == _T("")) {
					bEnableMenu = FALSE;
				}
			}

			// Primary Connection
			CXTPControl* pPrimaryConnection = pToolBar->GetControls()->FindControl(IDS_PRIMARY_CONNECTION);
			if(pAlarmPanelType) {
				s.Format(_T("%s: %s"), RES_STRING(IDS_PRIMARY_CONNECTION), (LPCTSTR)gPrimaryConnectionStr);
				pPrimaryConnection->SetCaption(s);
				if(gPrimaryConnectionStr == _T("")) {
					bEnableMenu = FALSE;
				}
			}
		}
	}

	CString strWndText; strWndText.Format(_T("%s - %d"), RES_STRING(IDS_CTRL_ID), m_nRtuNumber);
	SetWindowText(strWndText);
	EnableMenuBar(bEnableMenu);
	RepositionControls();
	m_wndStatusBar.SetPaneText(0, _T(""));

	if(bEnableMenu) {		
		if(m_rtuDevicesPage.m_hWnd)
			m_rtuDevicesPage.ShowWindow(SW_HIDE);
		if(m_rtuStatusPage2.m_hWnd)
			m_rtuStatusPage2.ShowWindow(SW_HIDE);

		if(!GetGeneralBmsConfig()) {
			GetRtuStatus();
		}
	}

	EnableHardDriveMenu(realRtuType == RTU_2000_TYPE);
	if(m_pControllerID) {
		m_pControllerID->SetFocused(TRUE);
	}
}

void CRtuCtrlCfgDlg::SetTheme(XTPPaintTheme paintTheme)
{
	CXTPPaintManager::SetTheme(paintTheme);
	RedrawWindow(0, 0, RDW_ALLCHILDREN|RDW_INVALIDATE);
}

BOOL CRtuCtrlCfgDlg::OnCommand(WPARAM wParam, LPARAM lParam) 
{
	// TODO: Add your specialized code here and/or call the base class
	OnGms(wParam, lParam);
	return CRtuCtrlCfgDlgBase::OnCommand(wParam, lParam);
}

LRESULT CRtuCtrlCfgDlg::OnTextMessage(WPARAM wParam, LPARAM)
{
	m_wndStatusBar.SetPaneText(0, (LPTSTR)wParam);
	return 0;
}
LRESULT CRtuCtrlCfgDlg::OnRtuStatusMessage(WPARAM wParam, LPARAM)
{
	m_wndStatusBar.SetPaneText(0, (LPTSTR)wParam);
	m_rtuDevicesPage.ShowWindow(SW_HIDE);
	m_rtuStatusPage2.ShowWindow(SW_SHOW);
	m_bRtuStatus = TRUE;

	if(m_pCboView) {
		m_pCboView->SetCurSel(0);
	}
	return 0;
}

void CRtuCtrlCfgDlg::UploadCustomVocab() // written for TT#5950
{
	try {
		if (IsCustomVocab() && m_lpps && !m_bCustomVocabUploadSent) {

			m_bCustomVocabUploadSent = TRUE;

			m_rtuStatusPage2.ShowWindow(SW_SHOW);
			m_rtuDevicesPage.ShowWindow(SW_HIDE);

			const int prevOpt = SetRtuConfigOption(IDM_VIEW_VOCAB);
			Rtu::CPanelWnd::GetConfig(m_lpps->hmDlg, m_lpps, IDM_VIEW_VOCAB); // TT#5950
			SetRtuConfigOption(prevOpt);
		}
	}
	catch(...) {
	}
}

void CRtuCtrlCfgDlg::CustomVocabUploaded(BOOL bSaveIt) // written for TT#5950
{
	try {
		m_bCustomVocabUploadSent = FALSE;

		m_rtuDevicesPage.UpdateWindows();
		m_rtuStatusPage2.ShowWindow(SW_HIDE);
		m_rtuDevicesPage.ShowWindow(SW_SHOW);
		m_rtuDevicesPage.Invalidate();

		m_wndStatusBar.SetPaneText(0, _T("")); // OR: SetControllerInfo();

		if (bSaveIt) {
			const int prevOpt = SetRtuConfigOption(IDM_VIEW_VOCAB);
			SaveRtuVocab(m_lpps); // TT#5950
			SetRtuConfigOption(prevOpt);
		}
	}
	catch(...) {
	}
}

LRESULT CRtuCtrlCfgDlg::OnGms(WPARAM wParam, LPARAM lParam)
{
	HWND hDlg = GetSafeHwnd();
	UINT id = GET_WM_COMMAND_ID(wParam, lParam);
	CString s; 

	switch(id) {
		case IDD_COMMOVR_ERROR:   
			if (m_bCustomVocabUploadSent) {
				CustomVocabUploaded(FALSE); // TT#5950
				break;
			}
			break;

		case IDD_COMMOVR_CTRL_NUM:
		case IDD_COMMOVR_DATA:
			if(m_lpps2.Id==REQ_SRNO_CMD) {
				m_lpps2.Id = 0;
				m_wndStatusBar.SetPaneText(0, _T(""));
				LPBYTE pSerNumData = (LPBYTE)lParam;
				if(pSerNumData && (id == IDD_COMMOVR_DATA))
					DisplaySerialNumber(pSerNumData, m_rtups.eType, m_rtups.eNo);
				break;
			}

			if(m_bRequestGenBmsCfg) {
				m_bRequestGenBmsCfg = FALSE;
				ProcessGenBmsConfig();
				if(!m_bRtuStatus)
					GetRtuStatus();
			}

			if (m_bCustomVocabUploadSent) {
				CustomVocabUploaded(TRUE); // TT#5950
				break;
			}

			if (m_bCommovr || (RtuType==RTU_DIEBOLD_TYPE && m_option==9)) {
				if (m_option < RTU_OPNCNT) {
					m_lpps = &Rtups[m_option];
					m_lpps->heDlg = 0;
					}
				if (m_bCommovr)
					break;				//.Implies not to process
				}

			m_bCommovr = 1;
			if(id == IDD_COMMOVR_CTRL_NUM)
				break;
			if ((LPBYTE)lParam && InitRtuParms(hDlg, &m_rtups, (LPBYTE)lParam)) {
				if((!RtuLib::IsNewControllerType(realRtuType)) || ((PanelType != P1060_TYPE) && (PanelType != P8001_TYPE))) {
					bDisplayNewScreen = FALSE;
					//OnDestroy();
					if(pRtuCtrlCfgDlg) {
						pRtuCtrlCfgDlg->ShowWindow(SW_HIDE);
					}
					if (!lpRtuProc) {
						lpRtuProc = MakeProcInstance((FARPROC)GetRtuConfig, hrInst);
					}
					::PostMessage(m_hpWnd, WM_GMS, HID_HELP, (LPARAM)s_HelpFile);
					HWND hWnd = CreateDialogParam(hrInst, _T("RTUOPTIONS"), m_hpWnd, (DLGPROC)lpRtuProc, (LPARAM)&rtuSetup);
					::SendMessage(hWnd, WM_GMS, IDD_INITELEMNO, m_nRtuNumber);

					break;
				}
				m_nPanelType = PanelType;
				SetControllerInfo();
			ShowWindow(SW_SHOW);

			}
			m_rtups.heDlg = 0;
			break;
		
		case IDD_HIRESP:			//.Hi Resp to command sent
			break;
		case IDD_INITELEMNO: //.LPARAM = Rtu No.
			if (MAKERTUNO(m_rtups.eType, m_rtups.eNo) == (int)lParam)
    			break;

			m_nRtuNumber = (int)lParam;
			m_nReqRtuNumber = m_nRtuNumber;
			SetControllerInfo();
		    GetControllerConfig();
			break;
		case IDD_GETRTUNO:
			GetControllerConfig();
			break;

		default:
			break;
	}
	
	if(m_pControllerID && !m_bRtuStatus) {
		m_pControllerID->SetFocused(TRUE);
	}
	return(0);

}

void CRtuCtrlCfgDlg::GetControllerConfig()
{
	m_nRtuNumber = m_nReqRtuNumber;
	m_rtuno = m_nReqRtuNumber;
	m_rtuno--;
	gRtuNo = m_rtuno;
	HWND hDlg = GetSafeHwnd();
	if (m_rtuno < 0 || m_rtuno >= MAX_SITES || !IsValidSiteNo(m_rtuno, 3)) {
		DisplayError1(hDlg, InvRtuNo, Globals->hInst);
		return;
	}

	if (m_rtuno != MAKERTUNO(m_rtups.eType, m_rtups.eNo) && EPW_FLAG) {
		m_rtups.heDlg = hDlg;
		send_wr_eeprom(&m_rtups);
		EPW_FLAG = FALSE;
	}


	DefOption = 0;
	m_rtups.eNo = (BYTE)GETRTUOFFSET(m_rtuno);
	m_rtups.eType = (BYTE)GETGROUPNO(m_rtuno);
	m_rtups.heDlg = hDlg;
	m_rtups.lpData = (LPBYTE)RtuMem.lpMem;
	SetRtuConfigOK(m_rtuno, CFG_BLKSIZE, 0);
	m_rtups.BlkNo = 0;

	EnableMenuBar(FALSE);
	if (get_blk_sizes(&m_rtups) != -1) {
		m_bCommovr = 0;
	}
}

void CRtuCtrlCfgDlg::DisplaySerialNumber(LPBYTE pData, BYTE addr1, BYTE addr2)
{
	CRtu::DisplayControllerLicenseOptions(this, pData, addr1, addr2);
}

void CRtuCtrlCfgDlg::GetNetworkError()
{
	LPPARMPROC lpps = m_lpps;
	HWND hDlg = GetSafeHwnd();

	if((lpps = GetLPPARMPROC(hDlg, m_option=10, m_rtups, TRUE)) == NULL)
		return;

	memcpy(&m_lpps2, lpps, sizeof(m_lpps2));
	m_lpps2.lpData = m_lpps2Data;

	if(m_pPortParamObj == NULL) {
		m_pPortParamObj = new CRtuPortParamsConfig(this);
	}
	if(m_pPortParamObj != NULL) {
		m_pPortParamObj->GetNetworkError(&m_lpps2);
	}
}
void CRtuCtrlCfgDlg::GetPortConfig(int nCommandID, int nPortConfig, BOOL bError)
{
	TRACE2("CRtuCtrlCfgDlg::GetPortConfig(nCommandID=%d, nPortConfig=%d)\n", nCommandID,nPortConfig);
	LPPARMPROC lpps = m_lpps;
	HWND hDlg = GetSafeHwnd();

	if((lpps = GetLPPARMPROC(hDlg, m_option=10, m_rtups, TRUE)) == NULL)
		return;

	memcpy(&m_lpps2, lpps, sizeof(m_lpps2));
	m_lpps2.lpData = m_lpps2Data;

	//if((m_pPortParamObj = CRtuPortParamsConfig::GetInstance(this)) != NULL) {
	//	m_pPortParamObj->GetPortConfig(&m_lpps2, nCommandID, nPortConfig, bError);
	//}

	if(m_pPortParamObj == NULL) {
		m_pPortParamObj = new CRtuPortParamsConfig(this);
	}
	if(m_pPortParamObj != NULL) {
		m_pPortParamObj->GetPortConfig(&m_lpps2, nCommandID, nPortConfig, bError);
	}
}

void CRtuCtrlCfgDlg::OnFileRtuTemplate()
{
	LPPARMPROC lpps = m_lpps;
	HWND hDlg = GetSafeHwnd();

	if((lpps = GetLPPARMPROC(hDlg, m_option=11, m_rtups, TRUE)) == NULL)
		return;

	memcpy(&m_lpps2, lpps, sizeof(m_lpps2));
	m_lpps2.lpData = m_lpps2Data;

	int retCode = 0;
	CRtuTemplate* rtuTmpDlg = new CRtuTemplate(&m_lpps2, CWnd::FromHandle(m_lpps2.hmDlg));
	if(rtuTmpDlg != NULL) { //Always evaluates to true
		retCode = rtuTmpDlg->DoModal();
		delete rtuTmpDlg; rtuTmpDlg = NULL;
	}
}

// Download template to controller
void CRtuCtrlCfgDlg::OnFileLoadTemplateFromFile()
{
	GmsOutputDebugString(__FUNCTIONW__, __LINE__, _T("[RTU Config] Load Template... \n"));
	TCHAR strTemplate[MAX_PATH];
	TCHAR szFilter[] = _T("Data Files (*.rtu)|*.rtu; *.rtu|All Files (*.*)|*.*||");
	if(!RtuLib::GetFileName(strTemplate, _T(".rtu"), szFilter, TRUE))
		return;

	CString strTmp = strTemplate;
	if(strTmp == _T("")) {
		return;
	}

	LPPARMPROC lpps = m_lpps;
	HWND hDlg = GetSafeHwnd();

	if((lpps = GetLPPARMPROC(hDlg, m_option=11, m_rtups, TRUE)) == NULL)
		return;

	memcpy(&m_lpps2, lpps, sizeof(m_lpps2));
	m_lpps2.lpData = m_lpps2Data;

	_stprintf_s(strTemplate, _T("%s"), (LPCTSTR)strTmp);

	if(m_pRtuTemplate == NULL) {
		m_pRtuTemplate = new CRtuCtrlTemplate(&m_lpps2, this);
	}
	if(m_pRtuTemplate != NULL) {		
		m_pRtuTemplate->DownloadConfig(strTemplate);
	}
}

// Upload template from the controller
void CRtuCtrlCfgDlg::OnFileSaveTemplateToFile()
{
	GmsOutputDebugString(__FUNCTIONW__, __LINE__, _T("[RTU Config] Save Template... \n"));
	TCHAR strTemplate[MAX_PATH];
	memset(strTemplate, 0, sizeof(strTemplate));
	TCHAR szFilter[] = _T("Data Files (*.rtu)|*.rtu; *.rtu|All Files (*.*)|*.*||");
	if (RtuLib::GetFileName(strTemplate, _T(".rtu"), szFilter) == FALSE)
		return;

	CString strTmp = strTemplate;
	if(strTmp == _T("")) {
		return;
	}

	LPPARMPROC lpps = m_lpps;
	HWND hDlg = GetSafeHwnd();

	if((lpps = GetLPPARMPROC(hDlg, m_option=11, m_rtups, TRUE)) == NULL)
		return;

	memcpy(&m_lpps2, lpps, sizeof(m_lpps2));
	m_lpps2.lpData = m_lpps2Data;

	//strTmp = strTmp.Mid(0, strTmp.GetLength() - 4);
	_stprintf_s(strTemplate, _T("%s"), (LPCTSTR)strTmp);

	if(m_pRtuTemplate == NULL) {
		m_pRtuTemplate = new CRtuCtrlTemplate(&m_lpps2, this);
	}
	if(m_pRtuTemplate != NULL) {		
		m_pRtuTemplate->UploadConfig(strTemplate);
	}
}

void CRtuCtrlCfgDlg::OnFileSetupWizard()
{
	GmsOutputDebugString(__FUNCTIONW__, __LINE__, _T("[RTU Config] Setup Wizard... \n"));
	LPPARMPROC lpps = m_lpps;
	HWND hDlg = GetSafeHwnd();
	if((lpps = GetLPPARMPROC(hDlg, m_option=1, m_rtups, TRUE)) == NULL) {
		AfxMessageBox(_T("GetLPPARMPROC Failed"));
		return;
	}

	if(RtuLib::IsNewControllerType(realRtuType)) {
		CRtuSetupWizard* pSetupDg;
		pSetupDg = new CRtuSetupWizard(hrInst, Globals->hSysWnd, iblk, lpps);
		if(pSetupDg) { //Always evaluates to true
			int nCurRtuNum = m_nReqRtuNumber;
			if(pSetupDg->DoModal() == IDOK) {
				lpps->eType = pSetupDg->m_glpps.eType;
				lpps->eNo = pSetupDg->m_glpps.eNo;
				int nNewRtuNum = MAKERTUNO(lpps->eType, lpps->eNo) + 1;
				
				if(nCurRtuNum != nNewRtuNum) {
					m_nReqRtuNumber = nNewRtuNum;
					GetControllerCfg(m_nReqRtuNumber);
				}
			}
			delete pSetupDg; pSetupDg = NULL;
		}
	}
}

void CRtuCtrlCfgDlg::OnFileExportAllConfigurations()
{
	GmsOutputDebugString(__FUNCTIONW__, __LINE__, _T("[RTU Config] Export All Config... \n"));
	m_nPrintCfg = E_PRINT_ALL_ALARM;
	ProcessAlarmCommand(ID_ALARM_ALL);
	//ProcessAccessControlCommand(ID_ACCESSCONTROL_ALL);
}
void CRtuCtrlCfgDlg::OnFileExportAlarmsAll()
{
	GmsOutputDebugString(__FUNCTIONW__, __LINE__, _T("[RTU Config] Export Alarms Config... \n"));
	ProcessAlarmCommand(ID_ALARM_ALL);
}
void CRtuCtrlCfgDlg::OnFileExportAlarms(UINT nCommandID)
{
	ProcessAlarmCommand(nCommandID);
}
void CRtuCtrlCfgDlg::OnFileExportAlarmsHardware(UINT nCommandID)
{
	GmsOutputDebugString(__FUNCTIONW__, __LINE__, _T("[RTU Config] Export Alarms Hardware... \n"));
	ProcessAlarmCommand(nCommandID);
}
void CRtuCtrlCfgDlg::OnFileExportAlarmsSystems(UINT nCommandID)
{
	GmsOutputDebugString(__FUNCTIONW__, __LINE__, _T("[RTU Config] Export Alarms System Config... \n"));
	ProcessAlarmCommand(nCommandID);
}
void CRtuCtrlCfgDlg::OnFileExportAlarmsHours(UINT nCommandID)
{
	GmsOutputDebugString(__FUNCTIONW__, __LINE__, _T("[RTU Config] Export Alarms Hours... \n"));
	ProcessAlarmCommand(nCommandID);
}
void CRtuCtrlCfgDlg::OnFileExportAccessControl(UINT nCommandID)
{
	GmsOutputDebugString(__FUNCTIONW__, __LINE__, _T("[RTU Config] Export Access Control... \n"));
	ProcessAccessControlCommand(nCommandID);
}
void CRtuCtrlCfgDlg::OnFileUploadConfiguration()
{
	GmsOutputDebugString(__FUNCTIONW__, __LINE__, _T("[RTU Config] Upload Hardware Config... \n"));
	m_nCommandID = 0;
	m_bIsValidAlarmCfg = FALSE;
	m_rtuDevicesPage.Init();
	UploadConfiguration();
}
void CRtuCtrlCfgDlg::OnFileDownloadConfiguration()
{
	GmsOutputDebugString(__FUNCTIONW__, __LINE__, _T("[RTU Config] Download Hardware Config... \n"));
	if(m_rtuDevicesPage.m_hWnd && m_rtuDevicesPage.IsConfigChange()) {
		ProcessAlarmCommand(ID_FILE_DOWNLOADCONFIGURATION);
		m_rtuDevicesPage.UpdateConfig();
		m_bConfigDownloading = TRUE;
	}
}
void CRtuCtrlCfgDlg::OnFileExit()
{
	GmsOutputDebugString(__FUNCTIONW__, __LINE__, _T("[RTU Config] Closing Controller Settings... \n"));
	if(WantToDestroyNow()) {
		OnDestroy();
	}
}

void CRtuCtrlCfgDlg::EnableStatusMenu(BOOL bEnable)
{
	if(m_pMaskedStatusMenu)
		m_pMaskedStatusMenu->SetEnabled(bEnable);
	if(m_pUnmaskedStatusMenu)
		m_pUnmaskedStatusMenu->SetEnabled(bEnable);
}

void CRtuCtrlCfgDlg::EnableHardDriveMenu(BOOL bEnable)
{
	if(m_pHardDrivePrimaryMenu)
		m_pHardDrivePrimaryMenu->SetEnabled(bEnable);
	if(m_pHardDriveSecondaryMenu)
		m_pHardDriveSecondaryMenu->SetEnabled(bEnable);
	if(m_pHardDriveFlashMenu)
		m_pHardDriveFlashMenu->SetEnabled(bEnable);
}

// view...
BOOL CRtuCtrlCfgDlg::GetGeneralBmsConfig()
{
	GmsOutputDebugString(__FUNCTIONW__, __LINE__, _T("[RTU Config] Requesting General Bms Config... \n"));
	
	LPPARMPROC lpps = new PARMPROC;
	memset(lpps, 0, sizeof(PARMPROC));
	m_option = 18;
	lpps = &Rtups[m_option];

	*lpps = m_rtups;
	lpps->Id = (BYTE)m_option;
	lpps->lpData = (LPBYTE)RtuMem.lpMem + m_option*512;
	lpps->hmDlg = GetSafeHwnd();


	if (!FindAccPriv(E_RTU_BMSPARMS, CHK_EDIT|CHK_ACCESS, CHK_VIEW|CHK_RESET))
		return FALSE;
	iblk = (BYTE)2;
	lpps->BC = pblk_size[iblk];			//.Block Size

	memcpy(&m_ppsBms, lpps, sizeof(m_ppsBms));
	memcpy(m_ppsBmsData, lpps->lpData, sizeof(m_ppsBmsData));
	m_ppsBms.lpData = m_ppsBmsData;

	if(m_nReqRtuNumber != (MAKERTUNO(m_ppsBms.eType, m_ppsBms.eNo)+1)) {
		return FALSE;
	}

	get_BMS_parms(&m_ppsBms, 0, iblk);
	m_bRequestGenBmsCfg = TRUE;
	return TRUE;
}

void CRtuCtrlCfgDlg::ProcessGenBmsConfig()
{
	GmsOutputDebugString(__FUNCTIONW__, __LINE__, _T("[RTU Config] Processing General Bms Config...  \n"));
	int nRtuNo = MAKERTUNO(m_ppsBms.eType, m_ppsBms.eNo);
	TCHAR	bmsFileName[MAX_PATH];
	TCHAR	sPath[MAX_PATH];
	GetRtuParmFile(bmsFileName, BMS_REC0_FILE, nRtuNo);

	BmsGenCfg bmsGenCfg; 
	memset(&bmsGenCfg, 0, sizeof(bmsGenCfg));

	wsprintf(sPath, L"%s\\%s", CUSTOMER_RTU_UPLOAD_FOLDER, bmsFileName);
	
	CMyFile bmsFile;

	if (bmsFile.Open(DefaultLocation(sPath), FILE_READ|FILE_DENYNONE,0)) {
		int flen = (int)bmsFile.GetLength();
		if(flen == sizeof(bmsGenCfg)) {
			bmsFile.Read(&bmsGenCfg.tftpTime, flen);

			if(m_pBmsBACnetMenu) {
				m_pBmsBACnetMenu->SetEnabled(bmsGenCfg.flags & 1 ? TRUE : FALSE);
			}

			if(m_pBmsModbusMenu) {
				m_pBmsModbusMenu->SetEnabled(bmsGenCfg.flags & 2 ? TRUE : FALSE);
			}

		}
		bmsFile.Close();

	}
	else {
		CString errorMsg; errorMsg.Format(_T("Failed to open %s file.(e=%d)\n"), sPath, GetLastError());GmsOutputDebugString(__FUNCTIONW__, __LINE__, errorMsg);
	}

	m_wndStatusBar.SetPaneText(0, _T(""));
}


void CRtuCtrlCfgDlg::GetRtuStatus(BYTE nMask)
{	
	m_option = 3;
	if(!m_rtuStatusPage2.IsValid()) {
		if((m_lpps = GetLPPARMPROC(GetSafeHwnd(), m_option, m_rtups, TRUE)) == NULL) {
			m_bStatusPrivilege = FALSE;
			EnableStatusMenu(FALSE);
			return;
		}
	}
	else {
		if((m_lpps = GetLPPARMPROC(GetSafeHwnd(), m_option, m_rtups, FALSE)) == NULL) {
			m_bStatusPrivilege = FALSE;
			EnableStatusMenu(FALSE);
			return;
		}
	}
		
	m_bStatusPrivilege = TRUE;
	m_lpps->BlkNo = nMask;
	m_rtuStatusPage2.Init(m_lpps, m_option, nMask, this);
	EnableStatusMenu(TRUE);
}

void CRtuCtrlCfgDlg::OnViewControllerLicences()
{
	GmsOutputDebugString(__FUNCTIONW__, __LINE__, _T("[RTU Config] Requesting Controller Licenses... \n"));
	HWND hDlg = GetSafeHwnd();
	memcpy(&m_lpps2, &m_rtups, sizeof(m_lpps2));
	m_lpps2.lpData = m_lpps2Data;
	m_lpps2.Id = REQ_SRNO_CMD;
	m_lpps2.heDlg = m_lpps2.hmDlg = hDlg;
	GetRtuSerialNo(&m_lpps2);
}
void CRtuCtrlCfgDlg::OnViewControllerAccountDetails()
{
	ShowRtuAcctDetail(GetSafeHwnd(), MAKELONG(MAKERTUNO(m_rtups.eType,
						m_rtups.eNo), MAKEWORD(RAPType, m_rtups.NetType)));
}
void CRtuCtrlCfgDlg::OnViewControllerStatus(UINT nCommandID)
{
	GmsOutputDebugString(__FUNCTIONW__, __LINE__, _T("[RTU Config] Requesting Controller Status... \n"));
	m_rtuDevicesPage.ShowWindow(SW_HIDE);
	m_rtuStatusPage2.ShowWindow(SW_SHOW);

	if(m_bStatusPrivilege) {
		m_nCurStatus = (nCommandID == ID_VIEW_CONTROLLERSTATUS_UNMASKSTATUS) ? 0 : 1;
		if(!m_rtuStatusPage2.GetStatus(m_nCurStatus)) {
			if(m_pCboView) {
				m_pCboView->SetCurSel(0);
			}
		}
	}
}
void CRtuCtrlCfgDlg::OnViewCardAccessDiagnostics()
{
	GmsOutputDebugString(__FUNCTIONW__, __LINE__, _T("[RTU Config] Requesting Card Access Diagnostics... \n"));
	ProcessAccessControlCommand(ID_VIEW_CARDACCESSDIAGNOSTICS);
}
void CRtuCtrlCfgDlg::OnViewAccessControlCards()
{
	GmsOutputDebugString(__FUNCTIONW__, __LINE__, _T("[RTU Config] Requesting Access Control Cards... \n"));
	ProcessAccessControlCommand(ID_VIEW_ACCESSCONTROLCARDS);
}
void CRtuCtrlCfgDlg::OnViewSingleCard()
{
	GmsOutputDebugString(__FUNCTIONW__, __LINE__, _T("[RTU Config] Requesting Single Card... \n"));
	ProcessAccessControlCommand(ID_VIEW_SINGLECARDS);
}

void CRtuCtrlCfgDlg::OnViewPortErrors(UINT nCommandID)
{
	GmsOutputDebugString(__FUNCTIONW__, __LINE__, _T("[RTU Config] Requesting Port Diagnostics... \n"));
	int nPortNum = nCommandID - ID_VIEW_PORTERRORS_PORT1;
	if(realRtuType == RTU_8001_TYPE) {
		TRACE1("CRtuCtrlCfgDlg::OnViewPortErrors (nPortNum=%d)..\n", nPortNum);
		nPortNum = RTU8001_GetPortNumberFromPortIndex(nPortNum-1);
		if (nPortNum == 0)
			return;

		//switch(nPortNum) {
		//	case 1: nPortNum = 2; break;
		//	case 2: nPortNum = 3; break;
		//	case 3: nPortNum = 8; break;
		//	case 4: nPortNum = 9; break;
		//	case 5: nPortNum = 10; break;
		//	case 6: nPortNum = 11; break;
		//}
	}
	else if(realRtuType == RTU_1058_TYPE) {
		switch(nPortNum) {
			case 4: nPortNum = 8; break;
			case 5: nPortNum = 9; break;
		}
	}

	GetPortConfig(nCommandID, nPortNum, TRUE);
}
void CRtuCtrlCfgDlg::OnViewModemString1()
{
	GetPortConfig(ID_VIEW_MODEMSTRING1, PP_MODEM_STRING1_BLK);
}
void CRtuCtrlCfgDlg::OnViewModemString2()
{
	GetPortConfig(ID_VIEW_MODEMSTRING2, PP_MODEM_STRING2_BLK);
}
void CRtuCtrlCfgDlg::OnViewAlarmVocab()
{
	GmsOutputDebugString(__FUNCTIONW__, __LINE__, _T("[RTU Config] Requesting Alarm Vocab... \n"));
	ProcessAlarmCommand(ID_VIEW_ALARMVOCAB);
}

void CRtuCtrlCfgDlg::OnViewNetworkDiagnostics()
{
	GmsOutputDebugString(__FUNCTIONW__, __LINE__, _T("[RTU Config] Requesting Network Diagnostics... \n"));
	GetNetworkError();
}

// Commands...
//#pragma region RTU System Commands

int CRtuCtrlCfgDlg::GetRtuSystemCommand(int nOption)
{
	int nCommand = 0;

	if(nOption == BATTERY_TEST_CMD)
		nCommand = BATTERY_TEST_CMD;
	else if(nOption == PROG_INOV_TX_CMD)
		nCommand = PROG_INOV_TX_CMD;
	else if(nOption == SHUTDOWN_HDD_CMD)
		nCommand = SHUTDOWN_HDD_CMD;
	else if(nOption == PACOM_VAULT_CTRL_CMD)
		nCommand = PACOM_VAULT_CTRL_CMD;
	else
		nCommand = rtu_command[nOption];
	return nCommand;
}

int CRtuCtrlCfgDlg::GetCommandOption(int nMenuOption)
{
	int nCommandOption = -1;
	
	switch(nMenuOption) {
		// Controller Commands...
		case ID_CONTROLLERCOMMANDS_DIALCONTROLLER:				nCommandOption = -1;	break;
		case ID_CONTROLLERCOMMANDS_FORCEOFFDIALUP:				nCommandOption = 6;		break;
		case ID_CONTROLLERCOMMANDS_CHANGELINECARDCONNECTION: 	nCommandOption = 24;	break;
		case ID_CONTROLLERCOMMANDS_GETCONTROLLERTIMEZONES: 		nCommandOption = 21;	break;
		case ID_CONTROLLERCOMMANDS_SETCONTROLLERTIMEZONE: 		nCommandOption = 22;	break;
		case ID_CONTROLLERCOMMANDS_FORCECONTROLLEROFFLINE: 		nCommandOption = 0;		break;
		case ID_CONTROLLERCOMMANDS_FORCECONTROLLERONLINE: 		nCommandOption = 1;		break;
		//case ID_CONTROLLERCOMMANDS_WRITETOEEPROM: 				nCommandOption = 23;	break;
		case ID_WRITETOEEPROM_INTERNAL: 						nCommandOption = 23;	break;
		case ID_WRITETOEEPROM_EXTERNAL: 						nCommandOption = 23;	break;
		case ID_CONTROLLERCOMMANDS_SETLISTEN:					nCommandOption = 29;	break;
		case ID_CONTROLLERCOMMANDS_SETFACILITYCODE: 			nCommandOption = 28;	break;
		case ID_CONTROLLERCOMMANDS_SHUTDOWNHARDDRIVE: 			nCommandOption = 56;	break;
		
		// Mode Commands...
		case ID_MODECOMMANDS_DAYMODE:							nCommandOption = 2;		break; 
		case ID_MODECOMMANDS_NIGHTMODE:							nCommandOption = 3;		break; 
		case ID_MODECOMMANDS_RESTRICTEDMODE:					nCommandOption = 4;		break; 
		case ID_MODECOMMANDS_ENTERMODE:							nCommandOption = 4;		break; 
		case ID_MODECOMMANDS_EXITMODE:							nCommandOption = 5;		break; 

		// Keypad Commands...
		case ID_KEYPADCOMMANDS_ENABLEKEYPAD:					nCommandOption = 14;	break;
		case ID_KEYPADCOMMANDS_DISABLEKEYPAD:					nCommandOption = 13;	break;
		case ID_KEYPADCOMMANDS_RESETKEYPADTOIDLE:				nCommandOption = 15;	break;
		case ID_CONTROLLERCOMMANDS_RESETPSPTOIDLE:				nCommandOption = 15;	break;
		case ID_KEYPADCOMMANDS_DISPLAYKEYPADMESSAGE:			nCommandOption = -1;	break;
		case ID_KEYPADCOMMANDS_ISOLATEKEYPAD:					nCommandOption = -1;	break;
		case ID_KEYPADCOMMANDS_DEISOLATEKEYPAD:					nCommandOption = -1 ;	break;

		// Error Statistics Commands...
		case ID_ERRORSTATISTICS_RESETALLERRORSTATISTICS:		nCommandOption = 9;		break;
		case ID_ERRORSTATISTICS_RESETALARMERRORSTATISTICS:		nCommandOption = 10;	break; 
		case ID_ERRORSTATISTICS_RESETCOMMSERRORSTATISTICS:		nCommandOption = 11;	break; 
		case ID_ERRORSTATISTICS_RESETDIALUPERRORSTATISTICS:		nCommandOption = 12;	break; 

		// Test Commands...
		case ID_TEST_PERFORMDIALUPTEST:							nCommandOption = 26;	break; 
		case ID_TEST_PERFORMBATTERYTEST:						nCommandOption = 47;	break; 
		case ID_TEST_PERFORMSEISMICTEST:						nCommandOption = 61;	break; 
		case ID_TEST_PERFORMREMOTEMAINTENANCETEST:				nCommandOption = -1;	break; 

		// Other Commands...
		case ID_COMMANDS_RESETALLALARMS:						nCommandOption = 7;	break;
		case ID_COMMANDS_RESESALLOUTPUTS:						nCommandOption = 7;	break;
		case ID_COMMANDS_SYSTEMRESET:							nCommandOption = 7;	break;
		case ID_COMMANDS_RESTOREINPUT:							nCommandOption = 16;	break;
		case ID_COMMANDS_ISOLATEINPUT:							nCommandOption = -1;	break;
		case ID_COMMANDS_DEISOLATEINPUT:						nCommandOption = -1;	break;
		case ID_COMMANDS_RESTOREOUTPUT:							nCommandOption = -1;	break;
		case ID_COMMANDS_ISOLATEOUTPUT:							nCommandOption = -1;	break;
		case ID_COMMANDS_DEISOLATEOUTPUT:						nCommandOption = -1;	break;
		case ID_COMMANDS_OPENVAULT:								nCommandOption = -1;	break;
		case ID_COMMANDS_PROGRAMINOVONICSTRANSMITTER:			nCommandOption = -1;	break;
		case ID_COMMANDS_USERDEFINECOMMANDS:					nCommandOption = -1;	break;

		default: break;
	}

	return nCommandOption;
}

void CRtuCtrlCfgDlg::ExecuteSystemCommand(UINT nCommandID)
{
	LPPARMPROC lpps = m_lpps;
	HWND hDlg = GetSafeHwnd();

	if((lpps = GetLPPARMPROC(hDlg, m_option=8, m_rtups, TRUE)) == NULL)
		return;

	lpps->BlkNo = 0;
	memcpy(&m_lpps2, lpps, sizeof(m_lpps2));

	int pointNumber = -1; 
	switch(nCommandID) {
		case ID_CONTROLLERCOMMANDS_SETCONTROLLERTIMEZONE: // SET_TIMEZONE_CMD: 
			GmsOutputDebugString(__FUNCTIONW__, __LINE__, _T("[RTU Config] Set Controller Timezone... \n"));
			memset(&m_lpps2, 0, sizeof(m_lpps2));
			m_lpps2.lpData = m_lpps2Data;
			m_lpps2.heDlg = m_hWnd;
			m_lpps2.Id = SetTimeZoneReferenceCMD; // lpps->Id;
			m_lpps2.eNo = lpps->eNo; m_lpps2.eType = lpps->eType;
			break;
		case ID_KEYPADCOMMANDS_DISPLAYKEYPADMESSAGE:
			CKeypadMessageDlg* pDlg; pDlg = new CKeypadMessageDlg();
			if(pDlg) { //Always evaluates to true
				if(pDlg->DoModal() == IDOK) {
					GmsOutputDebugString(__FUNCTIONW__, __LINE__, _T("[RTU Config] Display Keypad Message... \n"));
					SendKeypadMsg(m_nRtuNumber-1, pDlg->GetKeypadNumber() - 1, pDlg->GetKeypadMessage());
				}
				delete pDlg; pDlg = NULL;
			}										 
			return;

		case ID_KEYPADCOMMANDS_ISOLATEKEYPAD:
			pointNumber = RtuLib::GetInputNumber(IDS_KPD_NUM);
			if(pointNumber <= 0)
				return;
			GmsOutputDebugString(__FUNCTIONW__, __LINE__, _T("[RTU Config] Isolate Keypad... \n"));
			SendIsolateCmd(m_nRtuNumber-1, pointNumber-1, KEYPAD_OBJ, 1, NULL);
			return;

		case ID_KEYPADCOMMANDS_DEISOLATEKEYPAD: 
			pointNumber = RtuLib::GetInputNumber(IDS_KPD_NUM);
			if(pointNumber <= 0)
				return;
			GmsOutputDebugString(__FUNCTIONW__, __LINE__, _T("[RTU Config] De-Isolate Keypad... \n"));
			SendIsolateCmd(m_nRtuNumber-1, pointNumber-1, KEYPAD_OBJ, 0, NULL);
			return;

		case ID_COMMANDS_ACCESSCONTROLCOMMANDS: 
			CReaderCommandDlg* pDlg2; pDlg2 = new CReaderCommandDlg(m_nRtuNumber, this);
			if(pDlg2) { //Always evaluates to true
				if(pDlg2->DoModal() == IDOK) {
					GmsOutputDebugString(__FUNCTIONW__, __LINE__, _T("[RTU Config] Access Controll Commands... \n"));
				}
				delete pDlg2; pDlg2 = NULL;
			}
			return;

		case ID_COMMANDS_ISOLATEINPUT:
			pointNumber = RtuLib::GetInputNumber(IDS_INPUT_NUMBER);
			if(pointNumber <= 0)
				return;
			GmsOutputDebugString(__FUNCTIONW__, __LINE__, _T("[RTU Config] Isolate Input... \n"));
			SendIsolateCmd(m_nRtuNumber-1, pointNumber-1, INPUT_OBJ, 1, NULL);
			return;
			
		case ID_COMMANDS_DEISOLATEINPUT:
			pointNumber = RtuLib::GetInputNumber(IDS_INPUT_NUMBER);
			if(pointNumber <= 0)
				return;
			GmsOutputDebugString(__FUNCTIONW__, __LINE__, _T("[RTU Config] De-Isolate Input... \n"));
			SendIsolateCmd(m_nRtuNumber-1, pointNumber-1, INPUT_OBJ, 0, NULL);
			return;

		case ID_COMMANDS_ACTIVATEOUTPUT:
			pointNumber = RtuLib::GetInputNumber(IDS_OUT_NUM);
			if(pointNumber <= 0)
				return;
			GmsOutputDebugString(__FUNCTIONW__, __LINE__, _T("[RTU Config] Activate Output... \n"));
			SendOnOffCmd(m_nRtuNumber-1, pointNumber-1, 1, NULL);
			return;

		case ID_COMMANDS_DEACTIVATEOUTPUT:
			pointNumber = RtuLib::GetInputNumber(IDS_OUT_NUM);
			if(pointNumber <= 0)
				return;
			GmsOutputDebugString(__FUNCTIONW__, __LINE__, _T("[RTU Config] De-Activate Output... \n"));
			SendOnOffCmd(m_nRtuNumber-1, pointNumber-1, 0, NULL);
			return;

		case ID_COMMANDS_ISOLATEOUTPUT:
			pointNumber = RtuLib::GetInputNumber(IDS_OUT_NUM);
			if(pointNumber <= 0)
				return;
			GmsOutputDebugString(__FUNCTIONW__, __LINE__, _T("[RTU Config] Isolate Output... \n"));
			SendIsolateCmd(m_nRtuNumber-1, pointNumber-1, OUTPUT_OBJ, 1, NULL);
			return;

		case ID_COMMANDS_DEISOLATEOUTPUT:
			pointNumber = RtuLib::GetInputNumber(IDS_OUT_NUM);
			if(pointNumber <= 0)
				return;
			GmsOutputDebugString(__FUNCTIONW__, __LINE__, _T("[RTU Config] De-Isolate Output... \n"));
			SendIsolateCmd(m_nRtuNumber-1, pointNumber-1, OUTPUT_OBJ, 2, NULL);
			return;

		case ID_COMMANDS_OPENVAULT:
			CSysCmdSelectOptionDlg* pDlg3; pDlg3 = new CSysCmdSelectOptionDlg(PACOM_VAULT_CTRL_CMD, this);
			if(pDlg3) { //Always evaluates to true
				if(pDlg3->DoModal() == IDOK) {
					GmsOutputDebugString(__FUNCTIONW__, __LINE__, _T("[RTU Config] Open Vault Command... \n"));
					DoPacomVaultCommand(GetSafeHwnd(), m_nRtuNumber-1, pDlg3->GetSelectedOption(), pDlg3->GetSelectedOption2(), pDlg3->GetFlags());
				}
				delete pDlg3; pDlg3 = NULL;
			}
			m_wndStatusBar.SetPaneText(0, _T(""));
			return;

		case ID_COMMANDS_PROGRAMINOVONICSTRANSMITTER: {
			CInovonicsCommandDlg dlg(m_nRtuNumber-1, this);
			if(dlg.DoModal() == IDOK) {
				GmsOutputDebugString(__FUNCTIONW__, __LINE__, _T("[RTU Config] Program Inovonics Transmitter... \n"));
			}
			m_wndStatusBar.SetPaneText(0, _T(""));
			}
			return;

		default:
			break;
	}

	if(m_pSystemCommandsObj == NULL) {
		m_pSystemCommandsObj = new CRtuSystemCommands(this);
	}
	if(m_pSystemCommandsObj != NULL) {
		int dbyte = -1;
		int nMode = -1;
		if(nCommandID == ID_MODECOMMANDS_RESTRICTEDMODE)
			nMode = 6;	// restricted mode index
		switch(nCommandID) {
			case ID_COMMANDS_RESETALLALARMS:	dbyte = 2;		break;
			case ID_COMMANDS_RESESALLOUTPUTS:	dbyte = 1;		break;
			case ID_COMMANDS_SYSTEMRESET:		dbyte = 3;		break;
			case ID_POWER_MONITOR_ALL:			dbyte = 0xff;	break;
			case ID_POWER_MONITOR_1:			dbyte = 0;		break;
			case ID_POWER_MONITOR_2:			dbyte = 1;		break;
			case ID_POWER_MONITOR_3:			dbyte = 2;		break;
			case ID_POWER_MONITOR_4:			dbyte = 3;		break;
		}

		m_pSystemCommandsObj->ExecuteSystemCommand(&m_lpps2, nCommandID, dbyte, nMode);	
	}
}

void CRtuCtrlCfgDlg::OnCommandFirmware(UINT nCommandID)
{
	LPPARMPROC lpps = m_lpps;
	HWND hDlg = GetSafeHwnd();
	
	switch(nCommandID) {
		case ID_FIRMWARECOMMANDS_VIEWFIRMWAREVERSION: {
			if((lpps = GetLPPARMPROC(hDlg, m_option=2, m_rtups, TRUE)) == NULL)
				return;
			GmsOutputDebugString(__FUNCTIONW__, __LINE__, _T("[RTU Config] Requesting Firmware Version... \n"));
			CRtuVersion* pDlg = NULL;
			pDlg = new CRtuVersion(lpps, CWnd::FromHandle(hDlg));
			if(pDlg != NULL) { //Always evaluates to true
				pDlg->DoModal();
				delete pDlg; pDlg = NULL;
			}

		}
		break;
		case ID_FIRMWARECOMMANDS_RESTARTUSINGLATESTVERSION: 
		case ID_FIRMWARECOMMANDS_RESTARTUSINGCHIP1VERSION: 
		case ID_FIRMWARECOMMANDS_RESTARTUSINGCHIP2VERSION: {
			if(!FindAccPriv(A_SW_CMDS, CHK_EDIT|CHK_ACCESS, CHK_VIEW|CHK_RESET))
				return;

			if((lpps = GetLPPARMPROC(hDlg, m_option=8, m_rtups, TRUE)) == NULL)
				return;

			GmsOutputDebugString(__FUNCTIONW__, __LINE__, _T("[RTU Config] Executing Firmware Command... \n"));
			lpps->Id = SW_RESET_CMD;
			lpps->BlkNo = 0;
			int nCommand = nCommandID - ID_FIRMWARECOMMANDS_RESTARTUSINGLATESTVERSION;
			send_rtu_cmd(lpps, SW_RESET_CMD, nCommand, HIRESP, 0, FALSE, 0);
		}
		break;
		case ID_FIRMWARECOMMANDS_OTHERFIRMWARECOMMANDS: {
			if((lpps = GetLPPARMPROC(hDlg, m_option=7, m_rtups, TRUE)) == NULL)
				return;

			if (RtuType==RTU_1003_TYPE)
				return;

			gHSoftCmdsDlg = SW_HIDE;
			lpps->lpProc = MakeProcInstance((FARPROC)ExecSoftCmds, hrInst);
			CreateDialogParam(hrInst, _T("SOFTWARECMDS"), hDlg,
				(DLGPROC)lpps->lpProc, (LPARAM)lpps);
		}
		break;
	default: break;
	}
}
void CRtuCtrlCfgDlg::OnCommandController(UINT nCommandID)
{
	GmsOutputDebugString(__FUNCTIONW__, __LINE__, _T("[RTU Config] Executing Controller Command ... \n"));
	if(nCommandID == ID_CONTROLLERCOMMANDS_DIALCONTROLLER) {
		try{
			if(m_nRtuNumber > 0)
				SendRtuDialoutCmd(GetSafeHwnd(), m_nRtuNumber - 1);
		} catch (...) {
		}
	}
	else {
		ExecuteSystemCommand(nCommandID);
	}
}
void CRtuCtrlCfgDlg::OnCommandControllerWriteToEEPROM(UINT nCommandID)
{
	GmsOutputDebugString(__FUNCTIONW__, __LINE__, _T("[RTU Config] Write to EEPROM ... \n"));
	ExecuteSystemCommand(nCommandID);
}

void CRtuCtrlCfgDlg::OnCommandMode(UINT nCommandID)
{
	GmsOutputDebugString(__FUNCTIONW__, __LINE__, _T("[RTU Config] Execute Mode Command... \n"));
	ExecuteSystemCommand(nCommandID);
}

void CRtuCtrlCfgDlg::OnCommandKeypad(UINT nCommandID)
{
	GmsOutputDebugString(__FUNCTIONW__, __LINE__, _T("[RTU Config] Execute Keypad Command... \n"));
	ExecuteSystemCommand(nCommandID);
}
void CRtuCtrlCfgDlg::OnCommandErrorStatistics(UINT nCommandID)
{
	ExecuteSystemCommand(nCommandID);
}
void CRtuCtrlCfgDlg::OnCommandTest(UINT nCommandID)
{
	ExecuteSystemCommand(nCommandID);
}

void CRtuCtrlCfgDlg::OnCommandTestFirePowerBattery(UINT nCommandID)
{
	GmsOutputDebugString(__FUNCTIONW__, __LINE__, _T("[RTU Config] Execute Test Fire Power Command... \n"));
	ExecuteSystemCommand(nCommandID);
}

void CRtuCtrlCfgDlg::OnCommandShutdownHardDrive(UINT nCommandID)
{
	GmsOutputDebugString(__FUNCTIONW__, __LINE__, _T("[RTU Config] Execute Shut Down Hard Drive Command... \n"));
	if(realRtuType != RTU_2000_TYPE)
		return;

	int nOption = nCommandID - ID_SHUTDOWN_HARDDRIVE_PRIMARY;
	DoShutdownHDD(GetSafeHwnd(), m_nRtuNumber-1, nOption);
}

void CRtuCtrlCfgDlg::OnCommandAccessControl()
{
	GmsOutputDebugString(__FUNCTIONW__, __LINE__, _T("[RTU Config] Execute Access Controll Command... \n"));
	ExecuteSystemCommand(ID_COMMANDS_ACCESSCONTROLCOMMANDS);
}

void CRtuCtrlCfgDlg::OnCommandResetAllAlarms()
{
	GmsOutputDebugString(__FUNCTIONW__, __LINE__, _T("[RTU Config] Reset All Alarms... \n"));
	ExecuteSystemCommand(ID_COMMANDS_RESETALLALARMS);
}
void CRtuCtrlCfgDlg::OnCommandResetAllOutputs()
{
	GmsOutputDebugString(__FUNCTIONW__, __LINE__, _T("[RTU Config] Reset All Outputs... \n"));
	ExecuteSystemCommand(ID_COMMANDS_RESESALLOUTPUTS);
}
void CRtuCtrlCfgDlg::OnCommandResetAllAlarmsAndOutputs()
{
	GmsOutputDebugString(__FUNCTIONW__, __LINE__, _T("[RTU Config] Reset All Alarms and Outputs... \n"));
	ExecuteSystemCommand(ID_COMMANDS_SYSTEMRESET);
}

void CRtuCtrlCfgDlg::OnCommandRestoreInput()
{
	GmsOutputDebugString(__FUNCTIONW__, __LINE__, _T("[RTU Config] Restore an Input... \n"));
	ExecuteSystemCommand(ID_COMMANDS_RESTOREINPUT);
}
void CRtuCtrlCfgDlg::OnCommandIsolateInput()
{
	GmsOutputDebugString(__FUNCTIONW__, __LINE__, _T("[RTU Config] Isolate an Input... \n"));
	ExecuteSystemCommand(ID_COMMANDS_ISOLATEINPUT);
}
void CRtuCtrlCfgDlg::OnCommandDeisolateInput()
{
	GmsOutputDebugString(__FUNCTIONW__, __LINE__, _T("[RTU Config] Deisolate an Input... \n"));
	ExecuteSystemCommand(ID_COMMANDS_DEISOLATEINPUT);
}

void CRtuCtrlCfgDlg::OnCommandGroupCommand()
{
	ExecuteSystemCommand(ID_COMMANDS_GROUPCOMMANDS);
}

void CRtuCtrlCfgDlg::OnCommandRestoreOutput()
{
}

void CRtuCtrlCfgDlg::OnCommandActivateOutput()
{
	GmsOutputDebugString(__FUNCTIONW__, __LINE__, _T("[RTU Config] Activating an Output... \n"));
	ExecuteSystemCommand(ID_COMMANDS_ACTIVATEOUTPUT);
}
	
void CRtuCtrlCfgDlg::OnCommandDeactivateOutput()
{
	GmsOutputDebugString(__FUNCTIONW__, __LINE__, _T("[RTU Config] De-activating an Output... \n"));
	ExecuteSystemCommand(ID_COMMANDS_DEACTIVATEOUTPUT);
}

void CRtuCtrlCfgDlg::OnCommandIsolateOutput()
{
	GmsOutputDebugString(__FUNCTIONW__, __LINE__, _T("[RTU Config] Isolate an Output... \n"));
	ExecuteSystemCommand(ID_COMMANDS_ISOLATEOUTPUT);
}
void CRtuCtrlCfgDlg::OnCommandDeisolateOutput()
{
	GmsOutputDebugString(__FUNCTIONW__, __LINE__, _T("[RTU Config] De-Isolate an Output... \n"));
	ExecuteSystemCommand(ID_COMMANDS_DEISOLATEOUTPUT);
}
void CRtuCtrlCfgDlg::OnCommandOpenVault()
{
	GmsOutputDebugString(__FUNCTIONW__, __LINE__, _T("[RTU Config] Open Vault Command... \n"));
	ExecuteSystemCommand(ID_COMMANDS_OPENVAULT);
}
void CRtuCtrlCfgDlg::OnCommandProgramInovonicsTransmitter()
{
	GmsOutputDebugString(__FUNCTIONW__, __LINE__, _T("[RTU Config] Programmning Inovonics Transmitter... \n"));
	ExecuteSystemCommand(ID_COMMANDS_PROGRAMINOVONICSTRANSMITTER);
}
void CRtuCtrlCfgDlg::OnCommandUserDefineCommand()
{
	GmsOutputDebugString(__FUNCTIONW__, __LINE__, _T("[RTU Config] User Defined Command... \n"));
	CRtuUserDefinedCmdDlg* pDlg = new CRtuUserDefinedCmdDlg(m_nRtuNumber, this);
	if(pDlg) { //Always evaluates to true
		pDlg->DoModal();
		delete pDlg; pDlg = NULL;
	}

	m_wndStatusBar.SetPaneText(0, _T(""));
}

void CRtuCtrlCfgDlg::OnCommandUserDefineCommandRange(UINT nCommandID)
{
	GmsOutputDebugString(__FUNCTIONW__, __LINE__, _T("[RTU Config] Executing User Defined Command... \n"));
	int nIndex = nCommandID - ID_USER_DEFINED_COMMAND_1;
	if(nIndex >= strArrUserDefinedCommands.GetCount())
		return;

	TCHAR 	str[262] = { 0 }, str1[32] = { 0 };
	UINT fc, etype, eno, fn=0;
	TCHAR text[240] = { 0 }, port = 0;

	_stprintf_s(str1, _T("%s"), (LPCTSTR)strArrUserDefinedCommands.GetAt(nIndex));
	if (GetPrivateProfileString(_T("User Commands"), str1, NULL, str, 260, DefaultLocation(USERCMD_CFG_FILE).Path)) {
		if (sscanfx(str, _T("%u, %u, %c, %u, %u, (%[^')']"), &etype, &eno, &port, &fc, 	&fn, text) >= 6) {
			CRtuUserDefinedCmdDlg::SendCommand(m_hWnd, m_nRtuNumber, (BYTE)fc, text);
		}
	}

}
void CRtuCtrlCfgDlg::OnCommandResetPspToIdle()
{
	GmsOutputDebugString(__FUNCTIONW__, __LINE__, _T("[RTU Config] Reset PSP... \n"));
	ExecuteSystemCommand(ID_CONTROLLERCOMMANDS_RESETPSPTOIDLE);
}

void CRtuCtrlCfgDlg::OnCommandEnableTriggerEvents()
{
	GmsOutputDebugString(__FUNCTIONW__, __LINE__, _T("[RTU Config] Enable Trigger Events... \n"));
	CRtuUserDefinedCmdDlg::SendCommand(m_hWnd, m_nRtuNumber, 46, _T("4,0x80,1"));
}

void CRtuCtrlCfgDlg::OnCommandDisableTriggerEvents()
{
	GmsOutputDebugString(__FUNCTIONW__, __LINE__, _T("[RTU Config] Disable Trigger Events... \n"));
	CRtuUserDefinedCmdDlg::SendCommand(m_hWnd, m_nRtuNumber, 46, _T("4,0x80,0"));
}

void CRtuCtrlCfgDlg::OnCommandProgramEOLResistor()
{
	GmsOutputDebugString(__FUNCTIONW__, __LINE__, _T("[RTU Config] Program EOL Resistor... \n"));
	int nAlarmResistorValue = 0;
	int nSecureResistorValue = 0;

	if(RtuLib::GetInputNumber2(nAlarmResistorValue, nSecureResistorValue, 
		IDS_ALARM_RESISTOR_VALUE, IDS_SECURE_RESISTOR_VALUE, IDS_EOL_RESISTOR_VALUE)) {
		CString strData; strData.Format(_T("4,0x90,1,%d,%d"), (BYTE)nAlarmResistorValue, (BYTE)nSecureResistorValue);
		CRtuUserDefinedCmdDlg::SendCommand(m_hWnd, m_nRtuNumber, 46, strData);
	}

}

void CRtuCtrlCfgDlg::OnCommandEnableRemoteCommands()
{
	GmsOutputDebugString(__FUNCTIONW__, __LINE__, _T("[RTU Config] Enable Remote commands... \n"));
	CRtuUserDefinedCmdDlg::SendCommand(m_hWnd, m_nRtuNumber, 21, _T("58,0"));
}

void CRtuCtrlCfgDlg::OnCommandDisableRemoteCommands()
{
	GmsOutputDebugString(__FUNCTIONW__, __LINE__, _T("[RTU Config] Disable Remote Commands... \n"));
	CRtuUserDefinedCmdDlg::SendCommand(m_hWnd, m_nRtuNumber, 21, _T("58,1"));
}

//#pragma endregion RTU System Commands

// Generals...
void CRtuCtrlCfgDlg::OnGeneralControllerType()
{
	GmsOutputDebugString(__FUNCTIONW__, __LINE__, _T("[RTU Config] Controller Type... \n"));
	LPPARMPROC lpps = NULL;
	HWND hDlg = GetSafeHwnd();

	if((lpps = GetLPPARMPROC(hDlg, m_option=6, m_rtups, TRUE)) == NULL)
		return;

	if (RtuType==RTU_1003_TYPE)
		return;

	lpps->BlkNo = (BYTE)RAPType;
	lpps->BC = (uchar)AlmCnt;
	if (ExecDialogBoxParam(hrInst, _T("SETPANELTYPE"), hDlg, EditRtuPanelType, (LPARAM)lpps)) {
		RAPType = PanelType = lpps->BlkNo;
		InitRtuOptions(hDlg, &m_rtups);
	}
}

void CRtuCtrlCfgDlg::OnGeneralControllerPasswords()
{
	GmsOutputDebugString(__FUNCTIONW__, __LINE__, _T("[RTU Config] Requesting Controller Password... \n"));
	GetPortConfig(ID_GENERAL_CONTROLLERPASSWORD, PP_PASSWORD_BLK);
}
void CRtuCtrlCfgDlg::OnGeneralPeerToPeerSettings()
{
	GmsOutputDebugString(__FUNCTIONW__, __LINE__, _T("[RTU Config] Requesting Peer To Peer Settings... \n"));
	GetPortConfig(ID_GENERAL_PEERTOPEERSETTINGS, PP_PORT_PEER_BLK);
}

void CRtuCtrlCfgDlg::OnGeneralTFTPServerSettings()
{
	GmsOutputDebugString(__FUNCTIONW__, __LINE__, _T("[RTU Config] Requesting TFTP Server Settings... \n"));
	GetPortConfig(ID_GENERAL_TFTPSETTINGS, PP_PORT_PEER_BLK);
}

void CRtuCtrlCfgDlg::OnGeneralAlarmEventsFilter()
{
	GmsOutputDebugString(__FUNCTIONW__, __LINE__, _T("[RTU Config] Requesting Message Filters... \n"));
	GetPortConfig(ID_GENERAL_ALARMEVENTSFILTER, PP_MESSAGE_FILTER_BLK);
}
void CRtuCtrlCfgDlg::OnGeneralYearlyCalendarAlarms()
{
	GmsOutputDebugString(__FUNCTIONW__, __LINE__, _T("[RTU Config] Requesting Alarm Yearly Calendar... \n"));
	ProcessAlarmCommand(ID_YEARLYCALENDAR_ALARMS);
}
void CRtuCtrlCfgDlg::OnGeneralYearlyCalendarCardAccess()
{
	GmsOutputDebugString(__FUNCTIONW__, __LINE__, _T("[RTU Config] Requesting Card Access Yearly Calendar... \n"));
	ProcessAccessControlCommand(ID_YEARLYCALENDAR_CARDACCESS);
}
void CRtuCtrlCfgDlg::OnGeneralControllerSettings()
{
	GmsOutputDebugString(__FUNCTIONW__, __LINE__, _T("[RTU Config] Requesting General Controller Settings... \n"));
	GetPortConfig(ID_GENERAL_CONTROLLERSETTINGS, PP_GENERAL_SYSTEM_BLK);
}
void CRtuCtrlCfgDlg::OnGeneralPortSettings()
{
	LPPARMPROC lpps = m_lpps;
	HWND hDlg = GetSafeHwnd();
	if((lpps = GetLPPARMPROC(hDlg, m_option=10, m_rtups, TRUE)) == NULL)
		return;

	if(RtuLib::IsNewControllerType(realRtuType)) {
		bShowAdvancedPortParams = FALSE;
	}

	if (realRtuType==RTU_MOSLER_1003_TYPE || realRtuType==RTU_MOSLER_1001_TYPE) {	//.Time Zone offset
		ExecDialogBoxParam(hrInst, _T("M1003TZ"), hDlg, EditM1003TimeZone, (LPARAM)lpps);
		}
	else if (realRtuType==RTU_1057_TYPE) {
		ExecDialogBoxParam(hrInst, _T("RTU1057PPS"), hDlg, Edit1057Ports, (LPARAM)lpps);
		}
	else if (realRtuType==RTU_1058_TYPE) {
		ExecDialogBoxParam(hrInst, _T("RTU1058PPS"), hDlg, Edit1058Ports, (LPARAM)lpps);
		}
	else if (realRtuType==RTU_2000_TYPE) {
		ExecDialogBoxParam(hrInst, _T("VCU2000PPS"), hDlg, EditVCU2000Ports, (LPARAM)lpps);
		}
	else if(realRtuType == RTU_8001_TYPE) {
		ExecDialogBoxParam(hrInst, _T("RTU8001PPS"), hDlg, Edit8001Ports, (LPARAM)lpps);
	}
	else if (PanelType==SRTU_TYPE) {	//.Stand alone SRTU donot support
		return;
	}
	else {
		ExecDialogBoxParam(hrInst, _T("RTUPPS"), hDlg, Edit1026Ports, (LPARAM)lpps);
	}
}
void CRtuCtrlCfgDlg::OnGeneralSNMPSettings()
{
	GmsOutputDebugString(__FUNCTIONW__, __LINE__, _T("[RTU Config] Requesting SNMP Settings... \n"));
	GetPortConfig(ID_GENERAL_SNMPSETTINGS, PP_SNMP_BLK);
}
void CRtuCtrlCfgDlg::OnGeneralPowerSupplySettings()
{
	GmsOutputDebugString(__FUNCTIONW__, __LINE__, _T("[RTU Config] Requesting Power Settings... \n"));
	GetPortConfig(ID_GENERAL_POWERSUPPLYSETTINGS, PP_BATT_TEST_BLK);
}
void CRtuCtrlCfgDlg::OnGeneralRemoteMaintenanceSettings()
{
	GmsOutputDebugString(__FUNCTIONW__, __LINE__, _T("[RTU Config] Requesting Remote Maintenance Settings... \n"));
	GetPortConfig(ID_GENERAL_REMOTEMAINTENANCESETTINGS, PP_REMOTE_MAINT_DT_BLK);
}
void CRtuCtrlCfgDlg::OnGeneralPSPSettings()
{
	GmsOutputDebugString(__FUNCTIONW__, __LINE__, _T("[RTU Config] Requesting PSP Settings... \n"));
	GetPortConfig(ID_GENERAL_PSPSETTINGS, PP_PSP_BLK);
}
void CRtuCtrlCfgDlg::OnGeneralGPIPSettings()
{
	GmsOutputDebugString(__FUNCTIONW__, __LINE__, _T("[RTU Config] Requesting GPIP Settings... \n"));
	GetPortConfig(ID_GENERAL_GPIPSETTINGS, PP_GPIP_PARAMS_BLK);
}
void CRtuCtrlCfgDlg::OnGeneralEMCSSettings()
{
	GmsOutputDebugString(__FUNCTIONW__, __LINE__, _T("[RTU Config] Requesting EMCS Settings... \n"));
	GetPortConfig(ID_GENERAL_EMCSSETTINGS, PP_EMCS_PARAMS_BLK);
}

// Alarm configuration...
LRESULT CRtuCtrlCfgDlg::OnAlarmHardwareConfigUploaded(WPARAM wParam, LPARAM)
{
	GmsOutputDebugString(__FUNCTIONW__, __LINE__, _T("[RTU Config] Controller Hardware Uploaded... \n"));
	m_wndStatusBar.SetPaneText(0, _T(""));
	BOOL bIsOK = (BOOL)wParam;
	if(bIsOK) {
		m_bIsValidAlarmCfg = TRUE;
		bAlarmHardwareUploaded = TRUE;
		m_rtuDevicesPage.CopyConfig();
		m_rtuDevicesPage.InitCoordinate();
		m_rtuDevicesPage.UpdateWindows();
		m_rtuStatusPage2.ShowWindow(SW_HIDE);
		m_rtuDevicesPage.ShowWindow(SW_SHOW);
		m_rtuDevicesPage.Invalidate();

		if(m_nCommandID > 0) {
			//ProcessAlarmCommand(m_nCommandID);
		}

		if(m_pCboView) {
			if(m_bStatusPrivilege)
				m_pCboView->SetEnabled(TRUE);
			m_pCboView->SetCurSel(1);
		}

		UploadCustomVocab(); // TT#5950
	}

	//SetCursor(LoadCursor(NULL, MAKEINTRESOURCE(IDC_ARROW)));
	return 0;
}

LRESULT CRtuCtrlCfgDlg::OnAlarmHardwareConfigDownloaded(WPARAM, LPARAM)
{
	GmsOutputDebugString(__FUNCTIONW__, __LINE__, _T("[RTU Config] Controller Hardware Downloaded... \n"));
	if(m_pDownloadMenu) {
		m_pDownloadMenu->SetEnabled(FALSE);
	}

	if(m_lpaps != NULL) {
		m_lpaps->BC = 5;
		*m_lpaps->lpData = SW_RESET_CMD;
        *(m_lpaps->lpData+1) = 0;
        *(m_lpaps->lpData+2) = RAUnit;
		*(m_lpaps->lpData+3) = 0;
        *(m_lpaps->lpData+4) = 0;
        send_rtu_cmd1(m_lpaps, HIRESP, 0, 0);
	}

	if(m_bWaitDownload) {
		OnDestroy();
	}
	else if(m_bReqChangeID) {
		OnChangeID();
		m_bReqChangeID = FALSE;
	}
	return 0;
}

LRESULT CRtuCtrlCfgDlg::OnConfigUploaded(WPARAM, LPARAM)
{
	if(pRtuCtrlCfgDlg == NULL)
		return 0;

	m_wndStatusBar.SetPaneText(0, _T(""));

	if(m_nPrintCfg == E_PRINT_ALL_ALARM) {
		m_nPrintCfg = E_PRINT_ALL_CARD_ACCESS;
		ProcessAccessControlCommand(ID_ACCESSCONTROL_ALL);
	}

	if(m_bReqCloseWindow) {
		OnDestroy();
	}
	return 0;
}

LRESULT CRtuCtrlCfgDlg::OnConfigDownloaded(WPARAM wParam, LPARAM lParam)
{
	if(pRtuCtrlCfgDlg == NULL)
		return 0;

	m_wndStatusBar.SetPaneText(0, _T(""));
	int msgType = (int)wParam;
	int msgSubType = (int)lParam;
	if((msgType == BMS_CONFIG_TYPE) && (msgSubType == BMS_GEN_CFG)) {
		GetGeneralBmsConfig();
	}

	if(m_bReqCloseWindow) {
		OnDestroy();
	}
	return 0;
}

LRESULT CRtuCtrlCfgDlg::OnConfigDownloading(WPARAM wParam, LPARAM)
{
	if(pRtuCtrlCfgDlg == NULL)
		return 0;

	int nDownloadStatus = (int)wParam;
	if(nDownloadStatus == CONFIG_START_DOWNLOADING) {
		m_bConfigDownloading = TRUE;
	}
	else if(nDownloadStatus == CONFIG_FINISH_DOWNLOADING){
		m_bConfigDownloading = FALSE;
		if(m_bReqCloseWindow) {
			OnDestroy();
		}
	}
	return 0;
}

LRESULT CRtuCtrlCfgDlg::OnConfigChanged(WPARAM wParam, LPARAM)
{
	if(m_pDownloadMenu) {
		m_pDownloadMenu->SetEnabled((BOOL)wParam);
	}

	return 0;
}

void CRtuCtrlCfgDlg::OnAlarmHardware()
{
	GmsOutputDebugString(__FUNCTIONW__, __LINE__, _T("[RTU Config] Requesting Hardware Upload... \n"));
	//SetCursor(LoadCursor(NULL, MAKEINTRESOURCE(IDC_WAIT)));

	m_nCommandID = ID_ALARM_HARDWARE;
	if(!m_bIsValidAlarmCfg || (GetKeyState(VK_SHIFT)&0x8000)) {
		m_rtuDevicesPage.Init();
		UploadConfiguration();
	}
	else {
		m_rtuStatusPage2.ShowWindow(SW_HIDE);
		m_rtuDevicesPage.ShowWindow(SW_SHOW);
	}
}

void CRtuCtrlCfgDlg::OnAlarmHardwareConfigure(UINT nCommandID)
{
	m_rtuStatusPage2.ShowWindow(SW_HIDE);
	m_rtuDevicesPage.ShowWindow(SW_SHOW);

	if(nCommandID == ID_ALARM_HARDWARE_ADDDEVICE) {
		m_rtuDevicesPage.AddNewDevice();
		return;
	}
	else if(nCommandID == ID_ALARM_HARDWARE_ADDKEYPAD) {
		m_rtuDevicesPage.AddNewKeypad();
		return;
	}
	else {
		m_rtuDevicesPage.Configure(nCommandID);
	}
}

void CRtuCtrlCfgDlg::OnAlarmHardwareVaultController()
{
	GmsOutputDebugString(__FUNCTIONW__, __LINE__, _T("[RTU Config] Requesting Vault Controller Settings... \n"));
	GetPortConfig(ID_HARDWARE_VAULT_CONTROLLER, PP_VAULT_CTRLS_BLK);
}

void CRtuCtrlCfgDlg::UploadConfiguration()
{
	LPPARMPROC lpps = m_lpps;
	HWND hDlg = GetSafeHwnd();
	if((lpps = GetLPPARMPROC(hDlg, m_option=0, m_rtups, TRUE)) == NULL) {
		AfxMessageBox(_T("GetLPPARMPROC Failed"));
		return;
	}
	bIsValidHardwareCfg = FALSE;
	if ((PanelType==P1060_TYPE || PanelType==PX8_TYPE || PanelType==P8001_TYPE)) {
		CRapWnd::EditP1060Params(lpps, SW_HIDE);
		lpps->hmDlg = GetSafeHwnd();
		::SendMessage(lpps->heDlg, WM_COMMAND, IDM_HARDWARE, 0);
	}
}

void CRtuCtrlCfgDlg::OnAlarmArea()
{
	GmsOutputDebugString(__FUNCTIONW__, __LINE__, _T("[RTU Config] Requesting Alarm Area Config... \n"));
	ProcessAlarmCommand(ID_ALARM_AREASETTINGS);
}

void CRtuCtrlCfgDlg::OnAlarmAccessHours(UINT nCommandID)
{
	GmsOutputDebugString(__FUNCTIONW__, __LINE__, _T("[RTU Config] Requesting Alarm Hours Config... \n"));
	ProcessAlarmCommand(nCommandID);
}

void CRtuCtrlCfgDlg::OnAlarmCounterSettings()
{
	GmsOutputDebugString(__FUNCTIONW__, __LINE__, _T("[RTU Config] Requesting Alarm Counter Config... \n"));
	ProcessBmsCommand(ID_ALARM_COUNTERSETTINGS);
}

//TT 8120
void CRtuCtrlCfgDlg::OnAlarmGlobalResistorSettings()
{
	OutputDebugString(_T("[RTU Config] Requesting Global Resistor Settings... \n"));
	ProcessAlarmCommand(ID_GLOBAL_RESISTOR_SETTINGS);
}

void CRtuCtrlCfgDlg::OnAlarmSystemParamters()
{
	GmsOutputDebugString(__FUNCTIONW__, __LINE__, _T("[RTU Config] Requesting Alarm System Config... \n"));
	ProcessAlarmCommand(ID_ALARM_ALARMSYSTEMPARAMETERS);
}

void CRtuCtrlCfgDlg::OnAlarmSystemFlags()
{
	GmsOutputDebugString(__FUNCTIONW__, __LINE__, _T("[RTU Config] Requesting Alarm System Flags... \n"));
	ProcessAlarmCommand(ID_ALARM_ALARMSYSTEMFLAGS);
}

void CRtuCtrlCfgDlg::OnAlarmUsers()
{
	GmsOutputDebugString(__FUNCTIONW__, __LINE__, _T("[RTU Config] Requesting Alarm Users Config... \n"));
	ProcessAlarmCommand(ID_ALARM_ALARMUSERS);
}

void CRtuCtrlCfgDlg::OnAlarmTemporarySchedule()
{
	GmsOutputDebugString(__FUNCTIONW__, __LINE__, _T("[RTU Config] Requesting Alarm Temp Schedule Config... \n"));
	ProcessAlarmCommand(ID_ALARM_TEMPORARYSCHEDULE);
}

void CRtuCtrlCfgDlg::OnAlarmTimeSchedules()
{
	GmsOutputDebugString(__FUNCTIONW__, __LINE__, _T("[RTU Config] Requesting Alarm Time Schedule Config... \n"));
	ProcessAlarmCommand(ID_ALARM_ALARMTIMESCHEDULES);
}


// Access control...
void CRtuCtrlCfgDlg::OnAccessControlAddReader()
{
	GmsOutputDebugString(__FUNCTIONW__, __LINE__, _T("[RTU Config] Requesting Access Control Single Reader Config... \n"));
	ProcessAccessControlCommand(ID_ACCESSCONTROL_HARDWARE_ADDREADER);

}
void CRtuCtrlCfgDlg::OnAccessControlReaders()
{
	GmsOutputDebugString(__FUNCTIONW__, __LINE__, _T("[RTU Config] Requesting Access Control Readers Config... \n"));
	ProcessAccessControlCommand(ID_ACCESSCONTROL_HARDWARE_READERS);
}
void CRtuCtrlCfgDlg::OnAccessControlAreaProfiles()
{
	GmsOutputDebugString(__FUNCTIONW__, __LINE__, _T("[RTU Config] Requesting Access Control Area Config... \n"));
	ProcessAccessControlCommand(ID_ACCESSCONTROL_AREAPROFILES);
}
void CRtuCtrlCfgDlg::OnAccessControlElevatorSettings()
{
	GmsOutputDebugString(__FUNCTIONW__, __LINE__, _T("[RTU Config] Requesting Access Control Elevator Config... \n"));
	ProcessAccessControlCommand(ID_ACCESSCONTROL_ELEVATORS_ELEVATORSETTINGS);
}
void CRtuCtrlCfgDlg::OnAccessControlUnlockedFloors()
{
	GmsOutputDebugString(__FUNCTIONW__, __LINE__, _T("[RTU Config] Requesting Access Control Floor Config... \n"));
	ProcessAccessControlCommand(ID_ACCESSCONTROL_ELEVATORS_UNLOCKFLOORS);
}
void CRtuCtrlCfgDlg::OnAccessControlCardTypeSettings()
{
	GmsOutputDebugString(__FUNCTIONW__, __LINE__, _T("[RTU Config] Requesting Access Control Card Type Config... \n"));
	ProcessAccessControlCommand(ID_ACCESSCONTROL_CARDTYPESETTINGS);
}
void CRtuCtrlCfgDlg::OnAccessControlCardFormats()
{
	GmsOutputDebugString(__FUNCTIONW__, __LINE__, _T("[RTU Config] Requesting Access Control Card Formats... \n"));
	ProcessAccessControlCommand(ID_ACCESSCONTROL_CARDFORMATS);
}
void CRtuCtrlCfgDlg::OnAccessControlTimeSchedules()
{
	GmsOutputDebugString(__FUNCTIONW__, __LINE__, _T("[RTU Config] Requesting Access Control Time Schedule Config... \n"));
	ProcessAccessControlCommand(ID_ACCESSCONTROL_ACCESSCONTROLTIMESCHEDULES);
}
void CRtuCtrlCfgDlg::OnAccessControlOpenCloseSchedule()
{
	GmsOutputDebugString(__FUNCTIONW__, __LINE__, _T("[RTU Config] Requesting Access Control Open/Close Schedule Config... \n"));
	ProcessAccessControlCommand(ID_ACCESSCONTROL_OPENCLOSESCHEDULES);
}
void CRtuCtrlCfgDlg::OnAccessControlOverallSettings()
{
	ProcessAccessControlCommand(ID_ACCESSCONTROL_OVERALL_SETTINGS);
}

// Building management...
void CRtuCtrlCfgDlg::OnbuildingManagementTFPTServerUpdate()
{
}
void CRtuCtrlCfgDlg::OnbuildingManagementTrendBmsSettings()
{
	GmsOutputDebugString(__FUNCTIONW__, __LINE__, _T("[RTU Config] Requesting Trend Bms Settings ... \n"));
	GetPortConfig(ID_BUILDINGMANAGEMENT_TRENDBMSSETTINGS, PP_TREND_BMS_BLK);
}
void CRtuCtrlCfgDlg::OnbuildingManagementModbusSettings()
{
	GmsOutputDebugString(__FUNCTIONW__, __LINE__, _T("[RTU Config] Requesting Mobus Settings... \n"));
	ProcessBmsCommand(ID_BUILDINGMANAGEMENT_MODBUSSETTINGS);
}
void CRtuCtrlCfgDlg::OnbuildingManagementBacnetSettings()
{
	GmsOutputDebugString(__FUNCTIONW__, __LINE__, _T("[RTU Config] Requesting BACNet Settings... \n"));
	ProcessBmsCommand(ID_BUILDINGMANAGEMENT_BACNETSETTINGS);
}

void CRtuCtrlCfgDlg::OnbuildingManagementGeneralSettings()
{
	GmsOutputDebugString(__FUNCTIONW__, __LINE__, _T("[RTU Config] Requesting General Bms Settings... \n"));
	ProcessBmsCommand(ID_BUILDINGMANAGEMENT_GENERALSETTING);
}

// Macros...
void CRtuCtrlCfgDlg::OnMacroAlarmEvents()
{
	GmsOutputDebugString(__FUNCTIONW__, __LINE__, _T("[RTU Config] Requesting Alarm Events Config... \n"));
	ProcessAlarmCommand(ID_MACROS_ALARMEVENTS);
}
void CRtuCtrlCfgDlg::OnMacroAlarmMacros()
{
	GmsOutputDebugString(__FUNCTIONW__, __LINE__, _T("[RTU Config] Requesting Alarm Macros Config... \n"));
	ProcessAlarmCommand(ID_MACROS_ALARMMACROS);

}
void CRtuCtrlCfgDlg::OnMacroReaderMacros()
{
	GmsOutputDebugString(__FUNCTIONW__, __LINE__, _T("[RTU Config] Requesting Reader Macros Config... \n"));
	ProcessAccessControlCommand(ID_MACROS_READERMACROS);
}
void CRtuCtrlCfgDlg::OnMacroBmsMacros()
{
	GmsOutputDebugString(__FUNCTIONW__, __LINE__, _T("[RTU Config] Requesting Bms Macros Config... \n"));
	ProcessBmsCommand(ID_MACROS_BMSMACROS);
}

BOOL CRtuCtrlCfgDlg::ProcessAlarmCommand(int nID)
{
	LPPARMPROC lpps = m_lpps;
	HWND hDlg = GetSafeHwnd();
	BOOL bRetVal = FALSE;
	if((lpps = GetLPPARMPROC(hDlg, m_option=0, m_rtups, TRUE)) == NULL)
		return bRetVal;

	m_lpaps = lpps;

	int wParam = -1;
	int lParam = 0;
	if ((PanelType==P1060_TYPE || PanelType==PX8_TYPE || PanelType==P8001_TYPE)) {
		if(nID == ID_ALARM_HARDWARE) {
			CRapWnd::EditP1060Params(lpps, SW_SHOW);
	
			::SendMessage(lpps->heDlg, WM_COMMAND, IDM_HARDWARE, 0);
			return TRUE;
		}

		CRapWnd::EditP1060Params(lpps, SW_HIDE);
		lpps->hmDlg = hDlg;
		
		switch(nID) {
		case ID_VIEW_ALARMVOCAB:						wParam = IDM_VIEW_VOCAB; break;
		case ID_YEARLYCALENDAR_ALARMS:					wParam = IDM_YEARLY_CAL; break;
		case ID_ALARM_HARDWARE_ADDDEVICE:				wParam = IDM_NEW_DEV; break;
		case ID_ALARM_HARDWARE_ADDKEYPAD:				wParam = IDM_NEW_KPD; break;
		case ID_ALARM_HARDWARE_IODEVICES:				wParam = IDM_RTU_DEVICE; break;
		case ID_ALARM_HARDWARE_INPUTS:					wParam = IDM_RTU_INPUT; break;
		case ID_ALARM_HARDWARE_ANALOGINPUTS:			wParam = IDM_RTU_ANALOGINPUT; break;
		case ID_ALARM_HARDWARE_OUTPUTS:					wParam = IDM_RTU_OUTPUT; break;
		case ID_ALARM_HARDWARE_FILMCAMERAS:				wParam = IDM_RTU_CAMERA; break;
		case ID_ALARM_HARDWARE_CCTVCAMERAS:				wParam = IDM_RTU_CCTVOUT; break;
		case ID_ALARM_HARDWARE_PULSECOUNTERS:			wParam = IDM_RTU_PULSE_COUNTER; break;
		case ID_ALARM_HARDWARE_KEYPADS:					wParam = IDM_RTU_KEYPAD; break;
		case ID_ALARM_AREASETTINGS:						wParam = IDM_AREA; break;
		case ID_ALARM_AREAACCESS_NORMALHOURS:			wParam = IDM_DFLT_HRS; break;
		case ID_ALARM_AREAACCESS_TEMPORARYHOURS:		wParam = IDM_TEMP_HRS; break;
		case ID_ALARM_AREAACCESS_ATMHOURS:				wParam = IDM_ATM_HRS; break;
		case ID_ALARM_AREAACCESS_CLEANERHOURS:			wParam = IDM_CLNR_HRS; break;
		case ID_ALARM_AREAACCESS_GUARDHOURS:			wParam = IDM_GUARD_HRS; break;
		case ID_ALARM_AREAACCESS_SERVICEHOURS:			wParam = IDM_SERVICE_HRS; break;
		case ID_ALARM_ALARMSYSTEMPARAMETERS:			wParam = IDM_PARAMETERS; break;
		case ID_ALARM_ALARMSYSTEMFLAGS:					wParam = IDM_FLAGS; break;
		case ID_ALARM_ALARMUSERS:						wParam = IDM_USER_ID; break;
		case ID_ALARM_TEMPORARYSCHEDULE:				wParam = IDM_TEMP_SCH; break;
		case ID_ALARM_ALARMTIMESCHEDULES:				wParam = IDM_MACRO_TIMEZONE; break;
		case ID_MACROS_ALARMEVENTS:						wParam = IDM_TIME_OUTPUT; break;
		case ID_MACROS_ALARMMACROS:						wParam = IDM_TIME_OUTPUT; lParam = 1; break;
		case ID_FILE_DOWNLOADCONFIGURATION:				wParam = IDM_DOWN_LOAD; break;
		case ID_ALARM_ALL:								wParam = IDM_PRINT_ALL; break;
		case ID_FILE_EXPORT_ALARM_AREAS:				wParam = IDM_PRINT_AREAS; break;
		case ID_HARDWARE_DEVICES:						wParam = IDM_PRINT_DEVICES; break;
		case ID_HARDWARE_KEYPADS:						wParam = IDM_PRINT_KEYPADS; break;
		case ID_HARDWARE_INPUTS:						wParam = IDM_PRINT_INPUTS; break;
		case ID_HARDWARE_OUTPUTS:						wParam = IDM_PRINT_OUTPUTS; break;
		case ID_HARDWARE_CAMERAS:						wParam = IDM_PRINT_CAMERAS; break;
		case ID_HARDWARE_ANALOGINPUTS:					wParam = IDM_PRINT_AINPUTS; break;
		case ID_HARDWARE_CCTVOUTPUTS:					wParam = IDM_PRINT_CCTVS; break;
		case ID_HARDWARE_PULSECOUNTERS:					wParam = IDM_PRINT_PULSE_COUNTERS; break;
		case ID_SYSTEMS_SYSTEMPARAMETERS:				wParam = IDM_PRINT_SYS_PARAMS; break;
		case ID_SYSTEMS_SYSTEMFLAGS:					wParam = IDM_PRINT_SYS_FLAGS; break;
		case ID_HOURS_NORMALHOURS:						wParam = IDM_PRINT_NORMAL_HRS; break;
		case ID_HOURS_TEMPORARYHOURS:					wParam = IDM_PRINT_TEMP_HRS; break;
		case ID_HOURS_ATMACCESSHOURS:					wParam = IDM_PRINT_ATM_HRS; break;
		case ID_HOURS_CLEANERACCESSHOURS:				wParam = IDM_PRINT_CLEANER_HRS; break;
		case ID_HOURS_GUARDACCESSHOURS:					wParam = IDM_PRINT_GUARD_HRS; break;
		case ID_HOURS_SERVICEACCESSHOURS:				wParam = IDM_PRINT_SERVICE_HRS; break;
		case ID_FILE_EXPORT_ALARM_TEMPORARYSCHEDULES:	wParam = IDM_PRINT_TEMP_SCH; break;
		case ID_FILE_EXPORT_ALARM_YEARLYCALENDAR:		wParam = IDM_PRINT_CALENDER; break;
		case ID_FILE_EXPORT_ALARM_EVENTDRIVER:			wParam = IDM_PRINT_EVENTS; break;
		case ID_FILE_EXPORT_ALARM_TIMEZONES:			wParam = IDM_PRINT_TIME_ZONE; break;
		case ID_FILE_EXPORT_ALARM_USERID:				wParam = IDM_PRINT_USER_ID; break;
		case ID_FILE_EXPORT_ALARM_MACROS:				wParam = IDM_PRINT_MACROS; break;
		//TT 8120
		case ID_GLOBAL_RESISTOR_SETTINGS:				wParam = IDM_GLOBAL_RESISTOR_SETTINGS; break;
		default: break;
		}	
    }


	if(wParam == -1)
		return FALSE;

	::SendMessage(lpps->heDlg, WM_COMMAND, wParam, lParam);
	return TRUE;
}

BOOL CRtuCtrlCfgDlg::ProcessAccessControlCommand(int nID)
{
	LPPARMPROC lpps = m_lpps;
	HWND hDlg = GetSafeHwnd();
	if((lpps = GetLPPARMPROC(hDlg, m_option = 17, m_rtups, TRUE)) == NULL)
		return FALSE;
	
	EditAccessParams(lpps, SW_HIDE);
	
	lpps->hmDlg = hDlg;
	int nRequestID = -1;
	switch(nID) {
	case ID_VIEW_CARDACCESSDIAGNOSTICS:						nRequestID = IDM_ERROR_STATS;			break;
	case ID_VIEW_ACCESSCONTROLCARDS:						nRequestID = IDM_1060_USER_CONFIG;		break;
	case ID_VIEW_SINGLECARDS:								nRequestID = IDM_VIEW_SINGLE_USER;		break;
	case ID_ACCESSCONTROL_HARDWARE_ADDREADER:				nRequestID = IDM_CAC_SINGLE_CFG;		break;
	case ID_ACCESSCONTROL_HARDWARE_READERS:					nRequestID = IDM_RDR;					break;
	case ID_ACCESSCONTROL_AREAPROFILES:						nRequestID = IDM_AREA;					break;
	case ID_ACCESSCONTROL_ELEVATORS_ELEVATORSETTINGS:		nRequestID = IDM_RDR_ELEV;				break;
	case ID_ACCESSCONTROL_ELEVATORS_UNLOCKFLOORS:			nRequestID = IDM_RDR_ELEV_TZ;			break;
	case ID_ACCESSCONTROL_CARDTYPESETTINGS:					nRequestID = IDM_CARDTYPE;				break;
	case ID_ACCESSCONTROL_CARDFORMATS:						nRequestID = IDM_CARD_FORMAT;			break; 
	case ID_ACCESSCONTROL_ACCESSCONTROLTIMESCHEDULES:		nRequestID = IDM_TIMEZONES;				break;
	case ID_ACCESSCONTROL_OPENCLOSESCHEDULES:				nRequestID = IDM_OP_CL_SCH;				break;
	case ID_MACROS_READERMACROS:							nRequestID = IDM_EVENT_DRVR;			break;
	case ID_YEARLYCALENDAR_CARDACCESS:						nRequestID = IDM_1060_YEARLY_CAL;		break;
	case ID_ACCESSCONTROL_ALL:								nRequestID = IDM_CAC_PRN_ALL;			break;
	case ID_ACCESSCONTROL_AREAS:							nRequestID = IDM_CAC_PRN_AREAS;			break;
	case ID_ACCESSCONTROL_READERS:							nRequestID = IDM_CAC_PRN_RDR;			break;
	case ID_ACCESSCONTROL_TIMEZONES:						nRequestID = IDM_CAC_PRN_TZ;			break;
	case ID_ACCESSCONTROL_ELEVATORS:						nRequestID = IDM_CAC_PRN_ELEV;			break;
	case ID_ACCESSCONTROL_ELEVATORFLOORACCESS:				nRequestID = IDM_CAC_PRN_FLR;			break;
	case ID_ACCESSCONTROL_YEARLYCALENDAR:					nRequestID = IDM_CAC_PRN_CAL;			break;
	case ID_ACCESSCONTROL_EVENTDRIVER:						nRequestID = IDM_CAC_PRN_EVT;			break;
	case ID_ACCESSCONTROL_CARDTYPES:						nRequestID = IDM_CAC_PRN_CTYPE;			break;
	case ID_ACCESSCONTROL_ACCESSDIAGNOSTICS:				nRequestID = IDM_CAC_PRN_ERR;			break;
	case ID_ACCESSCONTROL_USERCONFIGURATION:				nRequestID = IDM_CAC_PRN_UCFG;			break;
	case ID_ACCESSCONTROL_OPENCLOSESCH:						nRequestID = IDM_CAC_PRN_OP_CL_SCH;		break;
	case ID_ACCESSCONTROL_OVERALL_SETTINGS:					nRequestID = IDM_CAC_OVERALL_SETTINGS;	break;
	default: break;
	}

	if(nRequestID >= 0) {
		::SendMessage(lpps->heDlg, WM_COMMAND, nRequestID, 0);
	}
	return TRUE;
}

BOOL CRtuCtrlCfgDlg::ProcessBmsCommand(int nID)
{
	LPPARMPROC lpps = new PARMPROC;
	memset(lpps, 0, sizeof(PARMPROC));
	m_option = 18;
	lpps = &Rtups[m_option];

	*lpps = m_rtups;
	lpps->Id = (BYTE)m_option;
	lpps->lpData = (LPBYTE)RtuMem.lpMem + m_option*512;
	HWND hDlg = GetSafeHwnd();
	lpps->hmDlg = hDlg;


	if (!FindAccPriv(E_RTU_BMSPARMS, CHK_EDIT|CHK_ACCESS, CHK_VIEW|CHK_RESET))
		return FALSE;
	iblk = (BYTE)2;
	lpps->BC = pblk_size[iblk];			//.Block Size

	memcpy(&m_ppsBms, lpps, sizeof(m_ppsBms));
	memcpy(m_ppsBmsData, lpps->lpData, sizeof(m_ppsBmsData));
	m_ppsBms.lpData = m_ppsBmsData;

	ProcBmsConfig(hrInst, Globals->hSysWnd, hDlg, iblk, &m_ppsBms, SW_HIDE);

	if(m_ppsBms.heDlg == NULL)
		return FALSE;

	int nRequestID = -1;
	switch(nID) {
	case ID_BUILDINGMANAGEMENT_MODBUSSETTINGS:
		nRequestID = ID_CFG_MODBUS; break;
	case ID_BUILDINGMANAGEMENT_BACNETSETTINGS:
		nRequestID = ID_CFG_BACNET; break;
	case ID_MACROS_BMSMACROS:
		nRequestID = ID_CFG_MACROS; break;
	case ID_ALARM_COUNTERSETTINGS:
		nRequestID = ID_CFG_PULSECOUNTER; break;
	case ID_BUILDINGMANAGEMENT_GENERALSETTING:
		nRequestID = ID_CFG_GENERAL; break;
	default: break;
	}

	if(nRequestID > 0) {
		::SendMessage(m_ppsBms.heDlg, WM_COMMAND, nRequestID, 0);
	}
	return TRUE;
}


////////////////////////////////////////////////////////
////////////////////////////////////////////////////////
#pragma region CNetworkErrorDlg class
CNetworkErrorDlg::CNetworkErrorDlg(LPPARMPROC lpps, LPBYTE pData, CWnd* pParent) : 
	m_pData(pData), CDialog (CNetworkErrorDlg::IDD, pParent)
{
	memset(m_data, 0, sizeof(m_data));
	memcpy(m_data, lpps->lpData, sizeof(m_data));
	memcpy(&m_pps, lpps, sizeof(m_pps));
	m_pps.lpData = m_data;

	m_pagePrimary = NULL;
	m_pageSecondary = NULL;
	m_pageTertiary = NULL;
};

void CNetworkErrorDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CNetworkErrorDlg)
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CNetworkErrorDlg, CDialog)
	//{{AFX_MSG_MAP(CNetworkErrorDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CNetworkErrorDlg message handlers
/////////////////////////////////////////////////////////////////////////////
BOOL CNetworkErrorDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();

	m_pps.heDlg = GetSafeHwnd();
	m_pps.hmDlg = GetSafeHwnd();

	m_pagePrimary = new CNetworkParams_Err(IDD_NETWORK_ERRORS_DLG, m_pData);
	m_pageSecondary = new CNetworkParams_Err(IDD_NETWORK_ERRORS2_DLG, m_pData+66);
	m_pageTertiary = new CNetworkParams_Err(IDD_NETWORK_ERRORS3_DLG, m_pData+132);

	m_sheet.AddPage(m_pagePrimary);
	m_sheet.AddPage(m_pageSecondary);
	m_sheet.AddPage(m_pageTertiary);

	DWORD styles =  WS_CHILD | WS_VISIBLE | WS_TABSTOP | WS_CLIPCHILDREN | DS_CONTROL;
	m_sheet.Create(this, styles, WS_EX_CONTROLPARENT); 
	//TT 8345
	AdjustPropertySheetLocation(this,&m_sheet, TRUE);

	m_sheet.SetActivePage(0);
	m_pagePrimary->SetWindowText(_T("Primary"));

	return TRUE;
}

void CNetworkErrorDlg::OnOK()
{
	send_rtu_cmd(&m_pps, ResetPrimaryPortErrorStatisticsCMD, 0, 0, 0, FALSE, 0);
	send_rtu_cmd(&m_pps, ResetSecondaryTertiaryBackupPortErrorStatisticsCMD, 0, 0, 0, FALSE, 0);
	EndDialog(TRUE);
}
#pragma endregion

////////////////////////////////////////////////////////
////////////////////////////////////////////////////////
#pragma region CInovonicsCommandDlg class

CInovonicsCommandDlg::CInovonicsCommandDlg(int nRtuNumber, CWnd* pParent)
	: m_nRtuNumber(nRtuNumber), CDialog(CInovonicsCommandDlg::IDD, pParent)
{
	m_nTxOpLen = m_nTxAddrLen = 0;
}

CInovonicsCommandDlg::~CInovonicsCommandDlg()
{
}

void CInovonicsCommandDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CInovonicsCommandDlg)
	DDX_Control(pDX, IDC_CBO_PRG_INOV_CMD, m_cboCmdType);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CInovonicsCommandDlg, CDialog)
	//{{AFX_MSG_MAP(CInovonicsCommandDlg)
	ON_BN_CLICKED(IDOK, OnOK)
	ON_CBN_SELCHANGE(IDC_CBO_PRG_INOV_CMD, OnSelChangedCommandType)
	ON_EN_UPDATE(IDC_TXT_1, OnEnUpdateTxOption)
	ON_EN_UPDATE(IDC_TXT_2, OnEnUpdateTxAddress)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


BOOL CInovonicsCommandDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();

	//memset(strTxOp, 0, sizeof(strTxOp));
	m_strTxOp = _T("");
	m_strTxAddr = _T("");
	m_nTxOpLen = m_nTxAddrLen = -1;
	SendDlgItemMessage(IDC_TXT_1, EM_SETLIMITTEXT, 2, 0);
	SendDlgItemMessage(IDC_TXT_2, EM_SETLIMITTEXT, 4, 0);

	SetDlgItemInt(IDC_TXT_1, 1);
	SetDlgItemInt(IDC_TXT_2, 1);
	m_cboCmdType.ResetContent();
	for(int i=0; i<3; i++) {
		m_cboCmdType.AddString(RES_STRING(IDS_PROGRAM_TRANSMITTER + i));
	}
	m_cboCmdType.SetCurSel(0);
	OnSelChangedCommandType();
	
	CenterWindow();
	return TRUE;
}

void CInovonicsCommandDlg::OnOK()
{
	BYTE data[250];
	PCPCMD	pc;
	TCHAR str2[250];
	memset(&data[0], 0, sizeof(data));
	data[1] = 21;		// Function code
	memset(&pc, 0, sizeof(pc));

	int nIndex = m_cboCmdType.GetCurSel();
	int n1 = GetDlgItemInt(IDC_TXT_1);
	//int n2 = GetDlgItemInt(IDC_TXT_2);

	if(nIndex == 0) {
		TCHAR opTxt[10], addrTxt[10];
		GetDlgItemText(IDC_TXT_1, opTxt, _COUNTOF(opTxt));
		GetDlgItemText(IDC_TXT_2, addrTxt, _COUNTOF(addrTxt));
		UINT op = wGetStrHex(opTxt);
		UINT addr = wGetStrHex(addrTxt);
		wsprintf(str2, _T("55,%d,%d,%d"), op, addr&0xff, (addr>>8)&0xff);
	}
	else if(nIndex == 1) {
		if(n1 > 0)
			n1 -= 1;
		wsprintf(str2, _T("55,0xfe,%d"), n1);
	}
	else if(nIndex == 2) {
		wsprintf(str2, _T("55,0xff,0x30,0x05,0x01,0x11,0xff,0x46"));
	}

	int idx = FormatCommandData(str2, &data[5]);
	if(idx > 0) {
		data[0] = (BYTE)(idx + 5);
		pc.addr1 = (BYTE)GETGROUPNO(m_nRtuNumber);
		pc.addr2 = (BYTE)GETRTUOFFSET(m_nRtuNumber);
		pc.cport = 0;
		pc.lpCmd = data;
		pc.hWnd = GetSafeHwnd();
		pc.busy = 1;
		pc.errCode = 0;
		pc.bWait = HIRESP;
		pc.timer = 100;					//.5 second timeout
		pc.bDisErr = 1;
		SendGPPcpCommand(&pc, IDS_PROGRAM_INOVONICS_TRANSMITTER);
	}
}

void CInovonicsCommandDlg::OnSelChangedCommandType()
{
	GetDlgItem(IDC_LBL_1)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_LBL_2)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_TXT_1)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_TXT_2)->ShowWindow(SW_HIDE);

	int nIndex = m_cboCmdType.GetCurSel();
	if(nIndex == 0) {
		SendDlgItemMessage(IDC_TXT_1, EM_SETLIMITTEXT, 2, 0);
		GetDlgItem(IDC_LBL_1)->SetWindowText(RES_STRING(IDS_TX_OPTION));
		GetDlgItem(IDC_LBL_2)->SetWindowText(RES_STRING(IDS_TX_ADDRESS));
		GetDlgItem(IDC_LBL_1)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_LBL_2)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_TXT_1)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_TXT_2)->ShowWindow(SW_SHOW);
		
		SetDlgItemText(IDC_TXT_1, _T(""));
		GetDlgItem(IDC_TXT_1)->SetFocus();
	}
	else if(nIndex == 1) {
		SendDlgItemMessage(IDC_TXT_1, EM_SETLIMITTEXT, 3, 0);
		GetDlgItem(IDC_LBL_1)->SetWindowText(RES_STRING(IDS_INPUT_NUMBER));
		GetDlgItem(IDC_LBL_1)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_TXT_1)->ShowWindow(SW_SHOW);

		SetDlgItemText(IDC_TXT_1, _T(""));
		GetDlgItem(IDC_TXT_1)->SetFocus();
	}	
}

static BOOL IsValidHexString(CString& str)
{
	int len = str.GetLength();
	CString s = str;
	s.MakeUpper();
	for(int i=0; i<len; i++) {
		TCHAR c = s[i];
		if( !((c >= _T('0') && c <=_T('9')) || (c >= _T('A') && c <= _T('F'))) ) {
			return FALSE;
		}
	}

	return TRUE;
}

void CInovonicsCommandDlg::OnEnUpdateTxOption()
{
	if(m_cboCmdType.GetCurSel() > 0)
		return;
			
	CString sTxt; GetDlgItemText(IDC_TXT_1, sTxt);
	int sLen = sTxt.GetLength();

	//check if string valid
	if(IsValidHexString(sTxt)) {
		m_strTxOp = sTxt;
		m_nTxOpLen = sLen;
	}
	else {
		SetDlgItemText(IDC_TXT_1, m_strTxOp);
	}
					
	if(sLen == m_nTxOpLen) 
		return;

	SetDlgItemText(IDC_TXT_1, m_strTxOp);
}

void CInovonicsCommandDlg::OnEnUpdateTxAddress()
{
	if(m_cboCmdType.GetCurSel() > 0)
		return;
			
	CString sTxt; GetDlgItemText(IDC_TXT_2, sTxt);
	int sLen = sTxt.GetLength();

	//check if string valid
	if(IsValidHexString(sTxt)) {
		m_strTxAddr = sTxt;
		m_nTxAddrLen = sLen;
	}
	else {
		SetDlgItemText(IDC_TXT_2, m_strTxAddr);
	}
					
	if(sLen == m_nTxAddrLen) 
		return;

	SetDlgItemText(IDC_TXT_2, m_strTxAddr);
}
#pragma endregion

/////////////////////////////////////////////////////////////////////////////
// CRtuCtrlTemplate message handlers
/////////////////////////////////////////////////////////////////////////////
#pragma region CRtuCtrlTemplate class

CRtuCtrlTemplate::CRtuCtrlTemplate(LPPARMPROC lpps, CWnd* pParent)
{
	m_pParent = pParent;
	m_fileName = _T("");
	CString wnd_class_name = ::AfxRegisterWndClass(NULL);
	this->CreateEx(0, wnd_class_name, _T("CRtuCtrlTemplate"), 0, 0,
		0, 0, 0, HWND_MESSAGE, 0, 0);

	memset(m_ppsData, 0, sizeof(m_ppsData));
	memcpy(&m_pps, lpps, sizeof(m_pps));
	m_pps.lpData = m_ppsData;
	memcpy(m_ppsData, lpps->lpData, sizeof(m_ppsData));
	m_nMaxChip = E_MAX_CHIP_COUNT;
	
	m_fName = DefaultLocation(CUSTOMER_RTU_UPLOAD_FOLDER);

	m_nRtuNum = MAKERTUNO(m_pps.eType, m_pps.eNo) + 1;
	m_pps.heDlg = this->GetSafeHwnd();
	m_pps.hmDlg = this->GetSafeHwnd();
	m_strArrTempFiles.RemoveAll();
	m_eStatus = E_CTRL_STAT_IDLE;
}

CRtuCtrlTemplate::~CRtuCtrlTemplate()
{	
}

BEGIN_MESSAGE_MAP(CRtuCtrlTemplate, CWnd)
	ON_WM_DESTROY()
	ON_MESSAGE(WM_GMS, OnGms)
	ON_REGISTERED_MESSAGE(UWM_TEXT, OnTextMessage)
END_MESSAGE_MAP()

void CRtuCtrlTemplate::OnDestroy()
{
}

LRESULT CRtuCtrlTemplate::OnTextMessage(WPARAM wParam, LPARAM lParam)
{
	if(m_pParent) {
		m_pParent->SendMessage(UWM_TEXT, wParam, lParam);
	}
	return 0;
}

LRESULT CRtuCtrlTemplate::OnGms(WPARAM wParam, LPARAM lParam)
{
	int nRtuNum = (int)lParam;
	int id = GET_WM_COMMAND_ID(wParam, lParam);
	switch (id)	{
	case IDD_COMMOVR_ERROR:   
		break;
	case IDD_COMMOVR_CTRL_NUM:
		
		if(nRtuNum > 0 && nRtuNum < MAX_SITES) {
			if(m_eStatus == E_CTRL_STAT_UPLOADING) {
				CString EEP_Name; 
				TCHAR fname[MAX_PATH]; 
				EEP_Name.Format(_T("%s%d.EEP"), (LPCTSTR)m_fileName, m_nChipCount);
				wsprintf(fname, _T("%s\\%s"), m_fName.Path, (LPCTSTR)EEP_Name);	
		
				CFile f;
				if (f.Open(fname, CFile::modeRead|CFile::shareDenyNone, 0)) 
				{
					DWORD fSize = (DWORD) f.GetLength();
					f.Close();

					if (fSize == 0) 
						m_nChipCount--;

					m_uploadFiles.Add(EEP_Name); // contains filename without path.
					
					if ((++m_nChipCount < m_nMaxChip) && (fSize != 0)) 
					{
                        
						ProcNextCmd(m_fileName);
					}
					else 
					{
						SaveFileInfo();
					}
				}
				else 
				{
					CString errorMsg; errorMsg.Format(_T("Failed to open %s file.(e=%d)\n"), fname, GetLastError());GmsOutputDebugString(__FUNCTIONW__, __LINE__, errorMsg);
				}

				break;
			}
			else if (m_eStatus == E_CTRL_STAT_DOWNLOADING) 
			{
				if (++m_nChipCount < m_nMaxChip) 
				{
					ProcNextCmd(m_fileName);
				}
				else if (EPW_FLAG == TRUE) 
				{
					EPW_FLAG = FALSE;
					m_pps.BlkNo = 0;
					send_wr_eeprom(&m_pps);
					DeleteTempFiles(m_strArrTempFiles);
					if(m_pParent)
						m_pParent->SendMessage(UWM_CONFIG_UPLOADED);
					m_eStatus = E_CTRL_STAT_IDLE;
				}
			}
		}
		else if (m_nChipCount < m_nMaxChip) 
		{
			if(m_eStatus == E_CTRL_STAT_UPLOADING)
				SaveFileInfo();
			else if(EPW_FLAG == TRUE) {
				EPW_FLAG = FALSE;
				m_pps.BlkNo = 0;
				send_wr_eeprom(&m_pps);
				DeleteTempFiles(m_strArrTempFiles);
			}

			if(m_pParent)
				m_pParent->SendMessage(UWM_CONFIG_UPLOADED);
			m_eStatus = E_CTRL_STAT_IDLE;
		}

		break;

	default:
		break;
	}

	return TRUE;
}


void CRtuCtrlTemplate::SaveFileInfo()
{
	SaveConfig();

	if(m_pParent)
		m_pParent->SendMessage(UWM_CONFIG_UPLOADED);
	m_eStatus = E_CTRL_STAT_IDLE;
}

void CRtuCtrlTemplate::SaveHeader(CFile* pFile)
{
	if(pFile == NULL)
		return;

	_HeaderInfo hInfo;
	memset(&hInfo, 0, sizeof(hInfo));
	hInfo.nNumChips = (BYTE)m_nChipCount;
	hInfo.nRtuType = (BYTE)realRtuType;
	hInfo.nPanelType = (BYTE)PanelType;
	pFile->Write(&hInfo, sizeof(hInfo));
}

void CRtuCtrlTemplate::SaveConfig()
{
	CString sFileName;
	CFile templateFile;

	if (templateFile.Open(m_strTemplateName, CFile::modeCreate | CFile::modeWrite, 0)) {
		SaveHeader(&templateFile);
		LPBYTE p;
		for(int i=0; i<m_uploadFiles.GetSize(); i++) {
			sFileName.Format(_T("%s\\%s"), m_fName.Path, (LPCTSTR)m_uploadFiles.GetAt(i));
			CFile uploadFile;
			if (uploadFile.Open(sFileName, CFile::modeRead|CFile::shareDenyNone, 0)) {
				int nSize = (int) uploadFile.GetLength();
				if(nSize) {
					LPBYTE pBuffer = new BYTE[nSize + 1];
					memset(pBuffer, 0, nSize + 1);

						int nByteRead = uploadFile.Read(pBuffer, nSize);
						if(nByteRead == nSize) {
							p = (LPBYTE)&nSize;
							templateFile.Write(p, 4);
							templateFile.Write(pBuffer, nSize);
						}
						delete [] pBuffer;
						}
					uploadFile.Close();
					}
				else {
					CString errorMsg; errorMsg.Format(_T("Failed to open %s file.(e=%d)\n"), (LPCTSTR)sFileName, GetLastError());GmsOutputDebugString(__FUNCTIONW__, __LINE__, errorMsg);
				}
			// Delete file
			DeleteFile(sFileName);

			}

		templateFile.Close();
		}
	else {
		CString errorMsg; errorMsg.Format(_T("Failed to open %s file.(e=%d)\n"), (LPCTSTR)m_strTemplateName, GetLastError());GmsOutputDebugString(__FUNCTIONW__, __LINE__, errorMsg);
	}
		
}

DWORD CRtuCtrlTemplate::GetFileSize(CString strFileName)
{

	DWORD dwLength = 0;
	CFile f;
	if (f.Open(strFileName, CFile::modeRead|CFile::shareDenyNone, 0))
	{
		dwLength = (DWORD) f.GetLength();
		f.Close();
	}

	return dwLength;
}

void CRtuCtrlTemplate::UploadConfig(LPTSTR szFileName)
{
	m_eStatus = E_CTRL_STAT_UPLOADING;
	m_strTemplateName = szFileName;
	m_fileName = GetNewTemplateName();
	m_uploadFiles.RemoveAll();
	m_nChipCount = 0;
	m_nMaxChip = E_MAX_CHIP_COUNT;

	ProcNextCmd(m_fileName);
}

BOOL CRtuCtrlTemplate::GetHeaderInfo(CFile* pFile, _HeaderInfo* pInfo)
{
	if(pFile == NULL || pInfo == NULL)
		return FALSE;
	pFile->Read(pInfo, sizeof(_HeaderInfo));

	if(pInfo->nRtuType != realRtuType) {
		if( (realRtuType == RTU_8001_TYPE) && (pInfo->nRtuType == RTU_1057_TYPE || pInfo->nRtuType == RTU_1058_TYPE))
		{
			if(pInfo->nPanelType != P8001_TYPE) {
				return TRUE;
			} else {
				AfxMessageBox(RES_STRING(IDS_INVALID_TEMPLATE3)); return FALSE;
			}
		}

		CString strRtuType = GetRTUType(pInfo->nRtuType);
		if(strRtuType == _T(" ")) {
			AfxMessageBox(RES_STRING(IDS_INVALID_TEMPLATE));
		} else {
			CString s; s.Format(RES_STRING(IDS_INVALID_TEMPLATE2), strRtuType);
			AfxMessageBox(s);
		}
		return FALSE;
	}

	return TRUE;
}

CString CRtuCtrlTemplate::GetNewTemplateName()
{
	SYSTEMTIME st; GetLocalTime(&st);
	CString strTmpName;
	strTmpName.Format(_T("%02d%02d%02dT_"), st.wHour, st.wMinute, st.wSecond); // Need to have a digit in front, so the file will be created in RtuUploadFiles.
	return strTmpName;
}

void CRtuCtrlTemplate::DownloadConfig(LPTSTR szFileName)
{
	m_eStatus = E_CTRL_STAT_DOWNLOADING;
	m_strTemplateName = szFileName;
	m_fileName = GetNewTemplateName();
	m_uploadFiles.RemoveAll();
	m_nChipCount = 0;
	m_nMaxChip = 0;
	
	BYTE pBuffer[4];
	int nSize=0;
	BOOL bResult = FALSE;
	CFile rtuTemplateFile;
	
	if (rtuTemplateFile.Open(szFileName, CFile::modeRead|CFile::shareDenyNone, 0)) 
	{
		long lOff = 0;
		rtuTemplateFile.SeekToBegin();
		_HeaderInfo hInfo;
		if (!GetHeaderInfo(&rtuTemplateFile, &hInfo)) {
			rtuTemplateFile.Close();
			m_eStatus = E_CTRL_STAT_IDLE;
			return;
		}

		m_nMaxChip = hInfo.nNumChips;
		lOff = sizeof(hInfo);
		for(int i=0; i<m_nMaxChip; i++) {
			rtuTemplateFile.Seek(lOff, 0);
			rtuTemplateFile.Read(pBuffer, 4);
			nSize = *((DWORD*)pBuffer);
			lOff += 4;
			rtuTemplateFile.Seek(lOff, 0);
			
			CString EEP_FileName;
			EEP_FileName.Format(_T("%s\\%s%d.EEP"), m_fName.Path, (LPCTSTR)m_fileName, i);
			m_strArrTempFiles.Add(EEP_FileName); // contain full path name
			CFile EEP_File;
			if (EEP_File.Open(EEP_FileName, CFile::modeCreate|CFile::modeWrite, 0)) { 
				LPBYTE pBuffer2 = new BYTE[nSize + 1];
				if(pBuffer2) {
					rtuTemplateFile.Read(pBuffer2, nSize);
					if(i==0) {
						bResult = ShowControllerInfo(pBuffer2, &hInfo);
					}
					EEP_File.Write(pBuffer2, nSize);
					delete[] pBuffer2; 
					pBuffer2 = 0;
				}

				EEP_File.Close();
			}
			else {
				CString errorMsg; errorMsg.Format(_T("Failed to open %s file.(e=%d)\n"), (LPCTSTR)EEP_FileName, GetLastError());GmsOutputDebugString(__FUNCTIONW__, __LINE__, errorMsg);
			}

			lOff += (nSize);
		}
		rtuTemplateFile.Close();
	}	
	else {
		CString errorMsg; errorMsg.Format(_T("Failed to open %s file.(e=%d)\n"), szFileName, GetLastError());GmsOutputDebugString(__FUNCTIONW__, __LINE__, errorMsg);
	}

	if(bResult)
    {
		ProcNextCmd(m_fileName);
    }
	else {
		DeleteTempFiles(m_strArrTempFiles);
		m_eStatus = E_CTRL_STAT_IDLE;
	}

}

BOOL CRtuCtrlTemplate::ShowControllerInfo(LPBYTE pBuffer, _HeaderInfo* pInfo)
{
#if ShowTemplateOnly
	CControllerTemplate dlg(pBuffer, pInfo->nRtuType);
	if(dlg.DoModal() == IDOK) {
		return TRUE;
	}
	return FALSE;
#else
	CControllerTemplateMain dlg(&m_pps, pBuffer, pInfo->nRtuType);
	if(dlg.DoModal() == IDOK) {
		return TRUE;
	}
	return FALSE;
#endif
}


int CRtuCtrlTemplate::ProcNextCmd(CString strFileName)
{
	int retCode = -1;
	CString sFileName;

	// Check if file exist
	sFileName.Format(_T("%s\\%s%d.EEP"), m_fName.Path, (LPCTSTR)strFileName, m_nChipCount);

	if (m_eStatus == E_CTRL_STAT_DOWNLOADING) {

		CFileStatus sts;
		if (CFile::GetStatus(sFileName, sts) == FALSE)
		{
		DispMessageBox(GetSafeHwnd(), IDS_FILE_NOT_FOUND, IDS_ERROR, MB_OK);
		return retCode;
		}
	}

	sFileName.Format(_T("%s%d.EEP"), (LPCTSTR)strFileName, m_nChipCount);
	memset(m_ppsData, 0, sizeof(m_ppsData));
    int len = sFileName.GetLength() << 1;
	if(len > E_BUFF_SIZE - 3)
		len = E_BUFF_SIZE - 3;
    memcpy(&m_pps.lpData[2], sFileName.GetBuffer(len), len);
	m_pps.lpData[2 + len] = 0;
		
	m_pps.CommsErr = PCP_FORCEUL;

	m_pps.lpData[0] = (BYTE)realRtuType;	// hardware type
	m_pps.lpData[1] = rtuSoftwareType;			// software type
	if(m_eStatus == E_CTRL_STAT_UPLOADING) {
		EPW_FLAG = FALSE;
		retCode = get_complete_parms(&m_pps, m_nChipCount, iblk);
	}
	else if(m_eStatus == E_CTRL_STAT_DOWNLOADING) {
		EPW_FLAG = TRUE;
		if((retCode = send_complete_parms(&m_pps, m_nChipCount, iblk)) == -1)
			EPW_FLAG = FALSE;
	}

	return retCode;

}


void CRtuCtrlTemplate::DeleteTempFiles(CStringArray& strArrTempFiles)
{
	CFileStatus sts;
	for (int i=0; i<strArrTempFiles.GetSize(); i++) {
		CString strFile = strArrTempFiles.GetAt(i);
		if (CFile::GetStatus(strFile, sts) == TRUE)
		{
			DeleteFile(strFile);
		}
	}

	strArrTempFiles.RemoveAll();
}

#pragma endregion

//////////////////////////////////////////////////////////////////////////////
//	CControllerTemplate class												//
//////////////////////////////////////////////////////////////////////////////
#pragma region CControllerTemplate class
void ConvertUpProt( LPPORT_PROTOCOL ourp, LPPORT_PROTOCOL upp )
{
	upp->application = PPC_UNDEF;
	upp->session = PPC_UNDEF;
	upp->link = PPC_UNDEF;

	// check downloaded application level
#pragma region Application Level
	switch ( ourp->application ) {
		case RTU_PCA_N_SNA:     upp->application = PCA_SNA_NR; break;
		case RTU_PCA_N_X25:     upp->application = PCA_X25_NR; break;
		case RTU_PCA_N_IP:      upp->application = PCA_UDP_IP_NR; break;
		case RTU_PCA_N_SPOLL:   upp->application = PCA_SDLC_POLL_NR; break;
		case RTU_PCA_D_IP:      upp->application = PCA_UDP_IP_ACC; break;
		case RTU_PCA_DIALUP:    upp->application = PCA_ADIAL; break;
		case RTU_PCA_VCS_CCTV:  upp->application = PCA_VCS_NR; break;
		// Note GMS sees application only protocols as a link level so need to convert it
		case RTU_PCA_N_APOLL:   upp->link = PCL_ASYNC_POLL; break;
		case RTU_PCA_PCP:       upp->link = PCL_PCP; break;
		case RTU_PCA_PRINTER:   upp->link = PCL_PRN; break;
		case RTU_PCA_ASC_BMS:   upp->link = PCL_ASC; break;
		case RTU_PCA_DEVICE:    upp->link = PCL_DEV_LOOP; break;
		case RTU_PCA_DEV_SLV:   upp->link = PCL_DEV_SLV_LOOP; break;
		case RTU_PCA_PAGER:     upp->link = PCL_PAGER; break;
		case RTU_PCA_GPDRV:     upp->link = PCL_GPD; break;
		case RTU_PCA_IEC_CCTV:  upp->link = PCL_IEC; break;
		case RTU_PCA_PTZDRV:    upp->link = PCL_PTZ; break;
		case RTU_PCA_GENT:      upp->link = PCL_GEN; break;
		case RTU_PCA_ELEVATOR:  upp->link = PCL_ELEV_IFACE; break;
		case RTU_PCA_IRIS:      upp->link = PCL_IRIS; break;
		case RTU_PCA_GENCARRY:  upp->link = PCL_GEN_CARRY; break;
		case RTU_PCA_BMS:       upp->link = PCL_BMS; break;
		case RTU_PCA_EPCP:      upp->link = PCL_EPCP; break;
		case RTU_PCA_IRISYS:    upp->link = PCL_IRISYS; break;
		case RTU_PCA_INOVONIC:  upp->link = PCL_INOVONICS; break;
		case RTU_PCA_STUDRV:    upp->link = PCL_SECURITEL; break;
		case RTU_PCA_TRANS:     upp->link = PCL_TRANS; break;
		case RTU_PCA_DVRDRV:    upp->link = PCL_GDVR; break;
		case RTU_PCA_MODBUS:    upp->link = PCL_MODBUS; break;
		case RTU_PCA_WYRELESS:  upp->link = PCL_WYRELESS_ACCESS; break;
		case RTU_PCA_TIMECON:   upp->link = PCL_TIMECON_TCC; break;
		case RTU_PCA_APERIO:    upp->link = PCL_APERIO; break;
	}
#pragma endregion Application Level

	// check session level
#pragma region Session Level
	switch ( ourp->session ) {
		case RTU_PCS_SNA:       upp->session = PCS_SNA; break;
		case RTU_PCS_X25:       upp->session = PCS_X25; break;
		case RTU_PCS_IP:        upp->session = PCS_UDP_IP; break;
		case RTU_PCS_FEP_SNA:   upp->session = PCS_FEP_SNA; break;
	}
#pragma endregion Session Level

	// check link level
#pragma region Link Level
	switch ( ourp->link ) {
		case RTU_PCL_HDLC:          upp->link = PCL_HDLC; break;
		case RTU_PCL_MAC_105x:      upp->link = PCL_MAC_105X; break;
		case RTU_PCL_BISYNC:        upp->link = PCL_BISYNC; break;
		case RTU_PCL_TRANS_SDLC:    upp->link = PCL_TRANS_SDLC; break;
		case RTU_PCL_TRANS_BISYNC:  upp->link = PCL_TRANS_BISYNC; break;
		case RTU_PCL_MAC_ETHER:     upp->link = PCL_MAC_ETHERNET; break;
		case RTU_PCL_MAC_TOKEN:     upp->link = PCL_MAC_TOKENRING; break;
		case RTU_PCL_PPP:           upp->link = PCL_PPP; break;
		case RTU_PCL_DIALUP:        upp->link = PCL_RTU_DIAL; break;
	}
#pragma endregion Link Level

}

CControllerTemplate::CControllerTemplate(LPBYTE pParams, BYTE nRtuType, CWnd* ) : 
	CControllerTemplateBase(CControllerTemplate::IDD) //, pParent)
{
	m_pParams = pParams;
	LPBYTE p = m_pParams;
	m_nRtuType = nRtuType;
	LPBYTE pPortProtocol = p + 32;
	LPBYTE pPortPriority = p + 2732;
	LPBYTE p1LParam = p + 1664;
	m_bShowTelephone = TRUE;

	PORT_PROTOCOL rtu;
	PORT_PROTOCOL gms;
	if(pPortProtocol && pPortPriority) {
		for(int i=0; i<12; i++) {
			BYTE pri = *pPortPriority++;
			rtu.link = *pPortProtocol++;
			rtu.session = *pPortProtocol++;
			rtu.application = *pPortProtocol++;
			ConvertUpProt(&rtu, &gms);
			
			if(pri == PORT_PRIO_SECONDARY) {
				if(gms.link == PCL_PPP) {
					BYTE modemType = 0;
					LPBYTE pModemType = p1LParam + 16;
					modemType = *pModemType;
					m_bShowTelephone = FALSE;
				}
			}
			p1LParam += 64;
		}
	}

	m_nControllerID				= ((*(p+0x000E) << 8) | (*(p+0x000F))) + 1;
	m_controllerIpAddress		= GetIpAddress(m_nRtuType == RTU_8001_TYPE ? (p+0x0603) : (p+0x0383));
	m_controllerSubnetMask		= GetIpAddress(m_nRtuType == RTU_8001_TYPE ? (p+0x0607) : (p+0x0387));
	m_controllerDefaultGateway1 = GetIpAddress(m_nRtuType == RTU_8001_TYPE ? (p+0x060B) : (p+0x038B));
	m_controllerDefaultGateway2 = GetIpAddress(m_nRtuType == RTU_8001_TYPE ? (p+0x060F) : (p+0x038F));
	m_basestationIpAddress1		= GetIpAddress((p+0x0B1A));
	m_basestationIpAddress2		= GetIpAddress((p+0x0B24));

	if(m_bShowTelephone) {
		memcpy(m_telephoneNumber, p+0x0B7E, sizeof(m_telephoneNumber));
	}
	else {
		m_secondaryLine1IpAddress = GetIpAddress(p+0x0B7E);
	}
}

CControllerTemplate::~CControllerTemplate()
{

}

BEGIN_MESSAGE_MAP(CControllerTemplate, CControllerTemplateBase)
	ON_BN_CLICKED(IDOK, OnBtnOK)
END_MESSAGE_MAP()

void CControllerTemplate::DoDataExchange(CDataExchange* pDX)
{
	CControllerTemplateBase::DoDataExchange(pDX);

	DDX_IPAddress(pDX, IDC_IPA_CONTROLLER, m_controllerIpAddress);
	DDX_IPAddress(pDX, IDC_IPA_CONTROLLER_MASK, m_controllerSubnetMask);
	DDX_IPAddress(pDX, IDC_IPA_CONTROLLER_DEF_GATEWAY_1, m_controllerDefaultGateway1);
	DDX_IPAddress(pDX, IDC_IPA_CONTROLLER_DEF_GATEWAY_2, m_controllerDefaultGateway2);
	DDX_IPAddress(pDX, IDC_IPA_BASESTATION_1, m_basestationIpAddress1);
	DDX_IPAddress(pDX, IDC_IPA_BASESTATION_2, m_basestationIpAddress2);
	if(!m_bShowTelephone) {
		DDX_IPAddress(pDX, IDC_IPA_SECONDARY_LINE1, m_secondaryLine1IpAddress);
	}
}

BOOL CControllerTemplate::OnInitDialog()
{
	CControllerTemplateBase::OnInitDialog();
#if ShowTemplateOnly
	GetDlgItem(IDOK)->ShowWindow(SW_SHOW);
	GetDlgItem(IDCANCEL)->ShowWindow(SW_SHOW);
#endif
	SendDlgItemMessage(IDC_TXT_TELEPHONE_NUMBER, EM_LIMITTEXT, 18);
	SendDlgItemMessage(IDC_TXT_CONTROLLER_ID, EM_LIMITTEXT, 5);

	//m_lblGroup.SubclassDlgItem(IDC_CTRL_ID_1, this);
	//m_lblGroup.SetBorderThickness(1);
	CStatic* pGroupBox = (CStatic*)GetDlgItem(IDC_CTRL_ID_1);
	CString strText; 
	strText.Format(_T("%s %s"), GetRTUType(m_nRtuType), RES_STRING(IDS_CONTROLLER_TEMPLATE)); //TT 7516
	//m_lblGroup.SetText(strText);
	pGroupBox->SetWindowText(strText);

	for(int i=0; i<8; i++) {
		m_lblControls[i].SubclassDlgItem(IDC_CTRL_ID_2 + i, this);
		m_lblControls[i].Render();
	}
	
	if(!m_bShowTelephone) {
		GetDlgItem(IDC_TXT_TELEPHONE_NUMBER)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_IPA_SECONDARY_LINE1)->ShowWindow(SW_SHOW);
		CString strText2; strText2.Format(_T("%s :"), RES_STRING(IDS_SECONDARY_LINE1_IP));
		m_lblControls[7].SetText(strText2);
	}
	
	ShowParams();
	return TRUE;
}

void CControllerTemplate::OnBtnOK()
{
	if(!CheckParams())
		return;

	StoreParams();

	#if ShowTemplateOnly
	EndDialog(IDOK);
	#endif
}

void CControllerTemplate::ShowParams()
{
	UpdateData(FALSE);
	SetDlgItemInt(IDC_TXT_CONTROLLER_ID, m_nControllerID);

	if(m_bShowTelephone) {
		CString strTel = _T("");
		CString s;
		for(int i=0; i<9; i++) {
			BYTE b = m_telephoneNumber[i];
			BYTE b1 = b >> 4;
			BYTE b2 = b & 0x0f;
			if(b1 <= 9) {
				s.Format(_T("%d"), b1);
				strTel += s;
			}
			else {
				break;
			}

			if(b2 <= 9) {
				s.Format(_T("%d"), b2);
				strTel += s;
			}
			else {
				break;
			}
		}
		SetDlgItemText(IDC_TXT_TELEPHONE_NUMBER, strTel);
	}
}

void CControllerTemplate::StoreParams()
{
	UpdateData(TRUE);

	LPBYTE p = m_pParams;
	int nControllerID = GetDlgItemInt(IDC_TXT_CONTROLLER_ID) - 1;
	*(p+0x000E) = (BYTE)(nControllerID >> 8);
	*(p+0x000F) = (BYTE)(nControllerID & 0xff);

	SetIpAddress(m_nRtuType == RTU_8001_TYPE ? (p+0x0603) : (p+0x0383), m_controllerIpAddress);
	SetIpAddress(m_nRtuType == RTU_8001_TYPE ? (p+0x0607) : (p+0x0387), m_controllerSubnetMask);
	SetIpAddress(m_nRtuType == RTU_8001_TYPE ? (p+0x060B) : (p+0x038B), m_controllerDefaultGateway1);
	SetIpAddress(m_nRtuType == RTU_8001_TYPE ? (p+0x060F) : (p+0x038F), m_controllerDefaultGateway2);
	SetIpAddress((p+0x0B1A), m_basestationIpAddress1);
	SetIpAddress((p+0x0B24), m_basestationIpAddress2);

	if(m_bShowTelephone) {
		CString strTel;
		BYTE pTelNum[10];
		memset(pTelNum, 0xFF, sizeof(pTelNum));
		GetDlgItemText(IDC_TXT_TELEPHONE_NUMBER, strTel);
		for(int i=0; i<strTel.GetLength(); i++) {
			TCHAR c = strTel.GetAt(i);
			int n = _ttoi(&c);
			LPBYTE p2 = &pTelNum[i/2];
			if(i & 1) {
				*p2 &= 0xF0;
				*p2 |= (BYTE)(n & 0x0f);
			}
			else {
				*p2 &= 0x0F;
				*p2 |= (BYTE)(n<<4);
			}
		}
		memcpy(p+0x0B7E, pTelNum, sizeof(m_telephoneNumber));
	}
	else {
		SetIpAddress((p+0x0B7E), m_secondaryLine1IpAddress);
	}
}

BOOL CControllerTemplate::CheckParams()
{
	int nControllerID = GetDlgItemInt(IDC_TXT_CONTROLLER_ID);
	if(nControllerID <= 0)
		return FALSE;
	
	return TRUE;
}

DWORD CControllerTemplate::GetIpAddress(LPBYTE pIpAddress)
{
	DWORD dwIpAddress = 0;
	LPBYTE p = pIpAddress;
	dwIpAddress = (*p << 24) | (*(p+1) << 16) | (*(p+2) << 8) | (*(p+3));
	return dwIpAddress;
}

void CControllerTemplate::SetIpAddress(LPBYTE pIpAddress, DWORD dwIpAddress)
{
	LPBYTE p = pIpAddress;
	*p	   = (BYTE)(dwIpAddress >> 24);
	*(p+1) = (BYTE)(dwIpAddress >> 16);
	*(p+2) = (BYTE)(dwIpAddress >> 8);
	*(p+3) = (BYTE)(dwIpAddress);
}
#pragma endregion

#define WM_PAGE_SELECTED (WM_GMS+1)
class CPageNavigator : public CXTPPropertyPageListNavigator
{
public:
	CPageNavigator(CWnd* pParent);
	void OnPageSelected(CXTPPropertyPage* pPage);
private:
	CWnd* m_pParent;
};

CPageNavigator::CPageNavigator(CWnd* pParent)
{
	m_pParent = pParent;
}

void CPageNavigator::OnPageSelected(CXTPPropertyPage* pPage)
{
	int nItem = (int)pPage->m_dwData;
	CListBox::SetCurSel(nItem);
	if(m_pParent)
		m_pParent->SendMessage(WM_PAGE_SELECTED, (int)pPage->m_dwData);
}
#pragma region CControllerTemplateMain
//////////////////////////////////////////////////////////////////////////////
//	CControllerTemplateMain class												//
//////////////////////////////////////////////////////////////////////////////


CControllerTemplateMain::CControllerTemplateMain(LPPARMPROC lpps, LPBYTE pParams, BYTE nRtuType, CWnd* pParent) : 
	CDialog(CControllerTemplateMain::IDD, pParent)
{
	pPageLicense = NULL;
	pPageControllerTemplate = NULL;
	m_pParams = pParams;
	m_nRtuType = nRtuType;
	memcpy(&m_pps, lpps, sizeof(m_pps));
}

CControllerTemplateMain::~CControllerTemplateMain()
{
	if(pPageLicense) {
		delete pPageLicense; pPageLicense = NULL;
	}
	if(pPageControllerTemplate) {
		delete pPageControllerTemplate; pPageControllerTemplate = NULL;
	}
}

BEGIN_MESSAGE_MAP(CControllerTemplateMain, CDialog)
	ON_BN_CLICKED(IDOK, OnBtnOK)
	ON_MESSAGE(WM_GMS, OnGms)
	ON_MESSAGE(WM_PAGE_SELECTED, OnPageSelected)
	
END_MESSAGE_MAP()

void CControllerTemplateMain::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BOOL CControllerTemplateMain::OnInitDialog()
{
	CDialog::OnInitDialog();

	UploadLicense();
	return TRUE;
}

void CControllerTemplateMain::ShowConfig(LPBYTE pSerialData, BYTE addr1, BYTE addr2)
{
	//CXTPPropertyPageListNavigator* pList = new CXTPPropertyPageListNavigator();
	CPageNavigator* pList = new CPageNavigator(this);
	pList->SetListStyle(xtListBoxOfficeXP);
	m_sheet.SetNavigator(pList);

	pPageLicense = new CLicensePage(pSerialData, addr1, addr2, realRtuType==RTU_8001_TYPE ? IDD_RTU_SERNO_8001_DLG2 : IDD_RTU_SERNO_DLG2);
	pPageLicense->SetCaption(_T("License"));

	pPageControllerTemplate = new CControllerTemplate(m_pParams, m_nRtuType);
	m_sheet.AddPage(pPageLicense);
	#ifndef ShowTemplateOnly
	pPageControllerTemplate->SetCaption(_T("Template"));
	m_sheet.AddPage(pPageControllerTemplate);
	#endif

	DWORD styles =  WS_CHILD | WS_VISIBLE | WS_TABSTOP | WS_CLIPCHILDREN | DS_CONTROL;
	m_sheet.Create(this, styles, WS_EX_CONTROLPARENT); 
	//TT 8345
	AdjustPropertySheetLocation(this,&m_sheet, TRUE);	
}

void CControllerTemplateMain::UploadLicense()
{
	HWND hDlg = GetSafeHwnd();
	m_pps.lpData = m_lppsData;
	m_pps.Id = REQ_SRNO_CMD;
	m_pps.heDlg = m_pps.hmDlg = hDlg;
	GetRtuSerialNo(&m_pps);
}

void CControllerTemplateMain::OnBtnOK()
{
	int nIndex = m_sheet.GetActiveIndex();
	if(nIndex == 1) {
		pPageControllerTemplate->Download();
		EndDialog(TRUE);
	}
}

LRESULT CControllerTemplateMain::OnGms(WPARAM wParam, LPARAM lParam)
{
	int id = GET_WM_COMMAND_ID(wParam, lParam);
	switch (id) {
		case IDD_COMMOVR_CTRL_NUM:
		case IDD_COMMOVR_DATA:
			if(m_pps.Id==REQ_SRNO_CMD) {
				m_pps.Id = 0;
				LPBYTE pSerNumData = (LPBYTE)lParam;
				if(pSerNumData) {
					ShowConfig(pSerNumData, m_pps.eType, m_pps.eNo);
				}
				break;
			}
		default:
			break;
	}
	
	return TRUE;
}
LRESULT CControllerTemplateMain::OnPageSelected(WPARAM wParam, LPARAM)
{
	int nPageIndex = (int)wParam;
	if(nPageIndex == 1) {
		GetDlgItem(IDOK)->EnableWindow(TRUE);
	}
	else {
		GetDlgItem(IDOK)->EnableWindow(FALSE);
	}
	GetDlgItem(IDCANCEL)->SetFocus();

	return 1;
}

#pragma endregion

#pragma region 8001 License
static char licenseOptions[] = 
{
	'E',	// Ethernet
	'A',	// Access Control
	'P',	// Alarm Panel
	'H',	// Elevator HLI
	'I',	// Irisys Protocol
	'U',	// Dual Reporting Operation
	'M',	// Multi-card Format
	'Z',	// PTZ Driver
	'N',	// Inovonics
	'S',	// HOST HLI Support over IP
	'R',	// Remote Maintenance
	'D',	// Generic DVR Alarm Interfac
	'B',	// Enhance PAP(32 areas)
};	

void CLicensePage::GetEnabledStrings(CStringArray& strEn)
{
	UINT ids[E_NUM_OPTIONS];
	for(int i=0; i<10; i++) {
		ids[i] = IDS_ETH_EN + i;
	}
	for(int i=0; i<2; i++) {
		ids[i+10] = IDS_RMT_MAINT_EN + i;
	}
	ids[12] = IDS_EPAP_EN;

	if(realRtuType == RTU_8001_TYPE) {
		ids[1] = IDS_LARGE_MODEL_SYS_EN;
		ids[2] = IDS_MEDIUM_MODEL_SYS_EN;
		ids[3] = IDS_ELEVHLI_AND_BMS_EN;
		ids[7] = IDS_PEER_TO_PEER_EN;
	}

	for(int i=0; i<E_NUM_OPTIONS; i++) {
		strEn.Add(CString((LPTSTR)ids[i]));
	}
}

void CLicensePage::GetDisabledStrings(CStringArray& strDis)
{
	UINT ids[E_NUM_OPTIONS];
	for(int i=0; i<10; i++) {
		ids[i] = IDS_ETH_DIS + i;
	}
	for(int i=0; i<2; i++) {
		ids[i+10] = IDS_RMT_MAINT_DIS + i;
	}
	ids[12] = IDS_EPAP_DIS;

	if(realRtuType == RTU_8001_TYPE) {
		ids[1] = IDS_LARGE_MODEL_SYS_DIS;
		ids[2] = IDS_MEDIUM_MODEL_SYS_DIS;
		ids[3] = IDS_ELEVHLI_AND_BMS_DIS;
		ids[7] = IDS_PEER_TO_PEER_DIS;
	}

	for(int i=0; i<E_NUM_OPTIONS; i++) {
		strDis.Add(CString((LPTSTR)ids[i]));
	}
}

CLicensePage::CLicensePage(LPBYTE pLicenceData, BYTE addr1, BYTE addr2, int nDlgID) : 
	CLicensePageBase(nDlgID)
{
	if(pLicenceData == NULL)
		return;

	const int _8001_BC  = 144;
	const int _105X_BC  = 32;
	

	m_nCurOp=0;
	m_nAddress1 = 0;
	m_nAddress2 = 0;
	m_nByteCount = 0;
	m_bOpStat = 0;
	m_bChangeLicenceLimit = FALSE;
	m_bLicenceLimit = FALSE;
	m_nLimits = 0;
	memset(m_licenceLimits, 0, sizeof(m_licenceLimits));

	if(pLicenceData) {
		LPBYTE p = pLicenceData;
		int byteCount = 0, i = 0;
		byteCount = *(p - 5);

		char sSerialNumber[17]={0};
		memset(sSerialNumber, 0, sizeof(sSerialNumber));
		if(realRtuType == RTU_8001_TYPE) {
			memcpy(sSerialNumber, p+32, 16);	   // serial-3	for 8001

			if((byteCount-5) > _8001_BC) {
				m_bLicenceLimit = TRUE;
				memcpy(m_licenceLimits, p+_8001_BC, sizeof(m_licenceLimits));
			}

		} else {
			memcpy(sSerialNumber, p+8, 8);	  // serial-2 for 1057/1058/2000
			if((byteCount-5) > _105X_BC) {
				m_bLicenceLimit = TRUE;
				memcpy(m_licenceLimits, p+_105X_BC, sizeof(m_licenceLimits));
			}
		}

		byteCount = (byteCount >= 0x25) ? 16 : 8;

		char sLicences[17];
		for(i=0; i<byteCount; i++)
			sLicences[i] = *(p + 16 + i);
		sLicences[i] = 0;

		m_str = sSerialNumber;
		m_nAddress1 = addr1;
		m_nAddress2 = addr2;
		m_nByteCount = byteCount;
		SetLicenceOption(sLicences);
	}
}

void CLicensePage::DoDataExchange(CDataExchange* pDX)
{
	CLicensePageBase::DoDataExchange(pDX);
	for(int i=0; i<E_NUM_OPTIONS; i++) {
		DDX_Control(pDX, IDC_LBL_RTU_SERNO_ETHEN + i*2, m_lblLicences[i]);
	}
}


BEGIN_MESSAGE_MAP(CLicensePage, CLicensePageBase)
	//{{AFX_MSG_MAP(CLicensePage)
	ON_BN_CLICKED(IDOK, OnOK)
	ON_BN_CLICKED(IDC_BTN_RTU_SERNO_ETHEN, OnBtnEthernet)
	ON_BN_CLICKED(IDC_BTN_RTU_SERNO_ACCEN, OnBtnAccess)
	ON_BN_CLICKED(IDC_BTN_RTU_SERNO_ALMEN, OnBtnAlmPanel)	
	ON_BN_CLICKED(IDC_BTN_RTU_SERNO_HLIEN, OnBtnElevator)
	ON_BN_CLICKED(IDC_BTN_RTU_SERNO_RTEEN, OnBtnIriProt)
	ON_BN_CLICKED(IDC_BTN_RTU_SERNO_DRPTEN, OnBtnDualRpt)
	ON_BN_CLICKED(IDC_BTN_RTU_SERNO_MCFEN, OnBtnMultiFormat)
	ON_BN_CLICKED(IDC_BTN_RTU_SERNO_PTZEN, OnBtnPtzDriver)
	ON_BN_CLICKED(IDC_BTN_RTU_SERNO_INVEN, OnBtnInnovonics)
	ON_BN_CLICKED(IDC_BTN_RTU_SERNO_HHLIEN, OnBtnHostHLI)
	ON_BN_CLICKED(IDC_BTN_RTU_SERNO_RMT_MAINT, OnBtnRemoteMaint)
	ON_BN_CLICKED(IDC_BTN_RTU_SERNO_GEN_DVR, OnBtnGenDVRInterface)
	ON_BN_CLICKED(IDC_BTN_RTU_SERNO_EPAP, OnBtnEPAP)
	ON_BN_CLICKED(IDC_BTN_CHANGE_LIMIT_2, OnBtnUpdateNumberOfAperioReaders)
	ON_MESSAGE(WM_GMS, OnGms)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CLicense8001Page message handlers
/////////////////////////////////////////////////////////////////////////////
BOOL CLicensePage::OnInitDialog() 
{
	CLicensePageBase::OnInitDialog();
	
	m_lblSerialNumber.SubclassDlgItem(IDC_CTRL_ID_1, this);
	CString strSerNum; strSerNum.Format(_T("%s: %s"), RES_STRING(IDS_CTRL_SERIAL_NUMBER), (LPCTSTR)m_str);
	m_lblSerialNumber.SetText(strSerNum, FALSE);

	m_lblLicenseOptions.SubclassDlgItem(IDC_CTRL_ID_2, this);
	m_lblLicenseOptions.SetText(RES_STRING(IDS_LICENSE_OPTIONS), TRUE);

	if(realRtuType == RTU_8001_TYPE) {
		m_lblLicenseLimits.SubclassDlgItem(IDC_CTRL_ID_3, this);
		m_lblLicenseLimits.SetText(_T(""), FALSE);

		m_lblAperioLimit.SubclassDlgItem(IDC_CTRL_ID_4, this);
		CString s; GetDlgItemText(IDC_CTRL_ID_4, s);
		m_lblAperioLimit.SetText(s);
		
		if(m_bLicenceLimit) {
			for(int i=0; i<16; i++) {
				Rtu::RtuLib::SwapByteOrder(m_licenceLimits[i]);
			}
			if(GetDlgItem(IDC_BTN_CHANGE_LIMIT_2))
				GetDlgItem(IDC_BTN_CHANGE_LIMIT_2)->EnableWindow(TRUE);
			if(GetDlgItem(IDC_TXT_LICENCE_LIMIT_2))
				SetDlgItemInt(IDC_TXT_LICENCE_LIMIT_2, m_licenceLimits[1]);
		}
	}

	if(m_nByteCount < 16) {
		GetDlgItem(IDC_BTN_RTU_SERNO_INVEN)->EnableWindow(FALSE);
		GetDlgItem(IDC_BTN_RTU_SERNO_HHLIEN)->EnableWindow(FALSE);
		GetDlgItem(IDC_BTN_RTU_SERNO_RMT_MAINT)->EnableWindow(FALSE);
		GetDlgItem(IDC_BTN_RTU_SERNO_GEN_DVR)->EnableWindow(FALSE);
	}

	ShowLicenceOption();
	return TRUE;
}

void CLicensePage::InitializeComponent()
{
	/*int ids[] = {
		IDC_LBL_RTU_SERNO_ETHEN,
		IDC_LBL_RTU_SERNO_ACCEN,
		IDC_LBL_RTU_SERNO_ALMEN,
		IDC_LBL_RTU_SERNO_ELEEN,
		IDC_LBL_RTU_SERNO_RTEEN,
		IDC_LBL_RTU_SERNO_DRPTEN,
		IDC_LBL_RTU_SERNO_MCFEN,
		IDC_LBL_RTU_SERNO_PTZEN,
		IDC_LBL_RTU_SERNO_INVEN,
		IDC_LBL_RTU_SERNO_HHLIEN,
		IDC_LBL_RTU_SERNO_RMT_MAINT,
		IDC_LBL_RTU_SERNO_GEN_DVR,
		IDC_LBL_RTU_SERNO_EPAP
	};

	int ids8001[] = {
		IDC_LBL_RTU_SERNO_ACCEN,
		IDC_LBL_RTU_SERNO_ALMEN,
		IDC_LBL_RTU_SERNO_ELEEN,
		IDC_LBL_RTU_SERNO_DRPTEN,
		IDC_LBL_RTU_SERNO_PTZEN,
		IDC_LBL_RTU_SERNO_INVEN,
		IDC_LBL_RTU_SERNO_HHLIEN,
		IDC_LBL_RTU_SERNO_RMT_MAINT,
		IDC_LBL_RTU_SERNO_GEN_DVR,
	};*/

	if(realRtuType == RTU_8001_TYPE) {
	}
	else {
	}
}

void CLicensePage::SetLicenceOption(char* ptr)
{
	if(ptr == NULL)
		return;
	memcpy(m_licence, ptr, 16);
	for(int i=0; i<E_NUM_OPTIONS; i++)
	{
		m_licence[i] == licenseOptions[i] ? m_bOpStat |= (1 << i) : m_bOpStat &= ~(1 << i);
	}
}

void CLicensePage::ShowLicenceOption()
{	
	for(int i=0; i<E_NUM_OPTIONS; i++)
	{
		UpdateOption(IDC_BTN_RTU_SERNO_ETHEN + i*2, 
				IDC_LBL_RTU_SERNO_ETHEN + i*2, i, m_licence[i] == licenseOptions[i]);
	}

	if(realRtuType == RTU_8001_TYPE) {
		if(m_licence[1] == licenseOptions[1]) {	// Large model system enabled
			// Disable medium model system
			GetDlgItem(IDC_BTN_RTU_SERNO_ALMEN)->EnableWindow(FALSE);
			//m_lblLicences[2].SetTextColor(RGB(0x80, 0x80, 0x80));
			m_lblLicences[2].SetText(RES_STRING(IDS_MEDIUM_MODEL_SYS_EN), _T("#808080"));
		}
	}
}

void CLicensePage::ChangeOption(int opNum)
{
	int op = (m_bOpStat & (1 << opNum)) ? (opNum * 2) + 1 : (opNum * 2);
	m_nCurOp = opNum;
	CRTULicenceRenew licDlg(op, m_nAddress1, m_nAddress2, CWnd::FromHandle(m_hWnd));	
	if(licDlg.DoModal() == IDOK){
		m_bChangeLicenceLimit = FALSE;
	}
}

void CLicensePage::ChangeLicenceLimit()
{
	CRTULicenceRenew licDlg(0, m_nAddress1, m_nAddress2, CWnd::FromHandle(m_hWnd), TRUE, m_nLicenceLimitNumber);	
	if(licDlg.DoModal() == IDOK){
		m_bChangeLicenceLimit = TRUE;
		m_nLimits = licDlg.GetLicenceLimit();
	}
}

LRESULT CLicensePage::OnGms(WPARAM wParam, LPARAM lParam)
{
	int id = GET_WM_COMMAND_ID(wParam, lParam);
	switch (id)
	{
	case IDD_COMMOVR_ERROR:
		return FALSE;
		break;
	case IDD_COMMOVR_CTRL_NUM:
	case IDD_COMMOVR_DATA:
		if(lParam == NULL)
			return FALSE;
		else
		{
			if((realRtuType == RTU_8001_TYPE) && (m_bChangeLicenceLimit)) {
				if(GetDlgItem(IDC_TXT_LICENCE_LIMIT_1+m_nLicenceLimitNumber))
					SetDlgItemInt(IDC_TXT_LICENCE_LIMIT_1+m_nLicenceLimitNumber, m_nLimits);
				break;
			}

			BOOL flag;
			int bitpos = 1 << m_nCurOp;
			if(m_bOpStat & bitpos)
				m_bOpStat &= ~bitpos;
			else
				m_bOpStat |= bitpos;
			flag = (m_bOpStat & bitpos) ? TRUE : FALSE;
			
			UpdateOption(IDC_BTN_RTU_SERNO_ETHEN + (m_nCurOp * 2), 
				IDC_LBL_RTU_SERNO_ETHEN + (m_nCurOp * 2), m_nCurOp, flag);

			if((m_nCurOp == 1) && (realRtuType == RTU_8001_TYPE)) {
				if(flag == FALSE) {	// Large model system disabled
					// Enable medium model system
					GetDlgItem(IDC_BTN_RTU_SERNO_ALMEN)->EnableWindow(TRUE);
					//m_lblLicences[2].SetTextColor(m_licence[2] == licenseOptions[2] ? RGB(0,0,255) : RGB(255,0,0));
					CString s = RES_STRING(m_licence[2] == licenseOptions[2] ? IDS_MEDIUM_MODEL_SYS_EN : IDS_MEDIUM_MODEL_SYS_DIS);
					m_lblLicences[2].SetText(s, m_licence[2] == licenseOptions[2] ? _T("#0000ff") : _T("#ff0000"));

				} else {
					GetDlgItem(IDC_BTN_RTU_SERNO_ALMEN)->EnableWindow(FALSE);
					//m_lblLicences[2].SetTextColor(RGB(0x80,0x80,0x80));
					CString s; GetDlgItemText(IDC_LBL_RTU_SERNO_ELEEN, s);
					m_lblLicences[2].SetText(RES_STRING(IDS_MEDIUM_MODEL_SYS_EN), _T("#808080"));
				}
			}
		}
		break;

	default:
		break;
	}

	return TRUE;
}

void CLicensePage::UpdateOption(UINT id1, UINT, int index, BOOL flag)
{
	CStringArray strArr;
	if(flag) {
		GetEnabledStrings(strArr);
		GetDlgItem(id1)->SetWindowText(RES_STRING(IDS_DISABLE_U));
	}
	else {
		GetDisabledStrings(strArr);
		GetDlgItem(id1)->SetWindowText(RES_STRING(IDS_ENABLE_U));
	}
		
	//GetDlgItem(id2)->SetWindowText(strArr.GetAt(index));
	//m_lblLicences[index].SetTextColor(flag ? RGB(0,0,255) : RGB(255,0,0));
	CString strText = strArr.GetAt(index);
	m_lblLicences[index].SetText(strText, flag ? _T("#0000ff") : _T("#ff0000"));
}
#pragma endregion

///////////////////////////////////////////////////////////////////////////////
// CPropertyPageTaskPanelNavigator class
///////////////////////////////////////////////////////////////////////////////
#pragma region CPropertyPageTaskPanelNavigator class

CPropertyPageTaskPanelNavigator::CPropertyPageTaskPanelNavigator()
{
}

BOOL CPropertyPageTaskPanelNavigator::Create()
{
	CFont* pFont = m_pSheet->GetFont();

	if (!CXTPTaskPanel::Create(WS_VISIBLE | WS_CHILD | WS_GROUP | WS_TABSTOP, CRect(0, 0, 0, 0), m_pSheet, 1000))
		return FALSE;

	SetBehaviour(xtpTaskPanelBehaviourList);
	
	SetTheme(xtpTaskPanelThemeShortcutBarOffice2003);
	SetSelectItemOnFocus(TRUE);

	SetIconSize(CSize(32, 32));

	SetFont(pFont);

	CXTPTaskPanelGroup* pGroup = AddGroup(0);
	pGroup->SetCaption(_T("Options"));

	for (int i = 0; i < m_pSheet->GetPageCount(); i++)
	{
		CXTPPropertyPage* pPage = m_pSheet->GetPage(i);

		CString strCaption = pPage->GetCaption();

		CXTPTaskPanelGroupItem* pItem = pGroup->AddLinkItem(i, i);
		pItem->SetCaption(strCaption);
		pItem->SetItemData((DWORD_PTR)pPage);
		pPage->m_dwData = (DWORD_PTR)pItem;
	}

	//GetImageManager()->SetIcon(_T("8001_INP_BMP"), 0);
	GetImageManager()->SetIcon(IDI_ICON1, 0);
	GetImageManager()->SetIcon(IDI_ICON2, 1);


	m_pSheet->SetPageBorderStyle(xtpPageBorderBottomLine);

	return TRUE;
}

void CPropertyPageTaskPanelNavigator::OnPageSelected(CXTPPropertyPage* pPage)
{
	CXTPTaskPanelGroupItem* pItem = (CXTPTaskPanelGroupItem*)pPage->m_dwData;
	SetFocusedItem(pItem);
}

void CPropertyPageTaskPanelNavigator::SetFocusedItem(CXTPTaskPanelItem* pItem, BOOL bDrawFocusRect /*= FALSE*/, BOOL bSetFocus)
{
	if (m_pItemFocused != pItem && pItem && pItem->GetType() == xtpTaskItemTypeLink)
	{
		CXTPPropertyPage* pPage = (CXTPPropertyPage*)pItem->GetItemData();
		if (!m_pSheet->SetActivePage(pPage))
		{
			return;
		}
	}

	CXTPTaskPanel::SetFocusedItem(pItem, bDrawFocusRect, bSetFocus);

}
#pragma endregion

