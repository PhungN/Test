#pragma once


#pragma warning(disable : 4996)

#include "MyLib\FileLib.h"
#include "HardwareConfig\Rtu\PANELGRF\PANELHDR.H"


// TT 6971
class KeypadLcdCodepage
{
private:
	static KeypadLcdCodepage* _instance;
	CMap<BYTE, BYTE, BYTE, BYTE> _mapping;
	CMap<BYTE, BYTE, BYTE, BYTE> _reversed_mapping;
	BYTE _unicodePage;
	BYTE _defaultMap;
	bool _reverse;

	KeypadLcdCodepage()
	{
		_unicodePage = 0xFF; // used as a 'ready' flag as well
		_reverse = false;

		// first get the current GMS language.
		CString GMSlanguage;
		const TCHAR* cmdLine=GetCommandLine();
		CString cmdLineStr(cmdLine);
		int curPos=0;
		CString token;
		do {
			token = cmdLineStr.Tokenize(L" ", curPos);
			int offset= token.MakeUpper().Find(L"/X");
			if( offset != -1)
			{
				GMSlanguage = token.Mid(offset + 2);
			}
		} while(token != L"");
		if(GMSlanguage == L"") GMSlanguage = L"English";
		//
		// now parse the Keypad_LCD_fontpage.cfg file. Located on a server, in Language\XXXXX folder.
		DefaultLocation fName(CString(L"Language\\") + GMSlanguage + L"\\Keypad_LCD_fontpage.cfg"); // take the file from the active server
		CStdioFile configFile;

		if(configFile.Open(fName.Path, CFile::modeRead ))
		{
			// There must be a single line UNICODE=XX,CC. XX is a unicode page (hex) (like 0 for English, 4 for Cyrillic, 5 for Hebrew) and 
			// CC is a default code (hex) of a character to map into, when the unicode page is correct but no matching rule could be found for a character.
			// Matching rules are defines as lines UU:CC  where UU is a unicode character (in hex), and CC is ASCII code (in hex). For example: E5:86
			// A comment line begins with ;
			// Optionally there may be a line REVERSE=YES or REVERSE=NO. If 'yes', the input text will be reversed (something that it necessary for Hebrew) 
			CString oneLine;
			while(	configFile.ReadString(oneLine))
			{
				if( oneLine[0] == ';') continue;
				int offset = oneLine.MakeUpper().Find(L"UNICODE=");
				if( offset == 0)
				{
					CString unicodePageStr = oneLine.Mid(wcslen(L"UNICODE="));
					int page;
					int defaultMap;
					if( swscanf(unicodePageStr,L"%X,%X",&page,&defaultMap) == 0) 
					{
						OutputDebugString(L"Error in Keypad_LCD_fontpage.cfg\n");
						return; // error
					}
					_unicodePage = (BYTE)page;
					_defaultMap = (BYTE)defaultMap;
					continue;
				}
				offset = oneLine.MakeUpper().Find(L"REVERSE=YES");
				if( offset == 0)
				{
					_reverse = true;
					continue;
				}
				int uu=0;
				int cc=0;
				if( swscanf(oneLine,L"%X:%X",&uu,&cc) !=2 || cc > 255 || cc < 0)
				{
					OutputDebugString(L"Error in Keypad_LCD_fontpage.cfg\n");
					return; // error
				}
				_mapping[(BYTE)uu] = (BYTE)cc;
				_reversed_mapping[(BYTE)cc]=(BYTE)uu;
			}
			if( _unicodePage == 0xFF)
			{
				OutputDebugString(L"Error in Keypad_LCD_fontpage.cfg\n");
				return; // error
			}
		}
	}
public:
	static KeypadLcdCodepage* GetInstance()
	{
		if( _instance == NULL)
		{
			_instance = new KeypadLcdCodepage();
		}
		return _instance;
	}
	void ConvertFromGmsToLcd(const CString& unicodeText, char* pAsciiText, int maxLen)
	{
		*pAsciiText = '\0';
		if( _unicodePage == 0xFF) // no mapping defined. Return ASCII
		{
			CT2A ascii(unicodeText);
			if( maxLen == -1)
				strcpy(pAsciiText, ascii);
			else
				strncpy(pAsciiText, ascii, maxLen);
			return;
		}
		TCHAR oneByte;
		int ind;
		bool bAtLeastOneSubstituted = false;
		for( ind=0; ind < unicodeText.GetLength(); ind++)
		{
			oneByte = unicodeText[ind];
			BYTE unicodePage = oneByte>>8;
			BYTE aChar = oneByte%256;
			if(unicodePage != _unicodePage) // a character from different unicode page. Save as the same value in English
			{
				pAsciiText[ind] = aChar;
				continue;
			}
			BYTE mapInto;
			if( _mapping.Lookup((BYTE)(aChar), mapInto) )
			{
				bAtLeastOneSubstituted = true;
			}
			else 
			{
				if(unicodePage != 0) // map to default character, unless it is UnicodePage=0 (English). If English, leave it as it is.
					mapInto = _defaultMap;
				else
					mapInto = aChar;
			}
			pAsciiText[ind] = mapInto;

		}
		pAsciiText[ind]=0;
		if( _reverse && bAtLeastOneSubstituted) // reverse the text only if configured AND if at least one character was converted. If not
												// a single character was converted (for instance when the entire text was in English), then 
												// we assume that the text should remain as it is.
		{
			char reversedText[256]; memset(reversedText, 0, 256);
			for(int reverseInd=0; reverseInd < ind; reverseInd++)
			{
				reversedText[reverseInd] = pAsciiText[ind-1- reverseInd];
			}
			memcpy(pAsciiText, reversedText, ind);
		}
	}
	void ConvertFromLcdToGMS(char* pAsciiText, CString& unicodeText )
	{
		unicodeText = "";

		int asciiLen = strlen(pAsciiText);
		if( asciiLen > MAX_SPC_VOC_LEN)
		{
			unicodeText="";
			return;
		}
		if( _unicodePage == 0xFF) // no mapping defined. Return same text as CString
		{
			CString ascii(pAsciiText);
			unicodeText = ascii;
			return;
		}
		
		char tmpBuf[256]; strcpy(tmpBuf, pAsciiText);

		if( _reverse)
		{
			// scan to find out is there is anything to substitute. If so, then reverse. This is to allow keeping plain English text in natural order.
			for(WORD ind=0; ind < asciiLen; ind++)
			{
				BYTE oneChar = tmpBuf[ind];
				BYTE mapInto;
				if( _reversed_mapping.Lookup(oneChar, mapInto) )
				{ // a character needs substitution, so the text must be reversed.
					char reversedText[256];
					for(int reverseInd=0; reverseInd < asciiLen; reverseInd++)
					{
						reversedText[reverseInd] = pAsciiText[asciiLen-1- reverseInd];
					}
					memcpy(tmpBuf, reversedText, asciiLen);
					break;
				}
			}
		}
		unicodeText = L"";
		for(WORD ind=0; ind < asciiLen; ind++)
		{
			BYTE oneChar = tmpBuf[ind];
			BYTE mapInto;
			TCHAR unicodeChar;
			if( _reversed_mapping.Lookup(oneChar, mapInto) )
			{
				unicodeChar = _unicodePage*256 + mapInto;
			}
			else
			{
				unicodeChar = 0*256 + oneChar; // map into English
			}
			unicodeText.AppendChar(unicodeChar);
		}


	}

};
