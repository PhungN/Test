/********************************************************************************************************
 *		Description: RTU configuration window.
 *
*******************************************************************************************************/

#include "stdafx.h"
#include <math.h>
#include "RtuStatus.h"
#include "HardwareConfig\Protocols\Comm32\resource.h"
#include "GMS\CommonUse\CommonDefs.h"
#include "PANELGRF\PANELHDR.H"
#include <array>

using namespace Rtu;

#define TXT_EXTENT		1

#pragma region extern params..

extern int			realRtuType;
extern int			RtuType;
extern int			gRtuNo;
extern HINSTANCE	hrInst;
extern BYTE			iblk;

#pragma endregion extern params..

#pragma region local static variables..

static TCHAR* colors[] = {_T("bgcolor=#ffffe0"), _T("bgcolor=#add8e6"), 
	_T("bgcolor=#ffd700"), _T("bgcolor=#ffdead")};

static DEVICE_FIRMWARE s_keypadFirmware[MAX_RTU_KEYPADS];
static BOOL s_bKeypadFirmware;

static DEVICE_FIRMWARE s_ioFirmware[MAX_RTU_IOS];
static BOOL s_bIoFirmware;

static DEVICE_FIRMWARE s_cardReaderFirmware[MAX_RTU_READERS];
static BOOL s_bCardReaderFirmware;

#pragma endregion local static variables..

BOOL gIsCP01Panel = FALSE;

//............................................................................
BOOL IsRtu8002Type(); // defined in Rtulib.cpp
//............................................................................

void GetVocabList(CStringArray&);
//............................................................................

CString GetDevTypeString(BYTE nDevType)
{
	switch(nDevType)
	{
	case eDeviceConfigType::P1061_TYPE:// 9:
	case eDeviceConfigType::P1061R_TYPE: //10:
	case eDeviceConfigType::P1061Q_TYPE: //16:
		return _T("1061");
	case eDeviceConfigType::P1065_TYPE: //11:
		return _T("1065");
	case eDeviceConfigType::P1062_TYPE: //12:
	case eDeviceConfigType::P1062_DVR_TYPE: //23:
		return _T("1062");
	case eDeviceConfigType::P1064_ACC_TYPE: //14:
		return _T("1064(CRI)");
	case eDeviceConfigType::P1064_TYPE: //15:
		return _T("1064(I/O)");
	case eDeviceConfigType::ELEV_CTRL_TYPE: //17:
		return _T("1065(EC)");	
	case eDeviceConfigType::P1067_TYPE: //18:
		return _T("1067/1076");		
	case eDeviceConfigType::P1062_CRI_TYPE: //19:
		return _T("1062(CRI)");
	case eDeviceConfigType::P1068_TYPE: //21:
		return _T("1068(I/O)");
	case eDeviceConfigType::P1064EFM_TYPE: //22:
		return _T("1064(EFM)");
	case eDeviceConfigType::P1065EFM_TYPE: //24:
		return _T("1065(EFM)");
	case eDeviceConfigType::P1068_INOVONIC_TYPE: //25:
		return _T("1068(INOV)");
	case eDeviceConfigType::WAPM_ACC_TYPE: //26:
		return _T("Wyreless");
	case eDeviceConfigType::TIMECON_ACC_TYPE: //27:
		return _T("Timecon");
	case eDeviceConfigType::PX8_IO_CRI_TYPE: //28:
		return _T("PX-8");
	case eDeviceConfigType::P1064PM_TYPE: //29:
		return _T("1064(PM)");
	case eDeviceConfigType::P1076_TYPE: //30:
		return _T("1076(I/O)");
	case eDeviceConfigType::FIRE_PWR_TYPE: //31:
		return _T("8303");
	case eDeviceConfigType::P1076VC_TYPE: //32:
		return _T("1076(VC)");
	case eDeviceConfigType::P8501_TYPE: //38:
		return _T("8501");
	case eDeviceConfigType::P8601_TYPE: //41:
		return _T("8601");
	case eDeviceConfigType::P8602_TYPE: //43:
		return _T("8602");
	case eDeviceConfigType::P8003DCU_TYPE: //46
		return _T("8603");
	case eDeviceConfigType::P8502_TYPE: // 50
		return L"8502(PIR)";
	case 255:
		return _T("--");

	default:
#ifdef _DEBUG
		{
			CString db; db.Format(L"DeviceId-%d", nDevType);
		return db;
		}
#else
		return _T("");
#endif
	}
}

CString GetVersionString(BYTE major, BYTE minor)
{
	CString s;
	if (major == 0xff || minor == 0xff)
		s = _T("--");
	else
		s.Format(_T("%X.%02X"), major, minor);

	return s;
}

CString GetDevicePhysicalAddressString(BYTE address)
{
	CString s;
	if (address == 0xff)
		s = _T("--");
	else
		s.Format(_T("%d"), address + 1);
	return s;
}

CString GetDevicePhysicalPortString(BYTE port)
{
	CStringArray strArr;
	GetRtuPortList(strArr, realRtuType, IsRtu8002Type());
	CString s;
	if (port == 0xff)
		s = _T("--");
	else {
		if (realRtuType == RTU_1058_TYPE && port > 4) {
			port -= 4;
		}
		else if (realRtuType == RTU_8001_TYPE) {
			switch(port) {
			case  0: port = 0; break;
			case  2: port = 1; break;
			case  3: port = 2; break;
			case  8: port = 3; break;
			case  9: port = 4; break;
			case 10: port = 5; break;
			case 11: port = 6; break;
			default: port = 0; break;
			}
		}
		
		if (port >= strArr.GetSize())
			s = _T("");
		else
			s = strArr.GetAt(port);	
	}
	return s;
}
CString GetExpansionMemoryString(LPBYTE pMemoryModule)
{
	BYTE memoryModule = *pMemoryModule & 0x03;
	if (realRtuType == RTU_8001_TYPE) {
		memoryModule = *pMemoryModule & 0x07;
	}
	CString strMemory = _T("");
	switch(memoryModule) {
		case 0: strMemory = RES_STRING(IDS_MEMORY_MODULE); break;
		case 1: strMemory = _T("4MB"); break;
		case 2: strMemory = _T("16MB"); break;
		case 3: strMemory = _T("32MB"); break;
		case 4: strMemory = _T("64MB"); break;
		case 5: strMemory = _T("128MB"); break;
		case 6: strMemory = _T("256MB"); break;
		case 7: strMemory = _T("512MB"); break;
	}
	return strMemory;
}
CString GetOnBoardFlashMemoryString(LPBYTE pFlashSize)
{
	BYTE flashSize = (BYTE)((*pFlashSize >> 4) & 0x03);
	CString str = _T("");
	switch(flashSize) {
		case 0:	flashSize = 4;	break;
		case 1:	flashSize = 8;	break;
		case 2:	flashSize = 16; break;
		case 3:	flashSize = 32; break;
	}
	str.Format(_T("%dMB"), flashSize);
	return str;
}

/*------------------------------------------------------------------------------*/
/*					DIPSW button Class											*/
/*------------------------------------------------------------------------------*/
#pragma region CDIPSWButton
BEGIN_MESSAGE_MAP(CDIPSWButton, CButton)
	//{{AFX_MSG_MAP(CDIPSWButton)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDIPSWButton message handlers
void CDIPSWButton::DrawItem(LPDRAWITEMSTRUCT lpDrawItemStruct) 
{

	CDC* pDC = CDC::FromHandle(lpDrawItemStruct->hDC);
	int nSaveDC = pDC->SaveDC();
	CRect rect;
	rect.CopyRect(&lpDrawItemStruct->rcItem);
	CRect tempRC;
	COLORREF bgColor = RGB(255,255,255);
	COLORREF fgColor = RGB(0,0,255);

	if (m_bDraw && (m_addr >= 0)) {
		tempRC.CopyRect(&rc1);
		pDC->Rectangle(&tempRC);
		tempRC.DeflateRect(1,1);
		pDC->FillSolidRect(&tempRC, bgColor);

		tempRC.CopyRect(&rc2);
		tempRC.DeflateRect(1,1);
		pDC->FillSolidRect(&tempRC, GetSysColor(COLOR_BTNFACE));

		tempRC.CopyRect(&rc3);
		tempRC.DeflateRect(1,1);
		pDC->FillSolidRect(&tempRC, GetSysColor(COLOR_BTNFACE));

		int n = 1;	
		CString str; 
		for(int i=0; i<m_numDS; i++) {				
			if ((1 << i) & m_addr)
				pDC->FillSolidRect(&rcb[i], fgColor);
			else
				pDC->FillSolidRect(&rct[i], fgColor);

			str.Format(_T("%d"), n++);
			CRect rc;
			rc.CopyRect(&rcl[i]);
			rc.top = rc2.top;
			rc.bottom = rc2.bottom;
			rc.InflateRect(3, 0);
			pDC->SetBkMode(TRANSPARENT);
			pDC->DrawText(str, &rc, DT_CENTER|DT_TOP|DT_SINGLELINE);
		}
		
		tempRC.CopyRect(&rc3);
		tempRC.top = rct[0].top;
		tempRC.bottom = rct[0].bottom;
		tempRC.InflateRect(0, 1);
		str.Format(_T("OFF"));
		pDC->DrawText(str, &tempRC, DT_CENTER|DT_TOP|DT_SINGLELINE);

		tempRC.CopyRect(&rc3);
		tempRC.top = rcb[0].top;
		tempRC.bottom = rcb[0].bottom;
		tempRC.InflateRect(0, 1);
		str.Format(_T("ON"));
		pDC->DrawText(str, &tempRC, DT_CENTER|DT_TOP|DT_SINGLELINE);

	}
	else {
		tempRC.CopyRect(&rect);
		tempRC.DeflateRect(1,1);
		pDC->FillSolidRect(&tempRC, GetSysColor(COLOR_BTNSHADOW));
	}

	pDC->RestoreDC(nSaveDC);
	ReleaseDC(pDC);
}

void CDIPSWButton::PreSubclassWindow() 
{
	ModifyStyle(0, BS_OWNERDRAW);
	CButton::PreSubclassWindow();
}


void CDIPSWButton::Init(int numDS)
{

	CRect rect;
	GetWindowRect(&rect);
	ScreenToClient(&rect);

	m_numDS = numDS;
	if (numDS > MAX_DIPSWITCH)
		numDS = MAX_DIPSWITCH;

	int cx = 2 * rect.Width() / 3;
	int cy = 2 * rect.Height() / 3;
	rc1.CopyRect(&rect);
	rc2.CopyRect(&rect);
	rc3.CopyRect(&rect);
	rc1.bottom = rc1.top + cy;
	rc1.right = rc1.left + cx;
	rc2.top = rc1.bottom;
	rc2.right = rc2.left + cx;
	rc3.left = rc1.right;
	
	cx = cx / (2 * numDS + 1);
	cy = cy / 5;

	for(int i=0; i<m_numDS; i++) {
		rct[i].left = rect.left + (cx * (2*i+1));
		rct[i].right = rct[i].left + cx;
		rct[i].top = rect.top + cy;
		rct[i].bottom = rct[i].top + cy;

		rcb[i].CopyRect(&rct[i]);
		rcb[i].top = rcb[i].top + 2 * cy;
		rcb[i].bottom = rcb[i].top + cy;

		rcl[i].CopyRect(&rct[i]);
		rcl[i].bottom = rcb[i].bottom;
	}

	for(int i=0; i<m_numDS; i++)  {
		rct[i].InflateRect(1, 2);
		rcb[i].InflateRect(1, 2);
	}
		
	m_bDraw = FALSE;
}

#pragma endregion CDIPSWButton

#pragma region Old configurations..

/*------------------------------------------------------------------------------*/
/*					RTU status Page Class												*/
/*------------------------------------------------------------------------------*/
#pragma region RTUStatus
RTUStatus::RTUStatus(LPPARMPROC lpps, int op, CWnd* pParent) : CDialog(RTUStatus::IDD, pParent)
{
	m_option = op; 
	m_lpps = lpps;
	m_pages = m_header = m_header1 = m_header2 = 0; 
	m_pStatus = NULL; m_bIs1060Panel = FALSE;
}

RTUStatus::~RTUStatus()
{
	if (m_pStatus) {
		delete[] m_pStatus; m_pStatus = NULL;
	}
}
void RTUStatus::DoDataExchange(CDataExchange* pDX) 
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(RTUStatus)
	DDX_Control(pDX, IDC_RTUTYPE_TXT, m_rtuType);
	DDX_Control(pDX, IDC_PANELTYPE_TXT, m_panelType);
	DDX_Control(pDX, IDC_COMMSTYPE_TXT, m_commType);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(RTUStatus, CDialog)
	//{{AFX_MSG_MAP(RTUStatus)
	ON_BN_CLICKED(IDOK, OnClose)
	ON_BN_CLICKED(IDC_BTN__STS_REFRESH, OnBtnRefresh)
	ON_MESSAGE(WM_GMS, OnGMS)
	ON_COMMAND(ID_RTU_STATUS_MODE, OnPrintModeStatus)
	ON_COMMAND(ID_RTU_STATUS_PANEL, OnPrintPanelStatus)
	ON_COMMAND(ID_RTU_STATUS_INPUT, OnPrintInputStatus)
	ON_COMMAND(ID_RTU_STATUS_OUTPUT, OnPrintOutputStatus)
	ON_COMMAND(ID_RTU_STATUS_CAMERA, OnPrintCameraStatus)
	ON_COMMAND(ID_RTU_STATUS_DEVINFO_KEYPAD, OnPrintDevInfoKeypadStatus)
	ON_COMMAND(ID_RTU_STATUS_DEVINFO_16IO, OnPrintDevInfo16IOStatus)
	ON_COMMAND(ID_RTU_STATUS_DEVINFO_CAMCTRL, OnPrintDevInfoCamCtrlStatus)
	ON_COMMAND(ID_RTU_STATUS_DEVINFO_ELEVCTRL, OnPrintDevInfoElevCtrlStatus)
	ON_COMMAND(ID_RTU_STATUS_DEVINFO_DIALER, OnPrintDevInfoDialerStatus)
	ON_COMMAND(ID_RTU_STATUS_DEVINFO_CARDRDR, OnPrintDevInfoCardRdrStatus)
	ON_COMMAND(ID_RTU_STATUS_DOOR, OnPrintDoorStatus)
	ON_COMMAND(ID_RTU_STATUS_CCTV, OnPrintCctvStatus)
	ON_COMMAND(ID_RTU_STATUS_ELEVATOR, OnPrintElevatorStatus)
	ON_COMMAND(ID_RTU_STATUS_DRIVE, OnPrintDriveStatus)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// RTU Status message handlers
BOOL RTUStatus::OnInitDialog() 
{
	CDialog::OnInitDialog();	
	m_lpps->heDlg = GetSafeHwnd();
	m_lpps->hmDlg = m_lpps->heDlg;

	m_rtuType.SetColors(LL_YELLOW, L_BLUE);
	m_panelType.SetColors(LL_YELLOW, L_BLUE);
	m_commType.SetColors(LL_YELLOW, L_BLUE);

	m_pagePanel57.m_psp.dwFlags &= ~PSP_HASHELP;
	m_pagePanel60.m_psp.dwFlags &= ~PSP_HASHELP;
	m_pageMode.m_psp.dwFlags &= ~PSP_HASHELP;
	m_pageInpSts.m_psp.dwFlags &= ~PSP_HASHELP;  
	m_pageOpSts.m_psp.dwFlags &= ~PSP_HASHELP;  
	m_pageCamSts.m_psp.dwFlags &= ~PSP_HASHELP; 
	m_pageCctvSts.m_psp.dwFlags &= ~PSP_HASHELP;
	m_pageKeypad.m_psp.dwFlags &= ~PSP_HASHELP;
	m_page16IO.m_psp.dwFlags &= ~PSP_HASHELP;
	m_pageCamCtrl.m_psp.dwFlags &= ~PSP_HASHELP;
	m_pageElevCtrl.m_psp.dwFlags &= ~PSP_HASHELP;
	m_pageDialer.m_psp.dwFlags &= ~PSP_HASHELP;
	m_pageCardRdr.m_psp.dwFlags &= ~PSP_HASHELP;
	m_pageDriveStatus.m_psp.dwFlags &= ~PSP_HASHELP;
	m_pagePowerMonitorStatus.m_psp.dwFlags &= ~PSP_HASHELP;
	m_pageVaultCtrlStatus.m_psp.dwFlags &= ~PSP_HASHELP;
	m_sheet.m_psh.dwFlags &= ~PSH_HASHELP;

	m_sheet.SetEmptyPageText(RES_STRING(IDS_SEL_AN_ITEM));
	m_sheet.SetTreeViewMode(TRUE, TRUE, TRUE);
	
	SetPageIcon();
	if (GetStatus())
		ShowStatus();

	DWORD styles =  WS_CHILD | WS_VISIBLE | WS_TABSTOP | WS_CLIPCHILDREN | DS_CONTROL;
	m_sheet.Create(this, styles, WS_EX_CONTROLPARENT); 
	//TT 8345
	AdjustPropertySheetLocation(this,&m_sheet, TRUE);

	m_sheet.SetActivePage(m_bIs1060Panel ? (CPropertyPage*)(&m_pagePanel60) : (CPropertyPage*)(&m_pagePanel57));

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

BOOL RTUStatus::GetStatus()
{
	if (m_pStatus) {
		delete[] m_pStatus; m_pStatus = NULL;
	}

	BOOL bResult = FALSE;
	TCHAR	filename[MAX_PATH];
	TCHAR	sFilePath[MAX_PATH] = {0};
	GetRtuParmFile(filename, RTUSTUS_FILE, MAKERTUNO(m_lpps->eType, m_lpps->eNo));
	
	wsprintf(sFilePath, L"%s\\%s", CUSTOMER_RTU_UPLOAD_FOLDER, filename);

	int nSize = 0;
	CMyFile stsFile;

	if (stsFile.Open(DefaultLocation(sFilePath), FILE_READ|FILE_DENYNONE)) {
		int flen = (int)stsFile.GetLength();
		if (flen) {
			m_pStatus = new BYTE[flen + 1];
			if (m_pStatus) {
				memset(m_pStatus, 0, flen+1);
				nSize = stsFile.Read(m_pStatus, flen);
				if (RtuType==RTU_1003_TYPE && *m_pStatus==RTU_MOSLER_10030_TYPE)
    				ConvertOld2New1003(m_pStatus+2);
				bResult = TRUE;
			}
			else {
				DispMessageBox(NULL, IDS_NOT_ENOUGH_MEM, IDS_RTU_PARAMS, MB_OK|MB_ICONSTOP);
				GetDlgItem(IDC_BTN__STS_REFRESH)->EnableWindow(TRUE);
			}
		}

		stsFile.Close();
	}

	return bResult;
}


LRESULT RTUStatus::OnGMS(WPARAM wParam, LPARAM lParam)
{
	LPBYTE	p = (LPBYTE)lParam;
	if (p == NULL)
		return 0;

	UINT id = GET_WM_COMMAND_ID(wParam, lParam);
	switch(id) {
		case IDD_COMMOVR_ERROR:
			break;
		case IDD_COMMOVR_CTRL_NUM:
			if (GetStatus()) {
				ShowStatus();
				((CRtuStatusBase*)m_sheet.GetActivePage())->ShowStatus();
				GetDlgItem(IDC_BTN__STS_REFRESH)->EnableWindow(TRUE);
				SetFocus();
			}
			break;

		default:
			break;
	}
	
	return(0);
}

void RTUStatus::OnBtnRefresh()
{
	int id = -1;
	GetDlgItem(IDC_BTN__STS_REFRESH)->EnableWindow(FALSE);
	if (RtuType != RTU_1003_TYPE && RtuType != RTU_DIEBOLD_TYPE)
		id = PspGetRtuStatus(m_lpps, iblk, m_lpps->BlkNo<<1);
	else 
		id = get_masked_rtu_status(m_lpps, m_lpps->BlkNo);

	if (id==-1)	{
		wMessageBox(m_lpps->heDlg, CanotDnload, RES_STRING(IDS_RTU_PARAMS), MB_OK|MB_ICONSTOP);
		GetDlgItem(IDC_BTN__STS_REFRESH)->EnableWindow(TRUE);
		return;
	}

}

void RTUStatus::ShowStatus()
{
	if (IsWindow(m_hWnd) == FALSE) return;
	if (m_pStatus == NULL)
		return;

	CMenu* pMenu = this->GetMenu();
	pMenu = pMenu->GetSubMenu(0);
	for(int m=0; m<15; m++)
		pMenu->EnableMenuItem(ID_RTU_STATUS_MODE + m, MF_GRAYED);

	CString str;
	LPTSTR rtuTypeStr;
	TCHAR panelTypeStr[48], commTypeStr[48];

	LPBYTE p1 = m_pStatus;
	LPBYTE ptrHCnt = p1 + 3;
	BYTE nRtuType = *p1;
	if (RtuLib::IsNewControllerType(nRtuType)) {
		m_bIs1060Panel = FALSE;
	}
	else {
		m_bIs1060Panel = TRUE;
	}

	rtuTypeStr = GetRTUType(nRtuType);

	m_rtuType.SetText(rtuTypeStr);

	wsprintf(panelTypeStr, _T("%hs"), GetPanelType(*(p1 + 1)));
	m_panelType.SetText(panelTypeStr);

	LoadCommString(NetTypeMsg + *(p1 + 2), commTypeStr, 32);
	m_commType.SetText(commTypeStr);

	str.Format(_T("Controller ID - %d (%s) : %s"), gRtuNo+1, panelTypeStr, commTypeStr);
	SetWindowText(str);

	m_headerCount = (BYTE)(*(p1 + 3) >> 4);
	m_header = *ptrHCnt;

	p1 = GetStatusPtr(m_pStatus);			//.p1 pointing to 'ModeStatus' count
	
	// Check if mode status included
	p1 = AddStatusPage(p1, (m_header & HB0_MODE_STATUS_INC), ModePage, &m_pageMode, ID_RTU_STATUS_MODE, pMenu);
	
	//..... Display the Panel Status data .......
	// Check if panel included
	if (m_header & HB0_PANEL_STATUS_INC) {
		if (m_bIs1060Panel) {
			p1 = AddStatusPage(p1, TRUE, Panel60Page, &m_pagePanel60, ID_RTU_STATUS_PANEL, pMenu);
		}
		else {
			p1 = AddStatusPage(p1, TRUE, Panel57Page, &m_pagePanel57, ID_RTU_STATUS_PANEL, pMenu);
		}
	}

	p1 = AddStatusPage(p1, (m_header & HB0_ALARM_STATUS_INC), InputPage, &m_pageInpSts, ID_RTU_STATUS_INPUT, pMenu);
	p1 = AddStatusPage(p1, (m_header & HB0_OUTPUT_STATUS_INC), OutputPage, &m_pageOpSts, ID_RTU_STATUS_OUTPUT, pMenu);
	m_header1 = *(ptrHCnt + 1);	// Get header byte 1
	
	// Check if camera status included
	BOOL bAdded = (m_headerCount && (m_header1 & HB1_CAMERA_STATUS_INC)) ? TRUE : FALSE;;
	p1 = AddStatusPage(p1, bAdded, CameraPage, &m_pageCamSts, ID_RTU_STATUS_CAMERA, pMenu);
	
	// Setup device info data
	if (m_headerCount) {
		p1 = SetDevInfoStatus(p1, pMenu);
	}

	// Check if latch status included
	if (m_headerCount && (m_header1 & HB1_INPUT_LATCH_STATUS_INC))
		p1 = m_pageInpSts.SetLatchStsData(p1);

	// Check if soak status included
	if (m_headerCount && (m_header1 & HB1_SOAK_STATUS_INC))
		p1 = m_pageInpSts.SetSoakStsData(p1);

	// Check if reader status included
	bAdded = (m_headerCount && (m_header1 & HB1_READER_STATUS_INC))?TRUE:FALSE;
	p1 = AddStatusPage(p1, bAdded, DoorPage, &m_pageReader, ID_RTU_STATUS_DOOR, pMenu);

	// Check if CCTV status included
	bAdded = (m_headerCount && (m_header1 & HB1_CCTV_STATUS_INC))?TRUE:FALSE;
	p1 = AddStatusPage(p1, bAdded, CctvPage, &m_pageCctvSts, ID_RTU_STATUS_CCTV, pMenu);
					 
	m_header2 = *(ptrHCnt + 2);	//Get header byte 2
	// p1 points to elevator status
	bAdded = (m_headerCount > 1 && (m_header2 & HB2_ELEVATOR_STATUS_INC))?TRUE:FALSE;
	p1 = AddStatusPage(p1, bAdded, ElevatorFloorPage, &m_pageElevFlr, ID_RTU_STATUS_ELEVATOR, pMenu);
	
	// p1 points to drive status
	bAdded = (m_headerCount > 1 && (m_header2 & HB2_DRIVE_STATUS_INC))?TRUE:FALSE;
	p1 = AddStatusPage(p1, bAdded, DrivePage, &m_pageDriveStatus, ID_RTU_STATUS_DRIVE, pMenu);

	// extended reader status
	if (m_headerCount > 1 && (m_header2 & HB2_EXTENDED_READER_INC))	{
		BYTE numReaders = *p1++;
		int readerSize = 5;
		if (numReaders & 0x80) {
			numReaders &= 0x7f;
			readerSize = *(p1++);
		}
		
		int extReaderSize = numReaders * readerSize;
		//BYTE* pExtendedReaderData = new BYTE[extReaderSize];
		//memcpy(pExtendedReaderData, p1, extReaderSize);
		p1 += extReaderSize;
	}

	// power monitor status
	bAdded = (m_headerCount > 1 && (m_header2 & HB2_POWER_MONITOR_INC))?TRUE:FALSE;
	p1 = AddStatusPage(p1, bAdded, PowerMonitorPage, &m_pagePowerMonitorStatus, ID_RTU_STATUS_POWER_MONITOR, pMenu);

	// vault controller status
	bAdded = (m_headerCount > 1 && (m_header2 & HB2_VAULT_CONTROLLER_INC))?TRUE:FALSE;
	p1 = AddStatusPage(p1, bAdded, VaultControllerPage, &m_pageVaultCtrlStatus, ID_RTU_STATUS_POWER_MONITOR, pMenu);

	// device firmware version
	s_bKeypadFirmware = FALSE;
	s_bIoFirmware = FALSE;
	s_bCardReaderFirmware = FALSE;
	memset(s_keypadFirmware, 0xff, sizeof(s_keypadFirmware));
	memset(s_ioFirmware, 0xff, sizeof(s_ioFirmware));
	memset(s_cardReaderFirmware, 0xff, sizeof(s_cardReaderFirmware));
	int nDeviceSize = sizeof(DEVICE_FIRMWARE);
	if (m_headerCount > 1 && (m_header2 & HB2_DEVICE_FIRMWARE_INC))	{
		BYTE* pDevFirmware = p1;
		BYTE deviceType;// = *pDevFirmware++;
		BYTE numDevices;// = *pDevFirmware++;

		int bc = 0;// numDevices * 5;
		do {
			deviceType = *pDevFirmware++;
			numDevices = *pDevFirmware++;
			
			int nMax = numDevices;
			if ((deviceType & 0x7f) == 0x03) { // Keypad type
				if (nMax > MAX_RTU_KEYPADS)
					nMax = MAX_RTU_KEYPADS;
				memcpy(s_keypadFirmware, pDevFirmware, nMax * nDeviceSize);
				s_bKeypadFirmware = TRUE;
			}
			else if ((deviceType & 0x7f) == 0x04) { // IO type
				if (nMax > MAX_RTU_IOS)
					nMax = MAX_RTU_IOS;
				memcpy(s_ioFirmware, pDevFirmware, nMax * nDeviceSize);
				s_bIoFirmware = TRUE;
			}
			else if ((deviceType & 0x7f) == 0x29) { // Card reader type
				if (nMax > MAX_RTU_READERS)
					nMax = MAX_RTU_READERS;
				memcpy(s_cardReaderFirmware, pDevFirmware, nMax * nDeviceSize);
				s_bCardReaderFirmware = TRUE;
			}
			bc += numDevices * nDeviceSize;
			pDevFirmware += numDevices * nDeviceSize;
			
		}while(!(deviceType & 0x80));

		p1 = pDevFirmware;
	}

	if (m_headerCount > 1 && (m_header2 & HB2_INPUT_EXTENDED_DATA_INC)) {
		p1 = m_pageInpSts.SetExtendeInputData(p1);
	}
}

LPBYTE RTUStatus::AddStatusPage(LPBYTE pData, BOOL bAdded, ulong mask, CRtuStatusBase* pPage, UINT menuID, 
	CMenu* pMenu, int cnt, BOOL inc)
{
	LPBYTE p = pData;
	
	if (bAdded) {
		p = pPage->SetStatus(p, cnt, inc);
		if (pPage->IsValid()) {
			if (!(m_pages & mask)) {
				m_sheet.AddPage(pPage);
				m_pages |= mask;
			}
			
			pMenu->EnableMenuItem(menuID, MF_ENABLED);
			return p;
		}
	}
	if (m_pages & mask) {
		m_sheet.RemovePage(pPage);
		m_pages &= ~mask;
	}
	
	pMenu->EnableMenuItem(menuID, MF_GRAYED);
	return p;
}

void RTUStatus::SetPageIcon()
{
	// Panel status 
	CImageList PanelImg;
	PanelImg.Create(IDB_PANEL, 12, 0, RGB(0x00, 0x80, 0x80));
	CTreePropSheet::SetPageIcon(&m_pagePanel60, PanelImg, 0);
	CTreePropSheet::SetPageIcon(&m_pagePanel57, PanelImg, 0);

	// Mode status
	CTreePropSheet::SetPageIcon(&m_pageMode, PanelImg, 1);

	// Input status
	CImageList inpImg;
	inpImg.Create(IDB_INPUTS, 12, 0, RGB(0x00, 0x80, 0x80));
	CTreePropSheet::SetPageIcon(&m_pageInpSts, inpImg, 0);

	// Output status
	CImageList outImg;
	outImg.Create(IDB_OUTPUTS, 12, 0, RGB(0x00, 0x80, 0x80));
	CTreePropSheet::SetPageIcon(&m_pageOpSts, outImg, 0);

	// Camera status
	CImageList camImg;
	camImg.Create(IDB_CAMERAS, 18, 0, RGB(0x00, 0x80, 0x80));
	CTreePropSheet::SetPageIcon(&m_pageCamSts, camImg, 0);

	// CCTV status
	CImageList cctvImg;
	cctvImg.Create(_T("CCTVCAMERA"), 23, 0, RGB(0, 0x80, 0x80));
	CTreePropSheet::SetPageIcon(&m_pageCctvSts, cctvImg, 0);

	// device info status
	// Keypad device status
	CImageList kpdImg;
	kpdImg.Create(IDB_KEYPADS, 22, 0, RGB(0x00, 0x80, 0x80));
	CTreePropSheet::SetPageIcon(&m_pageKeypad, kpdImg, 0);
	
	// 16 i/o device status
	CImageList ioImg;
	ioImg.Create(IDB_16IOS, 12, 0, RGB(0x00, 0x80, 0x80));
	CTreePropSheet::SetPageIcon(&m_page16IO, ioImg, 0);
	
	// Camera controller device status
	CTreePropSheet::SetPageIcon(&m_pageCamCtrl, camImg, 0);

	// Elevator controller device status
	CImageList elevImg;
	elevImg.Create(IDB_ELEVATORS, 12, 0, RGB(0x00, 0x80, 0x80));
	CTreePropSheet::SetPageIcon(&m_pageElevCtrl, elevImg, 0);

	// Dialer device status
	CImageList dialImg;
	dialImg.Create(IDB_DIALUPS, 12, 0, RGB(0x00, 0x80, 0x80));
	CTreePropSheet::SetPageIcon(&m_pageDialer, dialImg, 0);
	
	// Card reader interface status
	CImageList rdrImg;
	rdrImg.Create(IDB_READERS, 16, 0, RGB(0x00, 0x80, 0x80));
	CTreePropSheet::SetPageIcon(&m_pageCardRdr, rdrImg, 0);

	// Door status
	CImageList doorImg;
	doorImg.Create(IDB_DOORS, 12, 0, RGB(0x00, 0x80, 0x80));
	CTreePropSheet::SetPageIcon(&m_pageReader, doorImg, 0);

	// Floor status
	CTreePropSheet::SetPageIcon(&m_pageElevFlr, elevImg, 0);

	// Drive status

	CImageList DefaultImages;
	DefaultImages.Create(IDB_DEFAULT, 12, 0, RGB(0x00, 0x80, 0x80));
	m_sheet.SetTreeDefaultImages(IDB_DEFAULT, 12, RGB(0, 0x80, 0x80));
}

LPBYTE RTUStatus::SetDevInfoStatus(LPBYTE lpData, CMenu* pMenu)
{
	BYTE deviceCounts[1+6+32];			//.Array of device counts;
	BYTE deviceMask;
	UINT dCnt=0;
	UINT i, j, k, hb;
	UINT cnt;
	LPBYTE p2, p3;

	memset(&deviceCounts, 0, sizeof(deviceCounts));
	p2 = lpData;					//.Pointer to Device Info byte.

	//....Now p2 is pointing to Device info.....
	if (IsBadReadPtr(p2, 1+3+6+3*8))
		return NULL;

	hb = *p2++;					//.p2 pointing to second Device Info byte
	deviceMask = (BYTE)hb;
	if (!hb)
		return p2;

	p3 = p2 + (hb >> 6);		//.p3 pointing to device counts;
	j = 1;

	for (i=0; i<6; i++) {	  	//.Process first header byte
		*(deviceCounts+j) = (BYTE)(((hb>>i)&1) ? *p3++ : 0);
		j++;
	}

	hb = hb >> 6;				//.hb = Header byte count
	for (k=0; k<hb; k++) {
		for (i=0; i<8; i++) {  	//.Process next header byte
			*(deviceCounts+j) = (BYTE)(((*p2>>i)&1) ? *p3++ : 0);
			j++;
		}
		p2++;
	}

	*deviceCounts = (BYTE)(j-1);				//.No.of device types

	// p3 point to the tamper
	for(i=0; i<deviceCounts[0]; i++) {
		int lCnt = deviceCounts[1+i];
		lCnt = (lCnt/8) + ((lCnt%8) ? 1 : 0);
		dCnt += lCnt;
	}

	BYTE kpadCnt = deviceCounts[1];
	BYTE io16Cnt = deviceCounts[2];
	BYTE camCtrlCnt = deviceCounts[3];
	BYTE elevCtrlCnt = deviceCounts[4];
	BYTE dialerCnt = deviceCounts[5];
	BYTE cardRdrCnt = deviceCounts[6];
	
#define DEV_INFO_MAX 128
	BYTE	kpBuff[DEV_INFO_MAX], ioBuff[DEV_INFO_MAX], camBuff[DEV_INFO_MAX];
	BYTE	elevBuff[DEV_INFO_MAX], dlrBuff[DEV_INFO_MAX], crdrBuff[DEV_INFO_MAX];
	int kpByteCnt, ioByteCnt, camByteCnt, elevByteCnt, dlrByteCnt, crdrByteCnt;

	memset(kpBuff, 0, sizeof(kpBuff));
	memset(ioBuff, 0, sizeof(ioBuff));
	memset(camBuff, 0, sizeof(camBuff));
	memset(elevBuff, 0, sizeof(elevBuff));
	memset(dlrBuff, 0, sizeof(dlrBuff));
	memset(crdrBuff, 0, sizeof(crdrBuff));

	kpByteCnt = (kpadCnt/8) + (kpadCnt%8 ? 1 : 0);
	ioByteCnt = (io16Cnt/8) + (io16Cnt%8 ? 1 : 0);
	camByteCnt = (camCtrlCnt/8) + (camCtrlCnt%8 ? 1 : 0);
	elevByteCnt = (elevCtrlCnt/8) + (elevCtrlCnt%8 ? 1 : 0);
	dlrByteCnt = (dialerCnt/8) + (dialerCnt%8 ? 1 : 0);
	crdrByteCnt = (cardRdrCnt/8) + (cardRdrCnt%8 ? 1 : 0);

	p2 = p3;
	if (kpByteCnt) {
		Copy(kpBuff, p3, kpByteCnt, dCnt, (m_header1 & HB1_CLEANER_KEY_STATUS_INC) ? TRUE : FALSE);
		p3 += kpByteCnt;
	}
	if (ioByteCnt) {
		Copy(ioBuff, p3, ioByteCnt, dCnt);
		p3 += ioByteCnt;
	}
	if (camByteCnt) {
		Copy(camBuff, p3, camByteCnt, dCnt);
		p3 += camByteCnt;
	}
	if (elevByteCnt) {
		Copy(elevBuff, p3, elevByteCnt, dCnt);
		p3 += elevByteCnt;
	}
	if (dlrByteCnt) {
		Copy(dlrBuff, p3, dlrByteCnt, dCnt);
		p3 += dlrByteCnt;
	}
	if (crdrByteCnt) {
		Copy(crdrBuff, p3, crdrByteCnt, dCnt);
		p3 += crdrByteCnt;
	}
	
	BOOL bAdded = (deviceMask & DEVINFO_KEYPAD_INC)?TRUE:FALSE;
	AddStatusPage(kpBuff, bAdded, DevInfoKeypadPage, &m_pageKeypad, ID_RTU_STATUS_DEVINFO_KEYPAD, 
		pMenu, kpadCnt, (m_header1 & HB1_CLEANER_KEY_STATUS_INC));	

	bAdded = (deviceMask & DEVINFO_16IO_INC)?TRUE:FALSE;
	AddStatusPage(ioBuff, bAdded, DevInfoIoPage, &m_page16IO, ID_RTU_STATUS_DEVINFO_16IO, pMenu, io16Cnt);

	bAdded = (deviceMask & DEVINFO_CAMCTRL_INC)?TRUE:FALSE;
	AddStatusPage(camBuff, bAdded, DevInfoCameraPage, &m_pageCamCtrl, ID_RTU_STATUS_DEVINFO_CAMCTRL, pMenu, camCtrlCnt);

	bAdded = (deviceMask & DEVINFO_ELEVCTRL_INC)?TRUE:FALSE;
	AddStatusPage(elevBuff, bAdded, DevInfoElevatorPage, &m_pageElevCtrl, ID_RTU_STATUS_DEVINFO_ELEVCTRL, pMenu, elevCtrlCnt);

	bAdded = (deviceMask & DEVINFO_DIALER_INC)?TRUE:FALSE;
	AddStatusPage(dlrBuff, bAdded, DevInfoDialerPage, &m_pageDialer, ID_RTU_STATUS_DEVINFO_DIALER, pMenu, dialerCnt);

	bAdded = (deviceMask & DEVINFO_CARDRDR_INC)?TRUE:FALSE;
	AddStatusPage(crdrBuff, bAdded, DevInfoCardReaderPage, &m_pageCardRdr, ID_RTU_STATUS_DEVINFO_CARDRDR, pMenu, cardRdrCnt);

	cnt = 0;
	int bc;
	BYTE mask = deviceMask;
	for(i=1; i<=6; i++) {
		if (mask & 1) {
			bc = deviceCounts[i];
			cnt += (bc / 8) + (bc % 8 ? 1 : 0);
		}
		mask >>= 1;
	}

	for (k=0; k<hb; k++) {
		for (i=0; i<8; i++) {
			bc = deviceCounts[k*8 + i + 7];
			if (bc)
				cnt += (bc / 8) + (bc % 8 ? 1 : 0);
		}
	}

	cnt *= 3;
	// check if keypad included, add keyswitch status bytes
	if (m_header1 & HB1_CLEANER_KEY_STATUS_INC) {
		bc = deviceCounts[1];
		cnt += (bc / 8) + (bc % 8 ? 1 : 0);
	}
		
	p2 += cnt;
	return p2;
}

LPBYTE RTUStatus::Copy(LPBYTE pBuffer, LPBYTE pData, int cnt, int dCnt, BOOL bKeypad)
{
	LPBYTE pDat = pData;
	LPBYTE pBuf = pBuffer;

	// Copying tamper data
	memcpy(pBuf, pDat, cnt);		
	pDat += dCnt;					
	pBuf += cnt;

	// Copying offline data
	memcpy(pBuf, pDat, cnt);	
	pDat += dCnt;					
	pBuf += cnt;

	// Copying isolated data
	memcpy(pBuf, pDat, cnt);	
	pDat += dCnt;					
	pBuf += cnt;

	// Copying key switch data
	if (bKeypad) {
		memcpy(pBuf, pDat, cnt);   
	}

	return pBuffer;
}


void RTUStatus::OnClose() 
{
	EndDialog(TRUE);
}


LPBYTE RTUStatus::GetStatusPtr(LPBYTE p1)
{
LPBYTE	p2;

	p2 = p1;					//.Skip blk Sts (Data block should not have it)
	p2 += 3;					//.Skip RtuType, Panel Type & CommsType
	p2 += 1 + (*p2 >> 4);		//.Skip Hdr count & No.of Header bytes.
	return p2;
}


void RTUStatus::OnPrintModeStatus()
{
	m_pageMode.Print();
}

void RTUStatus::OnPrintPanelStatus()
{
	if (m_bIs1060Panel)
		m_pagePanel60.Print();
	else
		m_pagePanel57.Print();

}

void RTUStatus::OnPrintInputStatus()
{
	m_pageInpSts.Print();
}

void RTUStatus::OnPrintOutputStatus()
{
	m_pageOpSts.Print();
}

void RTUStatus::OnPrintCameraStatus()
{
	m_pageCamSts.Print();
}

void RTUStatus::OnPrintDevInfoKeypadStatus()
{
	m_pageKeypad.Print();
}

void RTUStatus::OnPrintDevInfo16IOStatus()
{
	m_page16IO.Print();
}

void RTUStatus::OnPrintDevInfoCamCtrlStatus()
{
	m_pageCamCtrl.Print();
}

void RTUStatus::OnPrintDevInfoElevCtrlStatus()
{
	m_pageElevCtrl.Print();
}

void RTUStatus::OnPrintDevInfoDialerStatus()
{
	m_pageDialer.Print();
}

void RTUStatus::OnPrintDevInfoCardRdrStatus()
{
	m_pageCardRdr.Print();
}

void RTUStatus::OnPrintDoorStatus()
{
	m_pageReader.Print();
}

void RTUStatus::OnPrintCctvStatus()
{
	m_pageCctvSts.Print();
}

void RTUStatus::OnPrintElevatorStatus()
{
	m_pageElevFlr.Print();
}

void RTUStatus::OnPrintDriveStatus()
{
	m_pageDriveStatus.Print();
}

#pragma endregion 
/*------------------------------------------------------------------------------*/
/*					Mode Page Class												*/
/*------------------------------------------------------------------------------*/
#pragma region CRtuModePage
IMPLEMENT_DYNCREATE(CRtuModePage, CPropertyPage)

void CRtuModePage::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CRtuModePage)
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CRtuModePage, CPropertyPage)
	//{{AFX_MSG_MAP(CRtuModePage) 
	ON_NOTIFY(UDN_DELTAPOS, IDC_RTU_ID1, OnUpDownModeSts)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CRtuModePage message handlers
/////////////////////////////////////////////////////////////////////////////
CRtuModePage::CRtuModePage() : CRtuStatusBase(CRtuModePage::IDD)
{
	m_nCurArea = 0;
	m_nNumAreas = 0;
	memset(m_modeStatus, 0, sizeof(m_modeStatus));
};


BOOL CRtuModePage::OnInitDialog()
{
	CDialog::OnInitDialog();
	
	GetDlgItem(IDC_RTU_ID1)->ShowWindow(SW_SHOW);

	ShowStatusNum(m_nCurArea);
	return TRUE;
}

BOOL CRtuModePage::OnSetActive()
{
	ShowStatusNum(m_nCurArea);
	return CPropertyPage::OnSetActive();
}

LPBYTE CRtuModePage::SetStatus(LPBYTE lpData, int, BOOL)
{
	try
	{
		int cnt = *lpData;
		m_nNumAreas = cnt / 3;
		memcpy(m_modeStatus, lpData+1, cnt);
		lpData += (1 + cnt);
	}
	catch (...)
	{
		OutputDebugString(L"Exception in CRtuModePage::SetStatus()\n");
	}
	return lpData;
}

void CRtuModePage::ShowStatus()
{
	if (IsWindow(m_hWnd) == FALSE) return;
	ShowStatusNum(m_nCurArea);
}

void CRtuModePage::ShowStatusNum(int curArea)
{
	int index = curArea*3;
	CString str;
	CString sModSts = RES_STRING(IDS_AREA_MOD_STS_RNG);
	str.Format(sModSts, curArea + 1, m_nNumAreas);
	GetDlgItem(IDC_RTUSTAT_LBL1)->SetWindowText(str);
	
	SetCheckStatus(IDC_RTUSTAT_CHK1, m_modeStatus[index++]);
	SetCheckStatus(IDC_RTUSTAT_CHK9, m_modeStatus[index++]);
	SetCheckStatus(IDC_RTUSTAT_CHK17, m_modeStatus[index]);
}

void CRtuModePage::SetCheckStatus(UINT id, BYTE status)
{
	CButton* pBtn=NULL;
	BYTE mask = 1;
	for(int i=0; i<8; i++) {
		if ((pBtn = (CButton*)GetDlgItem(id + i)) != NULL) {
			pBtn->SetCheck((status & mask) ? TRUE : FALSE);
			mask <<= 1;
		}
	}

}

void CRtuModePage::OnUpDownModeSts(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_UPDOWN* pNMUpDown = (NM_UPDOWN*)pNMHDR;
	// TODO: Add your control notification handler code here
	if (pNMUpDown->iDelta == 1) {
		if (--m_nCurArea < 0)
			m_nCurArea = m_nNumAreas - 1;
	}
	else {
		if (++m_nCurArea >= m_nNumAreas)
			m_nCurArea = 0;
	}
	ShowStatusNum(m_nCurArea);

	*pResult = 0;
}

void CRtuModePage::Print()
{
	TCHAR fname[MAX_PATH] = _T("");
	if (!RtuLib::GetPrintFileName(fname, _T(".html")))
		return;

	CHtmlFile* pFile = new CHtmlFile(hrInst, fname);

	pFile->StartTags(IsRtu8002Type()? RTU_8002_TYPE: realRtuType, gRtuNo, IDS_RTU_STATUS, IDS_MODE_STATUS);

	CString sYes = RES_STRING(IDS_YES_TXT);
	CString sNo = RES_STRING(IDS_NO_TXT);
	CString sArea = RES_STRING(IDS_AREA);
	CString sMainSts = RES_STRING(IDS_MAIN_STATUS);
	CString sSubSts = RES_STRING(IDS_SUB_STATUS);
	CString sTmp;

	BYTE b1, b2, b3;
	for(int i=0; i<m_nNumAreas; i++) {
		int index = i*3;
		b1 = m_modeStatus[index];
		b2 = m_modeStatus[index+1];
		b3 = m_modeStatus[index+2];

		pFile->SetBgColor(colors[i & 1 ? 1 : 0]);
		sTmp.Format(_T("%s %d"), (LPCTSTR)sArea, i+1);
		pFile->AddTH(2, ROW_SPAN | 25, sTmp, COL_SPAN|2, sMainSts);

		pFile->AddRowResID1(IDS_MODE_DAY, b1 & BIT0 ? sYes : sNo);
		pFile->AddRowResID1(IDS_MODE_NIGHT, b1 & BIT1 ? sYes : sNo);
		pFile->AddRowResID1(IDS_MODE_REST, b3 & BIT1 ? sYes : sNo);
		pFile->AddRowResID1(IDS_RES_TYPE_ENG, b1 & BIT7 ? sYes : sNo);
		pFile->AddRowResID1(IDS_MODE_CLNR, b1 & BIT3 ? sYes : sNo);
		pFile->AddRowResID1(IDS_TEST, b1 & BIT5 ? sYes : sNo);
		pFile->AddRowResID1(IDS_DURESS, b2 & BIT5 ? sYes : sNo);
		pFile->AddRowResID1(IDS_MODE_ATM, b1 & BIT2 ? sYes : sNo);

		pFile->AddTH(1, COL_SPAN|2, sSubSts);
		pFile->AddRowResID1(IDS_PROGRAM, b2 & BIT0 ? sYes : sNo);
		pFile->AddRowResID1(IDS_EXTERN_ATM, b2 & BIT1 ? sYes : sNo);
		pFile->AddRowResID1(IDS_INTERN_ATM, b2 & BIT2 ? sYes : sNo);
		pFile->AddRowResID1(IDS_EXTERN_CLNR, b2 & BIT3 ? sYes : sNo);
		pFile->AddRowResID1(IDS_INTERN_CLNR, b2 & BIT4 ? sYes : sNo);
		pFile->AddRowResID1(IDS_MANAGEMENT, b1 & BIT6 ? sYes : sNo);
		pFile->AddRowResID1(IDS_ATM_DURESS, b2 & BIT6 ? sYes : sNo);
		pFile->AddRowResID1(IDS_CLNR_DURESS, b2 & BIT7 ? sYes : sNo);
		pFile->AddRowResID1(IDS_MAINT_DURESS, b3 & BIT0 ? sYes : sNo);
		pFile->AddRowResID1(IDS_AUX_MODE_1, b3 & BIT2 ? sYes : sNo);
		pFile->AddRowResID1(IDS_AUX_MODE_2, b3 & BIT3 ? sYes : sNo);
		pFile->AddRowResID1(IDS_SUB_AREA, b3 & BIT4 ? sYes : sNo);
		pFile->AddRowResID1(IDS_GUARD, b3 & BIT5 ? sYes : sNo);
		pFile->AddRowResID1(IDS_COURIER, b3 & BIT6 ? sYes : sNo);
		pFile->AddRowResID1(IDS_MAINTENANCE, b1 & BIT4 ? sYes : sNo);

	}
		
	pFile->EndTags(); delete pFile; pFile = NULL;
	RtuLib::FileExecute(GetSafeHwnd(), fname, _T("open"));
}

#pragma endregion CRtuModePage
/*------------------------------------------------------------------------------*/
/*					Panel57 Page Class											*/
/*------------------------------------------------------------------------------*/
#pragma region CRtuPanel57Page
IMPLEMENT_DYNCREATE(CRtuPanel57Page, CPropertyPage)

void CRtuPanel57Page::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CRtuPanel57Page)
	DDX_Control(pDX, IDC_RTUSTAT_DIPSW, m_btnDipSw);
	//}}AFX_DATA_MAP

	for (BYTE i=0; i<4; i++)
		RtuLib::DDX_Check(pDX, IDC_RTUSTAT_CHK1 + i, m_panelStatus.byte1, i);
	for(BYTE i=0; i<8; i++)
		RtuLib::DDX_Check(pDX, IDC_RTUSTAT_CHK9 + i, m_panelStatus.byte2, i);
	for(BYTE i=0; i<8; i++)
		RtuLib::DDX_Check(pDX, IDC_RTUSTAT_CHK17 + i, m_panelStatus.byte3, i);
	for(BYTE i=0; i<8; i++)
		RtuLib::DDX_Check(pDX, IDC_RTUSTAT_CHK25 + i, m_panelStatus.byte4, i);
	for(BYTE i=0; i<2; i++)
		RtuLib::DDX_Check(pDX, IDC_RTUSTAT_CHK33 + i, m_panelStatus.ExtDevStat, (BYTE)(i+2));
	for(BYTE i=0; i<5; i++)
		RtuLib::DDX_Check(pDX, IDC_RTUSTAT_CHK39 + i, m_panelStatus.lineStat, (BYTE)(i+3));
	for(BYTE i=0; i<8; i++)
		RtuLib::DDX_Check(pDX, IDC_RTUSTAT_CHK44 + i, m_panelStatus.graphStat, i);
}


BEGIN_MESSAGE_MAP(CRtuPanel57Page, CPropertyPage)
	//{{AFX_MSG_MAP(CRtuPanel57Page)	
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CRtuPanel57Page message handlers
/////////////////////////////////////////////////////////////////////////////
BOOL CRtuPanel57Page::OnInitDialog()
{
	CDialog::OnInitDialog();
	m_btnDipSw.Init(4);
	return TRUE;
}

BOOL CRtuPanel57Page::OnSetActive()
{
	ShowStatus();
	return CPropertyPage::OnSetActive();
}

void CRtuPanel57Page::ShowWitnessControls()
{
	int nShowCmd = SW_HIDE;
	if (realRtuType == RTU_2000_TYPE) {
		nShowCmd = SW_SHOW;
	}

	int nIDs[] = { IDC_RTUSTAT_CHK33, IDC_RTUSTAT_CHK34, IDC_LBL_WITNESS, IDC_LBL_HARD_DRIVE, IDC_LBL_DAUGHTER_BOARD };

	for(int i=0; i<sizeof(nIDs)/sizeof(nIDs[0]); i++) {
		CWnd* pWnd = GetDlgItem(nIDs[i]);
		if (pWnd) {
			pWnd->ShowWindow(nShowCmd);
		}
	}
}

void CRtuPanel57Page::ShowStatus()
{
	if (IsWindow(m_hWnd) == FALSE) return;
	
	UpdateData(FALSE);
	ShowWitnessControls();
	CString strText;
	strText.Format(_T("%s: %s"), RES_STRING(IDS_EXPANSION_MEMORY), (LPCTSTR)GetExpansionMemoryString(&m_panelStatus.ExtDevStat));
	GetDlgItem(IDC_RTUSTAT_LBL7)->SetWindowText(strText);
	strText.Format(_T("%s: %s"), RES_STRING(IDS_ONBOARD_FLASH_MEMORY), (LPCTSTR)GetOnBoardFlashMemoryString(&m_panelStatus.ExtDevStat));
	GetDlgItem(IDC_LBL_FLASH_SIZE)->SetWindowText(strText);

	m_btnDipSw.SetAddress(m_panelStatus.DipnVoc & 0x0F);
	m_btnDipSw.SetDrawState(TRUE);
	m_btnDipSw.Invalidate(FALSE);

	CStringArray strArrVocList;
	GetVocabList(strArrVocList);
	int i = m_panelStatus.DipnVoc >> 4;
	if (i < strArrVocList.GetSize() ) {
		GetDlgItem(IDC_RTUSTAT_EDIT5)->SetWindowText(strArrVocList.GetAt(i));
	}
}

LPBYTE CRtuPanel57Page::SetStatus(LPBYTE lpData, int, BOOL)
{
	try
	{
		int bytesCount = *lpData;				// Panel status byte count
		memcpy(&m_panelStatus, lpData+1, bytesCount);
		lpData += 1 + bytesCount;
	}
	catch (...)
	{
		OutputDebugString(L"Exception in CRtuPanel57Page::SetStatus()\n");
	}
	
	return lpData;
}

void CRtuPanel57Page::Print()
{
	TCHAR fname[MAX_PATH] = _T("");
	if (!RtuLib::GetPrintFileName(fname, _T(".html")))
		return;

	CHtmlFile* pFile = new CHtmlFile(hrInst, fname);
	pFile->StartTags(IsRtu8002Type()? RTU_8002_TYPE: realRtuType, gRtuNo, IDS_RTU_STATUS, IDS_PANEL_STS);

	CStringArray strArrVocList; GetVocabList(strArrVocList);
	BYTE b1 = m_panelStatus.byte1;
	BYTE b2 = m_panelStatus.byte2;
	BYTE b3 = m_panelStatus.byte3;
	BYTE b4 = m_panelStatus.byte4;
	BYTE ls = m_panelStatus.lineStat;
	BYTE gs = m_panelStatus.graphStat;
	BYTE es = m_panelStatus.ExtDevStat;

	CString sYes = RES_STRING(IDS_YES_TXT);
	CString sNo = RES_STRING(IDS_NO_TXT);

	// Power
	pFile->SetBgColor(colors[0]);
	pFile->AddTH(1, COL_SPAN|2, RES_STRING(IDS_POWER_STS));
	pFile->AddRowResID1(IDS_AC_FAIL, b1 & BIT0 ? sYes : sNo);
	pFile->AddRowResID1(IDS_BATT_LOW, b1 & BIT1 ? sYes : sNo);
	pFile->AddRowResID1(IDS_SEC_SUP_FAIL, b1 & BIT2 ? sYes : sNo);
	pFile->AddRowResID1(IDS_TER_SUP_FAIL, b1 & BIT3 ? sYes : sNo);
	pFile->AddRowResID1(IDS_AC_FAIL_ISOL, b4 & BIT6 ? sYes : sNo);
	pFile->AddRowResID1(IDS_BATT_LOW_ISOL, b4 & BIT7 ? sYes : sNo);
	pFile->AddRowResID1(IDS_INT_LITH_BATT_PROBLEM, b4 & BIT4 ? sYes : sNo);
	pFile->AddRowResID1(IDS_EXT_LITH_BATT_PROBLEM, b4 & BIT5 ? sYes : sNo);

	// Network
	pFile->SetBgColor(colors[1]);
	pFile->AddTH(1, COL_SPAN|2, RES_STRING(IDS_NW_STS));
	pFile->AddRowResID1(IDS_PRI_PORT_PHYS_LYR_FAIL, b2 & BIT0 ? sYes : sNo);
	pFile->AddRowResID1(IDS_PRI_PORT_DRV_FAIL, b2 & BIT1 ? sYes : sNo);
	pFile->AddRowResID1(IDS_PRI_PORT_LNK_LYR_FAIL, b2 & BIT2 ? sYes : sNo);
	pFile->AddRowResID1(IDS_PRI_PORT_SES_LYR_FAIL, b2 & BIT3 ? sYes : sNo);
	pFile->AddRowResID1(IDS_ON_DIALUP, b2 & BIT5 ? sYes : sNo);
	pFile->AddRowResID1(IDS_DIALUP_FAIL, b2 & BIT6 ? sYes : sNo);
	pFile->AddRowResID1(IDS_SEC_ACTIVE, b2 & BIT7 ? sYes : sNo);
	pFile->AddRowResID1(IDS_TER_ACTIVE, ls & BIT3 ? sYes : sNo);
	pFile->AddRowResID1(IDS_TER_FAIL, ls & BIT4 ? sYes : sNo);
	pFile->AddRowResID1(IDS_TER_ONLINE, ls & BIT5 ? sYes : sNo);
	pFile->AddRowResID1(IDS_SEC_FAIL, ls & BIT6 ? sYes : sNo);
	pFile->AddRowResID1(IDS_SEC_ONLINE, ls & BIT7 ? sYes : sNo);
	
	// Serial			 
	pFile->SetBgColor(colors[0]);
	pFile->AddTH(1, COL_SPAN|2, RES_STRING(IDS_SERIAL_STS));
	pFile->AddRowResID1(IDS_RAP_PORT_TAMPER, b3 & BIT0 ? sYes : sNo);
	pFile->AddRowResID1(IDS_RAP_PORT_TAMPER_ISOL, b3 & BIT1 ? sYes : sNo);
	pFile->AddRowResID1(IDS_SPARE_SERIAL_TAMPER, b3 & BIT2 ? sYes : sNo);
	pFile->AddRowResID1(IDS_SPARE_SERIAL_TAMPER_ISOL, b3 & BIT3 ? sYes : sNo);
	pFile->AddRowResID1(IDS_PANEL_STS_1, b3 & BIT4 ? sYes : sNo);
	pFile->AddRowResID1(IDS_MAIN_TAMPER_ISOL, b3 & BIT5 ? sYes : sNo);
	pFile->AddRowResID1(IDS_TERM_UNIT_TAMPER, b3 & BIT6 ? sYes : sNo);
	pFile->AddRowResID1(IDS_TERM_UNIT_TAMPER_ISOL, b3 & BIT7 ? sYes : sNo);

	// Remote Panel
	pFile->SetBgColor(colors[1]);
	pFile->AddTH(1, COL_SPAN|2, RES_STRING(IDS_REMOTE_PANAL_STS));
	pFile->AddRowResID1(IDS_REMOTE_PANEL_OFFLINE, b4 & BIT0 ? sYes : sNo);
	pFile->AddRowResID1(IDS_REMOTE_PANEL_TAMPER, b4 & BIT1 ? sYes : sNo);
	pFile->AddRowResID1(IDS_REMOTE_PANEL_AC_FAIL, b4 & BIT2 ? sYes : sNo);
	pFile->AddRowResID1(IDS_REMOTE_PANEL_BATT_FAIL, b4 & BIT3 ? sYes : sNo);
	
	// Graphics Status
	pFile->SetBgColor(colors[0]);
	pFile->AddTH(1, COL_SPAN|2, RES_STRING(IDS_GRAPHIC_STS));
	pFile->AddRowResID1(IDS_MAC_GRAPHIC_STS, gs & BIT7 ? sYes : sNo);
	pFile->AddRowResID1(IDS_DURESS_ALM, gs & BIT6 ? sYes : sNo);
	pFile->AddRowResID1(IDS_POWER_ALM, gs & BIT5 ? sYes : sNo);
	pFile->AddRowResID1(IDS_TEST_MODE, gs & BIT4 ? sYes : sNo);
	pFile->AddRowResID1(IDS_PARTIAL_SEAL, gs & BIT3 ? sYes : sNo);
	pFile->AddRowResID1(IDS_ZONE_ISOLATED, gs & BIT2 ? sYes : sNo);
	pFile->AddRowResID1(IDS_ZONE_ALM, gs & BIT1 ? sYes : sNo);
	pFile->AddRowResID1(IDS_NIGHT_MODE, gs & BIT0 ? sYes : sNo);
	
	// Witnesss
	pFile->SetBgColor(colors[1]);
	pFile->AddTH(1, COL_SPAN|2, RES_STRING(IDS_WITNESS_STS));
	pFile->AddRowResID1(IDS_HDRIVE_ONLINE, es & BIT2 ? sYes : sNo);
	pFile->AddRowResID1(IDS_DBOARD_ONLINE, es & BIT3 ? sYes : sNo);
	
	// General
	pFile->SetBgColor(colors[0]);
	pFile->AddTH(1, COL_SPAN|2, RES_STRING(IDS_GENERAL_STS));

	if ((m_panelStatus.DipnVoc >> 4) < strArrVocList.GetSize()) {
		pFile->AddRowResID1(IDS_ALM_VOC_LIST, strArrVocList.GetAt(m_panelStatus.DipnVoc >> 4));
	}

	pFile->AddRowResID1(IDS_EXPANSION_MEMORY, GetExpansionMemoryString(&es));
	pFile->AddRowResID1(IDS_ONBOARD_FLASH_MEMORY, GetOnBoardFlashMemoryString(&m_panelStatus.ExtDevStat));

	pFile->EndTags();
	RtuLib::FileExecute(GetSafeHwnd(), fname, _T("open"));
}

#pragma endregion CRtuPanel57Page
/*------------------------------------------------------------------------------*/
/*					Panel60 Page Class											*/
/*------------------------------------------------------------------------------*/
#pragma region CRtuPanel60Page
IMPLEMENT_DYNCREATE(CRtuPanel60Page, CPropertyPage)

void CRtuPanel60Page::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CRtuPanel60Page)
	DDX_Control(pDX, IDC_RTUSTAT_DIPSW, m_btnDipSw);
	//}}AFX_DATA_MAP

	for (BYTE i=0; i<8; i++)
		RtuLib::DDX_Check(pDX, IDC_RTUSTAT_CHK1 + i, m_panelStatus.byte1, i);
	for(BYTE i=0; i<8; i++)
		RtuLib::DDX_Check(pDX, IDC_RTUSTAT_CHK9 + i, m_panelStatus.byte2, i);
	for(BYTE i=0; i<8; i++)
		RtuLib::DDX_Check(pDX, IDC_RTUSTAT_CHK17 + i, m_panelStatus.byte3, i);
	for(BYTE i=0; i<8; i++)
		RtuLib::DDX_Check(pDX, IDC_RTUSTAT_CHK25 + i, m_panelStatus.byte4, i);
	for(BYTE i=0; i<5; i++)
		RtuLib::DDX_Check(pDX, IDC_RTUSTAT_CHK33 + i, m_panelStatus.lineStat, (BYTE)(i+3));

	for(BYTE i=0; i<8; i++)
		RtuLib::DDX_Check(pDX, IDC_RTUSTAT_CHK44 + i, m_panelStatus.graphStat, i);

}


BEGIN_MESSAGE_MAP(CRtuPanel60Page, CPropertyPage)
	//{{AFX_MSG_MAP(CRtuPanel60Page)	
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CRtuPanel60Page message handlers
/////////////////////////////////////////////////////////////////////////////
BOOL CRtuPanel60Page::OnInitDialog()
{
	CDialog::OnInitDialog();
	m_btnDipSw.Init(4);
	return TRUE;
}

BOOL CRtuPanel60Page::OnSetActive()
{
	ShowStatus();
	return CPropertyPage::OnSetActive();
}

void CRtuPanel60Page::ShowStatus()
{
	if (IsWindow(m_hWnd) == FALSE) 
		return;
	UpdateData(FALSE);
	SetDlgItemInt(IDC_RTUSTAT_EDIT1, m_panelStatus.ctrlAddr1, FALSE);
	SetDlgItemInt(IDC_RTUSTAT_EDIT2, m_panelStatus.ctrlAddr2, FALSE);
	SetDlgItemInt(IDC_RTUSTAT_EDIT3, m_panelStatus.RtsCtsDly, FALSE);
	CStringArray strArrVocList; GetVocabList(strArrVocList);
	GetDlgItem(IDC_RTUSTAT_EDIT5)->SetWindowText(strArrVocList.GetAt(m_panelStatus.DipnVoc >> 4));
	m_btnDipSw.SetAddress(m_panelStatus.DipnVoc & 0x0F);
	m_btnDipSw.SetDrawState(TRUE);
	m_btnDipSw.Invalidate(FALSE);
}

LPBYTE CRtuPanel60Page::SetStatus(LPBYTE lpData, int, BOOL)
{
	try
	{
		int bytesCount = *lpData;				// Panel status byte count
		memcpy(&m_panelStatus, lpData+1, bytesCount);
		lpData += 1 + bytesCount;
	}
	catch (...)
	{
		OutputDebugString(L"Exception in CRtuPanel60Page::SetStatus()\n");
	}
	return lpData;
}

void CRtuPanel60Page::Print()
{
	TCHAR fname[MAX_PATH] = _T("");
	if (!RtuLib::GetPrintFileName(fname, _T(".html")))
		return;

	CHtmlFile* pFile = new CHtmlFile(hrInst, fname);
	pFile->StartTags(IsRtu8002Type()? RTU_8002_TYPE: realRtuType, gRtuNo, IDS_RTU_STATUS, IDS_PANEL_STS);

	BYTE b1 = m_panelStatus.byte1;
	BYTE b2 = m_panelStatus.byte2;
	BYTE b3 = m_panelStatus.byte3;
	BYTE b4 = m_panelStatus.byte4;
	BYTE ls = m_panelStatus.lineStat;
	BYTE gs = m_panelStatus.graphStat;

	CString sYes = RES_STRING(IDS_YES_TXT);
	CString sNo = RES_STRING(IDS_NO_TXT);

	// Power
	pFile->SetBgColor(colors[0]);
	pFile->AddTH(1, COL_SPAN|2, RES_STRING(IDS_POWER_STS));
	pFile->AddRowResID1(IDS_AC_FAIL, b1 & BIT0 ? sYes : sNo);
	pFile->AddRowResID1(IDS_BATT_LOW, b1 & BIT1 ? sYes : sNo);
	pFile->AddRowResID1(IDS_SEC_SUP_FAIL, b1 & BIT2 ? sYes : sNo);
	pFile->AddRowResID1(IDS_TER_SUP_FAIL, b1 & BIT3 ? sYes : sNo);
	pFile->AddRowResID1(IDS_AC_FAIL_ISOL, b4 & BIT6 ? sYes : sNo);
	pFile->AddRowResID1(IDS_BATT_LOW_ISOL, b4 & BIT7 ? sYes : sNo);

	// Network
	pFile->SetBgColor(colors[1]);
	pFile->AddTH(1, COL_SPAN|2, RES_STRING(IDS_NW_STS));
	pFile->AddRowResID1(IDS_DATA_LINE_FAIL, b2 & BIT0 ? sYes : sNo);
	pFile->AddRowResID1(IDS_MODEM_FAIL, b2 & BIT1 ? sYes : sNo);
	pFile->AddRowResID1(IDS_CTRLR_FAIL, b2 & BIT2 ? sYes : sNo);
	pFile->AddRowResID1(IDS_CTRLR_DEACT, b2 & BIT3 ? sYes : sNo);
	pFile->AddRowResID1(IDS_DLU_POLL_ACT, b2 & BIT4 ? sYes : sNo);
	pFile->AddRowResID1(IDS_ON_DIALUP, b2 & BIT5 ? sYes : sNo);
	pFile->AddRowResID1(IDS_TEL_LINE_FAIL, b2 & BIT6 ? sYes : sNo);
	pFile->AddRowResID1(IDS_CTRLR_ADDR_VAL, b2 & BIT7 ? sYes : sNo);
	pFile->AddRowResID1(IDS_TER_ACTIVE, ls & BIT3 ? sYes : sNo);
	pFile->AddRowResID1(IDS_TER_FAIL, ls & BIT4 ? sYes : sNo);
	pFile->AddRowResID1(IDS_TER_ONLINE, ls & BIT5 ? sYes : sNo);
	pFile->AddRowResID1(IDS_SEC_FAIL, ls & BIT6 ? sYes : sNo);
	pFile->AddRowResID1(IDS_SEC_ONLINE, ls & BIT7 ? sYes : sNo);
   
	// Serial			 
	pFile->SetBgColor(colors[0]);
	pFile->AddTH(1, COL_SPAN|2, RES_STRING(IDS_SERIAL_STS));
	pFile->AddRowResID1(IDS_MAIN_PORT1_TAMP, b3 & BIT0 ? sYes : sNo);
	pFile->AddRowResID1(IDS_MAIN_PORT1_TAMP_ISOL, b3 & BIT1 ? sYes : sNo);
	pFile->AddRowResID1(IDS_MAIN_PORT2_TAMP, b3 & BIT2 ? sYes : sNo);
	pFile->AddRowResID1(IDS_MAIN_PORT2_TAMP_ISOL, b3 & BIT3 ? sYes : sNo);
	pFile->AddRowResID1(IDS_PANEL_STS_1, b3 & BIT4 ? sYes : sNo);
	pFile->AddRowResID1(IDS_MAIN_TAMPER_ISOL, b3 & BIT5 ? sYes : sNo);
	pFile->AddRowResID1(IDS_TERM_UNIT_TAMPER, b3 & BIT6 ? sYes : sNo);
	pFile->AddRowResID1(IDS_TERM_UNIT_TAMPER_ISOL, b3 & BIT7 ? sYes : sNo);

	// Remote Panel
	pFile->SetBgColor(colors[1]);
	pFile->AddTH(1, COL_SPAN|2, RES_STRING(IDS_REMOTE_PANAL_STS));
	pFile->AddRowResID1(IDS_REMOTE_PANEL_OFFLINE, b4 & BIT0 ? sYes : sNo);
	pFile->AddRowResID1(IDS_REMOTE_PANEL_TAMPER, b4 & BIT1 ? sYes : sNo);
	pFile->AddRowResID1(IDS_REMOTE_PANEL_AC_FAIL, b4 & BIT2 ? sYes : sNo);
	pFile->AddRowResID1(IDS_REMOTE_PANEL_BATT_FAIL, b4 & BIT3 ? sYes : sNo);
	
	// Graphics Status
	pFile->SetBgColor(colors[0]);
	pFile->AddTH(1, COL_SPAN|2, RES_STRING(IDS_GRAPHIC_STS));
	pFile->AddRowResID1(IDS_MAC_GRAPHIC_STS, gs & BIT7 ? sYes : sNo);
	pFile->AddRowResID1(IDS_DURESS_ALM, gs & BIT6 ? sYes : sNo);
	pFile->AddRowResID1(IDS_POWER_ALM, gs & BIT5 ? sYes : sNo);
	pFile->AddRowResID1(IDS_TEST_MODE, gs & BIT4 ? sYes : sNo);
	pFile->AddRowResID1(IDS_PARTIAL_SEAL, gs & BIT3 ? sYes : sNo);
	pFile->AddRowResID1(IDS_ZONE_ISOLATED, gs & BIT2 ? sYes : sNo);
	pFile->AddRowResID1(IDS_ZONE_ALM, gs & BIT1 ? sYes : sNo);
	pFile->AddRowResID1(IDS_NIGHT_MODE, gs & BIT0 ? sYes : sNo);
	
	// General
	pFile->SetBgColor(colors[0]);
	pFile->AddTH(1, COL_SPAN|2, RES_STRING(IDS_GENERAL_STS));
	pFile->AddRowResID1(IDS_KPD_LCK_OUT, b1 & BIT4 ? sYes : sNo);
	pFile->AddRowResID1(IDS_BYPASS_SW, b1 & BIT5 ? sYes : sNo);
	pFile->AddRowResID1(IDS_CABINET_TAMPER, b1 & BIT6 ? sYes : sNo);
	pFile->AddRowResID1(IDS_SYS_IN_ALM, b1 & BIT7 ? sYes : sNo);
	pFile->AddRowResID1(IDS_SNA_ADDR_1, m_panelStatus.ctrlAddr1);
	pFile->AddRowResID1(IDS_SNA_ADDR_2, m_panelStatus.ctrlAddr2);
	pFile->AddRowResID1(IDS_RTS_CTS_DLY, m_panelStatus.RtsCtsDly);
	
	CStringArray strArrVocList; GetVocabList(strArrVocList);
	if ((m_panelStatus.DipnVoc >> 4) < strArrVocList.GetSize()) {
		pFile->AddRowResID1(IDS_ALM_VOC_LIST, strArrVocList.GetAt(m_panelStatus.DipnVoc >> 4));
	}

	pFile->EndTags();
	RtuLib::FileExecute(GetSafeHwnd(), fname, _T("open"));
}

#pragma endregion CRtuPanel60Page
/*------------------------------------------------------------------------------*/
/*					Reader Status Page Class									*/
/*------------------------------------------------------------------------------*/
#pragma region CRtuDoorStatusPage
IMPLEMENT_DYNCREATE(CRtuDoorStatusPage, CPropertyPage)

void CRtuDoorStatusPage::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CRtuDoorStatusPage)
	DDX_Control(pDX, IDC_LIST, m_rdrList);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CRtuDoorStatusPage, CPropertyPage)
	//{{AFX_MSG_MAP(CRtuDoorStatusPage)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


BOOL CRtuDoorStatusPage::OnInitDialog()
{
	CDialog::OnInitDialog();

	m_imgList.Create(IDB_DOORS, 12, 0, RGB(0x00, 0x80, 0x80));
	for(int i=0; i<6; i++) {
		CString str = RES_STRING(IDS_DOOR_NUM + i);
		CSize size = ((CDC*)this->GetDC())->GetTextExtent(str);
		m_rdrList.InsertColumn(i, str, LVCFMT_CENTER, size.cx);
	}

	m_rdrList.SetGridLines(TRUE);
	m_rdrList.SetImageList(&m_imgList, LVSIL_SMALL);
	return TRUE;
}

BOOL CRtuDoorStatusPage::OnSetActive()
{
	ShowStatus();
	return CPropertyPage::OnSetActive();
}

LPBYTE CRtuDoorStatusPage::SetStatus(LPBYTE lpData, int, BOOL)
{
	m_numReaders = *lpData;
	try
	{
		if (m_numReaders > MAX_RTU_RDRS)
			m_numReaders = MAX_RTU_RDRS;
		memcpy(m_readerStatus, lpData+1, m_numReaders);
		lpData += 1 + m_numReaders;
	}
	catch (...)
	{
		m_numReaders  = 0;
		OutputDebugString(L"Exception in CRtuDoorStatusPage::SetStatus()\n");
	}
	return lpData;
}

void CRtuDoorStatusPage::ShowStatus(void)
{
	UINT  nStrikeIDs[] = {IDS_SECURE, IDS_ACTIVE, IDS_EMPTY, IDS_TROUBLE};

	CString sYes = RES_STRING(IDS_YES_TXT);
	CString sNo = RES_STRING(IDS_NO_TXT);
	CString str;
	LVITEM lvi;
	lvi.mask = LVIF_IMAGE | LVIF_TEXT;
	int imgNum=0;
	m_rdrList.DeleteAllItems();

	for (int i=0; i<m_numReaders; i++) {
		BYTE data = m_readerStatus[i];
		lvi.iItem = i;
	
		if (data & 0x40)
			imgNum = 2;
		else if ((data >> 2) & 3)
			imgNum = 1;
		else
			imgNum = 0;
		lvi.iImage = imgNum;

		// Reader number
		str.Format(_T("%d"), i+1);
		lvi.iSubItem = 0;
		lvi.pszText = (LPTSTR)(LPCTSTR)str;
		m_rdrList.InsertItem(&lvi);

		// Reader status
		str = RES_STRING(IDS_RDR_STS + (data & 3));
		lvi.iSubItem = 1;
		lvi.pszText = (LPTSTR)(LPCTSTR)str;
		m_rdrList.SetItem(&lvi);

		// Door contact status
		str = RES_STRING(IDS_SECURE + ((data >> 2) & 3));
		lvi.iSubItem = 2;
		lvi.pszText = (LPTSTR)(LPCTSTR)str;
		m_rdrList.SetItem(&lvi);

		// Door strike status
		str = RES_STRING(nStrikeIDs[(data >> 4) & 3]);
		lvi.iSubItem = 3;
		lvi.pszText = (LPTSTR)(LPCTSTR)str;
		m_rdrList.SetItem(&lvi);

		// Door contact isolated
		str = data & 0x40 ? sYes : sNo;
		lvi.iSubItem = 4;
		lvi.pszText = (LPTSTR)(LPCTSTR)str;
		m_rdrList.SetItem(&lvi);

		// Door strike isolated
		str = data & 0x80 ? sYes : sNo;
		lvi.iSubItem = 5;
		lvi.pszText = (LPTSTR)(LPCTSTR)str;
		m_rdrList.SetItem(&lvi);
	}

}

void CRtuDoorStatusPage::Print()
{
	TCHAR fname[MAX_PATH] = _T("");
	if (!RtuLib::GetPrintFileName(fname, _T(".html")))
		return;

	CHtmlFile* pFile = new CHtmlFile(hrInst, fname);
	pFile->StartTags(IsRtu8002Type()? RTU_8002_TYPE: realRtuType, gRtuNo, IDS_RTU_STATUS, IDS_DOOR_STATUS);

	UINT contactStsIDs[] = {IDS_SECURE, IDS_AJAR_ALM, IDS_FORCE_ALM, IDS_TROUBLE};
	std::array<UINT, 3> strikeStsIDs = { IDS_SECURE, IDS_ACTIVE, IDS_TROUBLE };
	CString sYes = RES_STRING(IDS_YES_TXT);
	CString sNo = RES_STRING(IDS_NO_TXT);
	CString sDoorNum = RES_STRING(IDS_DOOR_NUM);
	CString sReaderSts = RES_STRING(IDS_READER_STATUS);
	CString sContactSts = RES_STRING(IDS_CONTACT_STATUS);
	CString sStrikeSts = RES_STRING(IDS_STRIKE_STATUS);
	CString sContactIsol = RES_STRING(IDS_CONTACT_ISOLATED);
	CString sStrikeIsol = RES_STRING(IDS_STRIKE_ISOLATED);

	pFile->SetBgColor(colors[2]);
	pFile->AddTH(6, 1, sDoorNum, 1, sReaderSts, 1, sContactSts,
		1, sStrikeSts, 1, sContactIsol, 1, sStrikeIsol);

	CString sTmp;
	for (int i=0; i<m_numReaders; i++) {
		pFile->SetBgColor(colors[i & 1 ? 1 : 0]);
		BYTE data = m_readerStatus[i];
		sTmp.Format(_T("%d"), i + 1);
		sReaderSts = RES_STRING(IDS_RDR_STS + (data & 3));
		sContactSts = RES_STRING(contactStsIDs[(data >> 2) & 3]);
		auto index = (data >> 4) & 3;
		sStrikeSts = index < (int)strikeStsIDs.size() ?  RES_STRING(strikeStsIDs[index]) : _T("");

		pFile->AddTD(6, 1, sTmp,
			1, sReaderSts, 1, sContactSts, 1, sStrikeSts,
			1, data & 0x40 ? sYes : sNo, 1, data & 0x80 ? sYes : sNo);
	}

	pFile->EndTags(); delete pFile; pFile = NULL;
	RtuLib::FileExecute(GetSafeHwnd(), fname, _T("open"));
}

#pragma endregion CRtuDoorStatusPage
/*------------------------------------------------------------------------------*/
/*					Elevator Floor Status Page Class							*/
/*------------------------------------------------------------------------------*/
#pragma region CRtuElevFlrPage
IMPLEMENT_DYNCREATE(CRtuElevFlrPage, CPropertyPage)

void CRtuElevFlrPage::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CRtuElevFlrPage)
	DDX_Control(pDX, IDC_RTU_ID1, m_btn1);
	DDX_Control(pDX, IDC_RTU_ID2, m_btn2);
	DDX_Control(pDX, IDC_RTU_ID3, m_btn3);
	DDX_Control(pDX, IDC_RTU_ID4, m_btn4);
	DDX_Control(pDX, IDC_RTU_ID5, m_btn5);
	DDX_Control(pDX, IDC_RTU_ID6, m_btn6);
	DDX_Control(pDX, IDC_RTU_ID7, m_btn7);
	DDX_Control(pDX, IDC_RTU_ID8, m_btn8);
	DDX_Control(pDX, IDC_RTU_ID11, m_lblElevNum);
	DDX_Control(pDX, IDC_RTU_ID12, m_lstOffStatus);
	DDX_Control(pDX, IDC_RTU_ID13, m_chkFlrAccess);
	DDX_Control(pDX, IDC_RTU_ID14, m_chkFlrRestore);

	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CRtuElevFlrPage, CPropertyPage)
	//{{AFX_MSG_MAP(CRtuElevFlrPage)
	ON_NOTIFY(UDN_DELTAPOS, IDC_RTU_ID9, OnUpDownElevSts)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


BOOL CRtuElevFlrPage::OnInitDialog()
{
	CDialog::OnInitDialog();
	
	CChkButton* pBtn[] = {&m_btn1, &m_btn2, &m_btn3, &m_btn4, &m_btn5, &m_btn6, &m_btn7, &m_btn8};
	for(int i=0; i<8; i++) {
		pBtn[i]->Init(1, 15);
		pBtn[i]->Init(2, &m_elevatorStatus[m_curElevatorNum].accessFloors[i*2], 16, 16, TRUE, TRUE);
		pBtn[i]->SetBitmapIDs(IDB_DOORS, IDB_DOORS);
	}


	TCHAR * strTxt[] = {_T("1065EC Number"),_T(" 1 "),_T(" 2 "), _T(" 3"), _T(" 4 "), 
		_T(" 5 "),_T(" 6 "), _T(" 7 "), _T(" 8 ")};

	for(int i=0; i<9; i++) {
		CSize size = ((CDC*)this->GetDC())->GetTextExtent(strTxt[i]);
		m_lstOffStatus.InsertColumn(i, strTxt[i], LVCFMT_CENTER, size.cx + 22);
	}
	m_lstOffStatus.SetGridLines(TRUE);

	BYTE data = 0;
	
	m_chkFlrRestore.Init(1, 1);
	m_chkFlrRestore.Init(1, &data, 1);
	m_chkFlrRestore.SetBitmapIDs(IDB_DOORS, IDB_DOORS);

	data = 0xff;
	m_chkFlrAccess.Init(1, 1);
	m_chkFlrAccess.Init(1, &data, 1);
	m_chkFlrAccess.SetBitmapIDs(IDB_DOORS, IDB_DOORS);

	GetDlgItem(IDC_RTU_ID9)->ShowWindow(SW_SHOW);
	return TRUE;
}

BOOL CRtuElevFlrPage::OnSetActive()
{
	ShowStatus();
	return CPropertyPage::OnSetActive();
}

LPBYTE CRtuElevFlrPage::SetStatus(LPBYTE lpData, int, BOOL)
{
	LPBYTE p = lpData;
	
	m_numElevators = *p++;
	try
	{
		if (m_numElevators > MAX_RTU_ELEVRECS)
			m_numElevators = MAX_RTU_ELEVRECS;

		for(int i=0; i<m_numElevators; i++) {
			BYTE cnt = *p;
			memcpy(&m_elevatorStatus[i], p, cnt+1);
			p += (cnt + 1);
		}

	}
	catch (...)
	{
		m_numElevators  = 0;
		OutputDebugString(L"Exception in CRtuElevFlrPage::SetStatus()\n");
	}
	return p;
}

void CRtuElevFlrPage::ShowStatus(void)
{
	CWnd* pWnd;
	int size = m_elevatorStatus[m_curElevatorNum].size;
	//TT 8351
	UINT showOrHide = (m_numElevators == 0)?SW_HIDE:SW_SHOW;

	for(int i=0; i<17; i++) {
		if ((pWnd = GetDlgItem(IDC_RTU_ID1 + i)) != NULL) {
			pWnd->ShowWindow(showOrHide);
		}
	}
	
	if (m_numElevators == 0)	return;

	CString str;
	CString sElevFlrRng = RES_STRING(IDS_ELEV_FLR_RNG);
	str.Format(sElevFlrRng, m_curElevatorNum+1, m_numElevators);
	SetDlgItemText(IDC_RTU_TOTAL, str);

	for(int i=0; i<8; i++) {
		GetDlgItem(IDC_RTU_ID1+i)->ShowWindow(size == 0 ? SW_HIDE : SW_SHOW);
		GetDlgItem(IDC_RTU_ID10+i)->ShowWindow(size == 0 ? SW_HIDE : SW_SHOW);
	}

	if (size >= 2) {
		str.Format(_T("%d"), m_elevatorStatus[m_curElevatorNum].elevatorNumber + 1);
		m_lblElevNum.SetText(str);
	}
	
	if (size >= 3) {
		CString sYes = RES_STRING(IDS_YES_TXT);
		CString sNo = RES_STRING(IDS_NO_TXT);
		CString sOnline = RES_STRING(IDS_ONLINE);
		LVITEM lvi;
		lvi.mask = LVIF_TEXT;
		m_lstOffStatus.DeleteAllItems();
		lvi.iItem = 0;
		BYTE mask=0x01;
		BYTE data = m_elevatorStatus[m_curElevatorNum].offlineStatus;

		lvi.iSubItem = 0;
		lvi.pszText = (LPTSTR)(LPCTSTR)sOnline;
		m_lstOffStatus.InsertItem(&lvi);

		for(int i=1; i<=8; i++) {
			lvi.iSubItem = i;
			CString str2 = data & mask ? sNo : sYes;
			lvi.pszText = (LPTSTR)(LPCTSTR)str2;
			m_lstOffStatus.SetItem(&lvi);
			mask <<= 1;
		}

		size -= 3;
		size = (size / 2) + (size & 1 ? 1 : 0);
		CChkButton* pBtn[] = {&m_btn1, &m_btn2, &m_btn3, &m_btn4, &m_btn5, &m_btn6, &m_btn7, &m_btn8};
		for(int i=0; i<8; i++) {
			if (i < size) {
				pBtn[i]->ShowWindow(SW_SHOW);
				pBtn[i]->SetBitMap(2, &m_elevatorStatus[m_curElevatorNum].accessFloors[i*2], i*16 + 1);
				pBtn[i]->Invalidate();
			}
			else {
				pBtn[i]->ShowWindow(SW_HIDE);
			}
		}

		for(int i=0; i<5; i++) {
			if ((pWnd = GetDlgItem(IDC_RTU_ID13 + i)) != NULL) {
				pWnd->ShowWindow(size > 0 ? SW_SHOW : SW_HIDE);
			}
		}

	}

	GetDlgItem(IDC_RTU_ID9)->EnableWindow((m_numElevators<=1)? 0:1);
}

void CRtuElevFlrPage::OnUpDownElevSts(NMHDR* pNMHDR, LRESULT* pResult)
{
	NM_UPDOWN* pNMUpDown = (NM_UPDOWN*)pNMHDR;
			
	if (pNMUpDown->iDelta == 1) {
		--m_curElevatorNum;
		if (m_curElevatorNum < 0)
			m_curElevatorNum = m_numElevators - 1;
	}
	else  {
		++m_curElevatorNum;
		if (m_curElevatorNum >= m_numElevators)
			m_curElevatorNum = 0;
	}

	ShowStatus();

	*pResult = 0;

}

void CRtuElevFlrPage::Print()
{
	TCHAR fname[MAX_PATH] = _T("");
	if (!RtuLib::GetPrintFileName(fname, _T(".html")))
		return;

	CHtmlFile* pFile = new CHtmlFile(hrInst, fname);
	pFile->StartTags(IsRtu8002Type()? RTU_8002_TYPE: realRtuType, gRtuNo, IDS_RTU_STATUS, IDS_ELEVATOR_STATUS);

	CString sYes = RES_STRING(IDS_YES_TXT);
	CString sNo = RES_STRING(IDS_NO_TXT);
	CString sElevNum = RES_STRING(IDS_ELEV_NUM);
	CString sECNum = RES_STRING(IDS_1065EC_NUM);
	CString sOnline = RES_STRING(IDS_ONLINE);
	CString sOffline = RES_STRING(IDS_OFFLINE);
	CString sFlrAcc = RES_STRING(IDS_FLOOR_ACCESS);

	CString sTmp;
	for(int i=0; i<m_numElevators; i++) {
		pFile->SetBgColor(colors[i & 1 ? 1 : 0]);
		int size = m_elevatorStatus[i].size;
		if (size >= 2) {
			sTmp.Format(_T("%d"), m_elevatorStatus[i].elevatorNumber + 1);
			pFile->AddRow(1, 1, COL_SPAN | 2, sElevNum, COL_SPAN | 16, sTmp);
		}
		
		if (size >= 3) {
			BYTE data = m_elevatorStatus[i].offlineStatus;
			pFile->AddRow(2, 1, ROW_SPAN|8, sECNum, 1, _T("1"), 
				COL_SPAN | 16, data & 1 ? sOffline : sOnline);

			data >>= 1;
			for(int n=1; n<8; n++) {
				sTmp.Format(_T("%d"), n + 1);
				pFile->AddRow(1, 1, 1, sTmp, COL_SPAN | 16, data & 1 ? sOffline : sOnline);
				data >>= 1;
			}

			size -= 3;
			size = (size / 2) + (size & 1 ? 1 : 0);
			if (size > 0) {
				pFile->AddRow(1, 1, ROW_SPAN|(size+1)|COL_SPAN|(2<<7), sFlrAcc, COL_SPAN|16, _T("&nbsp;"));
				for(int j=0; j<8; j++) {
					if (j < size) {
						TCHAR faTxt[16][40];
						int st = (m_elevatorStatus[i].accessFloors[j*2 + 1] << 8) | (m_elevatorStatus[i].accessFloors[j*2]);
						for(int n=0; n<16; n++) {
							wsprintf(faTxt[n], _T("<b>%d</b> <br>%s"), n+1+j*16, st&1 ? (LPCTSTR)sYes : (LPCTSTR)sNo);
							st >>= 1;
						}
						pFile->AddTD(16, 
							1, faTxt[0], 1, faTxt[1], 1, faTxt[2], 1, faTxt[3],
							1, faTxt[4], 1, faTxt[5], 1, faTxt[6], 1, faTxt[7],
							1, faTxt[8], 1, faTxt[9], 1, faTxt[10], 1, faTxt[11],
							1, faTxt[12], 1, faTxt[13], 1, faTxt[14], 1, faTxt[15]);
					}
				}
			}
		}

	}

	pFile->EndTags(); delete pFile; pFile = NULL;
	RtuLib::FileExecute(GetSafeHwnd(), fname, _T("open"));
}

#pragma endregion CRtuElevFlrPage
/*------------------------------------------------------------------------------*/
/*					Keypad Status Page Class									*/
/*------------------------------------------------------------------------------*/
#pragma region CRtuKeypadPage

IMPLEMENT_DYNCREATE(CRtuKeypadPage, CPropertyPage)

void CRtuKeypadPage::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CRtuKeypadPage)
	DDX_Control(pDX, IDC_LIST, m_kpdList);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CRtuKeypadPage, CPropertyPage)
	//{{AFX_MSG_MAP(CRtuKeypadPage)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


BOOL CRtuKeypadPage::OnInitDialog()
{
	CDialog::OnInitDialog();
	 
	m_imgList.Create(IDB_KEYPADS, 22, 0, RGB(0, 0x80, 0x80));
	UINT nStrIDs[] = {IDS_NUMBER, IDS_TAMPER, IDS_OFFLINE, IDS_ISOLATED, IDS_KEY_SWITCH, 
		IDS_DEVICE_TYPE, IDS_PHYSICAL_ADDRESS, IDS_PHYSICAL_PORT, IDS_FIRMWARE_VER, IDS_BOOT_LOADER_VER};
	
	int nColumn = 5;
	if (s_bKeypadFirmware)
		nColumn += 5;

	for(int i=0; i<nColumn; i++) {
		CString strTxt = RES_STRING(nStrIDs[i]);
		CSize size = ((CDC*)this->GetDC())->GetTextExtent(strTxt);
		m_kpdList.InsertColumn(i, strTxt, LVCFMT_CENTER, size.cx + TXT_EXTENT);
	}

	m_kpdList.SetGridLines();
	m_kpdList.SetImageList(&m_imgList, LVSIL_SMALL);

	return TRUE;
}

BOOL CRtuKeypadPage::OnSetActive()
{
	ShowStatus();
	return CPropertyPage::OnSetActive();
}

LPBYTE CRtuKeypadPage::SetStatus(LPBYTE dp, int numkp, BOOL bKeySwitchInc)
{
	LPBYTE ptr = dp;
	m_numKeypads = numkp;
	try
	{
		if (m_numKeypads > (MAX_DEVINFO_BYTE * 8) )
			m_numKeypads = MAX_DEVINFO_BYTE * 8;

		memset(m_tamperData, 0, sizeof(m_tamperData));
		memset(m_offlineData, 0, sizeof(m_offlineData));
		memset(m_isolatedData, 0, sizeof(m_isolatedData));
		memset(m_keyswitchData, 0, sizeof(m_keyswitchData));

		m_bKeySwitchInc = bKeySwitchInc;
		if (m_numKeypads != 0)
		{
			int bc = (m_numKeypads / 8) + ((m_numKeypads % 8) ? 1 : 0);
			if(bc > MAX_DEVINFO_BYTE) 
				bc = MAX_DEVINFO_BYTE;
			memcpy(m_tamperData, ptr, bc);
			ptr += bc;
			memcpy(m_offlineData, ptr, bc);
			ptr += bc;
			memcpy(m_isolatedData, ptr, bc);
			ptr += bc;

			if (m_bKeySwitchInc) {
				memcpy(m_keyswitchData, ptr, bc);
				ptr += bc;
			}
		}
	}
	catch (...)
	{
		m_numKeypads  = 0;
		OutputDebugString(L"Exception in CRtuKeypadPage::SetStatus()\n");
	}
	return ptr+1;
}

void CRtuKeypadPage::ShowStatus()
{
	CString sYes = RES_STRING(IDS_YES_TXT);
	CString sNo = RES_STRING(IDS_NO_TXT);

	m_kpdList.DeleteAllItems();

	LVITEM lvi;
	lvi.mask = LVIF_IMAGE | LVIF_TEXT;
	lvi.iImage = 0;
	CString str;
	BYTE tdata=0;
	BYTE odata=0;
	BYTE idata=0;
	BYTE kdata=0;
	int imgNum=0;
	for(int i=0; i<m_numKeypads; i++) {
		if ((i % 8) == 0) {
			tdata = m_tamperData[i / 8];
			odata = m_offlineData[i / 8];
			idata = m_isolatedData[i / 8];
			kdata = m_keyswitchData[i / 8];
		}

		lvi.iItem = i;
		str.Format(_T("%d"), i + 1);

		if (idata & 1)
			imgNum = 2;
		else if (tdata & 1)
			imgNum = 1;
		else if (odata & 1)
			imgNum = 3;
		else 
			imgNum = 0;

		lvi.iImage = imgNum;
		lvi.pszText = (LPTSTR)(LPCTSTR)str;
		lvi.iSubItem = 0;
		m_kpdList.InsertItem(&lvi);

		// Tamper status
		m_kpdList.SetItemText(i, 1, tdata & 1 ? sYes : sNo);

		// Offline status
		m_kpdList.SetItemText(i, 2, odata & 1 ? sYes : sNo);

		// Isolated status
		m_kpdList.SetItemText(i, 3, idata & 1 ? sYes : sNo);
		
		tdata >>= 1; odata >>= 1; idata >>= 1;

		// Key switch status
		if (m_bKeySwitchInc) {
			m_kpdList.SetItemText(i, 4, kdata & 1 ? sYes : sNo);
			kdata >>= 1;
		}

		if (s_bKeypadFirmware) {
			// device type
			m_kpdList.SetItemText(i, 5, GetDeviceTypeString(i));

			// device physical address
			m_kpdList.SetItemText(i, 6, GetDevicePhysicalAddressString(s_keypadFirmware[i].physicalAddress));

			// device physical port
			m_kpdList.SetItemText(i, 7, GetDevicePhysicalPortString(s_keypadFirmware[i].physicalPort));

			// firmware verion
			m_kpdList.SetItemText(i, 8, GetFirmwareVersionString(i));

			// bootloader version
			m_kpdList.SetItemText(i, 9, GetBootloaderVersionString(i));
		}
	}
}

CString CRtuKeypadPage::GetDeviceTypeString(int index)
{
	CString s;
	s = GetDevTypeString(s_keypadFirmware[index].deviceType);
	if (s == _T(""))
		s = _T("Keypad");

	return s;
}
CString CRtuKeypadPage::GetFirmwareVersionString(int index)
{
	return GetVersionString(s_keypadFirmware[index].firmwareVerMajor, s_keypadFirmware[index].firmwareVerMinor);
}
CString CRtuKeypadPage::GetBootloaderVersionString(int index)
{
	return GetVersionString(s_keypadFirmware[index].bootLoaderVerMajor, s_keypadFirmware[index].bootLoaderVerMinor);
}

void CRtuKeypadPage::Print()
{
	TCHAR fname[MAX_PATH] = _T("");
	if (!RtuLib::GetPrintFileName(fname, _T(".html")))
		return;

	CHtmlFile* pFile = new CHtmlFile(hrInst, fname);
	pFile->StartTags(IsRtu8002Type()? RTU_8002_TYPE: realRtuType, gRtuNo, IDS_RTU_STATUS, IDS_KEYPAD_STATUS);

	CString sYes = RES_STRING(IDS_YES_TXT);
	CString sNo = RES_STRING(IDS_NO_TXT);
	CString sKpdNum = RES_STRING(IDS_KPD_NUM);
	CString sTamper = RES_STRING(IDS_TAMPER);
	CString sOffline = RES_STRING(IDS_OFFLINE);
	CString sIsolated = RES_STRING(IDS_ISOLATED);
	CString sKeySwitch = RES_STRING(IDS_KEY_SWITCH);
	CString sDevType = RES_STRING(IDS_DEVICE_TYPE);
	CString sPhysAddr = RES_STRING(IDS_PHYSICAL_ADDRESS);
	CString sPhysPort = RES_STRING(IDS_PHYSICAL_PORT);
	CString sFirmware = RES_STRING(IDS_FIRMWARE_VER);
	CString sBootLoader = RES_STRING(IDS_BOOT_LOADER_VER);

	pFile->SetBgColor(colors[2]);
	int hCount = 4;
	if (m_bKeySwitchInc)
		hCount += 1;
	if (s_bKeypadFirmware)
		hCount += 5;

	if (hCount == 10) {
		pFile->AddTH(hCount, 1, sKpdNum, 1, sTamper, 1, sOffline, 1, sIsolated, 1, sKeySwitch, 
			1, sDevType, 1, sPhysAddr, 1, sPhysPort, 1, sFirmware, 1, sBootLoader);
	}
	else if (hCount == 9) {
		pFile->AddTH(hCount, 1, sKpdNum, 1, sTamper, 1, sOffline, 1, sIsolated, 
			1, sDevType, 1, sPhysAddr, 1, sPhysPort, 1, sFirmware, 1, sBootLoader);
	}
	else if (hCount == 5) {
		pFile->AddTH(hCount, 1, sKpdNum, 1, sTamper, 1, sOffline, 1, sIsolated, 1, sKeySwitch);
	}
	else {
		pFile->AddTH(hCount, 1, sKpdNum, 1, sTamper, 1, sOffline, 1, sIsolated);
	}


	BYTE tdata=0;
	BYTE odata=0;
	BYTE idata=0;
	BYTE kdata=0;
	CString sTmp;
	for(int i=0; i<m_numKeypads; i++) {
		if ((i % 8) == 0) {
			tdata = m_tamperData[i / 8];
			odata = m_offlineData[i / 8];
			idata = m_isolatedData[i / 8];
			kdata = m_keyswitchData[i / 8];
		}

		pFile->SetBgColor(colors[i & 1 ? 1 : 0]);
		sTmp.Format(_T("%d"), i + 1);
		if (s_bKeypadFirmware) {
			if (m_bKeySwitchInc) {
				pFile->AddTD(10, 1, sTmp,
					1, tdata & 1 ? sYes : sNo,
					1, odata & 1 ? sYes : sNo,
					1, idata & 1 ? sYes : sNo,
					1, kdata & 1 ? sYes : sNo,
					1, GetDeviceTypeString(i),
					1, GetDevicePhysicalAddressString(s_keypadFirmware[i].physicalAddress),
					1, GetDevicePhysicalPortString(s_keypadFirmware[i].physicalPort),
					1, GetFirmwareVersionString(i), 
					1, GetBootloaderVersionString(i));
			}
			else {
				pFile->AddTD(9, 1, sTmp,
					1, tdata & 1 ? sYes : sNo,
					1, odata & 1 ? sYes : sNo,
					1, idata & 1 ? sYes : sNo,
					1, GetDeviceTypeString(i), 
					1, GetDevicePhysicalAddressString(s_keypadFirmware[i].physicalAddress),
					1, GetDevicePhysicalPortString(s_keypadFirmware[i].physicalPort),
					1, GetFirmwareVersionString(i), 
					1, GetBootloaderVersionString(i));
			}
		}
		else {
			if (m_bKeySwitchInc) {
				pFile->AddTD(5, 1, sTmp,
					1, tdata & 1 ? sYes : sNo,
					1, odata & 1 ? sYes : sNo,
					1, idata & 1 ? sYes : sNo,
					1, kdata & 1 ? sYes : sNo);
			}
			else {
				pFile->AddTD(4, 1, sTmp,
					1, tdata & 1 ? sYes : sNo,
					1, odata & 1 ? sYes : sNo,
					1, idata & 1 ? sYes : sNo);
			}
		}
			
		tdata >>= 1; odata >>= 1; idata >>= 1; kdata >>= 1;

	}

	pFile->EndTags(); delete pFile; pFile = NULL;
	RtuLib::FileExecute(GetSafeHwnd(), fname, _T("open"));
}

#pragma endregion CRtuKeypadPage
/*------------------------------------------------------------------------------*/
/*					16 I/O Status Page Class									*/
/*------------------------------------------------------------------------------*/
#pragma region CRtu16IOPage

IMPLEMENT_DYNCREATE(CRtu16IOPage, CPropertyPage)

void CRtu16IOPage::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CRtu16IOPage)
	DDX_Control(pDX, IDC_LIST, m_16ioList);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CRtu16IOPage, CPropertyPage)
	//{{AFX_MSG_MAP(CRtu16IOPage)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


BOOL CRtu16IOPage::OnInitDialog()
{
	CDialog::OnInitDialog();

	m_imgList.Create(IDB_16IOS, 12, 0, RGB(0, 0x80, 0x80));
	UINT nStrIDs[] = {IDS_NUMBER, IDS_TAMPER, IDS_OFFLINE, IDS_ISOLATED, 
		IDS_DEVICE_TYPE, IDS_PHYSICAL_ADDRESS, IDS_PHYSICAL_PORT, IDS_FIRMWARE_VER, IDS_BOOT_LOADER_VER};
	
	int nColumn = 4;
	if (s_bIoFirmware)
		nColumn += 5;

	for(int i=0; i<nColumn; i++) {
		CString strTxt = RES_STRING(nStrIDs[i]);
		CSize size = ((CDC*)this->GetDC())->GetTextExtent(strTxt);
		m_16ioList.InsertColumn(i, strTxt, LVCFMT_CENTER, size.cx + TXT_EXTENT);
	}

	m_16ioList.SetGridLines();
	m_16ioList.SetImageList(&m_imgList, LVSIL_SMALL);

	return TRUE;
}

BOOL CRtu16IOPage::OnSetActive()
{
	ShowStatus();
	return CPropertyPage::OnSetActive();
}

LPBYTE CRtu16IOPage::SetStatus(LPBYTE dp, int cnt, BOOL)
{
	LPBYTE ptr = dp;
	m_num16IOs = cnt;
	try
	{
		if (m_num16IOs > MAX_DEVINFO_BYTE * 8)
			m_num16IOs = MAX_DEVINFO_BYTE * 8;
		memset(m_tamperData, 0, sizeof(m_tamperData));
		memset(m_offlineData, 0, sizeof(m_offlineData));
		memset(m_isolatedData, 0, sizeof(m_isolatedData));

		int bc = (m_num16IOs / 8) + ((m_num16IOs % 8) ? 1 : 0);
		if(bc > MAX_DEVINFO_BYTE) 
			bc = MAX_DEVINFO_BYTE;
		memcpy(m_tamperData, ptr, bc);
		ptr += bc;
		memcpy(m_offlineData, ptr, bc);
		ptr += bc;
		memcpy(m_isolatedData, ptr, bc);
		ptr += bc;
		}
	catch (...)
	{
		m_num16IOs  = 0;
		OutputDebugString(L"Exception in CRtu16IOPage::SetStatus()\n");
	}

	return ptr;
}

void CRtu16IOPage::ShowStatus()
{
	if (IsWindow(m_hWnd) == FALSE) return;
	CString sYes = RES_STRING(IDS_YES_TXT);
	CString sNo = RES_STRING(IDS_NO_TXT);

	m_16ioList.DeleteAllItems();

	LVITEM lvi;
	lvi.mask = LVIF_IMAGE | LVIF_TEXT;
	CString str;
	BYTE tdata=0;
	BYTE odata=0;
	BYTE idata=0;
	int imgNum=0;
	for(int i=0; i<m_num16IOs; i++) {
		if ((i % 8) == 0) {
			tdata = m_tamperData[i / 8];
			odata = m_offlineData[i / 8];
			idata = m_isolatedData[i / 8];
		}

		lvi.iItem = i;
			
		if (idata & 1)
			imgNum = 2;
		else if (tdata & 1)
			imgNum = 1;
		else if (odata & 1)
			imgNum = 3;
		else
			imgNum = 0;
		lvi.iImage = imgNum;


		str.Format(_T("%d"), i + 1);
		lvi.pszText = (LPTSTR)(LPCTSTR)str;
		lvi.iSubItem = 0;
		m_16ioList.InsertItem(&lvi);

		// Tamper status
		m_16ioList.SetItemText(i, 1, tdata & 1 ? sYes : sNo);

		// Offline status
		m_16ioList.SetItemText(i, 2, odata & 1 ? sYes : sNo);

		// Isolated status
		m_16ioList.SetItemText(i, 3, idata & 1 ? sYes : sNo);

		if (s_bIoFirmware) {
			// device type
			m_16ioList.SetItemText(i, 4, GetDeviceTypeString(i));

			// device physical address
			m_16ioList.SetItemText(i, 5, GetDevicePhysicalAddressString(s_ioFirmware[i].physicalAddress));

			// device physical port
			m_16ioList.SetItemText(i, 6, GetDevicePhysicalPortString(s_ioFirmware[i].physicalPort));
			
			// firmware verion
			m_16ioList.SetItemText(i, 7, GetFirmwareVersionString(i));

			// bootloader version
			m_16ioList.SetItemText(i, 8, GetBootloaderVersionString(i));
		}

		tdata >>= 1; odata >>= 1; idata >>= 1; 
	}

}

CString CRtu16IOPage::GetDeviceTypeString(int index)
{
	CString s;
	s = GetDevTypeString(s_ioFirmware[index].deviceType);
	if (s == _T(""))
		s = _T("I/O");

	return s;
}
CString CRtu16IOPage::GetFirmwareVersionString(int index)
{
	return GetVersionString(s_ioFirmware[index].firmwareVerMajor, s_ioFirmware[index].firmwareVerMinor);
}
CString CRtu16IOPage::GetBootloaderVersionString(int index)
{
	return GetVersionString(s_ioFirmware[index].bootLoaderVerMajor, s_ioFirmware[index].bootLoaderVerMinor);
}

void CRtu16IOPage::Print()
{
	TCHAR fname[MAX_PATH] = _T("");
	if (!RtuLib::GetPrintFileName(fname, _T(".html")))
		return;

	CHtmlFile* pFile = new CHtmlFile(hrInst, fname);
	pFile->StartTags(IsRtu8002Type()? RTU_8002_TYPE: realRtuType, gRtuNo, IDS_RTU_STATUS, IDS_16IO_STATUS);

	CString sYes = RES_STRING(IDS_YES_TXT);
	CString sNo = RES_STRING(IDS_NO_TXT);
	CString sIONum = RES_STRING(IDS_IO_NUM);
	CString sTamper = RES_STRING(IDS_TAMPER);
	CString sOffline = RES_STRING(IDS_OFFLINE);
	CString sIsolated = RES_STRING(IDS_ISOLATED);

	CString sDevType = RES_STRING(IDS_DEVICE_TYPE);
	CString sPhysAddr = RES_STRING(IDS_PHYSICAL_ADDRESS);
	CString sPhysPort = RES_STRING(IDS_PHYSICAL_PORT);
	CString sFirmware = RES_STRING(IDS_FIRMWARE_VER);
	CString sBootLoader = RES_STRING(IDS_BOOT_LOADER_VER);

	pFile->SetBgColor(colors[2]);
	
	int hCount = 4;
	if (s_bIoFirmware)
		hCount += 5;

	if (hCount == 4)
		pFile->AddTH(hCount, 1, sIONum, 1, sTamper, 1, sOffline, 1, sIsolated);
	else 
		pFile->AddTH(hCount, 1, sIONum, 1, sTamper, 1, sOffline, 1, sIsolated, 
			1, sDevType, 1, sPhysAddr, 1, sPhysPort, 1, sFirmware, 1, sBootLoader);

	BYTE tdata=0;
	BYTE odata=0;
	BYTE idata=0;
	CString sTmp;
	for(int i=0; i<m_num16IOs; i++) {
		if ((i % 8) == 0) {
			tdata = m_tamperData[i / 8];
			odata = m_offlineData[i / 8];
			idata = m_isolatedData[i / 8];
		}

		pFile->SetBgColor(colors[i & 1 ? 1 : 0]);
		sTmp.Format(_T("%d"), i + 1);
		if (s_bIoFirmware) {
			pFile->AddTD(9, 1, sTmp,
				1, tdata & 1 ? sYes : sNo,
				1, odata & 1 ? sYes : sNo,
				1, idata & 1 ? sYes : sNo, 
				1, GetDeviceTypeString(i), 
				1, GetDevicePhysicalAddressString(s_ioFirmware[i].physicalAddress),
				1, GetDevicePhysicalPortString(s_ioFirmware[i].physicalPort),
				1, GetFirmwareVersionString(i), 
				1, GetBootloaderVersionString(i));
		}
		else {
			pFile->AddTD(4, 1, sTmp,
				1, tdata & 1 ? sYes : sNo,
				1, odata & 1 ? sYes : sNo,
				1, idata & 1 ? sYes : sNo);
		}
			
			
		tdata >>= 1; odata >>= 1; idata >>= 1;

	}

	pFile->EndTags(); delete pFile; pFile = NULL;
	RtuLib::FileExecute(GetSafeHwnd(), fname, _T("open"));
}

#pragma endregion CRtu16IOPage
/*------------------------------------------------------------------------------*/
/*					Camera Controller Status Page Class							*/
/*------------------------------------------------------------------------------*/
#pragma region CRtuCamCtrlPage
IMPLEMENT_DYNCREATE(CRtuCamCtrlPage, CPropertyPage)

void CRtuCamCtrlPage::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CRtuCamCtrlPage)
	DDX_Control(pDX, IDC_LIST, m_camCtrlList);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CRtuCamCtrlPage, CPropertyPage)
	//{{AFX_MSG_MAP(CRtuCamCtrlPage)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


BOOL CRtuCamCtrlPage::OnInitDialog()
{
	CDialog::OnInitDialog();

	m_imgList.Create(IDB_CAMERAS, 18, 0, RGB(0, 0x80, 0x80));
	UINT nStrIDs[] = {IDS_NUMBER, IDS_TAMPER, IDS_OFFLINE, IDS_ISOLATED};
	for(int i=0; i<4; i++) {
		CString strTxt = RES_STRING(nStrIDs[i]);
		CSize size = ((CDC*)this->GetDC())->GetTextExtent(strTxt);
		m_camCtrlList.InsertColumn(i, strTxt, LVCFMT_CENTER, size.cx + TXT_EXTENT);
	}

	m_camCtrlList.SetGridLines();
	m_camCtrlList.SetImageList(&m_imgList, LVSIL_SMALL);

	return TRUE;
}

BOOL CRtuCamCtrlPage::OnSetActive()
{

	ShowStatus();
	return CPropertyPage::OnSetActive();
}

LPBYTE CRtuCamCtrlPage::SetStatus(LPBYTE dp, int cnt, BOOL)
{
	LPBYTE ptr = dp;
	m_numCamCtrls = cnt;
	try
	{
		if (m_numCamCtrls > MAX_DEVINFO_BYTE * 8)
			m_numCamCtrls = MAX_DEVINFO_BYTE * 8;
		memset(m_tamperData, 0, sizeof(m_tamperData));
		memset(m_offlineData, 0, sizeof(m_offlineData));
		memset(m_isolatedData, 0, sizeof(m_isolatedData));

		int bc = (m_numCamCtrls / 8) + ((m_numCamCtrls % 8) ? 1 : 0);
		if(bc > MAX_DEVINFO_BYTE) 
			bc = MAX_DEVINFO_BYTE;
		memcpy(m_tamperData, ptr, bc);
		ptr += bc;
		memcpy(m_offlineData, ptr, bc);
		ptr += bc;
		memcpy(m_isolatedData, ptr, bc);
		ptr += bc;
	}
	catch (...)
	{
		m_numCamCtrls  = 0;
		OutputDebugString(L"Exception in CRtuCamCtrlPage::SetStatus()\n");
	}

	return ptr+1;
}

void CRtuCamCtrlPage::ShowStatus()
{
	if (IsWindow(m_hWnd) == FALSE) return;

	CString sYes = RES_STRING(IDS_YES_TXT);
	CString sNo = RES_STRING(IDS_NO_TXT);
	m_camCtrlList.DeleteAllItems();

	LVITEM lvi;
	lvi.mask = LVIF_IMAGE | LVIF_TEXT;
	CString str;
	BYTE tdata=0;
	BYTE odata=0;
	BYTE idata=0;
	int imgNum=0;
	for(int i=0; i<m_numCamCtrls; i++) {
		if ((i % 8) == 0) {
			tdata = m_tamperData[i / 8];
			odata = m_offlineData[i / 8];
			idata = m_isolatedData[i / 8];
		}

		lvi.iItem = i;
		if (idata & 1)
			imgNum = 2;
		else if (tdata & 1)
			imgNum = 1;
		else if (odata & 1)
			imgNum = 3;
		else
			imgNum = 0;
		lvi.iImage = imgNum;


		str.Format(_T("%d"), i + 1);
		lvi.pszText = (LPTSTR)(LPCTSTR)str;
		lvi.iSubItem = 0;
		m_camCtrlList.InsertItem(&lvi);

		// Tamper status
		m_camCtrlList.SetItemText(i, 1, tdata & 1 ? sYes : sNo);

		// Offline status
		m_camCtrlList.SetItemText(i, 2, odata & 1 ? sYes : sNo);

		// Isolated status
		m_camCtrlList.SetItemText(i, 3, idata & 1 ? sYes : sNo);

		tdata >>= 1; odata >>= 1; idata >>= 1; 
	}
   
}

void CRtuCamCtrlPage::Print()
{
	TCHAR fname[MAX_PATH] = _T("");
	if (!RtuLib::GetPrintFileName(fname, _T(".html")))
		return;

	CHtmlFile* pFile = new CHtmlFile(hrInst, fname);
	pFile->StartTags(IsRtu8002Type()? RTU_8002_TYPE: realRtuType, gRtuNo, IDS_RTU_STATUS, IDS_CAM_CTRLR_STS);

	CString sYes = RES_STRING(IDS_YES_TXT);
	CString sNo = RES_STRING(IDS_NO_TXT);
	CString sCamNum = RES_STRING(IDS_CAMERA_NUM);
	CString sTamper = RES_STRING(IDS_TAMPER);
	CString sOffline = RES_STRING(IDS_OFFLINE);
	CString sIsolated = RES_STRING(IDS_ISOLATED);

	pFile->SetBgColor(colors[2]);
	pFile->AddTH(4, 1, sCamNum, 1, sTamper, 1, sOffline, 1, sIsolated);

	BYTE tdata=0;
	BYTE odata=0;
	BYTE idata=0;
	for(int i=0; i<m_numCamCtrls; i++) {
		if ((i % 8) == 0) {
			tdata = m_tamperData[i / 8];
			odata = m_offlineData[i / 8];
			idata = m_isolatedData[i / 8];
		}

		pFile->SetBgColor(colors[i & 1 ? 1 : 0]);
		sCamNum.Format(_T("%d"), i + 1);
		pFile->AddTD(4, 1, sCamNum,
			1, tdata & 1 ? sYes : sNo,
			1, odata & 1 ? sYes : sNo,
			1, idata & 1 ? sYes : sNo);
		tdata >>= 1; odata >>= 1; idata >>= 1;
	}

	pFile->EndTags(); delete pFile; pFile = NULL;
	RtuLib::FileExecute(GetSafeHwnd(), fname, _T("open"));
}

#pragma endregion CRtuCamCtrlPage
/*------------------------------------------------------------------------------*/
/*					Elevator Controller Status Page Class						*/
/*------------------------------------------------------------------------------*/
#pragma region CRtuElevCtrlPage
IMPLEMENT_DYNCREATE(CRtuElevCtrlPage, CPropertyPage)

void CRtuElevCtrlPage::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CRtuElevCtrlPage)
	DDX_Control(pDX, IDC_LIST, m_elevCtrlList);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CRtuElevCtrlPage, CPropertyPage)
	//{{AFX_MSG_MAP(CRtuElevCtrlPage)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


BOOL CRtuElevCtrlPage::OnInitDialog()
{
	CDialog::OnInitDialog();
	
	m_imgList.Create(IDB_ELEVATORS, 12, 0, RGB(0, 0x80, 0x80));
	UINT nStrIDs[] = {IDS_NUMBER, IDS_TAMPER, IDS_OFFLINE, IDS_ISOLATED};
	for(int i=0; i<4; i++) {
		CString strTxt = RES_STRING(nStrIDs[i]);
		CSize size = ((CDC*)this->GetDC())->GetTextExtent(strTxt);
		m_elevCtrlList.InsertColumn(i, strTxt, LVCFMT_CENTER, size.cx + TXT_EXTENT);
	}

	m_elevCtrlList.SetGridLines();
	m_elevCtrlList.SetImageList(&m_imgList, LVSIL_SMALL);

	CWnd *pNextBtn = GetDlgItem(IDC_RTU_ID9);
	if (pNextBtn) pNextBtn->ShowWindow(SW_SHOW);
	return TRUE;
}

BOOL CRtuElevCtrlPage::OnSetActive()
{

	ShowStatus();
	return CPropertyPage::OnSetActive();
}

LPBYTE CRtuElevCtrlPage::SetStatus(LPBYTE dp, int cnt, BOOL)
{
	LPBYTE ptr = dp;
	m_numElevatorCtrls = cnt;
	try
	{
		if (m_numElevatorCtrls > MAX_DEVINFO_BYTE * 8)
			m_numElevatorCtrls = MAX_DEVINFO_BYTE * 8;

		memset(m_tamperData, 0, sizeof(m_tamperData));
		memset(m_offlineData, 0, sizeof(m_offlineData));
		memset(m_isolatedData, 0, sizeof(m_isolatedData));

		int bc = (m_numElevatorCtrls / 8) + ((m_numElevatorCtrls % 8) ? 1 : 0);
		if(bc > MAX_DEVINFO_BYTE) 
			bc = MAX_DEVINFO_BYTE;
		memcpy(m_tamperData, ptr, bc);
		ptr += bc;
		memcpy(m_offlineData, ptr, bc);
		ptr += bc;
		memcpy(m_isolatedData, ptr, bc);
		ptr += bc;
	}
	catch (...)
	{
		m_numElevatorCtrls  = 0;
		OutputDebugString(L"Exception in CRtuElevCtrlPage::SetStatus()\n");
	}
	return ptr+1;
}

void CRtuElevCtrlPage::ShowStatus()
{
	if (IsWindow(m_hWnd) == FALSE) return;

	CString sYes = RES_STRING(IDS_YES_TXT);
	CString sNo = RES_STRING(IDS_NO_TXT);

	m_elevCtrlList.DeleteAllItems();

	CWnd *pNextBtn = GetDlgItem(IDC_RTU_ID9);
	if (pNextBtn) 
	{
		pNextBtn->EnableWindow(m_numElevatorCtrls>1);
	}
	LVITEM lvi;
	lvi.mask = LVIF_IMAGE | LVIF_TEXT;
	CString str;
	BYTE tdata=0;
	BYTE odata=0;
	BYTE idata=0;
	int imgNum=0;
	for(int i=0; i<m_numElevatorCtrls; i++) {
		if ((i % 8) == 0) {
			tdata = m_tamperData[i / 8];
			odata = m_offlineData[i / 8];
			idata = m_isolatedData[i / 8];
		}

		lvi.iItem = i;
		
		if (idata & 1)
			imgNum = 2;
		else if (tdata & 1)
			imgNum = 1;
		else if (odata & 1)
			imgNum = 3;
		else 
			imgNum = 0;
		lvi.iImage = imgNum;

		str.Format(_T("%d"), i + 1);
		lvi.pszText = (LPTSTR)(LPCTSTR)str;
		lvi.iSubItem = 0;
		m_elevCtrlList.InsertItem(&lvi);

		// Tamper status
		m_elevCtrlList.SetItemText(i, 1, tdata & 1 ? sYes : sNo);

		// Offline status
		m_elevCtrlList.SetItemText(i, 2, odata & 1 ? sYes : sNo);

		// Isolated status
		m_elevCtrlList.SetItemText(i, 3, idata & 1 ? sYes : sNo);

		tdata >>= 1; odata >>= 1; idata >>= 1; 
	}

}

void CRtuElevCtrlPage::Print()
{
	TCHAR fname[MAX_PATH] = _T("");
	if (!RtuLib::GetPrintFileName(fname, _T(".html")))
		return;

	CHtmlFile* pFile = new CHtmlFile(hrInst, fname);
	pFile->StartTags(IsRtu8002Type()? RTU_8002_TYPE: realRtuType, gRtuNo, IDS_RTU_STATUS, IDS_ELEV_CTRLR_STS);

	CString sYes = RES_STRING(IDS_YES_TXT);
	CString sNo = RES_STRING(IDS_NO_TXT);
	CString sElevNum = RES_STRING(IDS_ELEV_NUM);
	CString sTamper = RES_STRING(IDS_TAMPER);
	CString sOffline = RES_STRING(IDS_OFFLINE);
	CString sIsolated = RES_STRING(IDS_ISOLATED);

	pFile->SetBgColor(colors[2]);
	pFile->AddTH(4, 1, sElevNum, 1, sTamper, 1, sOffline, 1, sIsolated);

	BYTE tdata=0;
	BYTE odata=0;
	BYTE idata=0;
	for(int i=0; i<m_numElevatorCtrls; i++) {
		if ((i % 8) == 0) {
			tdata = m_tamperData[i / 8];
			odata = m_offlineData[i / 8];
			idata = m_isolatedData[i / 8];
		}

		pFile->SetBgColor(colors[i & 1 ? 1 : 0]);
		sElevNum.Format(_T("%d"), i + 1);
		pFile->AddTD(4, 1, sElevNum,
			1, tdata & 1 ? sYes : sNo,
			1, odata & 1 ? sYes : sNo,
			1, idata & 1 ? sYes : sNo);
		tdata >>= 1; odata >>= 1; idata >>= 1;

	}

	pFile->EndTags(); delete pFile; pFile = NULL;
	RtuLib::FileExecute(GetSafeHwnd(), fname, _T("open"));
}

#pragma endregion CRtuElevCtrlPage
/*------------------------------------------------------------------------------*/
/*					Dialer Status Page Class									*/
/*------------------------------------------------------------------------------*/
#pragma region CRtuDialerPage

IMPLEMENT_DYNCREATE(CRtuDialerPage, CPropertyPage)

void CRtuDialerPage::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CRtuDialerPage)
	DDX_Control(pDX, IDC_LIST, m_dialList);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CRtuDialerPage, CPropertyPage)
	//{{AFX_MSG_MAP(CRtuDialerPage)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


BOOL CRtuDialerPage::OnInitDialog()
{
	CDialog::OnInitDialog();
	
	m_imgList.Create(IDB_DIALUPS, 12, 0, RGB(0, 0x80, 0x80));
	UINT nStrIDs[] = {IDS_NUMBER, IDS_TAMPER, IDS_OFFLINE, IDS_ISOLATED};
	for(int i=0; i<4; i++) {
		CString strTxt = RES_STRING(nStrIDs[i]);
		CSize size = ((CDC*)this->GetDC())->GetTextExtent(strTxt);
		m_dialList.InsertColumn(i, strTxt, LVCFMT_CENTER, size.cx + TXT_EXTENT);
	}

	m_dialList.SetGridLines();
	m_dialList.SetImageList(&m_imgList, LVSIL_SMALL);

	return TRUE;
}

BOOL CRtuDialerPage::OnSetActive()
{
	ShowStatus();
	return CPropertyPage::OnSetActive();
}

LPBYTE CRtuDialerPage::SetStatus(LPBYTE dp, int cnt, BOOL)
{
	LPBYTE ptr = dp;
	m_numDialers = cnt;
	try
	{
		if (m_numDialers > MAX_DEVINFO_BYTE * 8)
			m_numDialers = MAX_DEVINFO_BYTE * 8;
		memset(m_tamperData, 0, sizeof(m_tamperData));
		memset(m_offlineData, 0, sizeof(m_offlineData));
		memset(m_isolatedData, 0, sizeof(m_isolatedData));

		int bc = (m_numDialers / 8) + ((m_numDialers % 8) ? 1 : 0);
		if(bc > MAX_DEVINFO_BYTE) 
			bc = MAX_DEVINFO_BYTE;
		memcpy(m_tamperData, ptr, bc);
		ptr += bc;
		memcpy(m_offlineData, ptr, bc);
		ptr += bc;
		memcpy(m_isolatedData, ptr, bc);
		ptr += bc;
	}
	catch (...)
	{
		m_numDialers  = 0;
		OutputDebugString(L"Exception in CRtuDialerPage::SetStatus()\n");
	}
	return ptr+1;
}

void CRtuDialerPage::ShowStatus()
{
	if (IsWindow(m_hWnd) == FALSE) return;

	CString sYes = RES_STRING(IDS_YES_TXT);
	CString sNo = RES_STRING(IDS_NO_TXT);

	m_dialList.DeleteAllItems();

	LVITEM lvi;
	lvi.mask = LVIF_IMAGE | LVIF_TEXT;
	CString str;
	BYTE tdata=0;
	BYTE odata=0;
	BYTE idata=0;
	int imgNum=0;
	for(int i=0; i<m_numDialers; i++) {
		if ((i % 8) == 0) {
			tdata = m_tamperData[i / 8];
			odata = m_offlineData[i / 8];
			idata = m_isolatedData[i / 8];
		}

		lvi.iItem = i;
		
		if (idata & 1)
			imgNum = 2;
		else if (tdata & 1)
			imgNum = 1;
		else if (odata & 1)
			imgNum = 3;
		else
			imgNum = 0;
		lvi.iImage = imgNum;

		str.Format(_T("%d"), i + 1);
		lvi.pszText = (LPTSTR)(LPCTSTR)str;
		lvi.iSubItem = 0;
		m_dialList.InsertItem(&lvi);

		// Tamper status
		m_dialList.SetItemText(i, 1, tdata & 1 ? sYes : sNo);

		// Offline status
		m_dialList.SetItemText(i, 2, odata & 1 ? sYes : sNo);

		// Isolated status
		m_dialList.SetItemText(i, 3, idata & 1 ? sYes : sNo);

		tdata >>= 1; odata >>= 1; idata >>= 1; 
	}

}

void CRtuDialerPage::Print()
{
	TCHAR fname[MAX_PATH] = _T("");
	if (!RtuLib::GetPrintFileName(fname, _T(".html")))
		return;

	CHtmlFile* pFile = new CHtmlFile(hrInst, fname);
	pFile->StartTags(IsRtu8002Type()? RTU_8002_TYPE: realRtuType, gRtuNo, IDS_RTU_STATUS, IDS_DIALER_STS);

	CString sYes = RES_STRING(IDS_YES_TXT);
	CString sNo = RES_STRING(IDS_NO_TXT);
	CString sDialerNum = RES_STRING(IDS_DIALER_NUM);
	CString sTamper = RES_STRING(IDS_TAMPER);
	CString sOffline = RES_STRING(IDS_OFFLINE);
	CString sIsolated = RES_STRING(IDS_ISOLATED);

	pFile->SetBgColor(colors[2]);
	pFile->AddTH(4, 1, sDialerNum, 1, sTamper, 1, sOffline, 1, sIsolated);

	BYTE tdata=0;
	BYTE odata=0;
	BYTE idata=0;
	for(int i=0; i<m_numDialers; i++) {
		if ((i % 8) == 0) {
			tdata = m_tamperData[i / 8];
			odata = m_offlineData[i / 8];
			idata = m_isolatedData[i / 8];
		}

		pFile->SetBgColor(colors[i & 1 ? 1 : 0]);
		sDialerNum.Format(_T("%d"), i + 1);
		pFile->AddTD(4, 1, sDialerNum,
			1, tdata & 1 ? sYes : sNo,
			1, odata & 1 ? sYes : sNo,
			1, idata & 1 ? sYes : sNo);
		tdata >>= 1; odata >>= 1; idata >>= 1;

	}

	pFile->EndTags(); delete pFile; pFile = NULL;
	RtuLib::FileExecute(GetSafeHwnd(), fname, _T("open"));
}

#pragma endregion CRtuDialerPage
/*------------------------------------------------------------------------------*/
/*					Card Reader Status Page Class								*/
/*------------------------------------------------------------------------------*/
#pragma region CRtuCardRdrPage 

IMPLEMENT_DYNCREATE(CRtuCardRdrPage, CPropertyPage)

void CRtuCardRdrPage::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CRtuCardRdrPage)
	DDX_Control(pDX, IDC_LIST, m_rdrList);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CRtuCardRdrPage, CPropertyPage)
	//{{AFX_MSG_MAP(CRtuCardRdrPage)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


BOOL CRtuCardRdrPage::OnInitDialog()
{
	CDialog::OnInitDialog();

	m_imgList.Create(IDB_READERS, 16, 0, RGB(0, 0x80, 0x80));
	UINT nStrIDs[] = {IDS_NUMBER, IDS_TAMPER, IDS_OFFLINE, IDS_ISOLATED, 
		IDS_DEVICE_TYPE, IDS_PHYSICAL_ADDRESS, IDS_PHYSICAL_PORT, IDS_FIRMWARE_VER, IDS_BOOT_LOADER_VER};

	int nColumn = 4;
	if (s_bCardReaderFirmware)
		nColumn += 5;

	for(int i=0; i<nColumn; i++) {
		CString strTxt = RES_STRING(nStrIDs[i]);
		CSize size = ((CDC*)this->GetDC())->GetTextExtent(strTxt);
		m_rdrList.InsertColumn(i, strTxt, LVCFMT_CENTER, size.cx + TXT_EXTENT);
	}

	m_rdrList.SetGridLines();
	m_rdrList.SetImageList(&m_imgList, LVSIL_SMALL);

	return TRUE;
}

BOOL CRtuCardRdrPage::OnSetActive()
{
	ShowStatus();
	return CPropertyPage::OnSetActive();
}

LPBYTE CRtuCardRdrPage::SetStatus(LPBYTE dp, int cnt, BOOL)
{
	LPBYTE ptr = dp;
	m_numCardReaders = cnt;
	try
	{
		if (m_numCardReaders > MAX_DEVINFO_BYTE * 8)
			m_numCardReaders = MAX_DEVINFO_BYTE * 8;
		memset(m_tamperData, 0, sizeof(m_tamperData));
		memset(m_offlineData, 0, sizeof(m_offlineData));
		memset(m_isolatedData, 0, sizeof(m_isolatedData));

		int bc = (m_numCardReaders / 8) + ((m_numCardReaders % 8) ? 1 : 0);
		if(bc > MAX_DEVINFO_BYTE) 
			bc = MAX_DEVINFO_BYTE;
		memcpy(m_tamperData, ptr, bc);
		ptr += bc;
		memcpy(m_offlineData, ptr, bc);
		ptr += bc;
		memcpy(m_isolatedData, ptr, bc);
		ptr += bc;
	}
	catch (...)
	{
		m_numCardReaders  = 0;
		OutputDebugString(L"Exception in CRtuCardRdrPage::SetStatus()\n");
	}	

	return ptr + 1;
}

void CRtuCardRdrPage::ShowStatus()
{
	CString sYes = RES_STRING(IDS_YES_TXT);
	CString sNo = RES_STRING(IDS_NO_TXT);

	m_rdrList.DeleteAllItems();

	LVITEM lvi;
	lvi.mask = LVIF_IMAGE | LVIF_TEXT;
	CString str;
	BYTE tdata=0;
	BYTE odata=0;
	BYTE idata=0;
	int imgNum=0;
	for(int i=0; i<m_numCardReaders; i++) {
		if ((i % 8) == 0) {
			tdata = m_tamperData[i / 8];
			odata = m_offlineData[i / 8];
			idata = m_isolatedData[i / 8];
		}
		
		lvi.iItem = i;
		if (idata & 1)
			imgNum = 4;
		else if (tdata & 1)
			imgNum = 1;
		else if (odata & 1)
			imgNum = 5;
		else
			imgNum = 0;
		lvi.iImage = imgNum;

		str.Format(_T("%d"), i + 1);
		lvi.pszText = (LPTSTR)(LPCTSTR)str;
		lvi.iSubItem = 0;
		m_rdrList.InsertItem(&lvi);

		// Tamper status
		m_rdrList.SetItemText(i, 1, tdata & 1 ? sYes : sNo);

		// Offline status
		m_rdrList.SetItemText(i, 2, odata & 1 ? sYes : sNo);

		// Isolated status
		m_rdrList.SetItemText(i, 3, idata & 1 ? sYes : sNo);

		if (s_bCardReaderFirmware) {
			// device type
			m_rdrList.SetItemText(i, 4, GetDeviceTypeString(i));

			// device physical address
			m_rdrList.SetItemText(i, 5, GetDevicePhysicalAddressString(s_cardReaderFirmware[i].physicalAddress));

			// device physical port
			m_rdrList.SetItemText(i, 6, GetDevicePhysicalPortString(s_cardReaderFirmware[i].physicalPort));

			// firmware verion
			m_rdrList.SetItemText(i, 7, GetFirmwareVersionString(i));

			// bootloader version
			m_rdrList.SetItemText(i, 8, GetBootloaderVersionString(i));
		}

		tdata >>= 1; odata >>= 1; idata >>= 1; 
	}

}

CString CRtuCardRdrPage::GetDeviceTypeString(int index)
{
	CString s;

	s = GetDevTypeString(s_cardReaderFirmware[index].deviceType);
	if (s == _T(""))
		s = _T("CRI");

	return s;
}
CString CRtuCardRdrPage::GetFirmwareVersionString(int index)
{
	return GetVersionString(s_cardReaderFirmware[index].firmwareVerMajor, s_cardReaderFirmware[index].firmwareVerMinor);
}
CString CRtuCardRdrPage::GetBootloaderVersionString(int index)
{
	return GetVersionString(s_cardReaderFirmware[index].bootLoaderVerMajor, s_cardReaderFirmware[index].bootLoaderVerMinor);
}

void CRtuCardRdrPage::Print()
{
	TCHAR fname[MAX_PATH] = _T("");
	if (!RtuLib::GetPrintFileName(fname, _T(".html")))
		return;

	CHtmlFile* pFile = new CHtmlFile(hrInst, fname);
	pFile->StartTags(IsRtu8002Type()? RTU_8002_TYPE: realRtuType, gRtuNo, IDS_RTU_STATUS, IDS_CARD_RDR_STS);

	CString sYes = RES_STRING(IDS_YES_TXT);
	CString sNo = RES_STRING(IDS_NO_TXT);
	CString sRdrNum = RES_STRING(IDS_RDR_NUM);
	CString sTamper = RES_STRING(IDS_TAMPER);
	CString sOffline = RES_STRING(IDS_OFFLINE);
	CString sIsolated = RES_STRING(IDS_ISOLATED);
	CString sDevType = RES_STRING(IDS_DEVICE_TYPE);
	CString sPhysAddr = RES_STRING(IDS_PHYSICAL_ADDRESS);
	CString sPhysPort = RES_STRING(IDS_PHYSICAL_PORT);
	CString sFirmware = RES_STRING(IDS_FIRMWARE_VER);
	CString sBootLoader = RES_STRING(IDS_BOOT_LOADER_VER);

	pFile->SetBgColor(colors[2]);

	int hCount = 4;
	if (s_bCardReaderFirmware)
		hCount += 5;

	if (hCount == 4)
		pFile->AddTH(hCount, 1, sRdrNum, 1, sTamper, 1, sOffline, 1, sIsolated);
	else
		pFile->AddTH(hCount, 1, sRdrNum, 1, sTamper, 1, sOffline, 1, sIsolated, 
			1, sDevType, 1, sPhysAddr, 1, sPhysPort, 1, sFirmware, 1, sBootLoader);
	
	BYTE tdata=0;
	BYTE odata=0;
	BYTE idata=0;
	for(int i=0; i<m_numCardReaders; i++) {
		if ((i % 8) == 0) {
			tdata = m_tamperData[i / 8];
			odata = m_offlineData[i / 8];
			idata = m_isolatedData[i / 8];
		}

		pFile->SetBgColor(colors[i & 1 ? 1 : 0]);
		sRdrNum.Format(_T("%d"), i + 1);
		if (s_bCardReaderFirmware) {
			pFile->AddTD(7, 1, sRdrNum,
				1, tdata & 1 ? sYes : sNo,
				1, odata & 1 ? sYes : sNo,
				1, idata & 1 ? sYes : sNo, 
				1, GetDeviceTypeString(i),
				1, GetDevicePhysicalAddressString(s_cardReaderFirmware[i].physicalAddress),
				1, GetDevicePhysicalPortString(s_cardReaderFirmware[i].physicalPort),
				1, GetFirmwareVersionString(i),
				1, GetBootloaderVersionString(i));
		}
		else {
			pFile->AddTD(4, 1, sRdrNum,
				1, tdata & 1 ? sYes : sNo,
				1, odata & 1 ? sYes : sNo,
				1, idata & 1 ? sYes : sNo);
		}
			
		tdata >>= 1; odata >>= 1; idata >>= 1;

	}

	pFile->EndTags(); delete pFile; pFile = NULL;
	RtuLib::FileExecute(GetSafeHwnd(), fname, _T("open"));
}

#pragma endregion CRtuCardRdrPage
/*------------------------------------------------------------------------------*/
/*					Output Status Page Class									*/
/*------------------------------------------------------------------------------*/
#pragma region CRtuOpStsPage

IMPLEMENT_DYNCREATE(CRtuOpStsPage, CPropertyPage)

void CRtuOpStsPage::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CRtuOpStsPage)
	DDX_Control(pDX, IDC_LIST, m_outputList);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CRtuOpStsPage, CPropertyPage)
	//{{AFX_MSG_MAP(CRtuOpStsPage)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

BOOL CRtuOpStsPage::OnInitDialog()
{
	CDialog::OnInitDialog();

	m_imgList.Create(IDB_OUTPUTS, 12, 0, RGB(0x00, 0x80, 0x80));
	UINT nStrIDs[] = {IDS_NUMBER, IDS_POINT_STS, IDS_ISOLATED};
	for(int i=0; i<3; i++) {
		CString strTxt = RES_STRING(nStrIDs[i]);
		CSize size = ((CDC*)this->GetDC())->GetTextExtent(strTxt);
		m_outputList.InsertColumn(i, strTxt, LVCFMT_CENTER, size.cx + TXT_EXTENT);
	}

	m_outputList.SetGridLines(TRUE);
	m_outputList.SetImageList(&m_imgList, LVSIL_SMALL);

	return TRUE;
}

BOOL CRtuOpStsPage::OnSetActive()
{
	ShowStatus();
	return CPropertyPage::OnSetActive();
}

LPBYTE CRtuOpStsPage::SetStatus(LPBYTE lpData, int, BOOL)
{
	LPBYTE p = lpData;
	m_numOutputs = *p;
	if (m_numOutputs > MAXOPS)
		m_numOutputs = MAXOPS;
	int cnt = (m_numOutputs % 4) ? m_numOutputs/4 + 1 : m_numOutputs/4;
	try
	{
		memcpy(m_outputStatus, p+1, cnt);
		lpData += 1 + cnt;
	}
	catch (...)
	{
		m_numOutputs  = 0;
		OutputDebugString(L"Exception in CRtuOpStsPage::SetStatus()\n");
	}	
	return lpData;
}

void CRtuOpStsPage::ShowStatus()
{
	m_outputList.DeleteAllItems();
	LVITEM lvi;
	CString strItem;

	CString str = RES_STRING(IDS_TOT_OUT);

	strItem.Format(str, m_numOutputs);
	GetDlgItem(IDC_RTU_TOTAL)->SetWindowText(strItem);
	lvi.mask = LVIF_IMAGE | LVIF_TEXT;

	int imgNum=0;
	BYTE data = 0;

	CString sYes = RES_STRING(IDS_YES_TXT);
	CString sNo = RES_STRING(IDS_NO_TXT);
	CString sOn = RES_STRING(IDS_ON);
	CString sOff = RES_STRING(IDS_OFF);

	for (int i=0; i<m_numOutputs; i++) {
		if ( (i % 4) == 0 ) {
			data = m_outputStatus[i/4];
		}

		if (data & 2)
			imgNum = 2;		// output isolated
		else if (data & 1)
			imgNum = 1;		// output ON
		else
			imgNum = 0;		// output OFF

		lvi.iItem = i;
		lvi.iImage = imgNum;

		strItem.Format(_T("%d"), i+1);
		lvi.iSubItem = 0;
		lvi.pszText = (LPTSTR)(LPCTSTR)(strItem);
		m_outputList.InsertItem(&lvi);

		// Set subitem 1
		m_outputList.SetItemText(i, 1, data & 1 ? sOn : sOff);

		// Set subitem 2
		m_outputList.SetItemText(i, 2, data & 2 ? sYes : sNo);

		data >>= 2;

	}
}

void CRtuOpStsPage::Print()
{
	TCHAR fname[MAX_PATH] = _T("");
	if (!RtuLib::GetPrintFileName(fname, _T(".html")))
		return;

	CHtmlFile* pFile = new CHtmlFile(hrInst, fname);
	pFile->StartTags(IsRtu8002Type()? RTU_8002_TYPE: realRtuType, gRtuNo, IDS_RTU_STATUS, RTU_DB_STSTYPE8);

	CString sYes = RES_STRING(IDS_YES_TXT);
	CString sNo = RES_STRING(IDS_NO_TXT);
	CString sOn = RES_STRING(IDS_ON);
	CString sOff = RES_STRING(IDS_OFF);
	CString sOutNum = RES_STRING(IDS_OUT_NUM);
	CString sPntSts = RES_STRING(IDS_POINT_STS);
	CString sIsolated = RES_STRING(IDS_ISOLATED);

	pFile->SetBgColor(colors[2]);
	pFile->AddTH(3, 1, sOutNum, 1, sPntSts, 1, sIsolated);
	BYTE data = 0;
	for (int i=0; i<m_numOutputs; i++) {
		pFile->SetBgColor(colors[i & 1 ? 1 : 0]);
		if ( (i % 4) == 0 ) {
			data = m_outputStatus[i/4];
		}

		sOutNum.Format(_T("%d"), i+1);
		pFile->AddTD(3, 1, sOutNum, 
			1, data & 1 ? sOn : sOff,
			1, data & 2 ? sYes : sNo);
		data >>= 2;
	}

	pFile->EndTags(); delete pFile; pFile = NULL;
	RtuLib::FileExecute(GetSafeHwnd(), fname, _T("open"));
}

#pragma endregion CRtuOpStsPage
/*------------------------------------------------------------------------------*/
/*					Camera Status Page Class									*/
/*------------------------------------------------------------------------------*/
#pragma region CRtuCamStsPage

IMPLEMENT_DYNCREATE(CRtuCamStsPage, CPropertyPage)

void CRtuCamStsPage::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CRtuCamStsPage)
	DDX_Control(pDX, IDC_LIST, m_camerList);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CRtuCamStsPage, CPropertyPage)
	//{{AFX_MSG_MAP(CRtuCamStsPage)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


BOOL CRtuCamStsPage::OnInitDialog()
{
	CDialog::OnInitDialog();

	m_imgList.Create(IDB_CAMERAS, 18, 0, RGB(0, 0x80, 0x80));
	
	//TCHAR * strTxt[] = { _T("Number"), _T("Point Status"), _T("  Isolated  "), _T("Film Low"),
	//	_T("Film Out"), _T("Frame Count") };
	UINT nStrIDs[] = {IDS_NUMBER, IDS_POINT_STS, IDS_ISOLATED, 
		IDS_FILM_LOW, IDS_FILM_OUT, IDS_FRAME_CNT};

	for(int i=0; i<6; i++) {
		CString strTxt = RES_STRING(nStrIDs[i]);
		CSize size = ((CDC*)this->GetDC())->GetTextExtent(strTxt);
		m_camerList.InsertColumn(i, strTxt, LVCFMT_CENTER, size.cx + TXT_EXTENT);
	}

	m_camerList.SetGridLines(TRUE);
	m_camerList.SetImageList(&m_imgList, LVSIL_SMALL);
	return TRUE;
}

BOOL CRtuCamStsPage::OnSetActive()
{
	ShowStatus();
	return CPropertyPage::OnSetActive();
}

LPBYTE CRtuCamStsPage::SetStatus(LPBYTE lpData, int, BOOL)
{
	LPBYTE p = lpData;
	m_numCameras = *p;
	if (m_numCameras > MAX_RTU_CAMPNTS)
		m_numCameras = MAX_RTU_CAMPNTS;
	int cnt = m_numCameras * sizeof(RTU_CAMSTATS);
	try
	{
		memcpy(&m_cameraStatus[0], p+1, cnt);
		lpData += 1 + cnt;
	}
	catch (...)
	{
		m_numCameras  = 0;
		OutputDebugString(L"Exception in CRtuCamStsPage::SetStatus()\n");
	}	
	return lpData;
}

void CRtuCamStsPage::ShowStatus()
{
	CString strItem;
	CString str = RES_STRING(IDS_TOT_CAM);
	strItem.Format(str, m_numCameras);
	GetDlgItem(IDC_RTU_CAMTOTAL)->SetWindowText(strItem);

	m_camerList.DeleteAllItems();

	LVITEM lvi;
	lvi.mask = LVIF_IMAGE | LVIF_TEXT;
	int imgNum=0;

	CString sYes = RES_STRING(IDS_YES_TXT);
	CString sNo = RES_STRING(IDS_NO_TXT);
	CString sOn = RES_STRING(IDS_ON);
	CString sOff = RES_STRING(IDS_OFF);

	for (int i=0; i<m_numCameras; i++) {
		
		if (m_cameraStatus[i].status & 2)
			imgNum = 2;			// point isolated
		else if (m_cameraStatus[i].status & 1)
			imgNum = 1;			// camera ON
		else
			imgNum = 0;

		lvi.iImage = imgNum;
		lvi.iItem = i;

		strItem.Format(_T("%d"), i+1);
		lvi.pszText = (LPTSTR)(LPCTSTR)strItem;
		lvi.iSubItem = 0;
		m_camerList.InsertItem(&lvi);

		m_camerList.SetItemText(i, 1, m_cameraStatus[i].status & 1 ? sOn : sOff);
		m_camerList.SetItemText(i, 2, m_cameraStatus[i].status & 2 ? sYes : sNo);
		m_camerList.SetItemText(i, 3, m_cameraStatus[i].status & 4 ? sYes : sNo);
		m_camerList.SetItemText(i, 4, m_cameraStatus[i].status & 8 ? sYes : sNo);

		int fcnt = (m_cameraStatus[i].frameCntH << 8) + m_cameraStatus[i].frameCntL;
		strItem.Format(_T("%d"), fcnt);
		m_camerList.SetItemText(i, 5, strItem);
	}

}

void CRtuCamStsPage::Print()
{
	TCHAR fname[MAX_PATH] = _T("");
	if (!RtuLib::GetPrintFileName(fname, _T(".html")))
		return;

	CHtmlFile* pFile = new CHtmlFile(hrInst, fname);
	pFile->StartTags(IsRtu8002Type()? RTU_8002_TYPE: realRtuType, gRtuNo, IDS_RTU_STATUS, IDS_CAMERA_STS);

	CString sYes = RES_STRING(IDS_YES_TXT);
	CString sNo = RES_STRING(IDS_NO_TXT);
	CString sOn = RES_STRING(IDS_ON);
	CString sOff = RES_STRING(IDS_OFF);
	CString sOutNum = RES_STRING(IDS_OUT_NUM);
	CString sPntSts = RES_STRING(IDS_POINT_STS);
	CString sIsolated = RES_STRING(IDS_ISOLATED);
	CString sFilmLow = RES_STRING(IDS_FILM_LOW);
	CString sFilmOut = RES_STRING(IDS_FILM_OUT);
	CString sFrameCnt = RES_STRING(IDS_FRAME_CNT);

	pFile->SetBgColor(colors[2]);
	pFile->AddTH(6, 1, sOutNum, 1, sPntSts, 1, sIsolated,
		1, sFilmLow, 1, sFilmOut, 1, sFrameCnt);
	
	for (int i=0; i<m_numCameras; i++) {
		pFile->SetBgColor(colors[i & 1 ? 1 : 0]);
		sOutNum.Format(_T("%d"), i+1);
		sFrameCnt.Format(_T("%d"), (m_cameraStatus[i].frameCntH << 8) + m_cameraStatus[i].frameCntL);
		pFile->AddTD(6, 1, sOutNum, 
			1, m_cameraStatus[i].status & 1 ? sOn : sOff,
			1, m_cameraStatus[i].status & 2 ? sYes : sNo,
			1, m_cameraStatus[i].status & 4 ? sYes : sNo,
			1, m_cameraStatus[i].status & 8 ? sYes : sNo,
			1, sFrameCnt);
	}

	pFile->EndTags(); delete pFile; pFile = NULL;
	RtuLib::FileExecute(GetSafeHwnd(), fname, _T("open"));
}

#pragma endregion CRtuCamStsPage
/*------------------------------------------------------------------------------*/
/*					CCTV Status Page Class										*/
/*------------------------------------------------------------------------------*/
#pragma region CRtuCctvStsPage

IMPLEMENT_DYNCREATE(CRtuCctvStsPage, CPropertyPage)

void CRtuCctvStsPage::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CRtuCctvStsPage)
	DDX_Control(pDX, IDC_LIST, m_cctvList);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CRtuCctvStsPage, CPropertyPage)
	//{{AFX_MSG_MAP(CRtuCctvStsPage)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


BOOL CRtuCctvStsPage::OnInitDialog()
{
	CDialog::OnInitDialog();

	m_imgList.Create(_T("CCTVCAMERA"), 23, 0 , RGB(0x00, 0x80, 0x80));
	
	UINT nStrIDs[] = {IDS_NUMBER, IDS_RECORDING, IDS_POINT_STS};
	for(int i=0; i<3; i++) {
		CString strTxt = RES_STRING(nStrIDs[i]);
		CSize size = ((CDC*)this->GetDC())->GetTextExtent(strTxt);
		m_cctvList.InsertColumn(i, strTxt, LVCFMT_CENTER, size.cx + TXT_EXTENT);
	}

	m_cctvList.SetGridLines(TRUE);
	m_cctvList.SetImageList(&m_imgList, LVSIL_SMALL);
	return TRUE;
}

BOOL CRtuCctvStsPage::OnSetActive()
{
	ShowStatus();
	return CPropertyPage::OnSetActive();
}

LPBYTE CRtuCctvStsPage::SetStatus(LPBYTE lpData, int, BOOL)
{
	LPBYTE p = lpData;
	m_numCCTVs = *p;
	if (m_numCCTVs > MAXOPS)
		m_numCCTVs= MAXOPS;
	int cnt = 0;
	try
	{
		if (m_numCCTVs) {
			cnt = ((m_numCCTVs - 1) / 2) + 1;
			memcpy(m_cctvStatus, p+1, cnt);
		}
		lpData += 1 + cnt;
	}
	catch (...)
	{
		m_numCCTVs  = 0;
		OutputDebugString(L"Exception in CRtuCctvStsPage::SetStatus()\n");
	}	

	return lpData;
}

void CRtuCctvStsPage::ShowStatus()
{
	BYTE data = 0;
	CString str;
	UINT cctvIDs[] = {IDS_OFF, IDS_ON, IDS_CAM_SIGNAL_LOST, IDS_PNT_ON_IN_ALM};
	CString sOff = RES_STRING(IDS_OFF);
	CString sActivated = RES_STRING(IDS_ACTIVATED);

	m_cctvList.DeleteAllItems();
	LVITEM lvi;
	lvi.mask = LVIF_IMAGE | LVIF_TEXT;
	
	for (int i=0; i<m_numCCTVs; i++) {
		if ( (i % 2) == 0) {
			data = m_cctvStatus[i/2];
		}

		lvi.iItem = i;
		lvi.iImage = 0;

		str.Format(_T(" %d"), i+1);
		lvi.pszText = (LPTSTR)(LPCTSTR)str;
		lvi.iSubItem = 0;
		m_cctvList.InsertItem(&lvi);

		m_cctvList.SetItemText(i, 1, data & 8 ? sActivated : sOff);
		CString sPntSts = RES_STRING(cctvIDs[data & 3]);
		m_cctvList.SetItemText(i, 2, sPntSts);

		data >>= 4;
	}
}

void CRtuCctvStsPage::Print()
{
	TCHAR fname[MAX_PATH] = _T("");
	if (!RtuLib::GetPrintFileName(fname, _T(".html")))
		return;

	CHtmlFile* pFile = new CHtmlFile(hrInst, fname);
	pFile->StartTags(IsRtu8002Type()? RTU_8002_TYPE: realRtuType, gRtuNo, IDS_RTU_STATUS, IDS_CCTV_STS);
	UINT cctvIDs[] = {IDS_OFF, IDS_ON, IDS_CAM_SIGNAL_LOST, IDS_PNT_ON_IN_ALM};

	CString sOff = RES_STRING(IDS_OFF);
	CString sActivated = RES_STRING(IDS_ACTIVATED);
	CString sCctvNum = RES_STRING(IDS_CCTV_NUMBER);
	CString sRecording = RES_STRING(IDS_RECORDING);
	CString sPntSts = RES_STRING(IDS_POINT_STS);

	pFile->SetBgColor(colors[2]);
	pFile->AddTH(3, 1, sCctvNum, 1, sRecording, 1, sPntSts);

	BYTE data = 0;
	for (int i=0; i<m_numCCTVs; i++) {
		pFile->SetBgColor(colors[i & 1 ? 1 : 0]);

		if ( (i % 2) == 0) {
			data = m_cctvStatus[i/2];
		}

		sCctvNum.Format(_T("%d"), i + 1);
		sPntSts = RES_STRING(cctvIDs[data & 3]);

		pFile->AddTD(3, 1, sCctvNum, 1, data & 8 ? sActivated : sOff, 1, sPntSts);
		data >>= 4;
	}

	pFile->EndTags(); delete pFile; pFile = NULL;
	RtuLib::FileExecute(GetSafeHwnd(), fname, _T("open"));
}

#pragma endregion CRtuCctvStsPage
/*------------------------------------------------------------------------------*/
/*					Input Status Page Class										*/
/*------------------------------------------------------------------------------*/
#pragma region CRtuInpStsPage

IMPLEMENT_DYNCREATE(CRtuInpStsPage, CPropertyPage)

CRtuInpStsPage::CRtuInpStsPage() : CRtuStatusBase(CRtuInpStsPage::IDD)
{
	m_numInputs=0; 
	m_curInputNum=0; 
	memset(m_inputStatus, 0, sizeof(m_inputStatus));

	m_numLatches=0;
	
	memset(m_latchedStatus, 0, sizeof(m_latchedStatus));

	m_numSoaks=0;
	
	memset(m_soakedStatus, 0, sizeof(m_soakedStatus));

	m_hasInputExtendedStatus = FALSE;
	m_numInputExtendedStatus = 0;
	memset(m_inputExtendedStatus, 0, sizeof(m_inputExtendedStatus));
}

void CRtuInpStsPage::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CRtuInpStsPage)
	DDX_Control(pDX, IDC_LIST, m_inputList);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CRtuInpStsPage, CPropertyPage)
	//{{AFX_MSG_MAP(CRtuInpStsPage)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


BOOL CRtuInpStsPage::OnInitDialog()
{
	CDialog::OnInitDialog();
	
	m_imgList.Create(IDB_INPUTS, 12, 0, RGB(0x00, 0x80, 0x80));
		
	UINT nStrIDs[] = {IDS_NUMBER, IDS_POINT_STS, IDS_ISOLATED, IDS_SOAK_STS, IDS_LATCH_STS};
	CString strTxt;
	for(int i=0; i<3; i++) {
		strTxt = RES_STRING(nStrIDs[i]);
		CSize size = ((CDC*)this->GetDC())->GetTextExtent(strTxt);
		m_inputList.InsertColumn(i, strTxt, LVCFMT_CENTER, size.cx + TXT_EXTENT);
	}
	
	int nextColumn = 3;
	if (m_numSoaks && m_numLatches) {
		for(int i=3; i<5; i++) {
			strTxt = RES_STRING(nStrIDs[i]);
			CSize size = ((CDC*)this->GetDC())->GetTextExtent(strTxt);
			m_inputList.InsertColumn(i, strTxt, LVCFMT_CENTER, size.cx + TXT_EXTENT);
		}
		nextColumn = 5;
	}

	else if (m_numSoaks) {
		strTxt = RES_STRING(nStrIDs[3]);
		CSize size = ((CDC*)this->GetDC())->GetTextExtent(strTxt);
		m_inputList.InsertColumn(3, strTxt, LVCFMT_CENTER, size.cx + TXT_EXTENT);
		nextColumn = 4;
	}

	else if (m_numLatches) {
		strTxt = RES_STRING(nStrIDs[4]);
		CSize size = ((CDC*)this->GetDC())->GetTextExtent(strTxt);
		m_inputList.InsertColumn(3, strTxt, LVCFMT_CENTER, size.cx + TXT_EXTENT);
		nextColumn = 4;
	}

	if (m_hasInputExtendedStatus) {
		UINT nStrID2s[] = {IDS_TX_STATUS_LEVEL, IDS_TAMPER_ALARM, IDS_BATT_LOW_ALARM, IDS_SUSPICION_ACTIVE};
		for(int i=0; i<4; i++) {
			strTxt = RES_STRING(nStrID2s[i]);
			CSize size = ((CDC*)this->GetDC())->GetTextExtent(strTxt);
			m_inputList.InsertColumn(nextColumn + i, strTxt, LVCFMT_CENTER, size.cx + TXT_EXTENT);
		}				
	}

	m_inputList.SetGridLines(TRUE);
	m_inputList.SetImageList(&m_imgList, LVSIL_SMALL);

	return TRUE;
}

BOOL CRtuInpStsPage::OnSetActive()
{
	ShowStatus();
	return CPropertyPage::OnSetActive();
}

LPBYTE CRtuInpStsPage::SetStatus(LPBYTE lpData, int, BOOL)
{
	return SetInpStsData(lpData);
}

LPBYTE CRtuInpStsPage::SetInpStsData(LPBYTE lpData)
{
	LPBYTE p = lpData;
	m_numInputs = *p;
	try
	{
		if (m_numInputs > MAX_RTU_ALMPNTS)
			m_numInputs = MAX_RTU_ALMPNTS;
		if (m_numInputs == 0)
			m_numInputs = MAX_RTU_ALMPNTS;
		int cnt = (m_numInputs>>1) + (m_numInputs%2 ? 1 : 0);
		memcpy(m_inputStatus, p+1, cnt);

		lpData += 1 + cnt;		//.I/P status bytes
	}
	catch (...)
	{
		m_numInputs  = 0;
		OutputDebugString(L"Exception in CRtuInpStsPage::SetStatus()\n");
	}	

	return lpData;
}

LPBYTE CRtuInpStsPage::SetLatchStsData(LPBYTE lpData)
{
	LPBYTE p = lpData;
	m_numLatches = *p;
	if (m_numLatches == 0) {
		m_numLatches = MAX_RTU_ALMPNTS;
	}
	int cnt = 0;
	if (m_numLatches) {
		cnt = ((m_numLatches - 1) / 8) + 1;
		memcpy(&m_latchedStatus[0], p+1, cnt);
	}
	lpData += 1 + cnt;
	return lpData;
}

LPBYTE CRtuInpStsPage::SetSoakStsData(LPBYTE lpData)
{
	LPBYTE p = lpData;
	m_numSoaks = *p;
	if (m_numSoaks == 0) {
		m_numSoaks = MAX_RTU_ALMPNTS;
	}
	int cnt = 0;
	if (m_numSoaks) {
		cnt = ((m_numSoaks - 1)/8) + 1;
		memcpy(&m_soakedStatus[0], p+1, cnt);
	}
	lpData += 1 + cnt;
	return lpData;
}

LPBYTE CRtuInpStsPage::SetExtendeInputData(LPBYTE lpData)
{
	LPBYTE p = lpData;
	memset(m_inputExtendedStatus, 0, sizeof(m_inputExtendedStatus));
	m_hasInputExtendedStatus = TRUE;
	m_numInputExtendedStatus = *p++;
	if (m_numInputExtendedStatus == 0) {
		m_numInputExtendedStatus = MAX_RTU_ALMPNTS;
	}
	memcpy(m_inputExtendedStatus, p, m_numInputExtendedStatus);
	p += m_numInputExtendedStatus;

	return p;
}

void CRtuInpStsPage::ShowStatus()
{
	
	CString sTmp = RES_STRING(IDS_TOT_INP);
	CString str; str.Format(sTmp, m_numInputs);
	GetDlgItem(IDC_RTU_INPTOTAL)->SetWindowText(str);

	UINT pntIDs[] = {IDS_NOT_DEFINED, IDS_SECURE, IDS_NORMAL, IDS_SHORT, 
		IDS_OPEN, IDS_TROUBLE, IDS_SHUNT, IDS_EMPTY};

	CString sYes = RES_STRING(IDS_YES_TXT);
	CString sNo = RES_STRING(IDS_NO_TXT);

	LVITEM lvi;
	CString strItem;
	lvi.mask =  LVIF_IMAGE | LVIF_TEXT;
	
	BYTE mask = 1;
	int imgNum=0;
	m_inputList.DeleteAllItems();
	for(int i=0; i<m_numInputs; i++) {
		BYTE data = m_inputStatus[i/2];
		if (i & 1)
			data >>= 4;
		
		if (data & 8)
			imgNum = 2;
		else if ((data & 7) == 1 || (data & 7) == 0)		// input secured, not define
			imgNum = 0;
		else 
			imgNum = 1;

		lvi.iItem = i;
		lvi.iImage = imgNum;
		strItem.Format(_T("%d"), i+1);
		lvi.iSubItem = 0;
		lvi.pszText = (LPTSTR)(LPCTSTR)(strItem);
		m_inputList.InsertItem(&lvi);

		// Set subitem 1
		sTmp = RES_STRING(pntIDs[data & 7]);
		m_inputList.SetItemText(i, 1, sTmp);

		// Set subitem 2
		m_inputList.SetItemText(i, 2, data & 8 ? sYes : sNo);

		int nextSubItem = 3;
		if (m_numSoaks && m_numLatches) {
			// Set subitem 3
			data = m_soakedStatus[i/8];
			m_inputList.SetItemText(i, 3, data & mask ? sYes : sNo);

			// Set subitem 4
			data = m_latchedStatus[i/8];
			m_inputList.SetItemText(i, 4, data & mask ? sYes : sNo);

			nextSubItem = 5;
		}
		else if (m_numSoaks) {
			data = m_soakedStatus[i/8];
			m_inputList.SetItemText(i, 3, data & mask ? sYes : sNo);
			nextSubItem = 4;
		}
		else if (m_numLatches) {
			data = m_latchedStatus[i/8];
			m_inputList.SetItemText(i, 3, data & mask ? sYes : sNo);
			nextSubItem = 4;
		}
		 
		mask <<= 1;
		if (mask == 0)
			mask = 1;

		if (m_hasInputExtendedStatus) {
			int stsLevel = m_inputExtendedStatus[i] & 0x07;
			if (stsLevel == 0)
				strItem = _T("--");
			else
				strItem.Format(_T("%d"), stsLevel);
			m_inputList.SetItemText(i, nextSubItem++, strItem);
			
			m_inputList.SetItemText(i, nextSubItem++, m_inputExtendedStatus[i] & 0x08 ? sYes : sNo);
			m_inputList.SetItemText(i, nextSubItem++, m_inputExtendedStatus[i] & 0x10 ? sYes : sNo);
			m_inputList.SetItemText(i, nextSubItem++, m_inputExtendedStatus[i] & 0x20 ? sYes : sNo);
		}

	}
}

void CRtuInpStsPage::Print()
{
	TCHAR fname[MAX_PATH] = _T("");
	if (!RtuLib::GetPrintFileName(fname, _T(".html")))
		return;

	CHtmlFile* pFile = new CHtmlFile(hrInst, fname);
	pFile->StartTags(IsRtu8002Type()? RTU_8002_TYPE: realRtuType, gRtuNo, IDS_RTU_STATUS, IDS_INPUT_STS);

	BOOL bSoak = FALSE;
	BOOL bLatch = FALSE;
	int iCount = 3;

	UINT pntIDs[] = {IDS_NOT_DEFINED, IDS_SECURE, IDS_NORMAL, IDS_SHORT, 
		IDS_OPEN, IDS_TROUBLE, IDS_SHUNT, IDS_EMPTY};

   	if (m_numSoaks && m_numLatches) {
		bSoak = TRUE; bLatch = TRUE; iCount = 5;
	}
	else if (m_numSoaks) {
		bSoak = TRUE; iCount = 4;
	}
	else if (m_numLatches) {
		bLatch = TRUE; iCount = 4;
	}

	CString sYes = RES_STRING(IDS_YES_TXT);
	CString sNo = RES_STRING(IDS_NO_TXT);
	CString sInpNum = RES_STRING(IDS_INPUT_NUMBER);
	CString sPntSts = RES_STRING(IDS_POINT_STS);
	CString sIsolated = RES_STRING(IDS_ISOLATED);
	CString sSoakSts = RES_STRING(IDS_SOAK_STS);
	CString sLatchSts = RES_STRING(IDS_LATCH_STS);

	pFile->SetBgColor(colors[2]);
	pFile->AddTH(iCount, 1, sInpNum, 1, sPntSts, 1, sIsolated, 1, sSoakSts, 1, sLatchSts);

	BYTE mask = 1;
	for(int i=0; i<m_numInputs; i++) {
	
		pFile->SetBgColor(colors[i & 1 ? 1 : 0]);
		
		BYTE data = m_inputStatus[i/2];
		if (i & 1)
			data >>= 4;
		sInpNum.Format(_T("%d"), i+1);
		sPntSts = RES_STRING(pntIDs[data & 7]);
		sIsolated = data & 8 ? sYes : sNo;

		if (bSoak && bLatch) {
			sSoakSts = m_soakedStatus[i/8] & mask ? sYes : sNo;
			sLatchSts = m_latchedStatus[i/8] & mask ? sYes : sNo;
		}
		else if (bSoak) {
			sSoakSts = m_soakedStatus[i/8] & mask ? sYes : sNo;
		}
		else if (bLatch) {
			sSoakSts = m_latchedStatus[i/8] & mask ? sYes : sNo;
		}

		mask <<= 1;
		if (mask == 0)
			mask = 1;

		pFile->AddTD(iCount, 1, sInpNum, 1, sPntSts, 1, sIsolated, 1, sSoakSts, 1, sLatchSts);
	}

	pFile->EndTags(); delete pFile; pFile = NULL;
	RtuLib::FileExecute(GetSafeHwnd(), fname, _T("open"));
}

#pragma endregion CRtuInpStsPage
/*------------------------------------------------------------------------------*/
/*					Extended checkbox Class										*/
/*------------------------------------------------------------------------------*/
#pragma region CChkButton

BEGIN_MESSAGE_MAP(CChkButton, CButton)
	//{{AFX_MSG_MAP(CChkButton)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMyChkButton message handlers

void CChkButton::DrawItem(LPDRAWITEMSTRUCT lpDrawItemStruct) 
{
	CDC* pDC = CDC::FromHandle(lpDrawItemStruct->hDC);
	UINT state = lpDrawItemStruct->itemState;
	int nSaveDC = pDC->SaveDC();

	DrawItem(pDC, state);
	
	pDC->RestoreDC(nSaveDC);
	ReleaseDC(pDC);
}

void CChkButton::DrawItem(CDC* pDC, UINT state)
{
	CString str;
	COLORREF color;
	CSize sz(10,10);
	CRect rect;

	for(int i=0; i<m_nMaxBox; i++) {
		rect.CopyRect(m_bTxtTop ? &rcb[i] : &rc[i]);

		pDC->FillSolidRect(&rect, RGB(255,255,255));

		if (state & ODS_DISABLED) {
			color = btnState[i] ? GetSysColor(COLOR_BTNSHADOW) : GetSysColor(COLOR_BTNFACE);
			
			m_imageList.DeleteImageList();
			if (btnState[i])	{
				m_imageList.Create(MAKEINTRESOURCE(m_nChkID), 12, 1, RGB(255, 255, 255));
				m_nImage = 1;
			}
			else {
				m_imageList.Create(MAKEINTRESOURCE(m_nUnchkID), 12, 1, RGB(255, 255, 255));
				m_nImage = 3;
			}

			int cx = (rect.left + rect.right) / 2 - 5;
			int cy = (rect.top + rect.bottom) / 2 - 5;

			CPoint pt(cx, cy);
			m_imageList.Draw(pDC, m_nImage, pt, ILD_TRANSPARENT);
		}
		else {
		}

		pDC->Draw3dRect(&rect, RGB(0,0,0), RGB(255,255,255));
		//pDC->Draw3dRect(&rect, RGB(0,0,0), RGB(0,0,0));
		
		if (m_bTxtDisp) {
			str.Format(_T("%d"), m_nNumStart + i);
			rect.CopyRect(m_bTxtTop ? &rc[i] : &rcb[i]);
			rect.InflateRect(4, 0);
			pDC->SetBkMode(TRANSPARENT);
			pDC->DrawText(str, &rect, DT_CENTER|DT_VCENTER|DT_SINGLELINE);
		}
		
	}

}

void CChkButton::PreSubclassWindow() 
{
	ModifyStyle(0, BS_OWNERDRAW);
	CButton::PreSubclassWindow();
}

void CChkButton::Init(int byteCnt, BYTE* ptrData, int numBox, BOOL fTxtTop, BOOL fTxtDisp, int numStart)
{
	m_bDefFlag = FALSE;
	m_bTxtTop = fTxtTop;
	m_bTxtDisp = fTxtDisp;
	m_nMaxBox = numBox;
	
	int cx, cy;
	CRect rect;
	GetWindowRect(&rect);
	ScreenToClient(&rect);

	cx = rect.Width() / numBox;
	cy = rect.Height() / 2;

	for(int i=0; i<numBox; i++)	{
		rc[i].top = rect.top;
		rc[i].bottom = rect.top + cy;
		rc[i].left = rect.left + i*cx;
		rc[i].right = rc[i].left + cx;

		rcb[i].top = rc[i].bottom;
		rcb[i].bottom = rect.bottom;
		rcb[i].left = rc[i].left;
		rcb[i].right = rc[i].right;

		rc[i].right -= m_nGap;
		rcb[i].right -= m_nGap;
	}

	SetBitMap(byteCnt, ptrData, numStart);
}

void CChkButton::SetBitMap(int byteCnt, BYTE* ptrData, int numStart)
{
	int n = 0;
	m_nNumStart = numStart;
	for(int i=0; i<byteCnt; i++) {
		BYTE mask = 1;
		for(int j=0; j<8; j++) {
			if ((*(ptrData+i) & mask))
				btnState[n++] = 1;
			else
				btnState[n++] = 0;

			mask <<= 1;
		}
	}

}

#pragma endregion CChkButton
/*------------------------------------------------------------------------------*/
/*					Drive Status Page Class										*/
/*------------------------------------------------------------------------------*/
#pragma region CRtuDriveStatusPage

IMPLEMENT_DYNCREATE(CRtuDriveStatusPage, CPropertyPage)

void CRtuDriveStatusPage::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CRtuDriveStatusPage)
	DDX_Control(pDX, IDC_RTU_ID3, m_lblDriveNum);
	DDX_Control(pDX, IDC_RTU_ID7, m_lblPhysSize);
	DDX_Control(pDX, IDC_RTU_ID9, m_lblPhysSizeFormatted);
	DDX_Control(pDX, IDC_RTU_ID11, m_lblPhysSizeRemain);
	DDX_Control(pDX, IDC_RTU_ID15, m_lblModelName);

	DDX_Control(pDX, IDC_RTU_ID18, m_lblCamNum);
	DDX_Control(pDX, IDC_RTU_ID20, m_lblCamOldestTime);
	DDX_Control(pDX, IDC_RTU_ID22, m_lblCamYoungestTime);

	DDX_Control(pDX, IDC_RTU_ID25, m_lblMicNum);
	DDX_Control(pDX, IDC_RTU_ID27, m_lblMicOldestTime);
	DDX_Control(pDX, IDC_RTU_ID29, m_lblMicYoungestTime);

	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CRtuDriveStatusPage, CPropertyPage)
	//{{AFX_MSG_MAP(CRtuDriveStatusPage)
	ON_NOTIFY(UDN_DELTAPOS, IDC_RTU_ID30, OnUpDownCamRecTimes)
	ON_NOTIFY(UDN_DELTAPOS, IDC_RTU_ID31, OnUpDownMicRecTimes)
	ON_NOTIFY(UDN_DELTAPOS, IDC_RTU_ID32, OnUpDownDriveStatus)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CRtuDriveStatusPage message handlers
/////////////////////////////////////////////////////////////////////////////
BOOL CRtuDriveStatusPage::OnInitDialog()
{
	CDialog::OnInitDialog();
	m_nCurDrive = 0;
	m_nCurCamRecTime = 0;
	m_nCurMicRecTime = 0;

	COLORREF txtColor = RGB(128, 0, 0);
	m_lblDriveNum.SetTextColor(txtColor);
	m_lblPhysSize.SetTextColor(txtColor);
	m_lblPhysSizeFormatted.SetTextColor(txtColor);
	m_lblPhysSizeRemain.SetTextColor(txtColor);
	m_lblModelName.SetTextColor(txtColor);
	
	m_lblCamNum.SetTextColor(txtColor);
	m_lblCamOldestTime.SetTextColor(txtColor);
	m_lblCamYoungestTime.SetTextColor(txtColor);
	m_lblMicNum.SetTextColor(txtColor);
	m_lblMicOldestTime.SetTextColor(txtColor);
	m_lblMicYoungestTime.SetTextColor(txtColor);

	m_lblDriveNum.SetBkColor(LL_YELLOW);
	m_lblPhysSize.SetBkColor(LL_YELLOW);
	m_lblPhysSizeFormatted.SetBkColor(LL_YELLOW);
	m_lblPhysSizeRemain.SetBkColor(LL_YELLOW);
	m_lblModelName.SetBkColor(LL_YELLOW);

	m_lblCamNum.SetBkColor(LL_YELLOW);
	m_lblCamOldestTime.SetBkColor(LL_YELLOW);
	m_lblCamYoungestTime.SetBkColor(LL_YELLOW);
	m_lblMicNum.SetBkColor(LL_YELLOW);
	m_lblMicOldestTime.SetBkColor(LL_YELLOW);
	m_lblMicYoungestTime.SetBkColor(LL_YELLOW);

	return TRUE;
}

BOOL CRtuDriveStatusPage::OnSetActive()
{
	ShowStatus();
	return CPropertyPage::OnSetActive();
}

void CRtuDriveStatusPage::ShowStatus()
{
	if (!m_ptrDriveStatus)
		return;

	RTU_DRIVESTATS* driveStatus = (m_ptrDriveStatus + m_nCurDrive);
	m_nCurCamRecTime = 0;
	m_nNumCamRecTimes = driveStatus->numOfCams;
	m_nCurMicRecTime = 0;
	m_nNumMicRecTimes = driveStatus->numOfMics;
   
	
	CString sTmp = RES_STRING(IDS_DRIVE_STS_RNG);
	CString str; str.Format(sTmp, m_nCurDrive + 1, m_nNumDrives);
	SetDlgItemText(IDC_RTU_ID1, str);
	GetDlgItem(IDC_RTU_ID32)->ShowWindow(m_nNumDrives > 1 ? SW_SHOW : SW_HIDE);

	str.Format(_T("%d"), driveStatus->driveNumber);
	m_lblDriveNum.SetText(str);
	
	str.Format(_T("%d"), driveStatus->physicalSize);
	m_lblPhysSize.SetText(str);
	
	str.Format(_T("%d %s"), driveStatus->totalSizeFormatted, _T("%"));
	m_lblPhysSizeFormatted.SetText(str);

	str.Format(_T("%d %s"), driveStatus->spaceRemain, _T("%"));
	m_lblPhysSizeRemain.SetText(str);

	TCHAR name[256];
	if (driveStatus->modelName != NULL) {
		wsprintf(name, _T("%hs"), driveStatus->modelName);
		m_lblModelName.SetText(name);
	}

	ShowCamRecTime();
	ShowMicRecTime();
}

void CRtuDriveStatusPage::ShowCamRecTime()
{
	if (m_nNumCamRecTimes == 0 || m_ptrDriveStatus == NULL) {
		GetDlgItem(IDC_RTU_ID30)->ShowWindow(SW_HIDE);
		return;
	}

	RECORDINGTIME* pTime = ((m_ptrDriveStatus + m_nCurDrive)->camStatus + m_nCurCamRecTime);

	CString sTmp = RES_STRING(IDS_CAM_STS_RNG);
	CString str; str.Format(sTmp, m_nCurCamRecTime+1, m_nNumCamRecTimes);
	SetDlgItemText(IDC_RTU_ID16, str);
	GetDlgItem(IDC_RTU_ID30)->ShowWindow(m_nNumCamRecTimes > 1 ? SW_SHOW : SW_HIDE);

	str.Format(_T("%d"), pTime->number);
	m_lblCamNum.SetText(str);
	
	GetTime(str, &pTime->oldestTime);
	m_lblCamOldestTime.SetText(str);

	GetTime(str, &pTime->youngestTime); 
	m_lblCamYoungestTime.SetText(str);

}

void CRtuDriveStatusPage::ShowMicRecTime()
{
	if (m_nNumMicRecTimes == 0 || m_ptrDriveStatus == NULL) {
		GetDlgItem(IDC_RTU_ID31)->ShowWindow(SW_HIDE);
		return;
	}

	RECORDINGTIME* pTime = ((m_ptrDriveStatus + m_nCurDrive)->micStatus + m_nCurMicRecTime);

	CString sTmp = RES_STRING(IDS_MIC_PHONE_STS_RNG);
	CString str; str.Format(sTmp, m_nCurMicRecTime+1, m_nNumMicRecTimes);
	SetDlgItemText(IDC_RTU_ID23, str);
	GetDlgItem(IDC_RTU_ID31)->ShowWindow(m_nNumMicRecTimes > 1 ? SW_SHOW : SW_HIDE);

	str.Format(_T("%d"), pTime->number);
	m_lblMicNum.SetText(str);

	GetTime(str, &pTime->oldestTime);
	m_lblMicOldestTime.SetText(str);

	GetTime(str, &pTime->youngestTime); 
	m_lblMicYoungestTime.SetText(str);
}

void CRtuDriveStatusPage::GetTime(CString& str, TIME* pTime)
{
	CStringArray strMonths; GetMonthStr(strMonths);
	TCHAR sMonth[50];
	int nMonth = pTime->month & 0x0f;
	if (nMonth > 12)
		wsprintf(sMonth, _T(""));
	else
		wsprintf(sMonth, _T("%s"), (LPCTSTR)strMonths.GetAt(nMonth));

	str.Format(_T("%.2d %s %.4d, %.2d:%.2d:%.2d"),
		pTime->day & 0x1f, sMonth, 2000 + (pTime->year & 0x7f), 
		pTime->hour & 0x1f, pTime->min & 0x3f, pTime->sec & 0x3f);
}

LPBYTE CRtuDriveStatusPage::SetStatus(LPBYTE lpData, int, BOOL)
{
	BYTE* p = lpData;
	m_nNumDrives = *p++;
	if (m_ptrDriveStatus != NULL)
	{
		delete [] m_ptrDriveStatus;
		m_ptrDriveStatus = NULL;
	}

	try
	{
	if (m_nNumDrives > 0)
	{
		m_ptrDriveStatus = new RTU_DRIVESTATS[m_nNumDrives];
		RTU_DRIVESTATS* driveStatus;
		BYTE* p2 = p;
		for(int i=0; i<m_nNumDrives; i++) {
			driveStatus = (m_ptrDriveStatus + i);
			memset(driveStatus, 0, sizeof(RTU_DRIVESTATS));

			int dataSize = *(p + 1);
			driveStatus->driveNumber = *p++;
			driveStatus->dataSize = *p++;
			driveStatus->flags = *p++;

			memcpy(&driveStatus->physicalSize, p, 4);
			RtuLib::SwapByteOrder(driveStatus->physicalSize);
			p += 4;
			driveStatus->totalSizeFormatted = *p++;
			driveStatus->spaceRemain = *p++;
		
			int driveModelNameSize = *p++;
			memcpy(&driveStatus->modelName, p, driveModelNameSize);
			p += driveModelNameSize;

			driveStatus->numOfCams = *p++;
			if (driveStatus->numOfCams > 8)
				driveStatus->numOfCams = 8;

			for(int j=0; j<driveStatus->numOfCams; j++) {
				driveStatus->camStatus[j].number = *p++;
				memcpy(&driveStatus->camStatus[j].oldestTime, p, 7);
				p += 7;
				memcpy(&driveStatus->camStatus[j].youngestTime, p, 7);
				p += 7;
			}

			driveStatus->numOfMics = *p++;
			if (driveStatus->numOfMics > 2)
				driveStatus->numOfMics = 2;

			for(int k=0; k<driveStatus->numOfMics; k++) {
				driveStatus->micStatus[k].number = *p++;
				memcpy(&driveStatus->micStatus[k].oldestTime, p, 7);
				p += 7;
				memcpy(&driveStatus->micStatus[k].youngestTime, p, 7);
				p += 7;
			}
		
			p2 += dataSize;
			p = p2;
		}
	}
	}
	catch (...)
	{
		OutputDebugString(L"Exception in CRtuDriveStatusPage::SetStatus()\n");
	}
	return p+1;
}


void CRtuDriveStatusPage::OnUpDownCamRecTimes(NMHDR* pNMHDR, LRESULT* pResult)
{
	NM_UPDOWN* pNMUpDown = (NM_UPDOWN*)pNMHDR;
	// TODO: Add your control notification handler code here
	if (pNMUpDown->iDelta == 1) {
		--m_nCurCamRecTime;
		if (m_nCurCamRecTime < 0)
			m_nCurCamRecTime = m_nNumCamRecTimes - 1;
	}
	else  {
		++m_nCurCamRecTime;
		if (m_nCurCamRecTime >= m_nNumCamRecTimes)
			m_nCurCamRecTime = 0;
	}

	ShowCamRecTime();
	*pResult = 0;

}

void CRtuDriveStatusPage::OnUpDownMicRecTimes(NMHDR* pNMHDR, LRESULT* pResult)
{
	NM_UPDOWN* pNMUpDown = (NM_UPDOWN*)pNMHDR;
	// TODO: Add your control notification handler code here
	if (pNMUpDown->iDelta == 1) {
		--m_nCurMicRecTime;
		if (m_nCurMicRecTime < 0)
			m_nCurMicRecTime = m_nNumMicRecTimes - 1;
	}
	else  {
		++m_nCurMicRecTime;
		if (m_nCurMicRecTime >= m_nNumMicRecTimes)
			m_nCurMicRecTime = 0;
	}
	
	ShowMicRecTime();
	*pResult = 0;

}


void CRtuDriveStatusPage::OnUpDownDriveStatus(NMHDR* pNMHDR, LRESULT* pResult)
{
	NM_UPDOWN* pNMUpDown = (NM_UPDOWN*)pNMHDR;
	// TODO: Add your control notification handler code here
	
	if (pNMUpDown->iDelta == 1) {
		--m_nCurDrive;
		if (m_nCurDrive < 0)
			m_nCurDrive = m_nNumDrives - 1;
	}
	else  {
		++m_nCurDrive;
		if (m_nCurDrive >= m_nNumDrives)
			m_nCurDrive = 0;
	}

	ShowStatus();
	*pResult = 0;

}

void CRtuDriveStatusPage::Print()
{
	TCHAR fname[MAX_PATH] = _T("");
	if (!RtuLib::GetPrintFileName(fname, _T(".html")))
		return;

	CHtmlFile* pFile = new CHtmlFile(hrInst, fname);
	pFile->StartTags(IsRtu8002Type()? RTU_8002_TYPE: realRtuType, gRtuNo, IDS_RTU_STATUS, IDS_DRIVE_STS);

	//TCHAR sTmp[MAX_BUFF], sTmp2[MAX_BUFF];

	CString sDriveNum = RES_STRING(IDS_DRIVE_NUM);
	CString sPhysSize = RES_STRING(IDS_PHYS_SIZE_MB);
	CString sPhysSizeFmt = RES_STRING(IDS_PHYS_SIZE_FMT);
	CString sSpaceRemain = RES_STRING(IDS_SPACE_REMAIN);
	CString sDriveModel = RES_STRING(IDS_DRIVE_MODEL);
	CString sCamNum = RES_STRING(IDS_CAMERA_NUM);
	CString sStartRecTime = RES_STRING(IDS_START_REC_TIME);
	CString sEndRecTime = RES_STRING(IDS_END_REC_TIME);
	CString sMicNum = RES_STRING(IDS_MIC_NUM);

	CString sTmp, sTmp2;
	for(int curDrive=0; curDrive<m_nNumDrives; curDrive++) {
		pFile->SetBgColor(colors[curDrive & 1 ? 1 : 0]);

		RTU_DRIVESTATS* driveStatus = (m_ptrDriveStatus + curDrive);
		m_nCurCamRecTime = 0;
		m_nNumCamRecTimes = driveStatus->numOfCams;
		m_nCurMicRecTime = 0;
		m_nNumMicRecTimes = driveStatus->numOfMics;

		int rowCnt = 4 + m_nNumCamRecTimes*2 + m_nNumMicRecTimes*2;
		sTmp.Format(_T("%s %d"), (LPCTSTR)sDriveNum, driveStatus->driveNumber);
		sTmp2.Format(_T("%d"), driveStatus->physicalSize);
		pFile->AddRow(2, 1, ROW_SPAN|rowCnt, sTmp, COL_SPAN|2, sPhysSize, 1, sTmp2);

		sTmp.Format(_T("%d %s"), driveStatus->totalSizeFormatted, _T("%"));
		pFile->AddRow(1, 1, COL_SPAN|2, sPhysSizeFmt, 1, sTmp);

		sTmp.Format(_T("%d %s"), driveStatus->spaceRemain, _T("%"));
		pFile->AddRow(1, 1, COL_SPAN|2, sSpaceRemain, 1, sTmp);

		sTmp.Format(_T("%hs"), driveStatus->modelName);
		pFile->AddRow(1, 1, COL_SPAN|2, sDriveModel, 1, sTmp);

		CString str;
		// Cam Config
		for(m_nCurCamRecTime = 0; m_nCurCamRecTime < m_nNumCamRecTimes; m_nCurCamRecTime++) {
			pFile->SetBgColor(colors[m_nCurCamRecTime & 1 ? 2 : 3]);
			RECORDINGTIME* pTime = ((m_ptrDriveStatus + curDrive)->camStatus + m_nCurCamRecTime);

			sTmp.Format(_T("%s %d"), (LPCTSTR)sCamNum, pTime->number);
			
			GetTime(str, &pTime->oldestTime);
			pFile->AddRow(2, 1, ROW_SPAN|2, sTmp, 1, sStartRecTime, 1, str);
			
			GetTime(str, &pTime->youngestTime);
			pFile->AddRow(sEndRecTime, str);
		}
		// Micro Config
		for(m_nCurMicRecTime = 0; m_nCurMicRecTime < m_nNumMicRecTimes; m_nCurMicRecTime++) {
			pFile->SetBgColor(colors[m_nCurMicRecTime & 1 ? 0 : 1]);
			RECORDINGTIME* pTime = ((m_ptrDriveStatus + curDrive)->micStatus + m_nCurMicRecTime);
			
			sTmp.Format(_T("%s %d"), (LPCTSTR)sMicNum, pTime->number);
			
			GetTime(str, &pTime->oldestTime);
			pFile->AddRow(2, 1, ROW_SPAN|2, sTmp, 1, sStartRecTime, 1, str);
			
			GetTime(str, &pTime->youngestTime); 
			pFile->AddRow(sEndRecTime, str);
		}
	}

	pFile->EndTags(); delete pFile; pFile = NULL;
	RtuLib::FileExecute(GetSafeHwnd(), fname, _T("open"));
}

#pragma endregion CRtuDriveStatusPage

/*------------------------------------------------------------------------------*/
/*					Power Monitor Page Class										*/
/*------------------------------------------------------------------------------*/
#pragma region CRtuPowerMonitorStatusPage

static int PowerMonitorGenIDs[] = {
	IDC_RTU_ID18,
	IDC_RTU_ID19,
	IDC_RTU_ID20,
	IDC_RTU_ID21,
	IDC_RTU_ID22,
	IDC_RTU_ID23,
	IDC_RTU_ID24,
	IDC_RTU_ID25,
	IDC_RTU_ID26,
	IDC_RTU_ID27,
	IDC_RTU_ID28,
	IDC_RTU_ID29,
	IDC_RTU_ID30,
	IDC_RTU_ID31,
};
CRtuPowerMonitorStatusPage::CRtuPowerMonitorStatusPage() : CRtuStatusBase(CRtuPowerMonitorStatusPage::IDD)
{
	m_pStatus = NULL;
	m_nNumDevices = 0;
	m_nCurDevice = m_Flag1 = m_Flag2 = 0;
};
CRtuPowerMonitorStatusPage::~CRtuPowerMonitorStatusPage()
{
	if (m_pStatus != NULL) {
		delete[] m_pStatus; m_pStatus = NULL;
	}
};

IMPLEMENT_DYNCREATE(CRtuPowerMonitorStatusPage, CPropertyPage)

void CRtuPowerMonitorStatusPage::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	for(int i=1; i<8; i++) {
		RtuLib::DDX_Check(pDX, IDC_RTU_ID2+i, m_Flag1, (BYTE)i);
	}
	for(int i=0; i<2; i++) {
		RtuLib::DDX_Check(pDX, IDC_RTU_ID10+i, m_Flag2, (BYTE)i);
	}
}

BEGIN_MESSAGE_MAP(CRtuPowerMonitorStatusPage, CPropertyPage)
	//{{AFX_MSG_MAP(CRtuPowerMonitorStatusPage)
	ON_NOTIFY(UDN_DELTAPOS, IDC_RTU_ID32, OnUpDownDeviceStatus)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CRtuPowerMonitorStatusPage message handlers
/////////////////////////////////////////////////////////////////////////////
BOOL CRtuPowerMonitorStatusPage::OnInitDialog()
{
	CDialog::OnInitDialog();

	if (m_nNumDevices <= 1)
		GetDlgItem(IDC_RTU_ID32)->EnableWindow(FALSE);

	CFont* font = new CFont;
	font->CreateFont(
	   15,                        // nHeight
	   0,                         // nWidth
	   0,                         // nEscapement
	   0,                         // nOrientation
	   FW_REGULAR,                   // nWeight
	   FALSE,                     // bItalic
	   FALSE,                     // bUnderline
	   0,                         // cStrikeOut
	   ANSI_CHARSET,              // nCharSet
	   OUT_DEFAULT_PRECIS,        // nOutPrecision
	   CLIP_DEFAULT_PRECIS,       // nClipPrecision
	   DEFAULT_QUALITY,           // nQuality
	   DEFAULT_PITCH | FF_SWISS,  // nPitchAndFamily
	   _T("Courier New"));

	for(int i=0; i<_COUNTOF(m_genCtrls); i++) {
		m_genCtrls[i].SubclassDlgItem(PowerMonitorGenIDs[i], this);
		m_genCtrls[i].SetFont(font);
	}

	return TRUE;
}

BOOL CRtuPowerMonitorStatusPage::OnSetActive()
{
	ShowStatus();
	return CPropertyPage::OnSetActive();
}

CString CRtuPowerMonitorStatusPage::GetStatusString(int index, int value)
{
	int types[] = {
		E_TYPE_BATTERY,
		E_TYPE_POWER,
		E_TYPE_TEMPERATURE,
		E_TYPE_BATTERY,
		E_TYPE_BATTERY,
		E_TYPE_BATTERY,
		E_TYPE_BATTERY,
		E_TYPE_POWER,
		E_TYPE_POWER,
		E_TYPE_TEMPERATURE,
		E_TYPE_TEMPERATURE,
	};

	
	CString strResult = _T("");
	float v1 = (float)(value);
	if (index < sizeof(types)/sizeof(types[0])) {
		int type = types[index];
		switch(type) {
		case E_TYPE_BATTERY:
			strResult.Format(_T("%4d  (%6.2f V )"), value, (float)(v1 * 16.0) / 0x3ff);
			break;
		case E_TYPE_POWER:
			strResult.Format(_T("%4d  (%6.2f V )"), value, (float)(v1 * 24.5) / 0x3ff);
			break;
		case E_TYPE_TEMPERATURE:
			strResult.Format(_T("%4d  (%6.2f�C )"), value, (float)(v1 * 100.0) / 0x3ff);
			break;
		default:
			break;
		}
	}

	return strResult;
}

void CRtuPowerMonitorStatusPage::ShowStatus()
{
	if (IsWindow(m_hWnd) == FALSE) return;
	if (m_nCurDevice >= m_nNumDevices)
		return;
	if (m_pStatus == NULL)
		return;

	GetDlgItem(IDC_RTU_ID32)->EnableWindow((m_nNumDevices <= 1) ? FALSE : TRUE);

	CString strText;
	strText.Format(_T("%s %d of %d"), (LPCTSTR)CString(LPTSTR(IDS_DEVICE)), m_nCurDevice+1, m_nNumDevices);
	SetDlgItemText(IDC_RTU_ID1, strText);

	m_Flag1 = m_pStatus[m_nCurDevice].flag1;
	m_Flag2 = m_pStatus[m_nCurDevice].flag2;
	
	LPBYTE p = &m_pStatus[m_nCurDevice].adcBattLo;
	for(int i=0; i<E_NUM_STATUS_READINGS; i++) {
		int n = *p++;
		n |= ((*p++) << 8);
		SetDlgItemText(IDC_RTU_ID18+i, GetStatusString(i, n&0x3ff));
	}

	UpdateData(FALSE);

	if (m_pStatus[m_nCurDevice].size > 24) {
		strText.Format(_T("%02d.%02d"), m_pStatus[m_nCurDevice].firmwareVersionMajor, m_pStatus[m_nCurDevice].firmwareVersionMinor);
		SetDlgItemText(IDC_RTU_ID29, strText);
		strText.Format(_T("%02d.%02d"), m_pStatus[m_nCurDevice].bootloadVersionMajor, m_pStatus[m_nCurDevice].bootloadVersionMinor);
		SetDlgItemText(IDC_RTU_ID30, strText);
	}
	else {
		SetDlgItemText(IDC_RTU_ID29, _T("--"));
		SetDlgItemText(IDC_RTU_ID30, _T("--"));
	}

	strText = _T("--");
	if (m_pStatus[m_nCurDevice].size > 28) {
		strText.Format(_T("%d"), m_pStatus[m_nCurDevice].controllerPortNumber);
	}
	SetDlgItemText(IDC_RTU_ID31, strText);

	CheckDlgButton(IDC_RTU_ID2, m_Flag1 & 1 ? FALSE : TRUE);
}

LPBYTE CRtuPowerMonitorStatusPage::SetStatus(LPBYTE p1, int, BOOL)
{
	m_nNumDevices = *p1++;
	if (m_pStatus != NULL) 
	{
		delete[] m_pStatus; m_pStatus = NULL;
	}
	try
	{
		if (m_nNumDevices > 0) {

		
			m_pStatus = new POWER_MONITOR_STATUS[m_nNumDevices];
			if (m_pStatus != NULL) {
				int size = sizeof(POWER_MONITOR_STATUS);

				memset(m_pStatus, 0, size * m_nNumDevices);
				for(int x=0; x<m_nNumDevices; x++) {
					LPPOWER_MONITOR_STATUS pPM = &m_pStatus[x];
					int cnt = *(p1 + 1);
					int bc = cnt + 2;	// Logical number + size + data
					memcpy(pPM, p1, min(size, bc));
					p1 += bc;
				}
			}
			else {
				DispMessageBox(GetSafeHwnd(), IDS_NOT_ENOUGH_MEM, IDS_ERROR, MB_OK|MB_ICONSTOP);
			}
		}
	}
	catch (...)
	{
		m_nNumDevices  = 0;
		OutputDebugString(L"Exception in CRtuPowerMonitorStatusPage::SetStatus()\n");
	}	

	return p1;
}

void CRtuPowerMonitorStatusPage::OnUpDownDeviceStatus(NMHDR* pNMHDR, LRESULT* pResult)
{
	NM_UPDOWN* pNMUpDown = (NM_UPDOWN*)pNMHDR;
	// TODO: Add your control notification handler code here
	
	if (pNMUpDown->iDelta == 1) {	// previous
		if (m_nCurDevice > 0) {
			m_nCurDevice--;
		}
		else {
			m_nCurDevice = m_nNumDevices - 1;
		}
	}
	else  {
		if (++m_nCurDevice >= m_nNumDevices)
			m_nCurDevice = 0;
	}

	ShowStatus();
	*pResult = 0;

}

void CRtuPowerMonitorStatusPage::Print()
{
}

#pragma endregion CRtuPowerMonitorStatusPage

/*------------------------------------------------------------------------------*/
/*					Vault control Page Class										*/
/*------------------------------------------------------------------------------*/
#pragma region CRtuVaultControllerStatusPage

CRtuVaultControllerStatusPage::CRtuVaultControllerStatusPage() : CRtuStatusBase(CRtuVaultControllerStatusPage::IDD)
{
	m_pStatus = NULL;
	m_nNumDevices = 0;
	m_nCurDevice = 0; m_Flag1 = 0;
};
CRtuVaultControllerStatusPage::~CRtuVaultControllerStatusPage()
{
	if (m_pStatus != NULL) {
		delete[] m_pStatus;
	}
};

IMPLEMENT_DYNCREATE(CRtuVaultControllerStatusPage, CPropertyPage)

void CRtuVaultControllerStatusPage::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CRtuVaultControllerStatusPage)
	//}}AFX_DATA_MAP
	for(int i=1; i<8; i++) {
		RtuLib::DDX_Check(pDX, IDC_RTU_ID2+i, m_Flag1, (BYTE)i);
	}
}


BEGIN_MESSAGE_MAP(CRtuVaultControllerStatusPage, CPropertyPage)
	//{{AFX_MSG_MAP(CRtuVaultControllerStatusPage)
	ON_NOTIFY(UDN_DELTAPOS, IDC_RTU_ID32, OnUpDownDeviceStatus)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CRtuVaultControllerStatusPage message handlers
/////////////////////////////////////////////////////////////////////////////
BOOL CRtuVaultControllerStatusPage::OnInitDialog()
{
	CDialog::OnInitDialog();
	GetDlgItem(IDC_RTU_ID32)->ShowWindow(SW_SHOW);

	m_strArrVaultStatus.RemoveAll();
	m_strArrVaultStatus.Add(CString(LPTSTR(IDS_IDLE)));
	m_strArrVaultStatus.Add(CString(LPTSTR(IDS_TIMING_DOWN)));
	m_strArrVaultStatus.Add(CString(LPTSTR(IDS_INTERLOCKED)));
	m_strArrVaultStatus.Add(CString(LPTSTR(IDS_UNLOCKED)));
	m_strArrVaultStatus.Add(CString(LPTSTR(IDS_OPEN)));
	m_strArrVaultStatus.Add(CString(LPTSTR(IDS_HASTENING)));
	m_strArrVaultStatus.Add(CString(LPTSTR(IDS_ALARM)));
	for(int i=0; i<8; i++) {
		m_strArrVaultStatus.Add(_T(""));
	}
	m_strArrVaultStatus.Add(CString(LPTSTR(IDS_UNKNOWN_STATE)));

	return TRUE;
}

BOOL CRtuVaultControllerStatusPage::OnSetActive()
{
	ShowStatus();
	return CPropertyPage::OnSetActive();
}

void CRtuVaultControllerStatusPage::ShowStatus()
{
	if (IsWindow(m_hWnd) == FALSE) return;
	if (m_nCurDevice >= m_nNumDevices || m_pStatus == NULL)
		return;

	GetDlgItem(IDC_RTU_ID32)->EnableWindow((m_nNumDevices <= 1) ? FALSE : TRUE);

	CString strText;
	strText.Format(_T("%s %d of %d"), (LPCTSTR)CString(LPTSTR(IDS_DEVICE)), m_nCurDevice+1, m_nNumDevices);
	SetDlgItemText(IDC_RTU_ID1, strText);

	m_Flag1 = m_pStatus[m_nCurDevice].byte1;
	UpdateData(FALSE);

	int vaultState = m_pStatus[m_nCurDevice].byte2 >> 4;
	strText = _T("");
	if (vaultState < m_strArrVaultStatus.GetSize())
		strText = m_strArrVaultStatus.GetAt(vaultState);

	SetDlgItemText(IDC_RTU_ID12, strText);
	if (m_pStatus[m_nCurDevice].size > 2) {
		strText.Format(_T("%02d.%02d"), m_pStatus[m_nCurDevice].firmwareVersionMajor, m_pStatus[m_nCurDevice].firmwareVersionMinor);
		SetDlgItemText(IDC_RTU_ID13, strText);
		strText.Format(_T("%02d.%02d"), m_pStatus[m_nCurDevice].bootloadVersionMajor, m_pStatus[m_nCurDevice].bootloadVersionMinor);
		SetDlgItemText(IDC_RTU_ID14, strText);
	}
	else {
		SetDlgItemText(IDC_RTU_ID13, _T("--"));
		SetDlgItemText(IDC_RTU_ID14, _T("--"));
	}

	strText = _T("--");
	if (m_pStatus[m_nCurDevice].size >= 8) {
		strText.Format(_T("%d"), m_pStatus[m_nCurDevice].controllerPortNumber);
	}
	SetDlgItemText(IDC_RTU_ID15, strText);

	CheckDlgButton(IDC_RTU_ID2, m_Flag1 & 1 ? FALSE : TRUE);
}

LPBYTE CRtuVaultControllerStatusPage::SetStatus(LPBYTE p1, int, BOOL)
{
	m_nNumDevices = *p1++;
	if (m_pStatus != NULL) 
	{
		delete[] m_pStatus; m_pStatus = NULL;
	}
	try
	{
		if (m_nNumDevices > 0) {
			m_pStatus = new VAULT_CONTROLLER[m_nNumDevices];
			memset(m_pStatus, 0, sizeof(VAULT_CONTROLLER) * m_nNumDevices);
			for(int x=0; x<m_nNumDevices; x++) {
				LPVAULT_CONTROLLER pVC = &m_pStatus[x];
				int cnt = *(p1 + 1);
				int bc = cnt + 2;	// Logical number + size + data
				memcpy(pVC, p1, bc);
				p1 += bc;
			}
		}
	}
	catch (...)
	{
		m_nNumDevices  = 0;
		OutputDebugString(L"Exception in CRtuVaultControllerStatusPage::SetStatus()\n");
	}			
	return p1;
}

void CRtuVaultControllerStatusPage::OnUpDownDeviceStatus(NMHDR* pNMHDR, LRESULT* pResult)
{
	NM_UPDOWN* pNMUpDown = (NM_UPDOWN*)pNMHDR;
	// TODO: Add your control notification handler code here
	
	if (pNMUpDown->iDelta == 1) {	// previous
		if (m_nCurDevice > 0) {
			m_nCurDevice--;
		}
		else {
			m_nCurDevice = m_nNumDevices - 1;
		}
	}
	else  {
		if (++m_nCurDevice >= m_nNumDevices)
			m_nCurDevice = 0;
	}

	ShowStatus();
	*pResult = 0;
}

void CRtuVaultControllerStatusPage::Print()
{
}

#pragma endregion CRtuVaultControllerStatusPage


HTREEITEM s_hItemPanel=0;

#pragma region CCategoriesTreeNavigator
CCategoriesTreeNavigator::CCategoriesTreeNavigator()
		: CXTPPropertyPageTreeNavigator(TVS_SHOWSELALWAYS | TVS_HASBUTTONS | TVS_HASLINES | TVS_LINESATROOT)
{		
}
	
BOOL CCategoriesTreeNavigator::CreateTree()
{
	m_imgList.Create(IDB_IMAGES, 12, 0, RGB(0, 0x80, 0x80));
	//hItemDeviceInfo = InsertItem(RES_STRING(IDS_DEVICE_INFO)); //TT 7804
	int nCount = m_pSheet->GetPageCount();
	for (int i = 0; i < nCount; i++) {
		CXTPPropertyPage* pPage = m_pSheet->GetPage(i);	
		CString strCaption = pPage->GetCaption();	
		HTREEITEM hItem = InsertItem(strCaption, -1, -1);//TT 7804
		SetItemData(hItem, (DWORD_PTR)pPage);
		pPage->m_dwData = (DWORD_PTR)hItem;	

		if (i == 1) {
			s_hItemPanel = hItem;
		}
	}
	
	return TRUE;
}

BOOL CCategoriesTreeNavigator::RecreateTree(StatusItems* pTree)
{
	this->DeleteAllItems();
	int nImage = -1;
	int nSelectedImage = -1;
	for(int i=0; i<pTree->Count; i++) {
		CXTPPropertyPage* pPage = pTree->Pages[i];
		CString strCaption = pPage->GetCaption();
		HTREEITEM hItem = InsertItem(strCaption, nImage, nSelectedImage);
		SetItemData(hItem, (DWORD_PTR)pPage);
		pPage->m_dwData = (DWORD_PTR)hItem;	
		if (i == 1) {
			s_hItemPanel = hItem;
		}
	}
	
	return TRUE;
}

void CCategoriesTreeNavigator::OnPageSelected(CXTPPropertyPage*)
{
}

#pragma endregion CCategoriesTreeNavigator

#pragma region CRtuStatusInfo
class CRtuStatusInfo
{
public:
	typedef enum {
		ST_MODE, ST_PANEL, ST_INPUTS, ST_OUTPUTS, ST_CAMERAS, ST_DEVICE_INFO, 
		ST_LATCH, ST_SOAK, ST_READERS, ST_CCTVS, ST_ELEVATORS, ST_DRIVES, ST_EXT_READERS, 
		ST_POWER_MONITOR, ST_VAULT_CONTROLLER, ST_DEVICE_FIRMWARE, ST_EXT_INPUTS 
	} STATUS_TYPE;

	CRtuStatusInfo(const LPBYTE pStatus) {
		m_pModeStatus = NULL;
		m_pPanelStatus = NULL;
		m_pInputStatus = NULL;
		m_pOutputStatus = NULL;
		m_pCameraStatus = NULL;
		m_pDeviceStatus = NULL;
		m_pLatchStatus = NULL;
		m_pSoakStatus = NULL;
		m_pReaderStatus = NULL;
		m_pCctvStatus = NULL;
		m_pElevatorStatus = NULL;
		m_pDriveStatus = NULL;
		m_pExtendedReaderStatus = NULL;
		m_pPowerMonitorStatus = NULL;
		m_pVaultControllerStatus = NULL;
		m_pDeviceFirmwareStatus = NULL;
		m_pExtendedInputStatus = NULL;

		memset(&m_headers, 0, sizeof(m_headers));
		m_pStatus = pStatus;
		LPBYTE p = pStatus;
		m_rtuType = *p++;
		m_panelType = *p++;
		m_commType = *p++;
		BYTE b = *p++;
		m_bitMask = b;
		m_headerCount = (BYTE)(b >> 4);
		for(int i=0; i<m_headerCount; i++) {
			m_headers[i] = *p++;
		}

		if (m_bitMask & 0x04) {	// Mode status included
			p = SetModeStatus(p);
		}

		if (m_bitMask & 0x08) {	// Panel status included
			p = SetPanelStatus(p);
		}

		if (m_bitMask & 0x01) {	// Input status included
			p = SetInputStatus(p);
		}

		if (m_bitMask & 0x02) {	// Output status included
			p = SetOutputStatus(p);
		}

		m_bitMask2 = m_headers[0];
		m_bitMask3 = m_headers[1];
		if (m_headerCount > 0) {
			if (m_bitMask2 & 0x01) {	// Camera status included
				p = SetCameraStatus(p);
			}
		}

		p = SetDeviceInfo(p);

		if (m_headerCount > 0) {
			if (m_bitMask2 & 0x08) {	// Input Latch Status included
				p = SetLatchStatus(p);
			}

			if (m_bitMask2 & 0x40) {	// Input Soak Status included
				p = SetSoakStatus(p);
			}

			if (m_bitMask2 & 0x80) {	// Reader Status included
				p = SetReaderStatus(p);
			}

			if (m_bitMask2 & 0x20) {	// CCTV Status included
				p = SetCctvStatus(p);
			}
		}

		if (m_headerCount > 1) {
			if (m_bitMask3 & 0x01) {	// Elevator Floor Status included
				p = SetElevatorStatus(p);	
			}

			if (m_bitMask3 & 0x02) {	// Drive Status included
				p = SetDriveStatus(p);
			}

			if (m_bitMask3 & 0x04) {	// Extended Reader Status included
				p = SetExtendedReaderStatus(p);
			}

			if (m_bitMask3 & 0x08) {	// Power Monitor Status included
				p = SetPowerMonitorStatus(p);
			}

			if (m_bitMask3 & 0x10) {	// Vault Controller Status included
				p = SetVaultControllerStatus(p);
			}

			if (m_bitMask3 & 0x20) {	// Device Firmware Status included
				p = SetDeviceFirmwareStatus(p);
			}

			if (m_bitMask3 & 0x40) {	// Extended Input Status included
				p = SetExtendedInputStatus(p);
			}
		}
	}
	
	LPBYTE GetStatusPtr(STATUS_TYPE type) {
		LPBYTE p = NULL;
		switch(type) {
		case ST_MODE:				p = m_pModeStatus;				break;
		case ST_PANEL:				p = m_pPanelStatus;				break;
		case ST_INPUTS:				p = m_pInputStatus;				break;
		case ST_OUTPUTS:			p = m_pOutputStatus;			break;
		case ST_CAMERAS:			p = m_pCameraStatus;			break;
		case ST_DEVICE_INFO:		p = m_pDeviceStatus;			break;
		case ST_LATCH:				p = m_pLatchStatus;				break;
		case ST_SOAK:				p = m_pSoakStatus;				break;
		case ST_READERS:			p = m_pReaderStatus;			break;
		case ST_CCTVS:				p = m_pCctvStatus;				break;
		case ST_ELEVATORS:			p = m_pElevatorStatus;			break;
		case ST_DRIVES:				p = m_pDriveStatus;				break;
		case ST_EXT_READERS:		p = m_pExtendedReaderStatus;	break;
		case ST_POWER_MONITOR:		p = m_pPowerMonitorStatus;		break;
		case ST_VAULT_CONTROLLER:	p = m_pVaultControllerStatus;	break;
		case ST_DEVICE_FIRMWARE:	p = m_pDeviceFirmwareStatus;	break;
		case ST_EXT_INPUTS:			p = m_pExtendedInputStatus;		break;
		default:													break;
		}

		return p;
	}

private:
	LPBYTE SetModeStatus(LPBYTE p) {
		m_pModeStatus = p;
		int cnt = *p;
		p += (cnt + 1);

		return p;
	}
	LPBYTE SetPanelStatus(LPBYTE p) {
		m_pPanelStatus = p;
		int cnt = *p;
		p += (cnt + 1);

		return p;
	}
	LPBYTE SetInputStatus(LPBYTE p) {
		m_pInputStatus = p;
		int cnt = *p;
		if (cnt == 0)
			cnt = 256;
		int bcnt = (cnt / 2) + (cnt % 2 ? 1 : 0);
		p += (bcnt + 1);

		return p;
	}
	LPBYTE SetOutputStatus(LPBYTE p) {
		m_pOutputStatus = p;
		int cnt = *p;
		int bcnt = (cnt / 4) + (cnt % 4 ? 1 : 0);
		p += (bcnt + 1);

		return p;
	}
	LPBYTE SetCameraStatus(LPBYTE p) {
		m_pCameraStatus = p;
		int cnt = *p;
		int bcnt = cnt * sizeof(RTU_CAMSTATS);
		p += (bcnt + 1);

		return p;
	}
	LPBYTE SetDeviceInfo(LPBYTE pDeviceInfo) {
		m_pDeviceStatus = pDeviceInfo;

		const int _MAX_DEVICE_COUNT = 4;
		LPBYTE p = pDeviceInfo;
		BYTE b = *p++;
		BYTE deviceMask = b;
		BYTE devCount = (BYTE)(b >> 6);
		BYTE devices[6 + _MAX_DEVICE_COUNT*8];
		memset(devices, 0, sizeof(devices));

		LPBYTE pHeaders = p;
		p += devCount;
		int numDevices = 0;
		for(int i=0; i<6; i++) {
			devices[i] = (BYTE)((deviceMask & 1) ? *p++ : 0);
			deviceMask >>= 1;
			numDevices++;
		}
		int index = 6;
		for(int i=0; i<devCount; i++) {
			b = *pHeaders++;
			for(int j=0; j<8; j++) {
				devices[index++] = (BYTE)((b & 1) ? *p++ : 0);
				b >>= 1;
				numDevices++;
			}
		}

		int totalBytes = 0;
		for(int i=0; i<numDevices; i++) {
			int cnt = devices[i];
			cnt = (cnt/8) + ((cnt%8) ? 1 : 0);
			totalBytes += cnt;
		}

		totalBytes *= 3;
		// If keypad is included, then add keyswitch status bytes
		if (m_bitMask2 & 0x10) {
			int cnt = devices[0];
			cnt = (cnt/8) + ((cnt%8) ? 1 : 0);
			totalBytes += cnt;
		}

		p += totalBytes;

		return p;
	}

	LPBYTE SetLatchStatus(LPBYTE p) {
		m_pLatchStatus = p;
		int cnt = *p;
		if (cnt == 0)
			cnt = 256;
		int bcnt = ((cnt - 1) / 8) + 1;
		p += (bcnt + 1);

		return p;
	}
	LPBYTE SetSoakStatus(LPBYTE p) {
		m_pSoakStatus = p;
		int cnt = *p;
		if (cnt == 0)
			cnt = 256;
		int bcnt = ((cnt - 1) / 8) + 1;
		p += (bcnt + 1);

		return p;
	}
	LPBYTE SetReaderStatus(LPBYTE p) {
		m_pReaderStatus = p;
		int cnt = *p;
		p += (cnt + 1);

		return p;
	}
	LPBYTE SetCctvStatus(LPBYTE p) {
		m_pCctvStatus = p;
		int cnt = *p; int bcnt = 0;
		if (cnt > 0)
			bcnt = ((cnt - 1) / 2) + 1;
		p += (bcnt + 1);

		return p;
	}
	LPBYTE SetElevatorStatus(LPBYTE p) {
		m_pElevatorStatus = p;
		int cnt = *p; int bcnt = 0;
		LPBYTE p2 = p + 1;
		for(int i=0; i<cnt; i++) {
			BYTE b = *p2;
			bcnt += b + 1;
			p2 += b + 1;
		}
		p += (bcnt + 1);

		return p;
	}
	LPBYTE SetDriveStatus(LPBYTE p) {
		m_pDriveStatus = p;
		int cnt = *p; int bcnt = 0;
		LPBYTE p2 = p + 1;
		for(int i=0; i<cnt; i++) {
			BYTE b = *(p2 + 1);
			bcnt += b;
			p2 += b;
		}
		p += (bcnt + 1);

		return p;
	}
	LPBYTE SetExtendedReaderStatus(LPBYTE p) {
		m_pExtendedReaderStatus = p;
		int cnt = *p; int bcnt = 0;
		int rdrSize = 4;	// default size
		if (cnt & 0x80) {
			cnt &= 0x7f;
			rdrSize = *(p+1);
			bcnt += 1;
		}
		bcnt += cnt * rdrSize;
		p += (bcnt + 1);

		return p;
	}
	LPBYTE SetPowerMonitorStatus(LPBYTE p) {
		m_pPowerMonitorStatus = p;
		int cnt = *p; int bcnt = 0;
		LPBYTE p2 = p + 1;
		for(int i=0; i<cnt; i++) {
			BYTE b = *(p2 + 1);
			bcnt += b + 2;
			p2 += (b + 2);
		}
		p += (bcnt + 1);

		return p;
	}
	LPBYTE SetVaultControllerStatus(LPBYTE p) {
		m_pVaultControllerStatus = p;
		int cnt = *p; int bcnt = 0;
		LPBYTE p2 = p + 1;
		for(int i=0; i<cnt; i++) {
			BYTE b = *(p2 + 1);
			bcnt += b + 2;
			p2 += (b + 2);
		}
		p += (bcnt + 1);

		return p;
	}
	LPBYTE SetDeviceFirmwareStatus(LPBYTE p) {
		m_pDeviceFirmwareStatus = p;
		LPBYTE pDevFirmware = p;
		BYTE deviceType=0;
		BYTE numDevices=0;
		do {
			deviceType = *pDevFirmware++;
			numDevices = *pDevFirmware++;
			pDevFirmware += numDevices * 7;
		}while(!(deviceType & 0x80));

		return pDevFirmware;
	}
	LPBYTE SetExtendedInputStatus(LPBYTE p) {
		m_pExtendedInputStatus = p;
		int cnt = *p;
		p += (cnt + 1);
		return p;
	}
private:
	LPBYTE m_pStatus;
	BYTE m_rtuType;
	BYTE m_panelType;
	BYTE m_commType;
	BYTE m_header;
	BYTE m_headers[16];
	BYTE m_headerCount;
	BYTE m_bitMask;
	BYTE m_bitMask2;
	BYTE m_bitMask3;
	
public:
	LPBYTE m_pModeStatus;
	LPBYTE m_pPanelStatus;
	LPBYTE m_pInputStatus;
	LPBYTE m_pOutputStatus;
	LPBYTE m_pCameraStatus;
	LPBYTE m_pDeviceStatus;
	LPBYTE m_pLatchStatus;
	LPBYTE m_pSoakStatus;
	LPBYTE m_pReaderStatus;
	LPBYTE m_pCctvStatus;
	LPBYTE m_pElevatorStatus;
	LPBYTE m_pDriveStatus;
	LPBYTE m_pExtendedReaderStatus;
	LPBYTE m_pPowerMonitorStatus;
	LPBYTE m_pVaultControllerStatus;
	LPBYTE m_pDeviceFirmwareStatus;
	LPBYTE m_pExtendedInputStatus;
};
#pragma endregion CRtuStatusInfo

#pragma endregion

#pragma region New configurations..
/*------------------------------------------------------------------------------*/
/*					New Rtu status Page Class										*/
/*------------------------------------------------------------------------------*/
#pragma region CRTUStatus2

CRTUStatus2::CRTUStatus2() : CRTUStatus2Base(CRTUStatus2::IDD)
{
	m_StatusBufferSize = 1024;
	m_StatusBuffer.reset(new BYTE[m_StatusBufferSize]());
	m_lpps = NULL; 
	m_pParent = NULL; 
	m_bIsValid = FALSE; 
	m_nMask = 0; m_pages = 0;
	memset(m_ParmProcData, 0, sizeof(m_ParmProcData)); 
	Reset();
}

CRTUStatus2::~CRTUStatus2()
{
	if(m_StatusBuffer != nullptr) {
		m_StatusBuffer.release();
	}
}

void CRTUStatus2::DoDataExchange(CDataExchange* pDX) 
{
	CRTUStatus2Base::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CRTUStatus2)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CRTUStatus2, CRTUStatus2Base)
	//{{AFX_MSG_MAP(CRTUStatus2)
	ON_BN_CLICKED(IDOK, OnClose)
	ON_BN_CLICKED(IDC_BTN__STS_REFRESH, OnBtnRefresh)
	ON_MESSAGE(WM_GMS, OnGMS)
	ON_COMMAND(ID_RTU_STATUS_MODE, OnPrintModeStatus)
	ON_COMMAND(ID_RTU_STATUS_PANEL, OnPrintPanelStatus)
	ON_COMMAND(ID_RTU_STATUS_INPUT, OnPrintInputStatus)
	ON_COMMAND(ID_RTU_STATUS_OUTPUT, OnPrintOutputStatus)
	ON_COMMAND(ID_RTU_STATUS_CAMERA, OnPrintCameraStatus)
	ON_COMMAND(ID_RTU_STATUS_DEVINFO_KEYPAD, OnPrintDevInfoKeypadStatus)
	ON_COMMAND(ID_RTU_STATUS_DEVINFO_16IO, OnPrintDevInfo16IOStatus)
	ON_COMMAND(ID_RTU_STATUS_DEVINFO_CAMCTRL, OnPrintDevInfoCamCtrlStatus)
	ON_COMMAND(ID_RTU_STATUS_DEVINFO_ELEVCTRL, OnPrintDevInfoElevCtrlStatus)
	ON_COMMAND(ID_RTU_STATUS_DEVINFO_DIALER, OnPrintDevInfoDialerStatus)
	ON_COMMAND(ID_RTU_STATUS_DEVINFO_CARDRDR, OnPrintDevInfoCardRdrStatus)
	ON_COMMAND(ID_RTU_STATUS_DOOR, OnPrintDoorStatus)
	ON_COMMAND(ID_RTU_STATUS_CCTV, OnPrintCctvStatus)
	ON_COMMAND(ID_RTU_STATUS_ELEVATOR, OnPrintElevatorStatus)
	ON_COMMAND(ID_RTU_STATUS_DRIVE, OnPrintDriveStatus)
	//}}AFX_MSG_MAP
	ON_REGISTERED_MESSAGE(UWM_TEXT, OnTextMessage)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// RTU Status message handlers
BOOL CRTUStatus2::OnInitDialog() 
{
	CRTUStatus2Base::OnInitDialog();
	ModifyStyle(0, WS_CLIPCHILDREN | WS_VSCROLL);

	UINT nIDCheck = IDB_CHKBOX_CHECKED;
	UINT nIDUncheck = IDB_CHKBOX_UNCHECKED;
	XTPImageManager()->SetIcons(IDB_CHKBOX_CHECKED, &nIDCheck, 1, CSize(12,12));
	XTPImageManager()->SetIcons(IDB_CHKBOX_UNCHECKED, &nIDUncheck, 1, CSize(12,12));

	for(int i=0; i<16; i++) {
		UINT nIDDipSwitch = IDB_DIP_SW_1+i;
		XTPImageManager()->SetIcons(IDB_DIP_SW_1 + i, &nIDDipSwitch, 1, CSize(28,22));
	}
	
	m_pageMode.SetCaption(RES_STRING(IDS_MODE_STATUS));
	m_pagePanel.SetCaption(RES_STRING(IDS_PANEL_STS));
	m_pageInpSts.SetCaption(RES_STRING(IDS_INPUTS));
	m_pageOpSts.SetCaption(RES_STRING(IDS_OUTPUTS));
	m_pageCamSts.SetCaption(RES_STRING(IDS_CAMERAS));
	m_pageKeypad.SetCaption(RES_STRING(IDS_KEYPADS));
	m_page16IO.SetCaption(RES_STRING(IDS_IOS));
	m_pageCamCtrl.SetCaption(RES_STRING(IDS_CAMERA_CONTROLLERS));
	m_pageElevCtrl.SetCaption(RES_STRING(IDS_ELEVATOR_CONTROLLERS));
	m_pageDialer.SetCaption(RES_STRING(IDS_DIALERS));
	m_pageCardRdr.SetCaption(RES_STRING(IDS_RDR_INF));
	m_pageReader.SetCaption(RES_STRING(IDS_DOORS));
	m_pageCctvSts.SetCaption(RES_STRING(IDS_CCTVS));
	m_pageElevFlr.SetCaption(RES_STRING(IDS_ELEVATORS));
	m_pageDriveStatus.SetCaption(RES_STRING(IDS_DRIVES));
	m_pagePowerMonitorStatus.SetCaption(RES_STRING(IDS_POWER_MONITORS));
	m_pageVaultCtrlStatus.SetCaption(RES_STRING(IDS_VAULT_CONTROLLERS));

	m_ps.SetNavigator(new CCategoriesTreeNavigator());
	m_ps.m_psh.dwFlags |= PSH_NOAPPLYNOW;
	m_ps.AddPage(&m_pageMode);
	m_ps.AddPage(&m_pagePanel);
	m_ps.AddPage(&m_pageInpSts);
	m_ps.AddPage(&m_pageOpSts);
	m_ps.AddPage(&m_pageCamSts);

	m_ps.AddPage(&m_pageKeypad);
	m_ps.AddPage(&m_page16IO);
	m_ps.AddPage(&m_pageCamCtrl);
	m_ps.AddPage(&m_pageElevCtrl);
	m_ps.AddPage(&m_pageDialer);
	m_ps.AddPage(&m_pageCardRdr);
	
	m_ps.AddPage(&m_pageReader);
	m_ps.AddPage(&m_pageCctvSts);
	m_ps.AddPage(&m_pageElevFlr);
	m_ps.AddPage(&m_pageDriveStatus);
	m_ps.AddPage(&m_pagePowerMonitorStatus);
	m_ps.AddPage(&m_pageVaultCtrlStatus);
	
	//TT 7804: _DEVICE8501
	m_ps.AddPage(&m_pageFullDevStatus);	
	
	m_ps.Create(this, WS_CHILD | WS_VISIBLE|WS_TABSTOP, WS_EX_CONTROLPARENT);

	CRect rect;
	GetWindowRect(&rect); 
	ScreenToClient(&rect);
	m_ps.SetWindowPos(NULL, rect.left, rect.top, 0, 0, SWP_NOZORDER | SWP_NOSIZE | SWP_NOACTIVATE);

	CXTPPropertyPageTreeNavigator* pNav = (CXTPPropertyPageTreeNavigator*)m_ps.GetNavigator();
	pNav->DeleteAllItems();
	m_pages = 0;
	
	m_bStartup = TRUE;

	// Change from VS2010 to VS2012: make sure all windows handles to be valid
#ifdef _oldcodes
	m_ps.SetActivePage(&m_pageMode);
	m_ps.SetActivePage(&m_pagePanel);
	m_ps.SetActivePage(&m_pageInpSts);
	m_ps.SetActivePage(&m_pageOpSts);
	m_ps.SetActivePage(&m_pageCamSts);
	m_ps.SetActivePage(&m_pageKeypad);
	m_ps.SetActivePage(&m_page16IO);
	m_ps.SetActivePage(&m_pageCamCtrl);
	m_ps.SetActivePage(&m_pageElevCtrl);
	m_ps.SetActivePage(&m_pageDialer);
	m_ps.SetActivePage(&m_pageCardRdr);	
	m_ps.SetActivePage(&m_pageReader);
	m_ps.SetActivePage(&m_pageCctvSts);
	m_ps.SetActivePage(&m_pageElevFlr);
	m_ps.SetActivePage(&m_pageDriveStatus);
	m_ps.SetActivePage(&m_pagePowerMonitorStatus);
	m_ps.SetActivePage(&m_pageVaultCtrlStatus);
	m_ps.SetActivePage(&m_pageFullDevStatus);
#endif
	return TRUE;
}

BOOL CRTUStatus2::GetStatus(BYTE nMask)
{
	if ((m_nMask != nMask) || (GetKeyState(VK_SHIFT)&0x8000)) {
		m_nMask = nMask;
		m_lpps->BlkNo = nMask;
		int id = -1;
		if (RtuType != RTU_1003_TYPE && RtuType != RTU_DIEBOLD_TYPE)
			id = PspGetRtuStatus(m_lpps, iblk, m_lpps->BlkNo<<1);
		else 
			id = get_masked_rtu_status(m_lpps, m_lpps->BlkNo);

		return TRUE;
	}

	return FALSE;
}

void CRTUStatus2::Reset()
{
	m_bStartup = TRUE;
}

void CRTUStatus2::Init(LPPARMPROC lpps, int /*nOption*/, BYTE nMask, CWnd* pParent)
{
	if (lpps == NULL)
		return;

	m_nMask = nMask;
	//m_nOption = nOption;
	memcpy(&m_pps, lpps, sizeof(m_pps));
	memcpy(m_ParmProcData, lpps->lpData, sizeof(m_ParmProcData));
	m_pps.lpData = m_ParmProcData;
	m_lpps = &m_pps;
	m_pParent = pParent;
	//m_pages = 0;

	HWND hDlg = GetSafeHwnd();
	if (hDlg) {
		m_pps.heDlg = hDlg;
		m_pps.hmDlg = hDlg;
	}

	m_bIsValid = TRUE;
	if (gRtuNo == MAKERTUNO(m_lpps->eType, m_lpps->eNo)) {
		int id = -1;
		try {
			if (RtuType != RTU_1003_TYPE && RtuType != RTU_DIEBOLD_TYPE) {
				OutputDebugString(_T("[CRTUStatus2] - PspGetRtuStatus ...\n"));
				id = PspGetRtuStatus(m_lpps, iblk, m_lpps->BlkNo<<1);
			}
			else {
				OutputDebugString(_T("[CRTUStatus2] - get_masked_rtu_status ...\n"));
				id = get_masked_rtu_status(m_lpps, m_lpps->BlkNo);
			}
		}
		catch(...) {
			OutputDebugString(_T("[CRTUStatus2] - Init ...\n"));
		}
	}	
}

LRESULT CRTUStatus2::OnTextMessage(WPARAM wParam, LPARAM lParam)
{
	if (m_pParent) {
		m_pParent->SendMessage(UWM_TEXT, wParam, lParam);
	}
	return 0;
}

BOOL CRTUStatus2::GetStatus()
{
	BOOL bResult = FALSE;
	TCHAR	filename[MAX_PATH]={0}, sFilePath[MAX_PATH]={0};
	GetRtuParmFile(filename, RTUSTUS_FILE, MAKERTUNO(m_lpps->eType, m_lpps->eNo));
	wsprintf(sFilePath, L"%s\\%s", CUSTOMER_RTU_UPLOAD_FOLDER, filename);

	CMyFile stsFile;
	if (stsFile.Open(DefaultLocation(sFilePath), FILE_READ|FILE_DENYNONE)) {
		uint flen = (uint)stsFile.GetLength();
		if (flen) {
			if(flen > m_StatusBufferSize) {
				m_StatusBufferSize = flen+1;
				m_StatusBuffer.reset(new BYTE[m_StatusBufferSize]());
			}
			if(m_StatusBuffer != nullptr) {
				auto ptr = m_StatusBuffer.get();
				if (ptr != nullptr) {
					memset(ptr, 0, m_StatusBufferSize);
					if(stsFile.Read(ptr, flen) == flen) {
						if (RtuType==RTU_1003_TYPE && *ptr==RTU_MOSLER_10030_TYPE)
    						ConvertOld2New1003(ptr+2);
						bResult = TRUE;
					}
				}
			}
			else {
				DispMessageBox(NULL, IDS_NOT_ENOUGH_MEM, IDS_RTU_PARAMS, MB_OK|MB_ICONSTOP);
				GetDlgItem(IDC_BTN__STS_REFRESH)->EnableWindow(TRUE);
			}
		}
		stsFile.Close();
	}

	return bResult;
}

LRESULT CRTUStatus2::OnGMS(WPARAM wParam, LPARAM lParam)
{
	LPBYTE	p = (LPBYTE)lParam;
	if (p == NULL)
		return 0;
	if (!m_bIsValid)
		return 0;

	UINT id = GET_WM_COMMAND_ID(wParam, lParam);
	switch(id) {
		case IDD_COMMOVR_ERROR:
			break;
		case IDD_COMMOVR_CTRL_NUM:
			if (GetStatus()) {
				ShowStatus();
				if (m_pParent) {
					m_pParent->PostMessage(UWM_RTU_STATUS, (WPARAM)_T(""));
				}
				//GetDlgItem(IDC_BTN__STS_REFRESH)->EnableWindow(TRUE);
				//SetFocus();
			}
			break;
		
		default:
			break;
	}
	
	return(0);
}

void CRTUStatus2::OnBtnRefresh()
{
	int id = -1;
	GetDlgItem(IDC_BTN__STS_REFRESH)->EnableWindow(FALSE);
	if (RtuType != RTU_1003_TYPE && RtuType != RTU_DIEBOLD_TYPE)
		id = PspGetRtuStatus(m_lpps, iblk, m_lpps->BlkNo<<1);
	else 
		id = get_masked_rtu_status(m_lpps, m_lpps->BlkNo);

	if (id==-1)	{
		wMessageBox(m_lpps->heDlg, CanotDnload, RES_STRING(IDS_RTU_PARAMS), MB_OK|MB_ICONSTOP);
		GetDlgItem(IDC_BTN__STS_REFRESH)->EnableWindow(TRUE);
		return;
	}

}

void CRTUStatus2::ShowStatus()
{
	if (IsWindow(m_hWnd) == FALSE) 
		return;
	auto pStsBuf = m_StatusBuffer.get();
	if (pStsBuf == nullptr)
		return;

	m_StatusItems.Count = 0;
	for(int i=0; i<STATUS_PAGE_CNT; i++) {
		m_StatusItems.Pages[i] = NULL;
		m_StatusItems.Items[i] = 0;
	}

	LPBYTE statusInfoPtr = pStsBuf;
	LPBYTE ptrHCnt = statusInfoPtr + 3;
	BYTE rtuType = *pStsBuf;
	BYTE panelType = *(pStsBuf+1);
	BYTE commType = *(pStsBuf+2);
	BYTE headerCount = (BYTE)(*(statusInfoPtr + 3) >> 4);
	BYTE header = *ptrHCnt;
	BYTE header1 = (headerCount > 0)? *(ptrHCnt + 1): 0;	// Get header byte 1
	BYTE header2 = (headerCount > 1)? *(ptrHCnt + 2): 0;	//Get header byte 2

	TRACE3("**** Header=%02x, Header1=%02x, Header2=%02x\n", header,  (headerCount > 0)? *(ptrHCnt + 1): 0, (headerCount > 1)? *(ptrHCnt + 2): 0);
	
	//CRtuStatusInfo rtuStsInfo(pStsBuf);
	statusInfoPtr = GetStatusPtr(pStsBuf);			//.statusInfoPtr pointing to 'ModeStatus' count
	
	// mode status
	statusInfoPtr = AddStatusPage(P_MODE, statusInfoPtr, (header & HB0_MODE_STATUS_INC)? TRUE : FALSE, ModePage, &m_pageMode, ID_RTU_STATUS_MODE, 0);
	
	//..... Display the Panel Status data .......
	// Check if panel included
	if (header & HB0_PANEL_STATUS_INC) {
		statusInfoPtr = AddStatusPage(P_1057, statusInfoPtr, TRUE, Panel57Page, &m_pagePanel);
	}

	statusInfoPtr = AddStatusPage(P_INPUT, statusInfoPtr, header & HB0_ALARM_STATUS_INC, InputPage, &m_pageInpSts);
	statusInfoPtr = AddStatusPage(P_OUTPUT, statusInfoPtr, header & HB0_OUTPUT_STATUS_INC, OutputPage, &m_pageOpSts);
	statusInfoPtr = AddStatusPage(P_CAMERA, statusInfoPtr, header1 & HB1_CAMERA_STATUS_INC, CameraPage, &m_pageCamSts);
	if (headerCount) {
		statusInfoPtr = SetDevInfoStatus(statusInfoPtr, header1);	// Setup device info data
	}
	
	if ((header1 & HB1_INPUT_LATCH_STATUS_INC))	// Check if latch status included
		statusInfoPtr = m_pageInpSts.SetLatchStsData(statusInfoPtr);
	if ((header1 & HB1_SOAK_STATUS_INC))			// Check if soak status included
		statusInfoPtr = m_pageInpSts.SetSoakStsData(statusInfoPtr);

	// reader status
	statusInfoPtr = AddStatusPage(P_READER, statusInfoPtr, header1 & HB1_READER_STATUS_INC, DoorPage, &m_pageReader);
	// CCTV status
	statusInfoPtr = AddStatusPage(P_CCTV, statusInfoPtr, header1 & HB1_CCTV_STATUS_INC, CctvPage, &m_pageCctvSts);
	// elevator status
	statusInfoPtr = AddStatusPage(P_ELEVATOR, statusInfoPtr, header2 & HB2_ELEVATOR_STATUS_INC, ElevatorFloorPage, &m_pageElevFlr);
	// drive status
	statusInfoPtr = AddStatusPage(P_DRIVE, statusInfoPtr, header2 & HB2_DRIVE_STATUS_INC, DrivePage, &m_pageDriveStatus);

	// extended reader status
	if ((header2 & HB2_EXTENDED_READER_INC))	{
		BYTE numReaders = *statusInfoPtr++;
		if (numReaders != 0) {
			int readerSize = 5;
			if (numReaders & 0x80) {
				numReaders &= 0x7f;
				readerSize = *(statusInfoPtr++);
			}
			int extReaderSize = numReaders * readerSize;
			if (extReaderSize != 0)	{
				// why copy then throw away?
				//BYTE* pExtendedReaderData = new BYTE[extReaderSize];
				//memcpy(pExtendedReaderData, statusInfoPtr, extReaderSize);
				statusInfoPtr += extReaderSize;
			}
		}
	}

	// power monitor status
	statusInfoPtr = AddStatusPage(P_POWER, statusInfoPtr, header2 & HB2_POWER_MONITOR_INC, PowerMonitorPage, &m_pagePowerMonitorStatus);
	// vault controller status
	statusInfoPtr = AddStatusPage(P_VAULT_CTRL, statusInfoPtr, header2 & HB2_VAULT_CONTROLLER_INC, VaultControllerPage, &m_pageVaultCtrlStatus);
	// device firmware version
	s_bKeypadFirmware = FALSE;
	s_bIoFirmware = FALSE;
	s_bCardReaderFirmware = FALSE;
	
	memset(s_keypadFirmware, 0xff, sizeof(s_keypadFirmware));
	memset(s_ioFirmware, 0xff, sizeof(s_ioFirmware));
	memset(s_cardReaderFirmware, 0xff, sizeof(s_cardReaderFirmware));
	int nDeviceSize = sizeof(DEVICE_FIRMWARE);
	
	if ((header2 & HB2_DEVICE_FIRMWARE_INC))	{
		BYTE* pDevFirmware = statusInfoPtr;
		BYTE deviceType;
		BYTE numDevices;
		int bc = 0;
		do {
			deviceType = *pDevFirmware++;
			numDevices = *pDevFirmware++;
			
			int nMax = numDevices;
			switch ((deviceType & 0x7f)) {
			case 0x03: 
				{ // Keypad type
				if (nMax > MAX_RTU_KEYPADS)
					nMax = MAX_RTU_KEYPADS;
				memcpy(s_keypadFirmware, pDevFirmware, nMax * nDeviceSize);
				s_bKeypadFirmware = TRUE;
				break;
				}
			case 0x04:
				{ // IO type
				if (nMax > MAX_RTU_IOS)
					nMax = MAX_RTU_IOS;
				memcpy(s_ioFirmware, pDevFirmware, nMax * nDeviceSize);
				s_bIoFirmware = TRUE;
				break;
				}
			case 0x29:
				{ // Card reader type
				if (nMax > MAX_RTU_READERS)
					nMax = MAX_RTU_READERS;
				//CString db;db.Format(L"DeviceFirmware: CardReaders=%d devices\n", nMax);OutputDebugString(db);
				memcpy(s_cardReaderFirmware, pDevFirmware, nMax * nDeviceSize);
				s_bCardReaderFirmware = TRUE;
				break;
				}
			}
			
			bc += numDevices * nDeviceSize;
			pDevFirmware += numDevices * nDeviceSize;
			
		}while(!(deviceType & 0x80));

		statusInfoPtr = pDevFirmware;
	}

	if ((header2 & HB2_INPUT_EXTENDED_DATA_INC)) {
		statusInfoPtr = m_pageInpSts.SetExtendeInputData(statusInfoPtr);
	}

	//TT 7804
	BOOL bFullDeviceStatus = FALSE;
	if ((header2 & HB2_FULL_DEVICE_STS_INC)) {
		CString db;db.Format(L"FullDeviceStatus: total=%d devices\n", *(LPWORD)statusInfoPtr);OutputDebugString(db);
		if (*(LPWORD)(statusInfoPtr) > 0) {
			bFullDeviceStatus = TRUE;
		}
	}
	
	statusInfoPtr = AddStatusPage(P_FULL_DEV_STS, statusInfoPtr, bFullDeviceStatus, FullDeviceStatusPage, &m_pageFullDevStatus);

	TRACE0("----------------------\n");

	if(m_bStartup) {
		((CCategoriesTreeNavigator*)m_ps.GetNavigator())->RecreateTree(&m_StatusItems);
		CXTPPropertyPage* pPage = (CXTPPropertyPage*)&m_pagePanel;
		m_ps.SetActivePage(pPage);
		m_bStartup = FALSE;
		CXTPPropertyPageTreeNavigator* pNav = (CXTPPropertyPageTreeNavigator*)m_ps.GetNavigator();
		pNav->SelectItem(s_hItemPanel);
	}
	else {
		((CRtuStatusBase2*)m_ps.GetActivePage())->ShowStatus();
	}
	GetDlgItem(IDC_BTN__STS_REFRESH)->EnableWindow(TRUE);
					 
	RTUDATA_ rtuData;		  
	rtuData.RtuNo = MAKERTUNO(m_lpps->eType, m_lpps->eNo)+1;
	rtuData.NetType = commType;
	rtuData.RAP = panelType;
	rtuData.RtuType = rtuType;
	rtuData.VocabList = m_pagePanel.GetVocabListId();
	_rtudatas_ * updateInfos = _rtudatas_::Get(eUpdateRtuData::eInfo, 1);
	memcpy(updateInfos->pInfos, &rtuData, sizeof(rtuData));
	::PostMessage(Globals->hSysWnd, WM_GMS, IDM_RTUDATA_UPDATE, (LPARAM) updateInfos);	// eUpdateRtuData::eInfo
}

LPBYTE CRTUStatus2::AddStatusPage(int nPage, LPBYTE pData, BOOL bAdded, ulong mask, CRtuStatusBase2* pPage, int cnt, BOOL inc)
{
	LPBYTE p = pData;
	CXTPPropertyPageTreeNavigator* pNav = (CXTPPropertyPageTreeNavigator*)m_ps.GetNavigator();
	HTREEITEM hItem = (HTREEITEM)(((CXTPPropertyPage*)pPage)->m_dwData);

	if (bAdded) {
		p = pPage->SetStatus(p, cnt, inc);
		if (pPage->IsValid()) {
			
			BOOL bNew = FALSE;
			if (!(m_pages & mask)) {						
				CXTPPropertyPage* pPage2 = (CXTPPropertyPage*)pPage;		
				CString strCaption = pPage2->GetCaption();
				HTREEITEM hItem2 = pNav->InsertItem(strCaption, -1, -1);//TT 7804
				pNav->SetItemData(hItem2, (DWORD_PTR)pPage2);
				pPage2->m_dwData = (DWORD_PTR)hItem2;
				m_pages |= mask;
				bNew = TRUE;
			}
	
			m_StatusItems.Pages[m_StatusItems.Count] = pPage;
			m_StatusItems.Items[m_StatusItems.Count] = hItem;
			m_StatusItems.Count += 1;

			if (bNew == FALSE)
			{
				TVITEM item;
				item.hItem = (HTREEITEM)pPage->m_dwData;
				item.mask = TVIF_STATE;

				if (pNav->GetItem(&item) == FALSE)
				{
					TRACE1("AddStatusPage %d has wrong tree node !!!!\n", m_StatusItems.Count-1);
				}
			}
			return p;
		}
	}
	if (m_pages & mask) {

		TRACE2("AddStatusPage delete [%d] tree node h=%x !!!!\n", nPage, hItem);
		TVITEM item;
		item.hItem = (HTREEITEM)pPage->m_dwData;
		item.mask = TVIF_STATE;

		if (pNav->GetItem(&item) == FALSE)
		{
			TRACE0("AddStatusPage: delete invalid tree node !!!!\n");
		}

		pNav->DeleteItem(hItem);
		m_pages &= ~mask;
	}

	return p;
}

void CRTUStatus2::SetPageIcon()
{
}

LPBYTE CRTUStatus2::SetDevInfoStatus(LPBYTE lpData, BYTE header1)
{
	BYTE deviceCounts[1+6+32];			//.Array of device counts;
	BYTE deviceHeaderByte;
	
	LPBYTE p2, p3;

	p2 = lpData;					//.Pointer to Device Info byte.
	
	//....Now p2 is pointing to Device info.....
	if (IsBadReadPtr(p2, 1+3+6+3*8))
		return NULL;

	deviceHeaderByte = *p2++;					// first byte is device header byte.
	
	
	if (deviceHeaderByte == 0)
		return p2;

	BYTE xDataBytes =  (deviceHeaderByte >> 6); // bit 6 & 7 of header byte.
	BYTE deviceMask =  (deviceHeaderByte & 0x3f) ; // bit 0..5
	
	memset(&deviceCounts, 0, sizeof(deviceCounts));

	p3 = p2 + xDataBytes;		//.p3 pointing to device counts;
	LPBYTE pCount = &deviceCounts[0];
	
	if (deviceMask != 0)
	{
		for (int ind=0; ind<6; ind++, pCount++) 	  	//.Process first header byte, 0-5 bit
		{
			if (((deviceMask>>ind) & 1) == 1)
				*pCount = *p3++ ;
		}
	}

	pCount = &deviceCounts[6];

	for (int ind = 0; ind < xDataBytes; ind++) 
	{
		for (int bit=0; bit<8 && *p2; bit++, pCount++) 
		{  	//.Process next header byte
			if (((*p2>>ind)&1) == 1)
				*pCount = *p3++;		
		}
		p2++;
	}
	

	int numTypes = 6 + 8*xDataBytes;				//.No.of device types

	// p3 point to the tamper
	// working out total byte count.
	int statusBytesCount = 0;
	for (int ind=0; ind<numTypes; ind++) {
		
		int cnt = deviceCounts[ind]; // number of devices of each type.
		if (cnt > 0)
		{
			int nBytes =  (cnt/8) + ((cnt%8) ? 1 : 0); // every 8 devices = 1 byte status

			statusBytesCount += nBytes;
		}
	}

	BYTE	kpBuff[DEV_INFO_MAX], ioBuff[DEV_INFO_MAX], camBuff[DEV_INFO_MAX];
	BYTE	elevBuff[DEV_INFO_MAX], dlrBuff[DEV_INFO_MAX], crdrBuff[DEV_INFO_MAX];

	int kpByteCnt, ioByteCnt, camByteCnt, elevByteCnt, dlrByteCnt, crdrByteCnt;


	BYTE kpadCnt = deviceCounts[0];
	BYTE io16Cnt = deviceCounts[1];
	BYTE camCtrlCnt = deviceCounts[2];
	BYTE elevCtrlCnt = deviceCounts[3];
	BYTE dialerCnt = deviceCounts[4];
	BYTE cardRdrCnt = deviceCounts[5];
	
	memset(kpBuff, 0, sizeof(kpBuff));
	memset(ioBuff, 0, sizeof(ioBuff));
	memset(camBuff, 0, sizeof(camBuff));
	memset(elevBuff, 0, sizeof(elevBuff));
	memset(dlrBuff, 0, sizeof(dlrBuff));
	memset(crdrBuff, 0, sizeof(crdrBuff));

	kpByteCnt = (kpadCnt/8) + (kpadCnt%8 ? 1 : 0);
	ioByteCnt = (io16Cnt/8) + (io16Cnt%8 ? 1 : 0);
	camByteCnt = (camCtrlCnt/8) + (camCtrlCnt%8 ? 1 : 0);
	elevByteCnt = (elevCtrlCnt/8) + (elevCtrlCnt%8 ? 1 : 0);
	dlrByteCnt = (dialerCnt/8) + (dialerCnt%8 ? 1 : 0);
	crdrByteCnt = (cardRdrCnt/8) + (cardRdrCnt%8 ? 1 : 0);

	p2 = p3;
	if (kpByteCnt) 
	{
		Copy(kpBuff, p3, kpByteCnt , statusBytesCount, (header1 & HB1_CLEANER_KEY_STATUS_INC) ? TRUE : FALSE);
		p3 += kpByteCnt;
	}

	if (ioByteCnt) {
		Copy(ioBuff, p3, ioByteCnt, statusBytesCount);
		p3 += ioByteCnt;
	}
	if (camByteCnt) {
		Copy(camBuff, p3, camByteCnt, statusBytesCount);
		p3 += camByteCnt;
	}
	if (elevByteCnt) 
	{
		Copy(elevBuff, p3, elevByteCnt, statusBytesCount);
		p3 += elevByteCnt;
	}
	
	if (dlrByteCnt) 
	{
		Copy(dlrBuff, p3, dlrByteCnt, statusBytesCount);
		p3 += dlrByteCnt;
	}
	
	if (crdrByteCnt) 
	{
		Copy(crdrBuff, p3, crdrByteCnt, statusBytesCount);
		p3 += crdrByteCnt;
	}
	
	BOOL bAdded = (deviceMask & DEVINFO_KEYPAD_INC);
	AddStatusPage(P_DEV_KEYPAD, kpBuff, bAdded, DevInfoKeypadPage, &m_pageKeypad, kpadCnt, (header1 & HB1_CLEANER_KEY_STATUS_INC));	

	bAdded = (deviceMask & DEVINFO_16IO_INC);
	AddStatusPage(P_DEV_IO, ioBuff, bAdded, DevInfoIoPage, &m_page16IO, io16Cnt);

	bAdded = (deviceMask & DEVINFO_CAMCTRL_INC);
	AddStatusPage(P_DEV_CAM, camBuff, bAdded, DevInfoCameraPage, &m_pageCamCtrl, camCtrlCnt);

	bAdded = (deviceMask & DEVINFO_ELEVCTRL_INC);
	AddStatusPage(P_DEV_ELEVATOR, elevBuff, bAdded, DevInfoElevatorPage, &m_pageElevCtrl, elevCtrlCnt);

	bAdded = (deviceMask & DEVINFO_DIALER_INC);
	AddStatusPage(P_DEV_DIALER, dlrBuff, bAdded, DevInfoDialerPage, &m_pageDialer, dialerCnt);

	bAdded = (deviceMask & DEVINFO_CARDRDR_INC);
	AddStatusPage(P_DEV_CRIF, crdrBuff, bAdded, DevInfoCardReaderPage, &m_pageCardRdr, cardRdrCnt);


	int cnt = 3 * statusBytesCount;
	// check if keypad included, add keyswitch status bytes
	if (header1 & HB1_CLEANER_KEY_STATUS_INC) {
		int bc = deviceCounts[0];
		cnt += (bc / 8) + (bc % 8 ? 1 : 0);
	}
		
	p2 += cnt;
	return p2;
}

LPBYTE CRTUStatus2::Copy(LPBYTE pBuffer, LPBYTE pData, int cnt, int dCnt, BOOL bKeypad)
{
	ASSERT(cnt <= DEV_INFO_MAX);

	LPBYTE pDat = pData;
	LPBYTE pBuf = pBuffer;

	// Copying tamper data
	memcpy(pBuf, pDat, cnt);		
	pDat += dCnt;					
	pBuf += cnt;

	// Copying offline data
	memcpy(pBuf, pDat, cnt);	
	pDat += dCnt;					
	pBuf += cnt;

	// Copying isolated data
	memcpy(pBuf, pDat, cnt);	
	pDat += dCnt;					
	pBuf += cnt;

	// Copying key switch data
	if (bKeypad) {
		memcpy(pBuf, pDat, cnt);   
	}

	return pBuffer;
}


void CRTUStatus2::OnClose() 
{
	//EndDialog(TRUE);
}


LPBYTE CRTUStatus2::GetStatusPtr(LPBYTE p1)
{
LPBYTE	p2;

	p2 = p1;					//.Skip blk Sts (Data block should not have it)
	p2 += 3;					//.Skip RtuType, Panel Type & CommsType
	p2 += 1 + (*p2 >> 4);		//.Skip Hdr count & No.of Header bytes.
	return p2;
}


void CRTUStatus2::OnPrintModeStatus()
{
	//m_pageMode.Print();
}

void CRTUStatus2::OnPrintPanelStatus()
{
}

void CRTUStatus2::OnPrintInputStatus()
{
	//m_pageInpSts.Print();
}

void CRTUStatus2::OnPrintOutputStatus()
{
	//m_pageOpSts.Print();
}

void CRTUStatus2::OnPrintCameraStatus()
{
	//m_pageCamSts.Print();
}

void CRTUStatus2::OnPrintDevInfoKeypadStatus()
{
	//m_pageKeypad.Print();
}

void CRTUStatus2::OnPrintDevInfo16IOStatus()
{
	//m_page16IO.Print();
}

void CRTUStatus2::OnPrintDevInfoCamCtrlStatus()
{
	//m_pageCamCtrl.Print();
}

void CRTUStatus2::OnPrintDevInfoElevCtrlStatus()
{
	//m_pageElevCtrl.Print();
}

void CRTUStatus2::OnPrintDevInfoDialerStatus()
{
	//m_pageDialer.Print();
}

void CRTUStatus2::OnPrintDevInfoCardRdrStatus()
{
	//m_pageCardRdr.Print();
}

void CRTUStatus2::OnPrintDoorStatus()
{
	//m_pageReader.Print();
}

void CRTUStatus2::OnPrintCctvStatus()
{
	//m_pageCctvSts.Print();
}

void CRTUStatus2::OnPrintElevatorStatus()
{
	//m_pageElevFlr.Print();
}

void CRTUStatus2::OnPrintDriveStatus()
{
	//m_pageDriveStatus.Print();
}

#pragma endregion

#pragma region CPropertyPageTaskPanelNavigator2
CPropertyPageTaskPanelNavigator2::CPropertyPageTaskPanelNavigator2()
{
}

BOOL CPropertyPageTaskPanelNavigator2::Create()
{
	CFont* pFont = m_pSheet->GetFont();

	if (!CXTPTaskPanel::Create(WS_VISIBLE | WS_CHILD | WS_GROUP | WS_TABSTOP, CRect(0, 0, 0, 0), m_pSheet, 1000))
		return FALSE;

	SetBehaviour(xtpTaskPanelBehaviourList);
	
	SetTheme(xtpTaskPanelThemeShortcutBarOffice2003);
	SetSelectItemOnFocus(TRUE);

	SetIconSize(CSize(32, 32));

	SetFont(pFont);

	CXTPTaskPanelGroup* pGroup = AddGroup(0);
	pGroup->SetCaption(_T("Controller Options"));

	for (int i = 0; i < m_pSheet->GetPageCount(); i++)
	{
		CXTPPropertyPage* pPage = m_pSheet->GetPage(i);

		CString strCaption = pPage->GetCaption();

		CXTPTaskPanelGroupItem* pItem = pGroup->AddLinkItem(i, i);
		pItem->SetCaption(strCaption);
		pItem->SetItemData((DWORD_PTR)pPage);
		pPage->m_dwData = (DWORD_PTR)pItem;
	}

	GetImageManager()->SetIcon(_T("8001_INP_BMP"), 0);
	

	m_pSheet->SetPageBorderStyle(xtpPageBorderBottomLine);

	return TRUE;
}

void CPropertyPageTaskPanelNavigator2::OnPageSelected(CXTPPropertyPage* pPage)
{
	CXTPTaskPanelGroupItem* pItem = (CXTPTaskPanelGroupItem*)pPage->m_dwData;
	SetFocusedItem(pItem);
}

void CPropertyPageTaskPanelNavigator2::SetFocusedItem(CXTPTaskPanelItem* pItem, BOOL bDrawFocusRect /*= FALSE*/, BOOL bSetFocus)
{
	if (m_pItemFocused != pItem && pItem && pItem->GetType() == xtpTaskItemTypeLink)
	{
		CXTPPropertyPage* pPage = (CXTPPropertyPage*)pItem->GetItemData();
		if (!m_pSheet->SetActivePage(pPage))
		{
			return;
		}
	}

	CXTPTaskPanel::SetFocusedItem(pItem, bDrawFocusRect, bSetFocus);

}

#pragma endregion CPropertyPageTaskPanelNavigator2

/*------------------------------------------------------------------------------*/
/*					New Mode Page Class										*/
/*------------------------------------------------------------------------------*/
#pragma region CRtuModePage2

IMPLEMENT_DYNCREATE(CRtuModePage2, CXTPPropertyPage)

void CRtuModePage2::DoDataExchange(CDataExchange* pDX)
{
	CXTPPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CRtuModePage2)
	DDX_Control(pDX, IDC_RTUSTAT_LBL1, m_lblModeStatus);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CRtuModePage2, CXTPPropertyPage)
	//{{AFX_MSG_MAP(CRtuModePage2) 
	ON_NOTIFY(UDN_DELTAPOS, IDC_RTU_ID1, OnUpDownModeSts)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CRtuModePage2 message handlers
/////////////////////////////////////////////////////////////////////////////
CRtuModePage2::CRtuModePage2() : CRtuStatusBase2(CRtuModePage2::IDD)
{
	m_nCurArea = 0; m_nNumAreas = 0;
	m_status1 = m_status2 = m_status3 = 0;
	memset(m_modeStatus, 0, sizeof(m_modeStatus));
};


BOOL CRtuModePage2::OnInitDialog()
{
	CDialog::OnInitDialog();
	ShowStatusNum(m_nCurArea);
	return TRUE;
}

BOOL CRtuModePage2::OnSetActive()
{
	ShowStatusNum(m_nCurArea);
	return CXTPPropertyPage::OnSetActive();
}

void _OutputDebugMemory(LPCTSTR /*name*/, LPBYTE /*lpData*/, int /*cnt*/)
{
#ifdef _DEBUG_RTU_MEMORY
	TCHAR db[2000], *ps = db;
	wsprintf(ps, L"%s (nbytes=%d) \n", name, cnt);
	ps += lstrlen(ps);
	for (int i =0; i < cnt && i < 512; i++)
	{
		int n = wsprintf(ps, L"%02x %s", *(lpData+i), ((i+1)%32)==0?L"\n":L"") ;
		ps += n;
	}
	lstrcpy(ps, L"\n----------\n");

	OutputDebugString(db);
#endif
}

LPBYTE CRtuModePage2::SetStatus(LPBYTE lpData, int, BOOL)
{
	int byteCount = *lpData;
	GmsOutputDebugString(__FUNCTIONW__, __LINE__, L"Count=%d", *lpData);
	try
	{
		m_nNumAreas = byteCount / 3;

		_OutputDebugMemory(L"CRtuModePage2::SetStatus", lpData, byteCount+1);

		memset(m_modeStatus, 0, sizeof(m_modeStatus));
		memcpy(m_modeStatus, lpData+1, byteCount);
	
		lpData += (1 + byteCount);
	}
	catch (...)
	{
		OutputDebugString(L"Exception in CRtuModePage2::SetStatus(..)\n");
	}
	return lpData;
}

void CRtuModePage2::ShowStatus()
{
	if (IsWindow(m_hWnd) == FALSE) return;
	ShowStatusNum(m_nCurArea);
}

void CRtuModePage2::ShowStatusNum(int curArea)
{
	int index = curArea*3;
	CString str;
	CString sModSts = RES_STRING(IDS_AREA_MOD_STS_RNG);
	str.Format(sModSts, curArea + 1, m_nNumAreas);
	GetDlgItem(IDC_RTUSTAT_LBL1)->SetWindowText(str);

	m_status1 = m_modeStatus[index++];
	m_status2 = m_modeStatus[index++];
	m_status3 = m_modeStatus[index++];

	CString str1 = GetMainStatus();
	CString str2 = GetSubStatus();
	CString str3 = _T("");
	str3.Format( 
		_T("<Border Padding='1' BorderThickness='1' BorderBrush='#767676' Background='#e4ecf7'>")
		_T("<StackPanel TextBlock.FontFamily='Tahoma' TextBlock.FontSize='11'>")
		_T("   <TextBlock Padding='1, 1, 1, 1' FontWeight='Bold'>%s</TextBlock>")
		_T("   <Border Height='1' Background='#9ebbdd' />")
		_T("   <Border Height='1' Background='White' />")
		_T("   <StackPanel Margin='1, 1, 1, 1' Orientation='Horizontal'>")
		_T("		<StackPanel Margin='40, 40, 0, 0'>")
		_T("			%s")
		_T("		</StackPanel>")
		_T("		<StackPanel Margin='20, 40, 0, 0'>")
		_T("			%s")
		_T("		</StackPanel>")
		_T("   </StackPanel>")
		_T("</StackPanel>")
		_T("</Border>"), 
		(LPCTSTR)str, (LPCTSTR)str1, (LPCTSTR)str2
		);
	m_lblModeStatus.SetMarkupText(str3);
	
}

CString CRtuModePage2::GetMainStatus()
{
	CString str;
	UINT nID1 = m_status1 & BIT0 ? IDB_CHKBOX_CHECKED : IDB_CHKBOX_UNCHECKED;	// Day
	UINT nID2 = m_status1 & BIT1 ? IDB_CHKBOX_CHECKED : IDB_CHKBOX_UNCHECKED;	// Night
	UINT nID3 = m_status3 & BIT1 ? IDB_CHKBOX_CHECKED : IDB_CHKBOX_UNCHECKED;	// Restricted
	UINT nID4 = m_status1 & BIT7 ? IDB_CHKBOX_CHECKED : IDB_CHKBOX_UNCHECKED;	// Engineer
	UINT nID5 = m_status1 & BIT3 ? IDB_CHKBOX_CHECKED : IDB_CHKBOX_UNCHECKED;	// Cleaner
	UINT nID6 = m_status1 & BIT5 ? IDB_CHKBOX_CHECKED : IDB_CHKBOX_UNCHECKED;	// Test
	UINT nID7 = m_status2 & BIT5 ? IDB_CHKBOX_CHECKED : IDB_CHKBOX_UNCHECKED;	// Duress
	UINT nID8 = m_status1 & BIT2 ? IDB_CHKBOX_CHECKED : IDB_CHKBOX_UNCHECKED;	// ATM

	str.Format( 
		_T("<Border Padding='1' BorderThickness='1' BorderBrush='#767600' Background='#ffffef'>")
		_T("<StackPanel TextBlock.FontFamily='Tahoma' TextBlock.FontSize='11'>")
		_T("   <TextBlock Padding='1, 1, 1, 1' FontWeight='Bold'>%s</TextBlock>")
		_T("   <Border Height='1' Background='#9ebbdd' />")
		_T("   <Border Height='1' Background='White' />")
		_T("   <StackPanel Margin='20, 4, 20, 4' Orientation='Horizontal'>")
		_T("	   <Image Source='%d'/>")
		_T("       <TextBlock Margin='5, 0, 0, 0' VerticalAlignment='Center'>%s</TextBlock>")
		_T("   </StackPanel>")
		_T("   <StackPanel Margin='20, 4, 20, 4' Orientation='Horizontal'>")
		_T("	   <Image Source='%d'/>")
		_T("       <TextBlock Margin='5, 0, 0, 0' VerticalAlignment='Center'>%s</TextBlock>")
		_T("   </StackPanel>")
		_T("   <StackPanel Margin='20, 4, 20, 4' Orientation='Horizontal'>")
		_T("	   <Image Source='%d'/>")
		_T("       <TextBlock Margin='5, 0, 0, 0' VerticalAlignment='Center'>%s</TextBlock>")
		_T("   </StackPanel>")
		_T("   <StackPanel Margin='20, 4, 20, 4' Orientation='Horizontal'>")
		_T("	   <Image Source='%d'/>")
		_T("       <TextBlock Margin='5, 0, 0, 0' VerticalAlignment='Center'>%s</TextBlock>")
		_T("   </StackPanel>")
		_T("   <StackPanel Margin='20, 4, 20, 4' Orientation='Horizontal'>")
		_T("	   <Image Source='%d'/>")
		_T("       <TextBlock Margin='5, 0, 0, 0' VerticalAlignment='Center'>%s</TextBlock>")
		_T("   </StackPanel>")
		_T("   <StackPanel Margin='20, 4, 20, 4' Orientation='Horizontal'>")
		_T("	   <Image Source='%d'/>")
		_T("       <TextBlock Margin='5, 0, 0, 0' VerticalAlignment='Center'>%s</TextBlock>")
		_T("   </StackPanel>")
		_T("   <StackPanel Margin='20, 4, 20, 4' Orientation='Horizontal'>")
		_T("	   <Image Source='%d'/>")
		_T("       <TextBlock Margin='5, 0, 0, 0' VerticalAlignment='Center'>%s</TextBlock>")
		_T("   </StackPanel>")
		_T("   <StackPanel Margin='20, 4, 20, 4' Orientation='Horizontal'>")
		_T("	   <Image Source='%d'/>")
		_T("       <TextBlock Margin='5, 0, 0, 0' VerticalAlignment='Center'>%s</TextBlock>")
		_T("   </StackPanel>")
		_T("</StackPanel>")
		_T("</Border>"), RES_STRING(IDS_MAIN_STATUS), 
		nID1, RES_STRING(IDS_DAY), 
		nID2, RES_STRING(IDS_NIGHT),
		nID3, RES_STRING(IDS_MODE_REST),
		nID4, RES_STRING(IDS_RES_TYPE_ENG),
		nID5, RES_STRING(IDS_CLEANER),
		nID6, RES_STRING(IDS_TEST),
		nID7, RES_STRING(IDS_DURESS),
		nID8, RES_STRING(IDS_ATM)
		);

	return str;
}

CString CRtuModePage2::GetSubStatus()
{
	UINT nID1 = m_status2 & BIT0 ? IDB_CHKBOX_CHECKED : IDB_CHKBOX_UNCHECKED;	// Program
	UINT nID2 = m_status2 & BIT1 ? IDB_CHKBOX_CHECKED : IDB_CHKBOX_UNCHECKED;	// External ATM
	UINT nID3 = m_status2 & BIT2 ? IDB_CHKBOX_CHECKED : IDB_CHKBOX_UNCHECKED;	// Internal ATM
	UINT nID4 = m_status2 & BIT3 ? IDB_CHKBOX_CHECKED : IDB_CHKBOX_UNCHECKED;	// External cleaner
	UINT nID5 = m_status2 & BIT4 ? IDB_CHKBOX_CHECKED : IDB_CHKBOX_UNCHECKED;	// Internal cleaner
	UINT nID6 = m_status1 & BIT6 ? IDB_CHKBOX_CHECKED : IDB_CHKBOX_UNCHECKED;	// Management
	UINT nID7 = m_status2 & BIT6 ? IDB_CHKBOX_CHECKED : IDB_CHKBOX_UNCHECKED;	// ATM duress
	UINT nID8 = m_status2 & BIT7 ? IDB_CHKBOX_CHECKED : IDB_CHKBOX_UNCHECKED;	// Cleaner duress

	UINT mID1 = m_status3 & BIT0 ? IDB_CHKBOX_CHECKED : IDB_CHKBOX_UNCHECKED;	// Maintenance duress
	UINT mID2 = m_status3 & BIT2 ? IDB_CHKBOX_CHECKED : IDB_CHKBOX_UNCHECKED;	// Auxilliary Mode 1
	UINT mID3 = m_status3 & BIT3 ? IDB_CHKBOX_CHECKED : IDB_CHKBOX_UNCHECKED;	// Auxilliary Mode 2
	UINT mID4 = m_status3 & BIT4 ? IDB_CHKBOX_CHECKED : IDB_CHKBOX_UNCHECKED;	// Subarea
	UINT mID5 = m_status3 & BIT5 ? IDB_CHKBOX_CHECKED : IDB_CHKBOX_UNCHECKED;	// Guard
	UINT mID6 = m_status3 & BIT6 ? IDB_CHKBOX_CHECKED : IDB_CHKBOX_UNCHECKED;	// Courier
	UINT mID7 = m_status1 & BIT4 ? IDB_CHKBOX_CHECKED : IDB_CHKBOX_UNCHECKED;	// Maintenance

	CString str;
	str.Format( 
			_T("<Border Padding='1' BorderThickness='1' BorderBrush='#767600' Background='#ffffef'>")
			_T("<StackPanel TextBlock.FontFamily='Tahoma' TextBlock.FontSize='11'>")
			_T("   <TextBlock Padding='1, 1, 1, 1' FontWeight='Bold'>%s</TextBlock>")
			_T("   <Border Height='1' Background='#9ebbdd' />")
			_T("   <Border Height='1' Background='White' />")
			_T(" <StackPanel Orientation='Horizontal' TextBlock.FontFamily='Tahoma'>")
			_T("   <StackPanel Margin='0, 0, 0, 0' Orientation='Vertical'>")
			_T("       <StackPanel Margin='20, 4, 20, 4' Orientation='Horizontal'>")
			_T("	       <Image Source='%d'/>")
			_T("           <TextBlock Margin='5, 0, 0, 0' VerticalAlignment='Center'>%s</TextBlock>")
			_T("       </StackPanel>")
			_T("       <StackPanel Margin='20, 4, 20, 4' Orientation='Horizontal'>")
			_T("	       <Image Source='%d'/>")
			_T("           <TextBlock Margin='5, 0, 0, 0' VerticalAlignment='Center'>%s</TextBlock>")
			_T("       </StackPanel>")
			_T("       <StackPanel Margin='20, 4, 20, 4' Orientation='Horizontal'>")
			_T("	       <Image Source='%d'/>")
			_T("           <TextBlock Margin='5, 0, 0, 0' VerticalAlignment='Center'>%s</TextBlock>")
			_T("       </StackPanel>")
			_T("       <StackPanel Margin='20, 4, 20, 4' Orientation='Horizontal'>")
			_T("	       <Image Source='%d'/>")
			_T("           <TextBlock Margin='5, 0, 0, 0' VerticalAlignment='Center'>%s</TextBlock>")
			_T("       </StackPanel>")
			_T("       <StackPanel Margin='20, 4, 20, 4' Orientation='Horizontal'>")
			_T("	       <Image Source='%d'/>")
			_T("           <TextBlock Margin='5, 0, 0, 0' VerticalAlignment='Center'>%s</TextBlock>")
			_T("       </StackPanel>")
			_T("       <StackPanel Margin='20, 4, 20, 4' Orientation='Horizontal'>")
			_T("	       <Image Source='%d'/>")
			_T("           <TextBlock Margin='5, 0, 0, 0' VerticalAlignment='Center'>%s</TextBlock>")
			_T("       </StackPanel>")
			_T("       <StackPanel Margin='20, 4, 20, 4' Orientation='Horizontal'>")
			_T("	       <Image Source='%d'/>")
			_T("           <TextBlock Margin='5, 0, 0, 0' VerticalAlignment='Center'>%s</TextBlock>")
			_T("       </StackPanel>")
			_T("       <StackPanel Margin='20, 4, 20, 4' Orientation='Horizontal'>")
			_T("	       <Image Source='%d'/>")
			_T("           <TextBlock Margin='5, 0, 0, 0' VerticalAlignment='Center'>%s</TextBlock>")
			_T("       </StackPanel>")
			_T("   </StackPanel>")
			_T("   <StackPanel Margin='0, 0, 0, 0' Orientation='Vertical'>")
			_T("       <StackPanel Margin='20, 4, 20, 4' Orientation='Horizontal'>")
			_T("	       <Image Source='%d'/>")
			_T("           <TextBlock Margin='5, 0, 0, 0' VerticalAlignment='Center'>%s</TextBlock>")
			_T("       </StackPanel>")
			_T("       <StackPanel Margin='20, 4, 20, 4' Orientation='Horizontal'>")
			_T("	       <Image Source='%d'/>")
			_T("           <TextBlock Margin='5, 0, 0, 0' VerticalAlignment='Center'>%s</TextBlock>")
			_T("       </StackPanel>")
			_T("       <StackPanel Margin='20, 4, 20, 4' Orientation='Horizontal'>")
			_T("	       <Image Source='%d'/>")
			_T("           <TextBlock Margin='5, 0, 0, 0' VerticalAlignment='Center'>%s</TextBlock>")
			_T("       </StackPanel>")
			_T("       <StackPanel Margin='20, 4, 20, 4' Orientation='Horizontal'>")
			_T("	       <Image Source='%d'/>")
			_T("           <TextBlock Margin='5, 0, 0, 0' VerticalAlignment='Center'>%s</TextBlock>")
			_T("       </StackPanel>")
			_T("       <StackPanel Margin='20, 4, 20, 4' Orientation='Horizontal'>")
			_T("	       <Image Source='%d'/>")
			_T("           <TextBlock Margin='5, 0, 0, 0' VerticalAlignment='Center'>%s</TextBlock>")
			_T("       </StackPanel>")
			_T("       <StackPanel Margin='20, 4, 20, 4' Orientation='Horizontal'>")
			_T("	       <Image Source='%d'/>")
			_T("           <TextBlock Margin='5, 0, 0, 0' VerticalAlignment='Center'>%s</TextBlock>")
			_T("       </StackPanel>")
			_T("       <StackPanel Margin='20, 4, 20, 4' Orientation='Horizontal'>")
			_T("	       <Image Source='%d'/>")
			_T("           <TextBlock Margin='5, 0, 0, 0' VerticalAlignment='Center'>%s</TextBlock>")
			_T("       </StackPanel>")
			_T("   </StackPanel>")
			_T(" </StackPanel>")
			_T("</StackPanel>")
			_T("</Border>"), RES_STRING(IDS_SUB_STATUS), 
			nID1, RES_STRING(IDS_PROGRAM), 
			nID2, RES_STRING(IDS_EXTERN_ATM), 
			nID3, RES_STRING(IDS_INTERN_ATM), 
			nID4, RES_STRING(IDS_EXTERN_CLNR), 
			nID5, RES_STRING(IDS_INTERN_CLNR), 
			nID6, RES_STRING(IDS_MANAGEMENT), 
			nID7, RES_STRING(IDS_ATM_DURESS),
			nID8, RES_STRING(IDS_CLNR_DURESS),
			mID1, RES_STRING(IDS_MAINT_DURESS),
			mID2, RES_STRING(IDS_AUX_MODE_1),
			mID3, RES_STRING(IDS_AUX_MODE_2),
			mID4, RES_STRING(IDS_SUB_AREA),
			mID5, RES_STRING(IDS_GUARD),
			mID6, RES_STRING(IDS_COURIER),
			mID7, RES_STRING(IDS_MAINTENANCE)
		);

	return str;
}

void CRtuModePage2::OnUpDownModeSts(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_UPDOWN* pNMUpDown = (NM_UPDOWN*)pNMHDR;
	// TODO: Add your control notification handler code here
	if (pNMUpDown->iDelta == 1) {
		if (--m_nCurArea < 0)
			m_nCurArea = m_nNumAreas - 1;
	}
	else {
		if (++m_nCurArea >= m_nNumAreas)
			m_nCurArea = 0;
	}
	ShowStatusNum(m_nCurArea);

	*pResult = 0;
}

void CRtuModePage2::Print()
{
	TCHAR fname[MAX_PATH] = _T("");
	if (!RtuLib::GetPrintFileName(fname, _T(".html")))
		return;

	CHtmlFile* pFile = new CHtmlFile(hrInst, fname);

	pFile->StartTags(IsRtu8002Type()? RTU_8002_TYPE: realRtuType, gRtuNo, IDS_RTU_STATUS, IDS_MODE_STATUS);

	CString sYes = RES_STRING(IDS_YES_TXT);
	CString sNo = RES_STRING(IDS_NO_TXT);
	CString sArea = RES_STRING(IDS_AREA);
	CString sMainSts = RES_STRING(IDS_MAIN_STATUS);
	CString sSubSts = RES_STRING(IDS_SUB_STATUS);
	CString sTmp;

	BYTE b1, b2, b3;
	for(int i=0; i<m_nNumAreas; i++) {
		int index = i*3;
		b1 = m_modeStatus[index];
		b2 = m_modeStatus[index+1];
		b3 = m_modeStatus[index+2];

		pFile->SetBgColor(colors[i & 1 ? 1 : 0]);
		sTmp.Format(_T("%s %d"), (LPCTSTR)sArea, i+1);
		pFile->AddTH(2, ROW_SPAN | 25, sTmp, COL_SPAN|2, sMainSts);

		pFile->AddRowResID1(IDS_MODE_DAY, b1 & BIT0 ? sYes : sNo);
		pFile->AddRowResID1(IDS_MODE_NIGHT, b1 & BIT1 ? sYes : sNo);
		pFile->AddRowResID1(IDS_MODE_REST, b3 & BIT1 ? sYes : sNo);
		pFile->AddRowResID1(IDS_RES_TYPE_ENG, b1 & BIT7 ? sYes : sNo);
		pFile->AddRowResID1(IDS_MODE_CLNR, b1 & BIT3 ? sYes : sNo);
		pFile->AddRowResID1(IDS_TEST, b1 & BIT5 ? sYes : sNo);
		pFile->AddRowResID1(IDS_DURESS, b2 & BIT5 ? sYes : sNo);
		pFile->AddRowResID1(IDS_MODE_ATM, b1 & BIT2 ? sYes : sNo);

		pFile->AddTH(1, COL_SPAN|2, sSubSts);
		pFile->AddRowResID1(IDS_PROGRAM, b2 & BIT0 ? sYes : sNo);
		pFile->AddRowResID1(IDS_EXTERN_ATM, b2 & BIT1 ? sYes : sNo);
		pFile->AddRowResID1(IDS_INTERN_ATM, b2 & BIT2 ? sYes : sNo);
		pFile->AddRowResID1(IDS_EXTERN_CLNR, b2 & BIT3 ? sYes : sNo);
		pFile->AddRowResID1(IDS_INTERN_CLNR, b2 & BIT4 ? sYes : sNo);
		pFile->AddRowResID1(IDS_MANAGEMENT, b1 & BIT6 ? sYes : sNo);
		pFile->AddRowResID1(IDS_ATM_DURESS, b2 & BIT6 ? sYes : sNo);
		pFile->AddRowResID1(IDS_CLNR_DURESS, b2 & BIT7 ? sYes : sNo);
		pFile->AddRowResID1(IDS_MAINT_DURESS, b3 & BIT0 ? sYes : sNo);
		pFile->AddRowResID1(IDS_AUX_MODE_1, b3 & BIT2 ? sYes : sNo);
		pFile->AddRowResID1(IDS_AUX_MODE_2, b3 & BIT3 ? sYes : sNo);
		pFile->AddRowResID1(IDS_SUB_AREA, b3 & BIT4 ? sYes : sNo);
		pFile->AddRowResID1(IDS_GUARD, b3 & BIT5 ? sYes : sNo);
		pFile->AddRowResID1(IDS_COURIER, b3 & BIT6 ? sYes : sNo);
		pFile->AddRowResID1(IDS_MAINTENANCE, b1 & BIT4 ? sYes : sNo);

	}
		
	pFile->EndTags(); delete pFile; pFile = NULL;
	RtuLib::FileExecute(GetSafeHwnd(), fname, _T("open"));
}

#pragma endregion CRtuModePage2

/*------------------------------------------------------------------------------*/
/*					New Panel Page Class										*/
/*------------------------------------------------------------------------------*/
#pragma region CRtuPanelPage2
IMPLEMENT_DYNCREATE(CRtuPanelPage2, CXTPPropertyPage)

void CRtuPanelPage2::DoDataExchange(CDataExchange* pDX)
{
	CXTPPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CRtuPanelPage2)
	//DDX_Control(pDX, IDC_RTUSTAT_DIPSW, m_btnDipSw);
	DDX_Control(pDX, IDC_LBL_POWER_STATUS, m_lblPowerStatus);
	DDX_Control(pDX, IDC_LBL_NETWORK_STATUS, m_lblNetworkStatus);
	DDX_Control(pDX, IDC_LBL_TAMPER_STATUS, m_lblTamperStatus);
	DDX_Control(pDX, IDC_LBL_REMOTE_PANEL_STATUS, m_lblRemotePanelStatus);
	DDX_Control(pDX, IDC_LBL_GRAPHICS_STATUS, m_lblGraphicsStatus);
	DDX_Control(pDX, IDC_LBL_GENERAL_STATUS, m_lblGeneralStatus);
	DDX_Control(pDX, IDC_LBL_WITNESS, m_lblWitness);
	DDX_Control(pDX, IDC_LBL_DIP_SWITCH, m_lblDipSwitch);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CRtuPanelPage2, CXTPPropertyPage)
	//{{AFX_MSG_MAP(CRtuPanelPage2)	
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CRtuPanelPage2 message handlers
/////////////////////////////////////////////////////////////////////////////
BOOL CRtuPanelPage2::OnInitDialog()
{
	CDialog::OnInitDialog();

	return TRUE;
}

BOOL CRtuPanelPage2::OnSetActive()
{
	ShowStatus();
	return CXTPPropertyPage::OnSetActive();
}

void CRtuPanelPage2::ShowPowerStatus()
{
	CString str;
	UINT nAcFailID = m_panelStatus.byte1 & BIT0 ? IDB_CHKBOX_CHECKED : IDB_CHKBOX_UNCHECKED;
	UINT nBattLowID = m_panelStatus.byte1 & BIT1 ? IDB_CHKBOX_CHECKED : IDB_CHKBOX_UNCHECKED;
	UINT nSecSupFailID = m_panelStatus.byte1 & BIT2 ? IDB_CHKBOX_CHECKED : IDB_CHKBOX_UNCHECKED;
	UINT nTerSupFailID = m_panelStatus.byte1 & BIT3 ? IDB_CHKBOX_CHECKED : IDB_CHKBOX_UNCHECKED;
	
	UINT nAcFailIsolID = m_panelStatus.byte4 & BIT6 ? IDB_CHKBOX_CHECKED : IDB_CHKBOX_UNCHECKED;
	UINT nBattLowIsolID = m_panelStatus.byte4 & BIT7 ? IDB_CHKBOX_CHECKED : IDB_CHKBOX_UNCHECKED;
	UINT nIntLitBattPrbID = m_panelStatus.byte4 & BIT4 ? IDB_CHKBOX_CHECKED : IDB_CHKBOX_UNCHECKED;
	UINT nExpBrdBattPrbID = m_panelStatus.byte4 & BIT5 ? IDB_CHKBOX_CHECKED : IDB_CHKBOX_UNCHECKED;

	if (m_bIs1060Panel) {
		str.Format( 
			_T("<Border Padding='1' BorderThickness='1' BorderBrush='#767676' Background='#e4ecf7'>")
			_T("<StackPanel TextBlock.FontFamily='Tahoma' TextBlock.FontSize='11'>")
			_T("   <TextBlock Padding='1, 1, 1, 1' FontWeight='Bold'>%s</TextBlock>")
			_T("   <Border Height='1' Background='#9ebbdd' />")
			_T("   <Border Height='1' Background='White' />")
			_T("   <StackPanel Margin='20, 4, 0, 0' Orientation='Horizontal'>")
			_T("	   <Image Source='%d'/>")
			_T("       <TextBlock Margin='5, 0, 0, 0' VerticalAlignment='Center'>%s</TextBlock>")
			_T("   </StackPanel>")
			_T("   <StackPanel Margin='20, 4, 0, 0' Orientation='Horizontal'>")
			_T("	   <Image Source='%d'/>")
			_T("       <TextBlock Margin='5, 0, 0, 0' VerticalAlignment='Center'>%s</TextBlock>")
			_T("   </StackPanel>")
			_T("   <StackPanel Margin='20, 4, 0, 0' Orientation='Horizontal'>")
			_T("	   <Image Source='%d'/>")
			_T("       <TextBlock Margin='5, 0, 0, 0' VerticalAlignment='Center'>%s</TextBlock>")
			_T("   </StackPanel>")
			_T("   <StackPanel Margin='20, 4, 0, 0' Orientation='Horizontal'>")
			_T("	   <Image Source='%d'/>")
			_T("       <TextBlock Margin='5, 0, 0, 0' VerticalAlignment='Center'>%s</TextBlock>")
			_T("   </StackPanel>")
			_T("   <StackPanel Margin='20, 4, 0, 0' Orientation='Horizontal'>")
			_T("	   <Image Source='%d'/>")
			_T("       <TextBlock Margin='5, 0, 0, 0' VerticalAlignment='Center'>%s</TextBlock>")
			_T("   </StackPanel>")
			_T("   <StackPanel Margin='20, 4, 0, 0' Orientation='Horizontal'>")
			_T("	   <Image Source='%d'/>")
			_T("       <TextBlock Margin='5, 0, 0, 0' VerticalAlignment='Center'>%s</TextBlock>")
			_T("   </StackPanel>")
			_T("</StackPanel>")
			_T("</Border>"), RES_STRING(IDS_POWER_STS), 
			nAcFailID, RES_STRING(IDS_AC_FAIL), 
			nBattLowID, RES_STRING(IDS_BATT_LOW),
			nSecSupFailID, RES_STRING(IDS_SEC_SUP_FAIL),
			nTerSupFailID, RES_STRING(IDS_TER_SUP_FAIL),
			nAcFailIsolID, RES_STRING(IDS_AC_FAIL_ISOL),
			nBattLowIsolID, RES_STRING(IDS_BATT_LOW_ISOL)
		);
	}
	else {
		str.Format( 
			_T("<Border Padding='1' BorderThickness='1' BorderBrush='#767676' Background='#e4ecf7'>")
			_T("<StackPanel TextBlock.FontFamily='Tahoma' TextBlock.FontSize='11'>")
			_T("   <TextBlock Padding='1, 1, 1, 1' FontWeight='Bold'>%s</TextBlock>")
			_T("   <Border Height='1' Background='#9ebbdd' />")
			_T("   <Border Height='1' Background='White' />")
			_T("   <StackPanel Margin='20, 4, 0, 0' Orientation='Horizontal'>")
			_T("	   <Image Source='%d'/>")
			_T("       <TextBlock Margin='5, 0, 0, 0' VerticalAlignment='Center'>%s</TextBlock>")
			_T("   </StackPanel>")
			_T("   <StackPanel Margin='20, 4, 0, 0' Orientation='Horizontal'>")
			_T("	   <Image Source='%d'/>")
			_T("       <TextBlock Margin='5, 0, 0, 0' VerticalAlignment='Center'>%s</TextBlock>")
			_T("   </StackPanel>")
			_T("   <StackPanel Margin='20, 4, 0, 0' Orientation='Horizontal'>")
			_T("	   <Image Source='%d'/>")
			_T("       <TextBlock Margin='5, 0, 0, 0' VerticalAlignment='Center'>%s</TextBlock>")
			_T("   </StackPanel>")
			_T("   <StackPanel Margin='20, 4, 0, 0' Orientation='Horizontal'>")
			_T("	   <Image Source='%d'/>")
			_T("       <TextBlock Margin='5, 0, 0, 0' VerticalAlignment='Center'>%s</TextBlock>")
			_T("   </StackPanel>")
			_T("   <StackPanel Margin='20, 4, 0, 0' Orientation='Horizontal'>")
			_T("	   <Image Source='%d'/>")
			_T("       <TextBlock Margin='5, 0, 0, 0' VerticalAlignment='Center'>%s</TextBlock>")
			_T("   </StackPanel>")
			_T("   <StackPanel Margin='20, 4, 0, 0' Orientation='Horizontal'>")
			_T("	   <Image Source='%d'/>")
			_T("       <TextBlock Margin='5, 0, 0, 0' VerticalAlignment='Center'>%s</TextBlock>")
			_T("   </StackPanel>")
			_T("   <StackPanel Margin='20, 4, 0, 0' Orientation='Horizontal'>")
			_T("	   <Image Source='%d'/>")
			_T("       <TextBlock Margin='5, 0, 0, 0' VerticalAlignment='Center'>%s</TextBlock>")
			_T("   </StackPanel>")
			_T("   <StackPanel Margin='20, 4, 0, 0' Orientation='Horizontal'>")
			_T("	   <Image Source='%d'/>")
			_T("       <TextBlock Margin='5, 0, 0, 0' VerticalAlignment='Center'>%s</TextBlock>")
			_T("   </StackPanel>")
			_T("</StackPanel>")
			_T("</Border>"), RES_STRING(IDS_POWER_STS), 
			nAcFailID, RES_STRING(IDS_AC_FAIL), 
			nBattLowID, RES_STRING(IDS_BATT_LOW),
			nSecSupFailID, RES_STRING(IDS_SEC_SUP_FAIL),
			nTerSupFailID, RES_STRING(IDS_TER_SUP_FAIL),
			nAcFailIsolID, RES_STRING(IDS_AC_FAIL_ISOL),
			nBattLowIsolID, RES_STRING(IDS_BATT_LOW_ISOL),
			nIntLitBattPrbID, RES_STRING(IDS_INT_LITH_BATT_PROBLEM),
			nExpBrdBattPrbID, RES_STRING(IDS_EXT_LITH_BATT_PROBLEM)
		);
	}

	m_lblPowerStatus.SetMarkupText(str);
	m_lblPowerStatus.SetFont(this->GetFont());
}

void CRtuPanelPage2::ShowNetworkStatus()
{
	CString str;
	
	UINT nID1 = m_panelStatus.byte2 & BIT0 ? IDB_CHKBOX_CHECKED : IDB_CHKBOX_UNCHECKED;
	UINT nID2 = m_panelStatus.byte2 & BIT1 ? IDB_CHKBOX_CHECKED : IDB_CHKBOX_UNCHECKED;
	UINT nID3 = m_panelStatus.byte2 & BIT2 ? IDB_CHKBOX_CHECKED : IDB_CHKBOX_UNCHECKED;
	UINT nID4 = m_panelStatus.byte2 & BIT3 ? IDB_CHKBOX_CHECKED : IDB_CHKBOX_UNCHECKED;
	UINT nID5 = m_panelStatus.byte2 & BIT4 ? IDB_CHKBOX_CHECKED : IDB_CHKBOX_UNCHECKED;
	UINT nID6 = m_panelStatus.byte2 & BIT5 ? IDB_CHKBOX_CHECKED : IDB_CHKBOX_UNCHECKED;
	UINT nID7 = m_panelStatus.byte2 & BIT6 ? IDB_CHKBOX_CHECKED : IDB_CHKBOX_UNCHECKED;
	UINT nID8 = m_panelStatus.byte2 & BIT7 ? IDB_CHKBOX_CHECKED : IDB_CHKBOX_UNCHECKED;

	UINT mID1 = m_panelStatus.lineStat & BIT3 ? IDB_CHKBOX_CHECKED : IDB_CHKBOX_UNCHECKED;
	UINT mID2 = m_panelStatus.lineStat & BIT4 ? IDB_CHKBOX_CHECKED : IDB_CHKBOX_UNCHECKED;
	UINT mID3 = m_panelStatus.lineStat & BIT5 ? IDB_CHKBOX_CHECKED : IDB_CHKBOX_UNCHECKED;
	UINT mID4 = m_panelStatus.lineStat & BIT6 ? IDB_CHKBOX_CHECKED : IDB_CHKBOX_UNCHECKED;
	UINT mID5 = m_panelStatus.lineStat & BIT7 ? IDB_CHKBOX_CHECKED : IDB_CHKBOX_UNCHECKED;

	if (m_bIs1060Panel) {
		str.Format( 
			_T("<Border Padding='1' BorderThickness='1' BorderBrush='#767676' Background='#e4ecf7'>")
			_T("<StackPanel TextBlock.FontFamily='Tahoma' TextBlock.FontSize='11'>")
			_T("   <TextBlock Padding='1, 1, 1, 1' FontWeight='Bold'>%s</TextBlock>")
			_T("   <Border Height='1' Background='#9ebbdd' />")
			_T("   <Border Height='1' Background='White' />")
			_T(" <StackPanel Orientation='Horizontal' TextBlock.FontFamily='Tahoma'>")
			_T("   <StackPanel Margin='20, 2, 0, 0' Orientation='Vertical'>")
			_T("       <StackPanel Margin='0, 4, 0, 0' Orientation='Horizontal'>")
			_T("	       <Image Source='%d'/>")
			_T("           <TextBlock Margin='5, 0, 0, 0' VerticalAlignment='Center'>%s</TextBlock>")
			_T("       </StackPanel>")
			_T("       <StackPanel Margin='0, 4, 0, 0' Orientation='Horizontal'>")
			_T("	       <Image Source='%d'/>")
			_T("           <TextBlock Margin='5, 0, 0, 0' VerticalAlignment='Center'>%s</TextBlock>")
			_T("       </StackPanel>")
			_T("       <StackPanel Margin='0, 4, 0, 0' Orientation='Horizontal'>")
			_T("	       <Image Source='%d'/>")
			_T("           <TextBlock Margin='5, 0, 0, 0' VerticalAlignment='Center'>%s</TextBlock>")
			_T("       </StackPanel>")
			_T("       <StackPanel Margin='0, 4, 0, 0' Orientation='Horizontal'>")
			_T("	       <Image Source='%d'/>")
			_T("           <TextBlock Margin='5, 0, 0, 0' VerticalAlignment='Center'>%s</TextBlock>")
			_T("       </StackPanel>")
			_T("       <StackPanel Margin='0, 4, 0, 0' Orientation='Horizontal'>")
			_T("	       <Image Source='%d'/>")
			_T("           <TextBlock Margin='5, 0, 0, 0' VerticalAlignment='Center'>%s</TextBlock>")
			_T("       </StackPanel>")
			_T("       <StackPanel Margin='0, 4, 0, 0' Orientation='Horizontal'>")
			_T("	       <Image Source='%d'/>")
			_T("           <TextBlock Margin='5, 0, 0, 0' VerticalAlignment='Center'>%s</TextBlock>")
			_T("       </StackPanel>")
			_T("       <StackPanel Margin='0, 4, 0, 0' Orientation='Horizontal'>")
			_T("	       <Image Source='%d'/>")
			_T("           <TextBlock Margin='5, 0, 0, 0' VerticalAlignment='Center'>%s</TextBlock>")
			_T("       </StackPanel>")
			_T("       <StackPanel Margin='0, 4, 0, 0' Orientation='Horizontal'>")
			_T("	       <Image Source='%d'/>")
			_T("           <TextBlock Margin='5, 0, 0, 0' VerticalAlignment='Center'>%s</TextBlock>")
			_T("       </StackPanel>")
			_T("   </StackPanel>")
			_T("   <StackPanel Margin='20, 2, 0, 0' Orientation='Vertical'>")
			_T("       <StackPanel Margin='0, 4, 0, 0' Orientation='Horizontal'>")
			_T("	       <Image Source='%d'/>")
			_T("           <TextBlock Margin='5, 0, 0, 0' VerticalAlignment='Center'>%s</TextBlock>")
			_T("       </StackPanel>")
			_T("       <StackPanel Margin='0, 4, 0, 0' Orientation='Horizontal'>")
			_T("	       <Image Source='%d'/>")
			_T("           <TextBlock Margin='5, 0, 0, 0' VerticalAlignment='Center'>%s</TextBlock>")
			_T("       </StackPanel>")
			_T("       <StackPanel Margin='0, 4, 0, 0' Orientation='Horizontal'>")
			_T("	       <Image Source='%d'/>")
			_T("           <TextBlock Margin='5, 0, 0, 0' VerticalAlignment='Center'>%s</TextBlock>")
			_T("       </StackPanel>")
			_T("       <StackPanel Margin='0, 4, 0, 0' Orientation='Horizontal'>")
			_T("	       <Image Source='%d'/>")
			_T("           <TextBlock Margin='5, 0, 0, 0' VerticalAlignment='Center'>%s</TextBlock>")
			_T("       </StackPanel>")
			_T("       <StackPanel Margin='0, 4, 0, 0' Orientation='Horizontal'>")
			_T("	       <Image Source='%d'/>")
			_T("           <TextBlock Margin='5, 0, 0, 0' VerticalAlignment='Center'>%s</TextBlock>")
			_T("       </StackPanel>")
			_T("   </StackPanel>")
			_T(" </StackPanel>")
			_T("</StackPanel>")
			_T("</Border>"), RES_STRING(IDS_NW_STS), 
			nID1, RES_STRING(IDS_DATA_LINE_FAIL), 
			nID2, RES_STRING(IDS_MODEM_FAIL), 
			nID3, RES_STRING(IDS_CTRLR_FAIL), 
			nID4, RES_STRING(IDS_CTRLR_DEACT), 
			nID5, RES_STRING(IDS_DLU_POLL_ACT), 
			nID6, RES_STRING(IDS_ON_DIALUP), 
			nID7, RES_STRING(IDS_TEL_LINE_FAIL),
			nID8, RES_STRING(IDS_CTRLR_ADDR_VAL),
			mID4, RES_STRING(IDS_SEC_FAIL),
			mID5, RES_STRING(IDS_SEC_ONLINE),
			mID1, RES_STRING(IDS_TER_ACTIVE),
			mID2, RES_STRING(IDS_TER_FAIL),
			mID3, RES_STRING(IDS_TER_ONLINE)
			
		);
	}
	else {
		str.Format( 
			_T("<Border Padding='1' BorderThickness='1' BorderBrush='#767676' Background='#e4ecf7'>")
			_T("<StackPanel TextBlock.FontFamily='Tahoma' TextBlock.FontSize='11'>")
			_T("   <TextBlock Padding='1, 1, 1, 1' FontWeight='Bold'>%s</TextBlock>")
			_T("   <Border Height='1' Background='#9ebbdd' />")
			_T("   <Border Height='1' Background='White' />")
			_T(" <StackPanel Orientation='Horizontal' TextBlock.FontFamily='Tahoma'>")
			_T("   <StackPanel Margin='20, 2, 0, 0' Orientation='Vertical'>")
			_T("       <StackPanel Margin='0, 4, 0, 0' Orientation='Horizontal'>")
			_T("	       <Image Source='%d'/>")
			_T("           <TextBlock Margin='5, 0, 0, 0' VerticalAlignment='Center'>%s</TextBlock>")
			_T("       </StackPanel>")
			_T("       <StackPanel Margin='0, 4, 0, 0' Orientation='Horizontal'>")
			_T("	       <Image Source='%d'/>")
			_T("           <TextBlock Margin='5, 0, 0, 0' VerticalAlignment='Center'>%s</TextBlock>")
			_T("       </StackPanel>")
			_T("       <StackPanel Margin='0, 4, 0, 0' Orientation='Horizontal'>")
			_T("	       <Image Source='%d'/>")
			_T("           <TextBlock Margin='5, 0, 0, 0' VerticalAlignment='Center'>%s</TextBlock>")
			_T("       </StackPanel>")
			_T("       <StackPanel Margin='0, 4, 0, 0' Orientation='Horizontal'>")
			_T("	       <Image Source='%d'/>")
			_T("           <TextBlock Margin='5, 0, 0, 0' VerticalAlignment='Center'>%s</TextBlock>")
			_T("       </StackPanel>")
			_T("       <StackPanel Margin='0, 4, 0, 0' Orientation='Horizontal'>")
			_T("	       <Image Source='%d'/>")
			_T("           <TextBlock Margin='5, 0, 0, 0' VerticalAlignment='Center'>%s</TextBlock>")
			_T("       </StackPanel>")
			_T("       <StackPanel Margin='0, 4, 0, 0' Orientation='Horizontal'>")
			_T("	       <Image Source='%d'/>")
			_T("           <TextBlock Margin='5, 0, 0, 0' VerticalAlignment='Center'>%s</TextBlock>")
			_T("       </StackPanel>")
			_T("   </StackPanel>")
			_T("   <StackPanel Margin='20, 2, 0, 0' Orientation='Vertical'>")
			_T("       <StackPanel Margin='0, 4, 0, 0' Orientation='Horizontal'>")
			_T("	       <Image Source='%d'/>")
			_T("           <TextBlock Margin='5, 0, 0, 0' VerticalAlignment='Center'>%s</TextBlock>")
			_T("       </StackPanel>")
			_T("       <StackPanel Margin='0, 4, 0, 0' Orientation='Horizontal'>")
			_T("	       <Image Source='%d'/>")
			_T("           <TextBlock Margin='5, 0, 0, 0' VerticalAlignment='Center'>%s</TextBlock>")
			_T("       </StackPanel>")
			_T("       <StackPanel Margin='0, 4, 0, 0' Orientation='Horizontal'>")
			_T("	       <Image Source='%d'/>")
			_T("           <TextBlock Margin='5, 0, 0, 0' VerticalAlignment='Center'>%s</TextBlock>")
			_T("       </StackPanel>")
			_T("       <StackPanel Margin='0, 4, 0, 0' Orientation='Horizontal'>")
			_T("	       <Image Source='%d'/>")
			_T("           <TextBlock Margin='5, 0, 0, 0' VerticalAlignment='Center'>%s</TextBlock>")
			_T("       </StackPanel>")
			_T("       <StackPanel Margin='0, 4, 0, 0' Orientation='Horizontal'>")
			_T("	       <Image Source='%d'/>")
			_T("           <TextBlock Margin='5, 0, 0, 0' VerticalAlignment='Center'>%s</TextBlock>")
			_T("       </StackPanel>")
			_T("       <StackPanel Margin='0, 4, 0, 0' Orientation='Horizontal'>")
			_T("	       <Image Source='%d'/>")
			_T("           <TextBlock Margin='5, 0, 0, 0' VerticalAlignment='Center'>%s</TextBlock>")
			_T("       </StackPanel>")
			_T("   </StackPanel>")
			_T(" </StackPanel>")
			_T("</StackPanel>")
			_T("</Border>"), RES_STRING(IDS_NW_STS), 
			nID1, RES_STRING(IDS_PRI_PORT_PHYS_LYR_FAIL), 
			nID2, RES_STRING(IDS_PRI_PORT_DRV_FAIL), 
			nID3, RES_STRING(IDS_PRI_PORT_LNK_LYR_FAIL), 
			nID4, RES_STRING(IDS_PRI_PORT_SES_LYR_FAIL), 
			nID6, RES_STRING(IDS_ON_DIALUP), 
			nID7, RES_STRING(IDS_DIALUP_FAIL),
			nID8, RES_STRING(IDS_SEC_ACTIVE),
			mID4, RES_STRING(IDS_SEC_FAIL),
			mID5, RES_STRING(IDS_SEC_ONLINE),
			mID1, RES_STRING(IDS_TER_ACTIVE),
			mID2, RES_STRING(IDS_TER_FAIL),
			mID3, RES_STRING(IDS_TER_ONLINE)			
		);
	}

	m_lblNetworkStatus.SetMarkupText(str);
}

void CRtuPanelPage2::ShowTamperStatus()
{
	CString str;
	UINT nID1 = m_panelStatus.byte3 & BIT0 ? IDB_CHKBOX_CHECKED : IDB_CHKBOX_UNCHECKED;
	UINT nID2 = m_panelStatus.byte3 & BIT1 ? IDB_CHKBOX_CHECKED : IDB_CHKBOX_UNCHECKED;
	UINT nID3 = m_panelStatus.byte3 & BIT2 ? IDB_CHKBOX_CHECKED : IDB_CHKBOX_UNCHECKED;
	UINT nID4 = m_panelStatus.byte3 & BIT3 ? IDB_CHKBOX_CHECKED : IDB_CHKBOX_UNCHECKED;
	UINT nID5 = m_panelStatus.byte3 & BIT4 ? IDB_CHKBOX_CHECKED : IDB_CHKBOX_UNCHECKED;
	UINT nID6 = m_panelStatus.byte3 & BIT5 ? IDB_CHKBOX_CHECKED : IDB_CHKBOX_UNCHECKED;
	UINT nID7 = m_panelStatus.byte3 & BIT6 ? IDB_CHKBOX_CHECKED : IDB_CHKBOX_UNCHECKED;
	UINT nID8 = m_panelStatus.byte3 & BIT7 ? IDB_CHKBOX_CHECKED : IDB_CHKBOX_UNCHECKED;

	if (m_bIs1060Panel) {
	}
	else {

	}
	str.Format( 
		_T("<Border Padding='1' BorderThickness='1' BorderBrush='#767676' Background='#e4ecf7'>")
		_T("<StackPanel TextBlock.FontFamily='Tahoma' TextBlock.FontSize='11'>")
		_T("   <TextBlock Padding='1, 1, 1, 1' FontWeight='Bold'>%s</TextBlock>")
		_T("   <Border Height='1' Background='#9ebbdd' />")
		_T("   <Border Height='1' Background='White' />")
		_T("   <StackPanel Margin='20, 4, 0, 0' Orientation='Horizontal'>")
		_T("	   <Image Source='%d'/>")
		_T("       <TextBlock Margin='5, 0, 0, 0' VerticalAlignment='Center'>%s</TextBlock>")
		_T("   </StackPanel>")
		_T("   <StackPanel Margin='20, 4, 0, 0' Orientation='Horizontal'>")
		_T("	   <Image Source='%d'/>")
		_T("       <TextBlock Margin='5, 0, 0, 0' VerticalAlignment='Center'>%s</TextBlock>")
		_T("   </StackPanel>")
		_T("   <StackPanel Margin='20, 4, 0, 0' Orientation='Horizontal'>")
		_T("	   <Image Source='%d'/>")
		_T("       <TextBlock Margin='5, 0, 0, 0' VerticalAlignment='Center'>%s</TextBlock>")
		_T("   </StackPanel>")
		_T("   <StackPanel Margin='20, 4, 0, 0' Orientation='Horizontal'>")
		_T("	   <Image Source='%d'/>")
		_T("       <TextBlock Margin='5, 0, 0, 0' VerticalAlignment='Center'>%s</TextBlock>")
		_T("   </StackPanel>")
		_T("   <StackPanel Margin='20, 4, 0, 0' Orientation='Horizontal'>")
		_T("	   <Image Source='%d'/>")
		_T("       <TextBlock Margin='5, 0, 0, 0' VerticalAlignment='Center'>%s</TextBlock>")
		_T("   </StackPanel>")
		_T("   <StackPanel Margin='20, 4, 0, 0' Orientation='Horizontal'>")
		_T("	   <Image Source='%d'/>")
		_T("       <TextBlock Margin='5, 0, 0, 0' VerticalAlignment='Center'>%s</TextBlock>")
		_T("   </StackPanel>")
		_T("   <StackPanel Margin='20, 4, 0, 0' Orientation='Horizontal'>")
		_T("	   <Image Source='%d'/>")
		_T("       <TextBlock Margin='5, 0, 0, 0' VerticalAlignment='Center'>%s</TextBlock>")
		_T("   </StackPanel>")
		_T("   <StackPanel Margin='20, 4, 0, 0' Orientation='Horizontal'>")
		_T("	   <Image Source='%d'/>")
		_T("       <TextBlock Margin='5, 0, 0, 0' VerticalAlignment='Center'>%s</TextBlock>")
		_T("   </StackPanel>")
		_T("</StackPanel>")
		_T("</Border>"), RES_STRING(IDS_TAMPER_STATUS), 
		nID1, RES_STRING(m_bIs1060Panel ? IDS_MAIN_PORT1_TAMP : IDS_RAP_PORT_TAMPER), 
		nID2, RES_STRING(m_bIs1060Panel ? IDS_MAIN_PORT1_TAMP_ISOL : IDS_RAP_PORT_TAMPER_ISOL),
		nID3, RES_STRING(m_bIs1060Panel ? IDS_MAIN_PORT2_TAMP : IDS_SPARE_SERIAL_TAMPER),
		nID4, RES_STRING(m_bIs1060Panel ? IDS_MAIN_PORT2_TAMP_ISOL : IDS_SPARE_SERIAL_TAMPER_ISOL),
		nID5, RES_STRING(IDS_PANEL_STS_1),
		nID6, RES_STRING(IDS_MAIN_TAMPER_ISOL),
		nID7, RES_STRING(IDS_TERM_UNIT_TAMPER),
		nID8, RES_STRING(IDS_TERM_UNIT_TAMPER_ISOL)
		);
	m_lblTamperStatus.SetMarkupText(str);
}

void CRtuPanelPage2::ShowRemotePanelStatus()
{
	CString str;
	UINT nID1 = m_panelStatus.byte4 & BIT0 ? IDB_CHKBOX_CHECKED : IDB_CHKBOX_UNCHECKED;
	UINT nID2 = m_panelStatus.byte4 & BIT1 ? IDB_CHKBOX_CHECKED : IDB_CHKBOX_UNCHECKED;
	UINT nID3 = m_panelStatus.byte4 & BIT2 ? IDB_CHKBOX_CHECKED : IDB_CHKBOX_UNCHECKED;
	UINT nID4 = m_panelStatus.byte4 & BIT3 ? IDB_CHKBOX_CHECKED : IDB_CHKBOX_UNCHECKED;

	str.Format( 
		_T("<Border Padding='1' BorderThickness='1' BorderBrush='#767676' Background='#e4ecf7'>")
		_T("<StackPanel TextBlock.FontFamily='Tahoma' TextBlock.FontSize='11'>")
		_T("   <TextBlock Padding='1, 1, 1, 1' FontWeight='Bold'>%s</TextBlock>")
		_T("   <Border Height='1' Background='#9ebbdd' />")
		_T("   <Border Height='1' Background='White' />")
		_T("   <StackPanel Margin='20, 4, 0, 0' Orientation='Horizontal'>")
		_T("	   <Image Source='%d'/>")
		_T("       <TextBlock Margin='5, 0, 0, 0' VerticalAlignment='Center'>%s</TextBlock>")
		_T("   </StackPanel>")
		_T("   <StackPanel Margin='20, 4, 0, 0' Orientation='Horizontal'>")
		_T("	   <Image Source='%d'/>")
		_T("       <TextBlock Margin='5, 0, 0, 0' VerticalAlignment='Center'>%s</TextBlock>")
		_T("   </StackPanel>")
		_T("   <StackPanel Margin='20, 4, 0, 0' Orientation='Horizontal'>")
		_T("	   <Image Source='%d'/>")
		_T("       <TextBlock Margin='5, 0, 0, 0' VerticalAlignment='Center'>%s</TextBlock>")
		_T("   </StackPanel>")
		_T("   <StackPanel Margin='20, 4, 0, 0' Orientation='Horizontal'>")
		_T("	   <Image Source='%d'/>")
		_T("       <TextBlock Margin='5, 0, 0, 0' VerticalAlignment='Center'>%s</TextBlock>")
		_T("   </StackPanel>")
		_T("</StackPanel>")
		_T("</Border>"), RES_STRING(IDS_REMOTE_PANAL_STS), 
		nID1, RES_STRING(IDS_REMOTE_PANEL_OFFLINE), 
		nID2, RES_STRING(IDS_REMOTE_PANEL_TAMPER),
		nID3, RES_STRING(IDS_REMOTE_PANEL_AC_FAIL),
		nID4, RES_STRING(IDS_REMOTE_PANEL_BATT_FAIL)
		);
	m_lblRemotePanelStatus.SetMarkupText(str);
}

void CRtuPanelPage2::ShowGraphicsStatus()
{
	CString str;
	UINT nID1 = m_panelStatus.graphStat & BIT0 ? IDB_CHKBOX_CHECKED : IDB_CHKBOX_UNCHECKED;
	UINT nID2 = m_panelStatus.graphStat & BIT1 ? IDB_CHKBOX_CHECKED : IDB_CHKBOX_UNCHECKED;
	UINT nID3 = m_panelStatus.graphStat & BIT2 ? IDB_CHKBOX_CHECKED : IDB_CHKBOX_UNCHECKED;
	UINT nID4 = m_panelStatus.graphStat & BIT3 ? IDB_CHKBOX_CHECKED : IDB_CHKBOX_UNCHECKED;
	UINT nID5 = m_panelStatus.graphStat & BIT4 ? IDB_CHKBOX_CHECKED : IDB_CHKBOX_UNCHECKED;
	UINT nID6 = m_panelStatus.graphStat & BIT5 ? IDB_CHKBOX_CHECKED : IDB_CHKBOX_UNCHECKED;
	UINT nID7 = m_panelStatus.graphStat & BIT6 ? IDB_CHKBOX_CHECKED : IDB_CHKBOX_UNCHECKED;
	UINT nID8 = m_panelStatus.graphStat & BIT7 ? IDB_CHKBOX_CHECKED : IDB_CHKBOX_UNCHECKED;

	str.Format( 
		_T("<Border Padding='1' BorderThickness='1' BorderBrush='#767676' Background='#e4ecf7'>")
		_T("<StackPanel TextBlock.FontFamily='Tahoma' TextBlock.FontSize='11'>")
		_T("   <TextBlock Padding='1, 1, 1, 1' FontWeight='Bold'>%s</TextBlock>")
		_T("   <Border Height='1' Background='#9ebbdd' />")
		_T("   <Border Height='1' Background='White' />")
		_T("   <StackPanel Margin='20, 4, 0, 0' Orientation='Horizontal'>")
		_T("	   <Image Source='%d'/>")
		_T("       <TextBlock Margin='5, 0, 0, 0' VerticalAlignment='Center'>%s</TextBlock>")
		_T("   </StackPanel>")
		_T("   <StackPanel Margin='20, 4, 0, 0' Orientation='Horizontal'>")
		_T("	   <Image Source='%d'/>")
		_T("       <TextBlock Margin='5, 0, 0, 0' VerticalAlignment='Center'>%s</TextBlock>")
		_T("   </StackPanel>")
		_T("   <StackPanel Margin='20, 4, 0, 0' Orientation='Horizontal'>")
		_T("	   <Image Source='%d'/>")
		_T("       <TextBlock Margin='5, 0, 0, 0' VerticalAlignment='Center'>%s</TextBlock>")
		_T("   </StackPanel>")
		_T("   <StackPanel Margin='20, 4, 0, 0' Orientation='Horizontal'>")
		_T("	   <Image Source='%d'/>")
		_T("       <TextBlock Margin='5, 0, 0, 0' VerticalAlignment='Center'>%s</TextBlock>")
		_T("   </StackPanel>")
		_T("   <StackPanel Margin='20, 4, 0, 0' Orientation='Horizontal'>")
		_T("	   <Image Source='%d'/>")
		_T("       <TextBlock Margin='5, 0, 0, 0' VerticalAlignment='Center'>%s</TextBlock>")
		_T("   </StackPanel>")
		_T("   <StackPanel Margin='20, 4, 0, 0' Orientation='Horizontal'>")
		_T("	   <Image Source='%d'/>")
		_T("       <TextBlock Margin='5, 0, 0, 0' VerticalAlignment='Center'>%s</TextBlock>")
		_T("   </StackPanel>")
		_T("   <StackPanel Margin='20, 4, 0, 0' Orientation='Horizontal'>")
		_T("	   <Image Source='%d'/>")
		_T("       <TextBlock Margin='5, 0, 0, 0' VerticalAlignment='Center'>%s</TextBlock>")
		_T("   </StackPanel>")
		_T("   <StackPanel Margin='20, 4, 0, 0' Orientation='Horizontal'>")
		_T("	   <Image Source='%d'/>")
		_T("       <TextBlock Margin='5, 0, 0, 0' VerticalAlignment='Center'>%s</TextBlock>")
		_T("   </StackPanel>")
		_T("</StackPanel>")
		_T("</Border>"), RES_STRING(IDS_GRAPHIC_STS), 
		nID8, RES_STRING(IDS_MAC_GRAPHIC_STS), 
		nID7, RES_STRING(IDS_DURESS_ALM),
		nID6, RES_STRING(IDS_POWER_ALM),
		nID5, RES_STRING(IDS_TEST_MODE),
		nID4, RES_STRING(IDS_PARTIAL_SEAL),
		nID3, RES_STRING(IDS_ZONE_ISOLATED),
		nID2, RES_STRING(IDS_ZONE_ALM),
		nID1, RES_STRING(IDS_NIGHT_MODE)
		);
	m_lblGraphicsStatus.SetMarkupText(str);
}

void CRtuPanelPage2::ShowGeneralStatus()
{
	CStringArray strArrVocList;
	GetVocabList(strArrVocList);
	int i = m_panelStatus.DipnVoc >> 4;
	CString str1; str1.Format(_T("%s: "), RES_STRING(IDS_ALM_VOC_LIST));
	if (i < strArrVocList.GetSize() ) {
		str1 += strArrVocList.GetAt(i);
	}

	gIsCP01Panel = m_panelStatus.spare1 == 4 ? TRUE : FALSE;

	CString str;
	if (m_bIs1060Panel) {
		CString strAddr1; strAddr1.Format(_T("%s: %d"), RES_STRING(IDS_SNA_ADDR_1), m_panelStatus.ExtDevStat);
		CString strAddr2; strAddr2.Format(_T("%s: %d"), RES_STRING(IDS_SNA_ADDR_2), m_panelStatus.spare1);
		CString strRtsCtsDly; strRtsCtsDly.Format(_T("%s: %d"), RES_STRING(IDS_RTS_CTS_DLY), m_panelStatus.spare2);
		UINT nID1 = m_panelStatus.byte1 & BIT4 ? IDB_CHKBOX_CHECKED : IDB_CHKBOX_UNCHECKED;
		UINT nID2 = m_panelStatus.byte1 & BIT5 ? IDB_CHKBOX_CHECKED : IDB_CHKBOX_UNCHECKED;
		UINT nID3 = m_panelStatus.byte1 & BIT6 ? IDB_CHKBOX_CHECKED : IDB_CHKBOX_UNCHECKED;
		UINT nID4 = m_panelStatus.byte1 & BIT7 ? IDB_CHKBOX_CHECKED : IDB_CHKBOX_UNCHECKED;
		str.Format( 
			_T("<Border Padding='1' BorderThickness='1' BorderBrush='#767676' Background='#e4ecf7'>")
			_T("<StackPanel TextBlock.FontFamily='Tahoma' TextBlock.FontSize='11'>")
			_T("   <TextBlock Padding='1, 1, 1, 1' FontWeight='Bold'>%s</TextBlock>")
			_T("   <Border Height='1' Background='#9ebbdd' />")
			_T("   <Border Height='1' Background='White' />")
			_T("   <StackPanel Margin='20, 4, 0, 0' Orientation='Horizontal'>")
			_T("       <TextBlock Margin='5, 0, 0, 0' VerticalAlignment='Center'>%s</TextBlock>")
			_T("   </StackPanel>")
			_T("   <StackPanel Margin='20, 4, 0, 0' Orientation='Horizontal'>")
			_T("       <TextBlock Margin='5, 0, 0, 0' VerticalAlignment='Center'>%s</TextBlock>")
			_T("   </StackPanel>")
			_T("   <StackPanel Margin='20, 4, 0, 0' Orientation='Horizontal'>")
			_T("       <TextBlock Margin='5, 0, 0, 0' VerticalAlignment='Center'>%s</TextBlock>")
			_T("   </StackPanel>")
			_T("   <StackPanel Margin='20, 4, 0, 0' Orientation='Horizontal'>")
			_T("       <TextBlock Margin='5, 0, 0, 0' VerticalAlignment='Center'>%s</TextBlock>")
			_T("   </StackPanel>")
			_T("   <StackPanel Margin='20, 4, 0, 0' Orientation='Horizontal'>")
			_T("	   <Image Source='%d'/>")
			_T("       <TextBlock Margin='5, 0, 0, 0' VerticalAlignment='Center'>%s</TextBlock>")
			_T("   </StackPanel>")
			_T("   <StackPanel Margin='20, 4, 0, 0' Orientation='Horizontal'>")
			_T("	   <Image Source='%d'/>")
			_T("       <TextBlock Margin='5, 0, 0, 0' VerticalAlignment='Center'>%s</TextBlock>")
			_T("   </StackPanel>")
			_T("   <StackPanel Margin='20, 4, 0, 0' Orientation='Horizontal'>")
			_T("	   <Image Source='%d'/>")
			_T("       <TextBlock Margin='5, 0, 0, 0' VerticalAlignment='Center'>%s</TextBlock>")
			_T("   </StackPanel>")
			_T("   <StackPanel Margin='20, 4, 0, 0' Orientation='Horizontal'>")
			_T("	   <Image Source='%d'/>")
			_T("       <TextBlock Margin='5, 0, 0, 0' VerticalAlignment='Center'>%s</TextBlock>")
			_T("   </StackPanel>")
			_T("</StackPanel>")
			_T("</Border>"), 
			RES_STRING(IDS_GENERAL_STS), (LPCTSTR)str1, (LPCTSTR)strAddr1, (LPCTSTR)strAddr2, (LPCTSTR)strRtsCtsDly,
			nID1, RES_STRING(IDS_KPD_LCK_OUT),
			nID2, RES_STRING(IDS_BYPASS_SW),
			nID3, RES_STRING(IDS_CABINET_TAMPER),
			nID4, RES_STRING(IDS_SYS_IN_ALM)
			);
	}
	else {
		CString str2; str2.Format(_T("%s: %s"), RES_STRING(IDS_EXPANSION_MEMORY), (LPCTSTR)GetExpansionMemoryString(&m_panelStatus.ExtDevStat));
		CString str3; str3.Format(_T("%s: %s"), RES_STRING(IDS_ONBOARD_FLASH_MEMORY), (LPCTSTR)GetOnBoardFlashMemoryString(&m_panelStatus.ExtDevStat));
		int nResID = IDS_NORMAL;
		switch(m_panelStatus.spare1) {
			case 0: nResID = IDS_NORMAL;		break;
			case 1: nResID = IDS_1058_BANK_CFG; break;
			case 2: nResID = IDS_EN50131;		break;
			case 3: nResID = IDS_UK_BANK_CFG;	break;
			case 4: nResID = IDS_CP01;			break;
			case 5: nResID = IDS_PAP_EN50131G2_CONFIG;			break; //TT 8055
			case 6: nResID = IDS_PAP_EN50131G4_CONFIG;			break; //TT 8055
			case 7: nResID = IDS_PAP_NFA2P_CONFIG;			break; //TT 8223

			default: nResID = IDS_UNKNOWN;		break;
		}
		CString str4; str4.Format(_T("%s: %s"), RES_STRING(IDS_CUSTOMIZED_PANEL), RES_STRING(nResID));

		str.Format( 
			_T("<Border Padding='1' BorderThickness='1' BorderBrush='#767676' Background='#e4ecf7'>")
			_T("<StackPanel TextBlock.FontFamily='Tahoma' TextBlock.FontSize='11'>")
			_T("   <TextBlock Padding='1, 1, 1, 1' FontWeight='Bold'>%s</TextBlock>")
			_T("   <Border Height='1' Background='#9ebbdd' />")
			_T("   <Border Height='1' Background='White' />")
			_T("   <StackPanel Margin='20, 4, 0, 0' Orientation='Horizontal'>")
			_T("       <TextBlock Margin='5, 0, 0, 0' VerticalAlignment='Center'>%s</TextBlock>")
			_T("   </StackPanel>")
			_T("   <StackPanel Margin='20, 4, 0, 0' Orientation='Horizontal'>")
			_T("       <TextBlock Margin='5, 0, 0, 0' VerticalAlignment='Center'>%s</TextBlock>")
			_T("   </StackPanel>")
			_T("   <StackPanel Margin='20, 4, 0, 0' Orientation='Horizontal'>")
			_T("       <TextBlock Margin='5, 0, 0, 0' VerticalAlignment='Center'>%s</TextBlock>")
			_T("   </StackPanel>")
			_T("   <StackPanel Margin='20, 4, 0, 0' Orientation='Horizontal'>")
			_T("       <TextBlock Margin='5, 0, 0, 0' VerticalAlignment='Center'>%s</TextBlock>")
			_T("   </StackPanel>")
			_T("</StackPanel>")
			_T("</Border>"), 
			RES_STRING(IDS_GENERAL_STS), (LPCTSTR)str1, (LPCTSTR)str2, (LPCTSTR)str3, (LPCTSTR)str4);
	}

	m_lblGeneralStatus.SetMarkupText(str);
}


void CRtuPanelPage2::ShowWitnessControls()
{
	if (realRtuType == RTU_2000_TYPE) {
		CString str;
		UINT nHardDriveOnlineID = m_panelStatus.ExtDevStat & BIT2 ? IDB_CHKBOX_CHECKED : IDB_CHKBOX_UNCHECKED;
		UINT nDaughterBoardOnlineID = m_panelStatus.ExtDevStat & BIT3 ? IDB_CHKBOX_CHECKED : IDB_CHKBOX_UNCHECKED;
		str.Format( 
			_T("<Border Padding='1' BorderThickness='1' BorderBrush='#767676' Background='#e4ecf7'>")
			_T("<StackPanel TextBlock.FontFamily='Tahoma' TextBlock.FontSize='11'>")
			_T("   <TextBlock Padding='1, 1, 1, 1' FontWeight='Bold'>%s</TextBlock>")
			_T("   <Border Height='1' Background='#9ebbdd' />")
			_T("   <Border Height='1' Background='White' />")
			_T("   <StackPanel Margin='20, 4, 0, 0' Orientation='Horizontal'>")
			_T("	   <Image Source='%d'/>")
			_T("       <TextBlock Margin='5, 0, 0, 0' VerticalAlignment='Center'>%s</TextBlock>")
			_T("   </StackPanel>")
			_T("   <StackPanel Margin='20, 4, 0, 0' Orientation='Horizontal'>")
			_T("	   <Image Source='%d'/>")
			_T("       <TextBlock Margin='5, 0, 0, 0' VerticalAlignment='Center'>%s</TextBlock>")
			_T("   </StackPanel>")
			_T("</StackPanel>")
			_T("</Border>"), RES_STRING(IDS_WITNESS_STS), 
			nHardDriveOnlineID, RES_STRING(IDS_HDRIVE_ONLINE), 
			nDaughterBoardOnlineID, RES_STRING(IDS_DBOARD_ONLINE)
		);
		m_lblWitness.SetMarkupText(str);
		m_lblWitness.ShowWindow(SW_SHOW);
	}
	else {
		m_lblWitness.ShowWindow(SW_HIDE);
	}
}

void CRtuPanelPage2::ShowStatus()
{
	if (IsWindow(m_hWnd) == FALSE) return;
	if (!m_bIsValid)
		return;

	if (RtuLib::IsNewControllerType(realRtuType)) {
		m_bIs1060Panel = FALSE;
	}
	else {
		m_bIs1060Panel = TRUE;
	}
		
	ShowPowerStatus();
	ShowNetworkStatus();
	ShowTamperStatus();
	ShowRemotePanelStatus();
	ShowGraphicsStatus();
	ShowGeneralStatus();
	ShowWitnessControls();
	CString str;
	int nDipSwitchIconIndex = IDB_DIP_SW_1 + (m_panelStatus.DipnVoc & 0x0F);
	str.Format( 
		_T("<Border Padding='1' BorderThickness='1' BorderBrush='#767676' Background='#e4ecf7'>")
		_T("<StackPanel TextBlock.FontFamily='Tahoma' TextBlock.FontSize='11'>")
		_T("   <TextBlock Padding='1, 1, 1, 1' FontWeight='Bold'>%s</TextBlock>")
		_T("   <Border Height='1' Background='#9ebbdd' />")
		_T("   <Border Height='1' Background='White' />")
		_T("   <StackPanel Margin='100, 10, 0, 0' Orientation='Horizontal'>")
		_T("       <StackPanel Orientation='Vertical'>")
		_T("	       <Image Source='%d'/>")
		_T("       </StackPanel>")
		_T("       <StackPanel Orientation='Vertical'>")
		_T("		   <TextBlock Padding='1, 0, 0, 0'>OFF</TextBlock>")
		_T("           <TextBlock Padding='1, -4, 0, 0'>ON</TextBlock>")
		_T("       </StackPanel>")
		_T("   </StackPanel>")
		_T("   <StackPanel Margin='100, 0, 0, 0' Orientation='Horizontal'>")
		_T("		<TextBlock Padding='2, 0, 0, 0'>1234</TextBlock>")
		_T("   </StackPanel>")
		_T("</StackPanel>")
		_T("</Border>"), RES_STRING(IDS_DIP_SWITCH_SETTING), nDipSwitchIconIndex
	);

	m_lblDipSwitch.SetMarkupText(str);
}

LPBYTE CRtuPanelPage2::SetStatus(LPBYTE lpData, int, BOOL)
{
	m_bIsValid = TRUE;
	
	int byteCount = *lpData;				// Panel status byte count
	int nBytes = sizeof(m_panelStatus);

	try
	{
		_OutputDebugMemory(L"CRtuPanelPage2::SetStatus", lpData, byteCount+1);
	
		memset(&m_panelStatus, 0, nBytes);
		memcpy(&m_panelStatus, lpData+1, min(nBytes, byteCount));

		lpData += (1 + byteCount);
	}
	catch (...)
	{
		OutputDebugString(L"Exception in CRtuPanelPage2::SetStatus(..)\n");
	}
	
	return lpData;
}

void CRtuPanelPage2::Print1060Panel()
{
	TCHAR fname[MAX_PATH] = _T("");
	if (!RtuLib::GetPrintFileName(fname, _T(".html")))
		return;

	CHtmlFile* pFile = new CHtmlFile(hrInst, fname);
	pFile->StartTags(IsRtu8002Type()? RTU_8002_TYPE: realRtuType, gRtuNo, IDS_RTU_STATUS, IDS_PANEL_STS);

	BYTE b1 = m_panelStatus.byte1;
	BYTE b2 = m_panelStatus.byte2;
	BYTE b3 = m_panelStatus.byte3;
	BYTE b4 = m_panelStatus.byte4;
	BYTE ls = m_panelStatus.lineStat;
	BYTE gs = m_panelStatus.graphStat;

	CString sYes = RES_STRING(IDS_YES_TXT);
	CString sNo = RES_STRING(IDS_NO_TXT);

	// Power
	pFile->SetBgColor(colors[0]);
	pFile->AddTH(1, COL_SPAN|2, RES_STRING(IDS_POWER_STS));
	pFile->AddRowResID1(IDS_AC_FAIL, b1 & BIT0 ? sYes : sNo);
	pFile->AddRowResID1(IDS_BATT_LOW, b1 & BIT1 ? sYes : sNo);
	pFile->AddRowResID1(IDS_SEC_SUP_FAIL, b1 & BIT2 ? sYes : sNo);
	pFile->AddRowResID1(IDS_TER_SUP_FAIL, b1 & BIT3 ? sYes : sNo);
	pFile->AddRowResID1(IDS_AC_FAIL_ISOL, b4 & BIT6 ? sYes : sNo);
	pFile->AddRowResID1(IDS_BATT_LOW_ISOL, b4 & BIT7 ? sYes : sNo);

	// Network
	pFile->SetBgColor(colors[1]);
	pFile->AddTH(1, COL_SPAN|2, RES_STRING(IDS_NW_STS));
	pFile->AddRowResID1(IDS_DATA_LINE_FAIL, b2 & BIT0 ? sYes : sNo);
	pFile->AddRowResID1(IDS_MODEM_FAIL, b2 & BIT1 ? sYes : sNo);
	pFile->AddRowResID1(IDS_CTRLR_FAIL, b2 & BIT2 ? sYes : sNo);
	pFile->AddRowResID1(IDS_CTRLR_DEACT, b2 & BIT3 ? sYes : sNo);
	pFile->AddRowResID1(IDS_DLU_POLL_ACT, b2 & BIT4 ? sYes : sNo);
	pFile->AddRowResID1(IDS_ON_DIALUP, b2 & BIT5 ? sYes : sNo);
	pFile->AddRowResID1(IDS_TEL_LINE_FAIL, b2 & BIT6 ? sYes : sNo);
	pFile->AddRowResID1(IDS_CTRLR_ADDR_VAL, b2 & BIT7 ? sYes : sNo);
	pFile->AddRowResID1(IDS_TER_ACTIVE, ls & BIT3 ? sYes : sNo);
	pFile->AddRowResID1(IDS_TER_FAIL, ls & BIT4 ? sYes : sNo);
	pFile->AddRowResID1(IDS_TER_ONLINE, ls & BIT5 ? sYes : sNo);
	pFile->AddRowResID1(IDS_SEC_FAIL, ls & BIT6 ? sYes : sNo);
	pFile->AddRowResID1(IDS_SEC_ONLINE, ls & BIT7 ? sYes : sNo);
   
	// Serial			 
	pFile->SetBgColor(colors[0]);
	pFile->AddTH(1, COL_SPAN|2, RES_STRING(IDS_SERIAL_STS));
	pFile->AddRowResID1(IDS_MAIN_PORT1_TAMP, b3 & BIT0 ? sYes : sNo);
	pFile->AddRowResID1(IDS_MAIN_PORT1_TAMP_ISOL, b3 & BIT1 ? sYes : sNo);
	pFile->AddRowResID1(IDS_MAIN_PORT2_TAMP, b3 & BIT2 ? sYes : sNo);
	pFile->AddRowResID1(IDS_MAIN_PORT2_TAMP_ISOL, b3 & BIT3 ? sYes : sNo);
	pFile->AddRowResID1(IDS_PANEL_STS_1, b3 & BIT4 ? sYes : sNo);
	pFile->AddRowResID1(IDS_MAIN_TAMPER_ISOL, b3 & BIT5 ? sYes : sNo);
	pFile->AddRowResID1(IDS_TERM_UNIT_TAMPER, b3 & BIT6 ? sYes : sNo);
	pFile->AddRowResID1(IDS_TERM_UNIT_TAMPER_ISOL, b3 & BIT7 ? sYes : sNo);

	// Remote Panel
	pFile->SetBgColor(colors[1]);
	pFile->AddTH(1, COL_SPAN|2, RES_STRING(IDS_REMOTE_PANAL_STS));
	pFile->AddRowResID1(IDS_REMOTE_PANEL_OFFLINE, b4 & BIT0 ? sYes : sNo);
	pFile->AddRowResID1(IDS_REMOTE_PANEL_TAMPER, b4 & BIT1 ? sYes : sNo);
	pFile->AddRowResID1(IDS_REMOTE_PANEL_AC_FAIL, b4 & BIT2 ? sYes : sNo);
	pFile->AddRowResID1(IDS_REMOTE_PANEL_BATT_FAIL, b4 & BIT3 ? sYes : sNo);
	
	// Graphics Status
	pFile->SetBgColor(colors[0]);
	pFile->AddTH(1, COL_SPAN|2, RES_STRING(IDS_GRAPHIC_STS));
	pFile->AddRowResID1(IDS_MAC_GRAPHIC_STS, gs & BIT7 ? sYes : sNo);
	pFile->AddRowResID1(IDS_DURESS_ALM, gs & BIT6 ? sYes : sNo);
	pFile->AddRowResID1(IDS_POWER_ALM, gs & BIT5 ? sYes : sNo);
	pFile->AddRowResID1(IDS_TEST_MODE, gs & BIT4 ? sYes : sNo);
	pFile->AddRowResID1(IDS_PARTIAL_SEAL, gs & BIT3 ? sYes : sNo);
	pFile->AddRowResID1(IDS_ZONE_ISOLATED, gs & BIT2 ? sYes : sNo);
	pFile->AddRowResID1(IDS_ZONE_ALM, gs & BIT1 ? sYes : sNo);
	pFile->AddRowResID1(IDS_NIGHT_MODE, gs & BIT0 ? sYes : sNo);
	
	// General
	pFile->SetBgColor(colors[0]);
	pFile->AddTH(1, COL_SPAN|2, RES_STRING(IDS_GENERAL_STS));
	pFile->AddRowResID1(IDS_KPD_LCK_OUT, b1 & BIT4 ? sYes : sNo);
	pFile->AddRowResID1(IDS_BYPASS_SW, b1 & BIT5 ? sYes : sNo);
	pFile->AddRowResID1(IDS_CABINET_TAMPER, b1 & BIT6 ? sYes : sNo);
	pFile->AddRowResID1(IDS_SYS_IN_ALM, b1 & BIT7 ? sYes : sNo);
	pFile->AddRowResID1(IDS_SNA_ADDR_1, m_panelStatus.ExtDevStat);
	pFile->AddRowResID1(IDS_SNA_ADDR_2, m_panelStatus.spare1);
	pFile->AddRowResID1(IDS_RTS_CTS_DLY, m_panelStatus.spare2);
	
	CStringArray strArrVocList; GetVocabList(strArrVocList);
	if ((m_panelStatus.DipnVoc >> 4) < strArrVocList.GetSize()) {
		pFile->AddRowResID1(IDS_ALM_VOC_LIST, strArrVocList.GetAt(m_panelStatus.DipnVoc >> 4));
	}

	pFile->EndTags();
	RtuLib::FileExecute(GetSafeHwnd(), fname, _T("open"));
}

void CRtuPanelPage2::Print()
{
	if (RtuLib::IsNewControllerType(realRtuType)) {
	}
	else {
		Print1060Panel();
		return;
	}

	TCHAR fname[MAX_PATH] = _T("");
	if (!RtuLib::GetPrintFileName(fname, _T(".html")))
		return;

	CHtmlFile* pFile = new CHtmlFile(hrInst, fname);
	pFile->StartTags(IsRtu8002Type()? RTU_8002_TYPE: realRtuType, gRtuNo, IDS_RTU_STATUS, IDS_PANEL_STS);

	CStringArray strArrVocList; GetVocabList(strArrVocList);
	BYTE b1 = m_panelStatus.byte1;
	BYTE b2 = m_panelStatus.byte2;
	BYTE b3 = m_panelStatus.byte3;
	BYTE b4 = m_panelStatus.byte4;
	BYTE ls = m_panelStatus.lineStat;
	BYTE gs = m_panelStatus.graphStat;
	BYTE es = m_panelStatus.ExtDevStat;

	CString sYes = RES_STRING(IDS_YES_TXT);
	CString sNo = RES_STRING(IDS_NO_TXT);

	// Power
	pFile->SetBgColor(colors[0]);
	pFile->AddTH(1, COL_SPAN|2, RES_STRING(IDS_POWER_STS));
	pFile->AddRowResID1(IDS_AC_FAIL, b1 & BIT0 ? sYes : sNo);
	pFile->AddRowResID1(IDS_BATT_LOW, b1 & BIT1 ? sYes : sNo);
	pFile->AddRowResID1(IDS_SEC_SUP_FAIL, b1 & BIT2 ? sYes : sNo);
	pFile->AddRowResID1(IDS_TER_SUP_FAIL, b1 & BIT3 ? sYes : sNo);
	pFile->AddRowResID1(IDS_AC_FAIL_ISOL, b4 & BIT6 ? sYes : sNo);
	pFile->AddRowResID1(IDS_BATT_LOW_ISOL, b4 & BIT7 ? sYes : sNo);
	pFile->AddRowResID1(IDS_INT_LITH_BATT_PROBLEM, b4 & BIT4 ? sYes : sNo);
	pFile->AddRowResID1(IDS_EXT_LITH_BATT_PROBLEM, b4 & BIT5 ? sYes : sNo);

	// Network
	pFile->SetBgColor(colors[1]);
	pFile->AddTH(1, COL_SPAN|2, RES_STRING(IDS_NW_STS));
	pFile->AddRowResID1(IDS_PRI_PORT_PHYS_LYR_FAIL, b2 & BIT0 ? sYes : sNo);
	pFile->AddRowResID1(IDS_PRI_PORT_DRV_FAIL, b2 & BIT1 ? sYes : sNo);
	pFile->AddRowResID1(IDS_PRI_PORT_LNK_LYR_FAIL, b2 & BIT2 ? sYes : sNo);
	pFile->AddRowResID1(IDS_PRI_PORT_SES_LYR_FAIL, b2 & BIT3 ? sYes : sNo);
	pFile->AddRowResID1(IDS_ON_DIALUP, b2 & BIT5 ? sYes : sNo);
	pFile->AddRowResID1(IDS_DIALUP_FAIL, b2 & BIT6 ? sYes : sNo);
	pFile->AddRowResID1(IDS_SEC_ACTIVE, b2 & BIT7 ? sYes : sNo);
	pFile->AddRowResID1(IDS_TER_ACTIVE, ls & BIT3 ? sYes : sNo);
	pFile->AddRowResID1(IDS_TER_FAIL, ls & BIT4 ? sYes : sNo);
	pFile->AddRowResID1(IDS_TER_ONLINE, ls & BIT5 ? sYes : sNo);
	pFile->AddRowResID1(IDS_SEC_FAIL, ls & BIT6 ? sYes : sNo);
	pFile->AddRowResID1(IDS_SEC_ONLINE, ls & BIT7 ? sYes : sNo);
	
	// Serial			 
	pFile->SetBgColor(colors[0]);
	pFile->AddTH(1, COL_SPAN|2, RES_STRING(IDS_SERIAL_STS));
	pFile->AddRowResID1(IDS_RAP_PORT_TAMPER, b3 & BIT0 ? sYes : sNo);
	pFile->AddRowResID1(IDS_RAP_PORT_TAMPER_ISOL, b3 & BIT1 ? sYes : sNo);
	pFile->AddRowResID1(IDS_SPARE_SERIAL_TAMPER, b3 & BIT2 ? sYes : sNo);
	pFile->AddRowResID1(IDS_SPARE_SERIAL_TAMPER_ISOL, b3 & BIT3 ? sYes : sNo);
	pFile->AddRowResID1(IDS_PANEL_STS_1, b3 & BIT4 ? sYes : sNo);
	pFile->AddRowResID1(IDS_MAIN_TAMPER_ISOL, b3 & BIT5 ? sYes : sNo);
	pFile->AddRowResID1(IDS_TERM_UNIT_TAMPER, b3 & BIT6 ? sYes : sNo);
	pFile->AddRowResID1(IDS_TERM_UNIT_TAMPER_ISOL, b3 & BIT7 ? sYes : sNo);

	// Remote Panel
	pFile->SetBgColor(colors[1]);
	pFile->AddTH(1, COL_SPAN|2, RES_STRING(IDS_REMOTE_PANAL_STS));
	pFile->AddRowResID1(IDS_REMOTE_PANEL_OFFLINE, b4 & BIT0 ? sYes : sNo);
	pFile->AddRowResID1(IDS_REMOTE_PANEL_TAMPER, b4 & BIT1 ? sYes : sNo);
	pFile->AddRowResID1(IDS_REMOTE_PANEL_AC_FAIL, b4 & BIT2 ? sYes : sNo);
	pFile->AddRowResID1(IDS_REMOTE_PANEL_BATT_FAIL, b4 & BIT3 ? sYes : sNo);
	
	// Graphics Status
	pFile->SetBgColor(colors[0]);
	pFile->AddTH(1, COL_SPAN|2, RES_STRING(IDS_GRAPHIC_STS));
	pFile->AddRowResID1(IDS_MAC_GRAPHIC_STS, gs & BIT7 ? sYes : sNo);
	pFile->AddRowResID1(IDS_DURESS_ALM, gs & BIT6 ? sYes : sNo);
	pFile->AddRowResID1(IDS_POWER_ALM, gs & BIT5 ? sYes : sNo);
	pFile->AddRowResID1(IDS_TEST_MODE, gs & BIT4 ? sYes : sNo);
	pFile->AddRowResID1(IDS_PARTIAL_SEAL, gs & BIT3 ? sYes : sNo);
	pFile->AddRowResID1(IDS_ZONE_ISOLATED, gs & BIT2 ? sYes : sNo);
	pFile->AddRowResID1(IDS_ZONE_ALM, gs & BIT1 ? sYes : sNo);
	pFile->AddRowResID1(IDS_NIGHT_MODE, gs & BIT0 ? sYes : sNo);
	
	// Witnesss
	pFile->SetBgColor(colors[1]);
	pFile->AddTH(1, COL_SPAN|2, RES_STRING(IDS_WITNESS_STS));
	pFile->AddRowResID1(IDS_HDRIVE_ONLINE, es & BIT2 ? sYes : sNo);
	pFile->AddRowResID1(IDS_DBOARD_ONLINE, es & BIT3 ? sYes : sNo);
	
	// General
	pFile->SetBgColor(colors[0]);
	pFile->AddTH(1, COL_SPAN|2, RES_STRING(IDS_GENERAL_STS));

	if ((m_panelStatus.DipnVoc >> 4) < strArrVocList.GetSize()) {
		pFile->AddRowResID1(IDS_ALM_VOC_LIST, strArrVocList.GetAt(m_panelStatus.DipnVoc >> 4));
	}

	pFile->AddRowResID1(IDS_EXPANSION_MEMORY, GetExpansionMemoryString(&es));
	pFile->AddRowResID1(IDS_ONBOARD_FLASH_MEMORY, GetOnBoardFlashMemoryString(&m_panelStatus.ExtDevStat));

	pFile->EndTags();
	RtuLib::FileExecute(GetSafeHwnd(), fname, _T("open"));
}

#pragma endregion CRtuPanelPage2

/*------------------------------------------------------------------------------*/
/*					New Rtu Panel Page Class									*/
/*------------------------------------------------------------------------------*/
#pragma region CRtuPanel60Page2
/*------------------------------------------------------------------------------*/
/*					Panel60 Page Class											*/
/*------------------------------------------------------------------------------*/
IMPLEMENT_DYNCREATE(CRtuPanel60Page2, CXTPPropertyPage)

void CRtuPanel60Page2::DoDataExchange(CDataExchange* pDX)
{
	CXTPPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CRtuPanel60Page2)
	DDX_Control(pDX, IDC_RTUSTAT_DIPSW, m_btnDipSw);
	//}}AFX_DATA_MAP

	for (BYTE i=0; i<8; i++)
		RtuLib::DDX_Check(pDX, IDC_RTUSTAT_CHK1 + i, m_panelStatus.byte1, i);
	for(BYTE i=0; i<8; i++)
		RtuLib::DDX_Check(pDX, IDC_RTUSTAT_CHK9 + i, m_panelStatus.byte2, i);
	for(BYTE i=0; i<8; i++)
		RtuLib::DDX_Check(pDX, IDC_RTUSTAT_CHK17 + i, m_panelStatus.byte3, i);
	for(BYTE i=0; i<8; i++)
		RtuLib::DDX_Check(pDX, IDC_RTUSTAT_CHK25 + i, m_panelStatus.byte4, i);
	for(BYTE i=0; i<5; i++)
		RtuLib::DDX_Check(pDX, IDC_RTUSTAT_CHK33 + i, m_panelStatus.lineStat, (BYTE)(i+3));

	for(BYTE i=0; i<8; i++)
		RtuLib::DDX_Check(pDX, IDC_RTUSTAT_CHK44 + i, m_panelStatus.graphStat, i);

}


BEGIN_MESSAGE_MAP(CRtuPanel60Page2, CXTPPropertyPage)
	//{{AFX_MSG_MAP(CRtuPanel60Page2)	
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CRtuPanel60Page2 message handlers
/////////////////////////////////////////////////////////////////////////////
BOOL CRtuPanel60Page2::OnInitDialog()
{
	CDialog::OnInitDialog();
	m_btnDipSw.Init(4);
	return TRUE;
}

BOOL CRtuPanel60Page2::OnSetActive()
{
	ShowStatus();
	return CXTPPropertyPage::OnSetActive();
}

void CRtuPanel60Page2::ShowStatus()
{
	if (IsWindow(m_hWnd) == FALSE) 
		return;
	UpdateData(FALSE);
	SetDlgItemInt(IDC_RTUSTAT_EDIT1, m_panelStatus.ctrlAddr1, FALSE);
	SetDlgItemInt(IDC_RTUSTAT_EDIT2, m_panelStatus.ctrlAddr2, FALSE);
	SetDlgItemInt(IDC_RTUSTAT_EDIT3, m_panelStatus.RtsCtsDly, FALSE);
	CStringArray strArrVocList; GetVocabList(strArrVocList);
	GetDlgItem(IDC_RTUSTAT_EDIT5)->SetWindowText(strArrVocList.GetAt(m_panelStatus.DipnVoc >> 4));
	m_btnDipSw.SetAddress(m_panelStatus.DipnVoc & 0x0F);
	m_btnDipSw.SetDrawState(TRUE);
	m_btnDipSw.Invalidate(FALSE);
}

LPBYTE CRtuPanel60Page2::SetStatus(LPBYTE lpData, int, BOOL)
{
	int byteCount = *lpData;				// Panel status byte count
	int nBytes = sizeof(m_panelStatus);

	try
	{
		_OutputDebugMemory(L"CRtuPanel60Page2::SetStatus", lpData, byteCount+1);
		memset(&m_panelStatus, 0, nBytes);
		memcpy(&m_panelStatus, lpData+1, min(nBytes, byteCount));
		lpData += (1 + byteCount);
	}
	catch (...)
	{
		OutputDebugString(L"Exception in CRtuPanel60Page2::SetStatus(..)\n");
	}
	return lpData;
}

void CRtuPanel60Page2::Print()
{
	TCHAR fname[MAX_PATH] = _T("");
	if (!RtuLib::GetPrintFileName(fname, _T(".html")))
		return;

	CHtmlFile* pFile = new CHtmlFile(hrInst, fname);
	pFile->StartTags(IsRtu8002Type()? RTU_8002_TYPE: realRtuType, gRtuNo, IDS_RTU_STATUS, IDS_PANEL_STS);

	BYTE b1 = m_panelStatus.byte1;
	BYTE b2 = m_panelStatus.byte2;
	BYTE b3 = m_panelStatus.byte3;
	BYTE b4 = m_panelStatus.byte4;
	BYTE ls = m_panelStatus.lineStat;
	BYTE gs = m_panelStatus.graphStat;

	CString sYes = RES_STRING(IDS_YES_TXT);
	CString sNo = RES_STRING(IDS_NO_TXT);

	// Power
	pFile->SetBgColor(colors[0]);
	pFile->AddTH(1, COL_SPAN|2, RES_STRING(IDS_POWER_STS));
	pFile->AddRowResID1(IDS_AC_FAIL, b1 & BIT0 ? sYes : sNo);
	pFile->AddRowResID1(IDS_BATT_LOW, b1 & BIT1 ? sYes : sNo);
	pFile->AddRowResID1(IDS_SEC_SUP_FAIL, b1 & BIT2 ? sYes : sNo);
	pFile->AddRowResID1(IDS_TER_SUP_FAIL, b1 & BIT3 ? sYes : sNo);
	pFile->AddRowResID1(IDS_AC_FAIL_ISOL, b4 & BIT6 ? sYes : sNo);
	pFile->AddRowResID1(IDS_BATT_LOW_ISOL, b4 & BIT7 ? sYes : sNo);

	// Network
	pFile->SetBgColor(colors[1]);
	pFile->AddTH(1, COL_SPAN|2, RES_STRING(IDS_NW_STS));
	pFile->AddRowResID1(IDS_DATA_LINE_FAIL, b2 & BIT0 ? sYes : sNo);
	pFile->AddRowResID1(IDS_MODEM_FAIL, b2 & BIT1 ? sYes : sNo);
	pFile->AddRowResID1(IDS_CTRLR_FAIL, b2 & BIT2 ? sYes : sNo);
	pFile->AddRowResID1(IDS_CTRLR_DEACT, b2 & BIT3 ? sYes : sNo);
	pFile->AddRowResID1(IDS_DLU_POLL_ACT, b2 & BIT4 ? sYes : sNo);
	pFile->AddRowResID1(IDS_ON_DIALUP, b2 & BIT5 ? sYes : sNo);
	pFile->AddRowResID1(IDS_TEL_LINE_FAIL, b2 & BIT6 ? sYes : sNo);
	pFile->AddRowResID1(IDS_CTRLR_ADDR_VAL, b2 & BIT7 ? sYes : sNo);
	pFile->AddRowResID1(IDS_TER_ACTIVE, ls & BIT3 ? sYes : sNo);
	pFile->AddRowResID1(IDS_TER_FAIL, ls & BIT4 ? sYes : sNo);
	pFile->AddRowResID1(IDS_TER_ONLINE, ls & BIT5 ? sYes : sNo);
	pFile->AddRowResID1(IDS_SEC_FAIL, ls & BIT6 ? sYes : sNo);
	pFile->AddRowResID1(IDS_SEC_ONLINE, ls & BIT7 ? sYes : sNo);
   
	// Serial			 
	pFile->SetBgColor(colors[0]);
	pFile->AddTH(1, COL_SPAN|2, RES_STRING(IDS_SERIAL_STS));
	pFile->AddRowResID1(IDS_MAIN_PORT1_TAMP, b3 & BIT0 ? sYes : sNo);
	pFile->AddRowResID1(IDS_MAIN_PORT1_TAMP_ISOL, b3 & BIT1 ? sYes : sNo);
	pFile->AddRowResID1(IDS_MAIN_PORT2_TAMP, b3 & BIT2 ? sYes : sNo);
	pFile->AddRowResID1(IDS_MAIN_PORT2_TAMP_ISOL, b3 & BIT3 ? sYes : sNo);
	pFile->AddRowResID1(IDS_PANEL_STS_1, b3 & BIT4 ? sYes : sNo);
	pFile->AddRowResID1(IDS_MAIN_TAMPER_ISOL, b3 & BIT5 ? sYes : sNo);
	pFile->AddRowResID1(IDS_TERM_UNIT_TAMPER, b3 & BIT6 ? sYes : sNo);
	pFile->AddRowResID1(IDS_TERM_UNIT_TAMPER_ISOL, b3 & BIT7 ? sYes : sNo);

	// Remote Panel
	pFile->SetBgColor(colors[1]);
	pFile->AddTH(1, COL_SPAN|2, RES_STRING(IDS_REMOTE_PANAL_STS));
	pFile->AddRowResID1(IDS_REMOTE_PANEL_OFFLINE, b4 & BIT0 ? sYes : sNo);
	pFile->AddRowResID1(IDS_REMOTE_PANEL_TAMPER, b4 & BIT1 ? sYes : sNo);
	pFile->AddRowResID1(IDS_REMOTE_PANEL_AC_FAIL, b4 & BIT2 ? sYes : sNo);
	pFile->AddRowResID1(IDS_REMOTE_PANEL_BATT_FAIL, b4 & BIT3 ? sYes : sNo);
	
	// Graphics Status
	pFile->SetBgColor(colors[0]);
	pFile->AddTH(1, COL_SPAN|2, RES_STRING(IDS_GRAPHIC_STS));
	pFile->AddRowResID1(IDS_MAC_GRAPHIC_STS, gs & BIT7 ? sYes : sNo);
	pFile->AddRowResID1(IDS_DURESS_ALM, gs & BIT6 ? sYes : sNo);
	pFile->AddRowResID1(IDS_POWER_ALM, gs & BIT5 ? sYes : sNo);
	pFile->AddRowResID1(IDS_TEST_MODE, gs & BIT4 ? sYes : sNo);
	pFile->AddRowResID1(IDS_PARTIAL_SEAL, gs & BIT3 ? sYes : sNo);
	pFile->AddRowResID1(IDS_ZONE_ISOLATED, gs & BIT2 ? sYes : sNo);
	pFile->AddRowResID1(IDS_ZONE_ALM, gs & BIT1 ? sYes : sNo);
	pFile->AddRowResID1(IDS_NIGHT_MODE, gs & BIT0 ? sYes : sNo);
	
	// General
	pFile->SetBgColor(colors[0]);
	pFile->AddTH(1, COL_SPAN|2, RES_STRING(IDS_GENERAL_STS));
	pFile->AddRowResID1(IDS_KPD_LCK_OUT, b1 & BIT4 ? sYes : sNo);
	pFile->AddRowResID1(IDS_BYPASS_SW, b1 & BIT5 ? sYes : sNo);
	pFile->AddRowResID1(IDS_CABINET_TAMPER, b1 & BIT6 ? sYes : sNo);
	pFile->AddRowResID1(IDS_SYS_IN_ALM, b1 & BIT7 ? sYes : sNo);
	pFile->AddRowResID1(IDS_SNA_ADDR_1, m_panelStatus.ctrlAddr1);
	pFile->AddRowResID1(IDS_SNA_ADDR_2, m_panelStatus.ctrlAddr2);
	pFile->AddRowResID1(IDS_RTS_CTS_DLY, m_panelStatus.RtsCtsDly);
	
	CStringArray strArrVocList; GetVocabList(strArrVocList);
	if ((m_panelStatus.DipnVoc >> 4) < strArrVocList.GetSize()) {
		pFile->AddRowResID1(IDS_ALM_VOC_LIST, strArrVocList.GetAt(m_panelStatus.DipnVoc >> 4));
	}

	pFile->EndTags();
	RtuLib::FileExecute(GetSafeHwnd(), fname, _T("open"));
}

#pragma endregion CRtuPanel60Page2

/*------------------------------------------------------------------------------*/
/*					New device info Class										*/
/*------------------------------------------------------------------------------*/
#pragma region CDeviceInfoData

CDeviceInfoData::CDeviceInfoData()
{
	memset(m_tamperData, 0, sizeof(m_tamperData));
	memset(m_offlineData, 0, sizeof(m_offlineData));
	memset(m_isolatedData, 0, sizeof(m_isolatedData));
	memset(m_keyswitchData, 0, sizeof(m_keyswitchData));
	m_nDeviceType = 0;
	m_nIndex = 0;
	m_nDeviceCount = 0;
	m_bKeyswitchInc = FALSE;
}

LPBYTE  CDeviceInfoData::SetData(int deviceType, LPBYTE lpData, int numDevices, BOOL bKeySwitchInc)
{
	
	m_nDeviceType = deviceType;
	m_bKeyswitchInc = bKeySwitchInc;
	m_nDeviceCount = numDevices;
	
	GmsOutputDebugString(__FUNCTIONW__, __LINE__, L"DeviceType=%d, Count=%d", m_nDeviceType, m_nDeviceCount);

	memset(&m_tamperData, 0, sizeof(m_tamperData));
	memset(&m_offlineData, 0, sizeof(m_offlineData));
	memset(&m_isolatedData, 0, sizeof(m_isolatedData));
	memset(&m_keyswitchData, 0, sizeof(m_keyswitchData));

	LPBYTE ptr = lpData;
	try
	{
	
		if (m_nDeviceCount > 0)
		{
			if (m_nDeviceCount > (MAX_DEVINFO_BYTE * 8) )
				m_nDeviceCount = MAX_DEVINFO_BYTE * 8;

			int bc = (m_nDeviceCount / 8) + ((m_nDeviceCount % 8) ? 1 : 0);

			TRACE3("---- CDeviceInfoData::SetData (devType=%d, dvcCount=%d, bc=%d)\n", m_nDeviceType, m_nDeviceCount, bc);
			if(bc > MAX_DEVINFO_BYTE) 
				bc = MAX_DEVINFO_BYTE;
			memcpy(m_tamperData, ptr, bc);
			ptr += bc;
			memcpy(m_offlineData, ptr, bc);
			ptr += bc;
			memcpy(m_isolatedData, ptr, bc);
			ptr += bc;
	
			if (m_bKeyswitchInc) 
			{
				memcpy(m_keyswitchData, ptr, bc);
				ptr += bc;
			}
			_OutputDebugMemory(L"", lpData, ptr-lpData);
		}
	}
	catch (...)
	{
		m_nDeviceCount = 0;
		CString db; db.Format(L"Exception in  CDeviceInfoData::SetData(type=%d..)\n", m_nDeviceType);
		OutputDebugString(db);
	}
	return ptr;
}

CString CDeviceInfoData::GetTamperStatus()
{
	return RES_STRING(m_tamper & 1 ? IDS_YES_TXT : IDS_NO_TXT);
}

CString CDeviceInfoData::GetOfflineStatus()
{
	return RES_STRING(m_offline& 1 ? IDS_YES_TXT : IDS_NO_TXT);
}

CString CDeviceInfoData::GetIsolatedStatus()
{
	return RES_STRING(m_isolated & 1 ? IDS_YES_TXT : IDS_NO_TXT);
}

CString CDeviceInfoData::GetKeyswitchStatus()
{
	return RES_STRING(m_keyswitch & 1 ? IDS_YES_TXT : IDS_NO_TXT);
}

int	CDeviceInfoData::GetImageIndex()
{
	int nImageIndex = 0;
	if (m_isolated & 1)
		nImageIndex = 2;
	else if (m_tamper & 1)
		nImageIndex = 1;
	else if (m_offline & 1) {
		nImageIndex = 3;
		if (m_nDeviceType == E_DEV_TYPE_READER)
			nImageIndex = 5;
	}
	else 
		nImageIndex = 0;

	return nImageIndex;
}

void CDeviceInfoData::MoveNext()
{
	m_tamper >>= 1; 
	m_offline >>= 1; 
	m_isolated >>= 1;
	m_keyswitch >>= 1;

	m_nIndex++;
	if ((m_nIndex % 8) == 0) {
		m_tamper = m_tamperData[m_nIndex / 8];
		m_offline = m_offlineData[m_nIndex / 8];
		m_isolated = m_isolatedData[m_nIndex / 8];
		m_keyswitch = m_keyswitchData[m_nIndex / 8];
	}
}

void CDeviceInfoData::Reset()
{
	m_nIndex = 0;
	m_tamper = m_tamperData[0];
	m_offline = m_offlineData[0];
	m_isolated = m_isolatedData[0];
	m_keyswitch = m_keyswitchData[0];
}

void CDeviceInfoData::UpdateListItem(LVITEM& lvi, int item, CString& strText)
{
	lvi.iItem = item;
	lvi.iImage = GetImageIndex();
	lvi.iSubItem = 0;
	strText.Format(_T("%d"), item+1);
	lvi.pszText = (LPTSTR)(LPCTSTR)strText;
}

#pragma endregion CDeviceInfoData

/*------------------------------------------------------------------------------*/
/*					Keypad Status Page Class									*/
/*------------------------------------------------------------------------------*/
#pragma region CRtuKeypadPage2

IMPLEMENT_DYNCREATE(CRtuKeypadPage2, CXTPPropertyPage)

void CRtuKeypadPage2::DoDataExchange(CDataExchange* pDX)
{
	CXTPPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CRtuKeypadPage2)
	DDX_Control(pDX, IDC_LIST, m_kpdList);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CRtuKeypadPage2, CXTPPropertyPage)
	//{{AFX_MSG_MAP(CRtuKeypadPage2)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


BOOL CRtuKeypadPage2::OnInitDialog()
{
	CDialog::OnInitDialog();
	CWnd* pWnd = GetDlgItem(IDC_RTU_TOTAL);
	if (pWnd) {
		pWnd->ShowWindow(SW_HIDE);
	}
	m_nNumColumns = 0;
	m_imgList.Create(IDB_KEYPADS, 22, 0, RGB(0, 0x80, 0x80));
	m_kpdList.SetGridLines();
	m_kpdList.SetImageList(&m_imgList, LVSIL_SMALL);
	return TRUE;
}

void CRtuKeypadPage2::UpdateStatusList()
{
	m_kpdList.DeleteAllItems();
	if (m_nNumColumns) {
		for(int col=m_nNumColumns-1; col>=0; col--) {
			m_kpdList.DeleteColumn(col);
		}
	}

	UINT nStrIDs[] = {IDS_NUMBER, IDS_TAMPER, IDS_OFFLINE, IDS_ISOLATED, IDS_KEY_SWITCH, 
		IDS_DEVICE_TYPE, IDS_PHYSICAL_ADDRESS, IDS_PHYSICAL_PORT, IDS_FIRMWARE_VER, IDS_BOOT_LOADER_VER};
	
	int nColumn = 4;
	if (m_bKeySwitchInc)
		nColumn += 1;
	if (s_bKeypadFirmware)
		nColumn += 5;

	for(int i=0; i<nColumn; i++) {
		CString strTxt = RES_STRING(nStrIDs[i]);
		CSize size = ((CDC*)this->GetDC())->GetTextExtent(strTxt);
		if ((i==4) && (!m_bKeySwitchInc)) {
			continue;
		}
		m_kpdList.InsertColumn(i, strTxt, LVCFMT_CENTER, size.cx + TXT_EXTENT);
	}

	m_nNumColumns = nColumn;
}

BOOL CRtuKeypadPage2::OnSetActive()
{
	ShowStatus();
	return CXTPPropertyPage::OnSetActive();
}

LPBYTE CRtuKeypadPage2::SetStatus(LPBYTE lpData, int numKeypads, BOOL bKeySwitchInc)
{
	return m_devInfo.SetData(CDeviceInfoData::E_DEV_TYPE_KEYPAD, lpData, numKeypads, bKeySwitchInc);
}

void CRtuKeypadPage2::ShowStatus()
{
	if (IsWindow(m_hWnd) == FALSE) return;

	UpdateStatusList();
	
	LVITEM lvi;
	lvi.mask = LVIF_IMAGE | LVIF_TEXT;
	lvi.iImage = 0;
	CString strText;
	m_devInfo.Reset();
	for(int i=0; i<m_devInfo.GetCount(); i++) {
		m_devInfo.UpdateListItem(lvi, i, strText);
		m_kpdList.InsertItem(&lvi);

		// Tamper status
		m_kpdList.SetItemText(i, 1, m_devInfo.GetTamperStatus());

		// Offline status
		m_kpdList.SetItemText(i, 2, m_devInfo.GetOfflineStatus());

		// Isolated status
		m_kpdList.SetItemText(i, 3, m_devInfo.GetIsolatedStatus());

		int nSubItem = 4;
		// Key switch status
		if (m_bKeySwitchInc) {
			m_kpdList.SetItemText(i, nSubItem++, m_devInfo.GetKeyswitchStatus());
		}

		if (s_bKeypadFirmware) {
			// device type
			m_kpdList.SetItemText(i, nSubItem++, GetDeviceTypeString(i));

			// device physical address
			m_kpdList.SetItemText(i, nSubItem++, GetDevicePhysicalAddressString(s_keypadFirmware[i].physicalAddress));

			// device physical port
			m_kpdList.SetItemText(i, nSubItem++, GetDevicePhysicalPortString(s_keypadFirmware[i].physicalPort));

			// firmware verion
			m_kpdList.SetItemText(i, nSubItem++, GetFirmwareVersionString(i));

			// bootloader version
			m_kpdList.SetItemText(i, nSubItem++, GetBootloaderVersionString(i));
		}

		m_devInfo.MoveNext();
	}
}

CString CRtuKeypadPage2::GetDeviceTypeString(int index)
{
	CString s;
	s = GetDevTypeString(s_keypadFirmware[index].deviceType);
	if (s == _T(""))
		s = RES_STRING(IDS_KEYPAD);// _T("Keypad");

	return s;
}
CString CRtuKeypadPage2::GetFirmwareVersionString(int index)
{
	return GetVersionString(s_keypadFirmware[index].firmwareVerMajor, s_keypadFirmware[index].firmwareVerMinor);
}
CString CRtuKeypadPage2::GetBootloaderVersionString(int index)
{
	return GetVersionString(s_keypadFirmware[index].bootLoaderVerMajor, s_keypadFirmware[index].bootLoaderVerMinor);
}

void CRtuKeypadPage2::Print()
{
	TCHAR fname[MAX_PATH] = _T("");
	if (!RtuLib::GetPrintFileName(fname, _T(".html")))
		return;

	CHtmlFile* pFile = new CHtmlFile(hrInst, fname);
	pFile->StartTags(IsRtu8002Type()? RTU_8002_TYPE: realRtuType, gRtuNo, IDS_RTU_STATUS, IDS_KEYPAD_STATUS);

	CString sKpdNum = RES_STRING(IDS_KPD_NUM);
	CString sTamper = RES_STRING(IDS_TAMPER);
	CString sOffline = RES_STRING(IDS_OFFLINE);
	CString sIsolated = RES_STRING(IDS_ISOLATED);
	CString sKeySwitch = RES_STRING(IDS_KEY_SWITCH);
	CString sDevType = RES_STRING(IDS_DEVICE_TYPE);
	CString sPhysAddr = RES_STRING(IDS_PHYSICAL_ADDRESS);
	CString sPhysPort = RES_STRING(IDS_PHYSICAL_PORT);
	CString sFirmware = RES_STRING(IDS_FIRMWARE_VER);
	CString sBootLoader = RES_STRING(IDS_BOOT_LOADER_VER);

	pFile->SetBgColor(colors[2]);
	int hCount = 4;
	if (m_bKeySwitchInc)
		hCount += 1;
	if (s_bKeypadFirmware)
		hCount += 5;

	if (hCount == 10) {
		pFile->AddTH(hCount, 1, sKpdNum, 1, sTamper, 1, sOffline, 1, sIsolated, 1, sKeySwitch, 
			1, sDevType, 1, sPhysAddr, 1, sPhysPort, 1, sFirmware, 1, sBootLoader);
	}
	else if (hCount == 9) {
		pFile->AddTH(hCount, 1, sKpdNum, 1, sTamper, 1, sOffline, 1, sIsolated, 
			1, sDevType, 1, sPhysAddr, 1, sPhysPort, 1, sFirmware, 1, sBootLoader);
	}
	else if (hCount == 5) {
		pFile->AddTH(hCount, 1, sKpdNum, 1, sTamper, 1, sOffline, 1, sIsolated, 1, sKeySwitch);
	}
	else {
		pFile->AddTH(hCount, 1, sKpdNum, 1, sTamper, 1, sOffline, 1, sIsolated);
	}

	CString sTmp;
	m_devInfo.Reset();
	for(int i=0; i<m_devInfo.GetCount(); i++) {
		pFile->SetBgColor(colors[i & 1 ? 1 : 0]);
		sTmp.Format(_T("%d"), i + 1);
		if (s_bKeypadFirmware) {
			if (m_bKeySwitchInc) {
				pFile->AddTD(10, 1, sTmp,
					1, m_devInfo.GetTamperStatus(),
					1, m_devInfo.GetOfflineStatus(),
					1, m_devInfo.GetIsolatedStatus(),
					1, m_devInfo.GetKeyswitchStatus(),
					1, GetDeviceTypeString(i),
					1, GetDevicePhysicalAddressString(s_keypadFirmware[i].physicalAddress),
					1, GetDevicePhysicalPortString(s_keypadFirmware[i].physicalPort),
					1, GetFirmwareVersionString(i), 
					1, GetBootloaderVersionString(i));
			}
			else {
				pFile->AddTD(9, 1, sTmp,
					1, m_devInfo.GetTamperStatus(),
					1, m_devInfo.GetOfflineStatus(),
					1, m_devInfo.GetIsolatedStatus(),
					1, GetDeviceTypeString(i), 
					1, GetDevicePhysicalAddressString(s_keypadFirmware[i].physicalAddress),
					1, GetDevicePhysicalPortString(s_keypadFirmware[i].physicalPort),
					1, GetFirmwareVersionString(i), 
					1, GetBootloaderVersionString(i));
			}
		}
		else {
			if (m_bKeySwitchInc) {
				pFile->AddTD(5, 1, sTmp,
					1, m_devInfo.GetTamperStatus(),
					1, m_devInfo.GetOfflineStatus(),
					1, m_devInfo.GetIsolatedStatus(),
					1, m_devInfo.GetKeyswitchStatus());
			}
			else {
				pFile->AddTD(4, 1, sTmp,
					1, m_devInfo.GetTamperStatus(),
					1, m_devInfo.GetOfflineStatus(),
					1, m_devInfo.GetIsolatedStatus());
			}
		}
			
		m_devInfo.MoveNext();
	}

	pFile->EndTags(); delete pFile; pFile = NULL;
	RtuLib::FileExecute(GetSafeHwnd(), fname, _T("open"));
}

#pragma endregion CRtuKeypadPage2

/*------------------------------------------------------------------------------*/
/*					16 I/O Status Page Class									*/
/*------------------------------------------------------------------------------*/
#pragma region CRtu16IOPage2

IMPLEMENT_DYNCREATE(CRtu16IOPage2, CXTPPropertyPage)

void CRtu16IOPage2::DoDataExchange(CDataExchange* pDX)
{
	CXTPPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CRtu16IOPage2)
	DDX_Control(pDX, IDC_LIST, m_16ioList);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CRtu16IOPage2, CXTPPropertyPage)
	//{{AFX_MSG_MAP(CRtu16IOPage2)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


BOOL CRtu16IOPage2::OnInitDialog()
{
	CDialog::OnInitDialog();
	CWnd* pWnd = GetDlgItem(IDC_RTU_TOTAL);
	if (pWnd) {
		pWnd->ShowWindow(SW_HIDE);
	}
	
	m_nNumColumns = 0;
	m_imgList.Create(IDB_16IOS, 12, 0, RGB(0, 0x80, 0x80));
	m_16ioList.SetGridLines();
	m_16ioList.SetImageList(&m_imgList, LVSIL_SMALL);
	return TRUE;
}

void CRtu16IOPage2::UpdateStatusList()
{
	m_16ioList.DeleteAllItems();
	if (m_nNumColumns) {
		for(int col=m_nNumColumns-1; col>=0; col--) {
			m_16ioList.DeleteColumn(col);
		}
	}

	UINT nStrIDs[] = {IDS_NUMBER, IDS_TAMPER, IDS_OFFLINE, IDS_ISOLATED, 
		IDS_DEVICE_TYPE, IDS_PHYSICAL_ADDRESS, IDS_PHYSICAL_PORT, IDS_FIRMWARE_VER, IDS_BOOT_LOADER_VER};
	
	int nColumn = 4;
	if (s_bIoFirmware)
		nColumn += 5;

	for(int i=0; i<nColumn; i++) {
		CString strTxt = RES_STRING(nStrIDs[i]);
		CSize size = ((CDC*)this->GetDC())->GetTextExtent(strTxt);
		m_16ioList.InsertColumn(i, strTxt, LVCFMT_CENTER, size.cx + TXT_EXTENT);
	}

	m_nNumColumns = nColumn;
}

BOOL CRtu16IOPage2::OnSetActive()
{
	ShowStatus();
	return CXTPPropertyPage::OnSetActive();
}

LPBYTE CRtu16IOPage2::SetStatus(LPBYTE lpData, int numDevices, BOOL)
{
	return m_devInfo.SetData(CDeviceInfoData::E_DEV_TYPE_IO, lpData, numDevices);
}

void CRtu16IOPage2::ShowStatus()
{
	if (IsWindow(m_hWnd) == FALSE) return;

	UpdateStatusList();

	LVITEM lvi;
	lvi.mask = LVIF_IMAGE | LVIF_TEXT;
	CString strText;
	m_devInfo.Reset();
	for(int i=0; i<m_devInfo.GetCount(); i++) {
		m_devInfo.UpdateListItem(lvi, i, strText);
		m_16ioList.InsertItem(&lvi);

		// Tamper status
		m_16ioList.SetItemText(i, 1, m_devInfo.GetTamperStatus());

		// Offline status
		m_16ioList.SetItemText(i, 2, m_devInfo.GetOfflineStatus());

		// Isolated status
		m_16ioList.SetItemText(i, 3, m_devInfo.GetIsolatedStatus());

		if (s_bIoFirmware) {
			// device type
			m_16ioList.SetItemText(i, 4, GetDeviceTypeString(i));

			// device physical address
			m_16ioList.SetItemText(i, 5, GetDevicePhysicalAddressString(s_ioFirmware[i].physicalAddress));

			// device physical port
			m_16ioList.SetItemText(i, 6, GetDevicePhysicalPortString(s_ioFirmware[i].physicalPort));
			
			// firmware verion
			m_16ioList.SetItemText(i, 7, GetFirmwareVersionString(i));

			// bootloader version
			m_16ioList.SetItemText(i, 8, GetBootloaderVersionString(i));
		}

		m_devInfo.MoveNext();
	}
}

CString CRtu16IOPage2::GetDeviceTypeString(int index)
{
	CString s;
	s = GetDevTypeString(s_ioFirmware[index].deviceType);
	if (s == _T(""))
		s = _T("I/O");

	return s;
}
CString CRtu16IOPage2::GetFirmwareVersionString(int index)
{
	return GetVersionString(s_ioFirmware[index].firmwareVerMajor, s_ioFirmware[index].firmwareVerMinor);
}
CString CRtu16IOPage2::GetBootloaderVersionString(int index)
{
	return GetVersionString(s_ioFirmware[index].bootLoaderVerMajor, s_ioFirmware[index].bootLoaderVerMinor);
}

void CRtu16IOPage2::Print()
{
	TCHAR fname[MAX_PATH] = _T("");
	if (!RtuLib::GetPrintFileName(fname, _T(".html")))
		return;

	CHtmlFile* pFile = new CHtmlFile(hrInst, fname);
	pFile->StartTags(IsRtu8002Type()? RTU_8002_TYPE: realRtuType, gRtuNo, IDS_RTU_STATUS, IDS_16IO_STATUS);

	CString sIONum = RES_STRING(IDS_IO_NUM);
	CString sTamper = RES_STRING(IDS_TAMPER);
	CString sOffline = RES_STRING(IDS_OFFLINE);
	CString sIsolated = RES_STRING(IDS_ISOLATED);

	CString sDevType = RES_STRING(IDS_DEVICE_TYPE);
	CString sPhysAddr = RES_STRING(IDS_PHYSICAL_ADDRESS);
	CString sPhysPort = RES_STRING(IDS_PHYSICAL_PORT);
	CString sFirmware = RES_STRING(IDS_FIRMWARE_VER);
	CString sBootLoader = RES_STRING(IDS_BOOT_LOADER_VER);

	pFile->SetBgColor(colors[2]);
	
	int hCount = 4;
	if (s_bIoFirmware)
		hCount += 5;

	if (hCount == 4)
		pFile->AddTH(hCount, 1, sIONum, 1, sTamper, 1, sOffline, 1, sIsolated);
	else 
		pFile->AddTH(hCount, 1, sIONum, 1, sTamper, 1, sOffline, 1, sIsolated, 
			1, sDevType, 1, sPhysAddr, 1, sPhysPort, 1, sFirmware, 1, sBootLoader);

	CString sTmp;
	m_devInfo.Reset();
	for(int i=0; i<m_devInfo.GetCount(); i++) {

		pFile->SetBgColor(colors[i & 1 ? 1 : 0]);
		sTmp.Format(_T("%d"), i + 1);
		if (s_bIoFirmware) {
			pFile->AddTD(9, 1, sTmp,
				1, m_devInfo.GetTamperStatus(),
				1, m_devInfo.GetOfflineStatus(),
				1, m_devInfo.GetIsolatedStatus(), 
				1, GetDeviceTypeString(i), 
				1, GetDevicePhysicalAddressString(s_ioFirmware[i].physicalAddress),
				1, GetDevicePhysicalPortString(s_ioFirmware[i].physicalPort),
				1, GetFirmwareVersionString(i), 
				1, GetBootloaderVersionString(i));
		}
		else {
			pFile->AddTD(4, 1, sTmp,
				1, m_devInfo.GetTamperStatus(),
				1, m_devInfo.GetOfflineStatus(),
				1, m_devInfo.GetIsolatedStatus());
		}
			
		m_devInfo.MoveNext();
	}

	pFile->EndTags(); delete pFile; pFile = NULL;
	RtuLib::FileExecute(GetSafeHwnd(), fname, _T("open"));
}

#pragma endregion CRtu16IOPage2
/*------------------------------------------------------------------------------*/
/*					Camera Controller Status Page Class							*/
/*------------------------------------------------------------------------------*/
#pragma region CRtuCamCtrlPage2

IMPLEMENT_DYNCREATE(CRtuCamCtrlPage2, CXTPPropertyPage)

void CRtuCamCtrlPage2::DoDataExchange(CDataExchange* pDX)
{
	CXTPPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CRtuCamCtrlPage2)
	DDX_Control(pDX, IDC_LIST, m_camCtrlList);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CRtuCamCtrlPage2, CXTPPropertyPage)
	//{{AFX_MSG_MAP(CRtuCamCtrlPage2)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


BOOL CRtuCamCtrlPage2::OnInitDialog()
{
	CDialog::OnInitDialog();
	CWnd* pWnd = GetDlgItem(IDC_RTU_TOTAL);
	if (pWnd) {
		pWnd->ShowWindow(SW_HIDE);
	}

	return TRUE;
}

void CRtuCamCtrlPage2::InitializeComponent()
{
	m_imgList.Create(IDB_CAMERAS, 18, 0, RGB(0, 0x80, 0x80));
	UINT nStrIDs[] = {IDS_NUMBER, IDS_TAMPER, IDS_OFFLINE, IDS_ISOLATED};
	for(int i=0; i<4; i++) {
		CString strTxt = RES_STRING(nStrIDs[i]);
		CSize size = ((CDC*)this->GetDC())->GetTextExtent(strTxt);
		m_camCtrlList.InsertColumn(i, strTxt, LVCFMT_CENTER, size.cx + TXT_EXTENT);
	}

	m_camCtrlList.SetGridLines();
	m_camCtrlList.SetImageList(&m_imgList, LVSIL_SMALL);

	m_bInitialized = TRUE;
}

BOOL CRtuCamCtrlPage2::OnSetActive()
{
	ShowStatus();
	return CXTPPropertyPage::OnSetActive();
}

LPBYTE CRtuCamCtrlPage2::SetStatus(LPBYTE lpData, int numDevices, BOOL)
{
	return m_devInfo.SetData(CDeviceInfoData::E_DEV_TYPE_CAM_CTRL, lpData, numDevices);
}

void CRtuCamCtrlPage2::ShowStatus()
{
	if (IsWindow(m_hWnd) == FALSE) return;

	if (!m_bInitialized)
		InitializeComponent();

	m_camCtrlList.DeleteAllItems();

	LVITEM lvi;
	lvi.mask = LVIF_IMAGE | LVIF_TEXT;
	CString strText;
	m_devInfo.Reset();
	for(int i=0; i<m_devInfo.GetCount(); i++) {
		m_devInfo.UpdateListItem(lvi, i, strText);
		m_camCtrlList.InsertItem(&lvi);

		// Tamper status
		m_camCtrlList.SetItemText(i, 1, m_devInfo.GetTamperStatus());

		// Offline status
		m_camCtrlList.SetItemText(i, 2, m_devInfo.GetOfflineStatus());

		// Isolated status
		m_camCtrlList.SetItemText(i, 3, m_devInfo.GetIsolatedStatus());

		m_devInfo.MoveNext();
	}
   
}

void CRtuCamCtrlPage2::Print()
{
	TCHAR fname[MAX_PATH] = _T("");
	if (!RtuLib::GetPrintFileName(fname, _T(".html")))
		return;

	CHtmlFile* pFile = new CHtmlFile(hrInst, fname);
	pFile->StartTags(IsRtu8002Type()? RTU_8002_TYPE: realRtuType, gRtuNo, IDS_RTU_STATUS, IDS_CAM_CTRLR_STS);

	CString sCamNum = RES_STRING(IDS_CAMERA_NUM);
	CString sTamper = RES_STRING(IDS_TAMPER);
	CString sOffline = RES_STRING(IDS_OFFLINE);
	CString sIsolated = RES_STRING(IDS_ISOLATED);

	pFile->SetBgColor(colors[2]);
	pFile->AddTH(4, 1, sCamNum, 1, sTamper, 1, sOffline, 1, sIsolated);

	m_devInfo.Reset();
	for(int i=0; i<m_devInfo.GetCount(); i++) {
		pFile->SetBgColor(colors[i & 1 ? 1 : 0]);
		sCamNum.Format(_T("%d"), i + 1);
		pFile->AddTD(4, 1, sCamNum,
			1, m_devInfo.GetTamperStatus(),
			1, m_devInfo.GetOfflineStatus(),
			1, m_devInfo.GetIsolatedStatus());
		
		m_devInfo.MoveNext();
	}

	pFile->EndTags(); delete pFile; pFile = NULL;
	RtuLib::FileExecute(GetSafeHwnd(), fname, _T("open"));
}

#pragma endregion CRtuCamCtrlPage2
/*------------------------------------------------------------------------------*/
/*					Elevator Controller Status Page Class						*/
/*------------------------------------------------------------------------------*/
#pragma region CRtuElevCtrlPage2

IMPLEMENT_DYNCREATE(CRtuElevCtrlPage2, CXTPPropertyPage)

void CRtuElevCtrlPage2::DoDataExchange(CDataExchange* pDX)
{
	CXTPPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CRtuElevCtrlPage2)
	DDX_Control(pDX, IDC_LIST, m_elevCtrlList);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CRtuElevCtrlPage2, CXTPPropertyPage)
	//{{AFX_MSG_MAP(CRtuElevCtrlPage2)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


BOOL CRtuElevCtrlPage2::OnInitDialog()
{
	CDialog::OnInitDialog();
	CWnd* pWnd = GetDlgItem(IDC_RTU_TOTAL);
	if (pWnd) {
		pWnd->ShowWindow(SW_HIDE);
	}
	
	return TRUE;
}

void CRtuElevCtrlPage2::InitializeComponent()
{
	m_imgList.Create(IDB_ELEVATORS, 12, 0, RGB(0, 0x80, 0x80));
	UINT nStrIDs[] = {IDS_NUMBER, IDS_TAMPER, IDS_OFFLINE, IDS_ISOLATED};
	for(int i=0; i<4; i++) {
		CString strTxt = RES_STRING(nStrIDs[i]);
		CSize size = ((CDC*)this->GetDC())->GetTextExtent(strTxt);
		m_elevCtrlList.InsertColumn(i, strTxt, LVCFMT_CENTER, size.cx + TXT_EXTENT);
	}

	m_elevCtrlList.SetGridLines();
	m_elevCtrlList.SetImageList(&m_imgList, LVSIL_SMALL);

	m_bInitialized = TRUE;
}

BOOL CRtuElevCtrlPage2::OnSetActive()
{
	ShowStatus();
	return CXTPPropertyPage::OnSetActive();
}

LPBYTE CRtuElevCtrlPage2::SetStatus(LPBYTE lpData, int numDevices, BOOL)
{
	return m_devInfo.SetData(CDeviceInfoData::E_DEV_TYPE_ELEVATOR, lpData, numDevices);
}

void CRtuElevCtrlPage2::ShowStatus()
{
	if (IsWindow(m_hWnd) == FALSE) return;
	if (!m_bInitialized)
		InitializeComponent();

	m_elevCtrlList.DeleteAllItems();

	LVITEM lvi;
	lvi.mask = LVIF_IMAGE | LVIF_TEXT;
	CString strText;
	m_devInfo.Reset();
	for(int i=0; i<m_devInfo.GetCount(); i++) {
		m_devInfo.UpdateListItem(lvi, i, strText);
		m_elevCtrlList.InsertItem(&lvi);

		// Tamper status
		m_elevCtrlList.SetItemText(i, 1, m_devInfo.GetTamperStatus());

		// Offline status
		m_elevCtrlList.SetItemText(i, 2, m_devInfo.GetOfflineStatus());

		// Isolated status
		m_elevCtrlList.SetItemText(i, 3, m_devInfo.GetIsolatedStatus());

		m_devInfo.MoveNext();
	}

}

void CRtuElevCtrlPage2::Print()
{
	TCHAR fname[MAX_PATH] = _T("");
	if (!RtuLib::GetPrintFileName(fname, _T(".html")))
		return;

	CHtmlFile* pFile = new CHtmlFile(hrInst, fname);
	pFile->StartTags(IsRtu8002Type()? RTU_8002_TYPE: realRtuType, gRtuNo, IDS_RTU_STATUS, IDS_ELEV_CTRLR_STS);

	CString sElevNum = RES_STRING(IDS_ELEV_NUM);
	CString sTamper = RES_STRING(IDS_TAMPER);
	CString sOffline = RES_STRING(IDS_OFFLINE);
	CString sIsolated = RES_STRING(IDS_ISOLATED);

	pFile->SetBgColor(colors[2]);
	pFile->AddTH(4, 1, sElevNum, 1, sTamper, 1, sOffline, 1, sIsolated);

	m_devInfo.Reset();
	for(int i=0; i<m_devInfo.GetCount(); i++) {
		pFile->SetBgColor(colors[i & 1 ? 1 : 0]);
		sElevNum.Format(_T("%d"), i + 1);
		pFile->AddTD(4, 1, sElevNum,
			1, m_devInfo.GetTamperStatus(),
			1, m_devInfo.GetOfflineStatus(),
			1, m_devInfo.GetIsolatedStatus());
		
		m_devInfo.MoveNext();
	}

	pFile->EndTags(); delete pFile; pFile = NULL;
	RtuLib::FileExecute(GetSafeHwnd(), fname, _T("open"));
}

#pragma endregion CRtuElevCtrlPage2
/*------------------------------------------------------------------------------*/
/*					Dialer Status Page Class									*/
/*------------------------------------------------------------------------------*/
#pragma region CRtuDialerPage2

IMPLEMENT_DYNCREATE(CRtuDialerPage2, CXTPPropertyPage)

void CRtuDialerPage2::DoDataExchange(CDataExchange* pDX)
{
	CXTPPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CRtuDialerPage2)
	DDX_Control(pDX, IDC_LIST, m_dialList);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CRtuDialerPage2, CXTPPropertyPage)
	//{{AFX_MSG_MAP(CRtuDialerPage2)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


BOOL CRtuDialerPage2::OnInitDialog()
{
	CDialog::OnInitDialog();
	CWnd* pWnd = GetDlgItem(IDC_RTU_TOTAL);
	if (pWnd) {
		pWnd->ShowWindow(SW_HIDE);
	}
	
	return TRUE;
}

void CRtuDialerPage2::InitializeComponent()
{
	m_imgList.Create(IDB_DIALUPS, 12, 0, RGB(0, 0x80, 0x80));
	UINT nStrIDs[] = {IDS_NUMBER, IDS_TAMPER, IDS_OFFLINE, IDS_ISOLATED};
	for(int i=0; i<4; i++) {
		CString strTxt = RES_STRING(nStrIDs[i]);
		CSize size = ((CDC*)this->GetDC())->GetTextExtent(strTxt);
		m_dialList.InsertColumn(i, strTxt, LVCFMT_CENTER, size.cx + TXT_EXTENT);
	}

	m_dialList.SetGridLines();
	m_dialList.SetImageList(&m_imgList, LVSIL_SMALL);

	m_bInitialized = TRUE;
}

BOOL CRtuDialerPage2::OnSetActive()
{
	ShowStatus();
	return CXTPPropertyPage::OnSetActive();
}

LPBYTE CRtuDialerPage2::SetStatus(LPBYTE lpData, int numDevices, BOOL)
{
	return m_devInfo.SetData(CDeviceInfoData::E_DEV_TYPE_DIALER, lpData, numDevices);
}

void CRtuDialerPage2::ShowStatus()
{
	if (IsWindow(m_hWnd) == FALSE) return;
	if (!m_bInitialized)
		InitializeComponent();

	m_dialList.DeleteAllItems();

	LVITEM lvi;
	lvi.mask = LVIF_IMAGE | LVIF_TEXT;
	CString strText;
	m_devInfo.Reset();
	for(int i=0; i<m_devInfo.GetCount(); i++) {
		m_devInfo.UpdateListItem(lvi, i, strText);
		m_dialList.InsertItem(&lvi);

		// Tamper status
		m_dialList.SetItemText(i, 1, m_devInfo.GetTamperStatus());

		// Offline status
		m_dialList.SetItemText(i, 2, m_devInfo.GetOfflineStatus());

		// Isolated status
		m_dialList.SetItemText(i, 3, m_devInfo.GetIsolatedStatus());

		m_devInfo.MoveNext();
	}

}

void CRtuDialerPage2::Print()
{
	TCHAR fname[MAX_PATH] = _T("");
	if (!RtuLib::GetPrintFileName(fname, _T(".html")))
		return;

	CHtmlFile* pFile = new CHtmlFile(hrInst, fname);
	pFile->StartTags(IsRtu8002Type()? RTU_8002_TYPE: realRtuType, gRtuNo, IDS_RTU_STATUS, IDS_DIALER_STS);

	CString sDialerNum = RES_STRING(IDS_DIALER_NUM);
	CString sTamper = RES_STRING(IDS_TAMPER);
	CString sOffline = RES_STRING(IDS_OFFLINE);
	CString sIsolated = RES_STRING(IDS_ISOLATED);

	pFile->SetBgColor(colors[2]);
	pFile->AddTH(4, 1, sDialerNum, 1, sTamper, 1, sOffline, 1, sIsolated);

	m_devInfo.Reset();
	for(int i=0; i<m_devInfo.GetCount(); i++) {
		pFile->SetBgColor(colors[i & 1 ? 1 : 0]);
		sDialerNum.Format(_T("%d"), i + 1);
		pFile->AddTD(4, 1, sDialerNum,
			1, m_devInfo.GetTamperStatus(),
			1, m_devInfo.GetOfflineStatus(),
			1, m_devInfo.GetIsolatedStatus());
		
		m_devInfo.MoveNext();
	}

	pFile->EndTags(); delete pFile; pFile = NULL;
	RtuLib::FileExecute(GetSafeHwnd(), fname, _T("open"));
}

#pragma endregion CRtuDialerPage2
/*------------------------------------------------------------------------------*/
/*					Card Reader Status Page Class								*/
/*------------------------------------------------------------------------------*/
#pragma region CRtuCardRdrPage2

IMPLEMENT_DYNCREATE(CRtuCardRdrPage2, CXTPPropertyPage)

void CRtuCardRdrPage2::DoDataExchange(CDataExchange* pDX)
{
	CXTPPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CRtuCardRdrPage2)
	DDX_Control(pDX, IDC_LIST, m_rdrList);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CRtuCardRdrPage2, CXTPPropertyPage)
	//{{AFX_MSG_MAP(CRtuCardRdrPage2)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


BOOL CRtuCardRdrPage2::OnInitDialog()
{
	CDialog::OnInitDialog();
	CWnd* pWnd = GetDlgItem(IDC_RTU_TOTAL);
	if (pWnd) {
		pWnd->ShowWindow(SW_HIDE);
	}

	m_nNumColumns = 0;
	m_imgList.Create(IDB_READERS, 16, 0, RGB(0, 0x80, 0x80));
	m_rdrList.SetGridLines();
	m_rdrList.SetImageList(&m_imgList, LVSIL_SMALL);
	return TRUE;
}

void CRtuCardRdrPage2::UpdateStatusList()
{
	m_rdrList.DeleteAllItems();
	if (m_nNumColumns) {
		for(int col=m_nNumColumns-1; col>=0; col--) {
			m_rdrList.DeleteColumn(col);
		}
	}

	UINT nStrIDs[] = {IDS_NUMBER, IDS_TAMPER, IDS_OFFLINE, IDS_ISOLATED, 
		IDS_DEVICE_TYPE, IDS_PHYSICAL_ADDRESS, IDS_PHYSICAL_PORT, IDS_FIRMWARE_VER, IDS_BOOT_LOADER_VER};

	int nColumn = 4;
	if (s_bCardReaderFirmware)
		nColumn += 5;

	for(int i=0; i<nColumn; i++) {
		CString strTxt = RES_STRING(nStrIDs[i]);
		CSize size = ((CDC*)this->GetDC())->GetTextExtent(strTxt);
		m_rdrList.InsertColumn(i, strTxt, LVCFMT_CENTER, size.cx + TXT_EXTENT);
	}

	m_nNumColumns = nColumn;
}

BOOL CRtuCardRdrPage2::OnSetActive()
{
	ShowStatus();
	return CXTPPropertyPage::OnSetActive();
}

LPBYTE CRtuCardRdrPage2::SetStatus(LPBYTE lpData, int numDevices, BOOL)
{
	return m_devInfo.SetData(CDeviceInfoData::E_DEV_TYPE_READER, lpData, numDevices);
}

void CRtuCardRdrPage2::ShowStatus()
{
	if (IsWindow(m_hWnd) == FALSE) return;
	UpdateStatusList();

	LVITEM lvi;
	lvi.mask = LVIF_IMAGE | LVIF_TEXT;
	CString strText;
	m_devInfo.Reset();
	for(int i=0; i<m_devInfo.GetCount(); i++) {
		m_devInfo.UpdateListItem(lvi, i, strText);
		m_rdrList.InsertItem(&lvi);

		// Tamper status
		m_rdrList.SetItemText(i, 1, m_devInfo.GetTamperStatus());

		// Offline status
		m_rdrList.SetItemText(i, 2, m_devInfo.GetOfflineStatus());

		// Isolated status
		m_rdrList.SetItemText(i, 3, m_devInfo.GetIsolatedStatus());

		if (s_bCardReaderFirmware) {
			// device type
			m_rdrList.SetItemText(i, 4, GetDeviceTypeString(i));

			// device physical address
			m_rdrList.SetItemText(i, 5, GetDevicePhysicalAddressString(s_cardReaderFirmware[i].physicalAddress));

			// device physical port
			m_rdrList.SetItemText(i, 6, GetDevicePhysicalPortString(s_cardReaderFirmware[i].physicalPort));

			// firmware verion
			m_rdrList.SetItemText(i, 7, GetFirmwareVersionString(i));

			// bootloader version
			m_rdrList.SetItemText(i, 8, GetBootloaderVersionString(i));
		}

		m_devInfo.MoveNext();
	}
}

CString CRtuCardRdrPage2::GetDeviceTypeString(int index)
{
	CString s = GetDevTypeString(s_cardReaderFirmware[index].deviceType);
	if (s == _T(""))
		s = _T("CRI");

	return s;
}
CString CRtuCardRdrPage2::GetFirmwareVersionString(int index)
{
	return GetVersionString(s_cardReaderFirmware[index].firmwareVerMajor, s_cardReaderFirmware[index].firmwareVerMinor);
}
CString CRtuCardRdrPage2::GetBootloaderVersionString(int index)
{
	return GetVersionString(s_cardReaderFirmware[index].bootLoaderVerMajor, s_cardReaderFirmware[index].bootLoaderVerMinor);
}

void CRtuCardRdrPage2::Print()
{
	TCHAR fname[MAX_PATH] = _T("");
	if (!RtuLib::GetPrintFileName(fname, _T(".html")))
		return;

	CHtmlFile* pFile = new CHtmlFile(hrInst, fname);
	pFile->StartTags(IsRtu8002Type()? RTU_8002_TYPE: realRtuType, gRtuNo, IDS_RTU_STATUS, IDS_CARD_RDR_STS);

	CString sRdrNum = RES_STRING(IDS_RDR_NUM);
	CString sTamper = RES_STRING(IDS_TAMPER);
	CString sOffline = RES_STRING(IDS_OFFLINE);
	CString sIsolated = RES_STRING(IDS_ISOLATED);
	CString sDevType = RES_STRING(IDS_DEVICE_TYPE);
	CString sPhysAddr = RES_STRING(IDS_PHYSICAL_ADDRESS);
	CString sPhysPort = RES_STRING(IDS_PHYSICAL_PORT);
	CString sFirmware = RES_STRING(IDS_FIRMWARE_VER);
	CString sBootLoader = RES_STRING(IDS_BOOT_LOADER_VER);

	pFile->SetBgColor(colors[2]);

	int hCount = 4;
	if (s_bCardReaderFirmware)
		hCount += 5;

	if (hCount == 4)
		pFile->AddTH(hCount, 1, sRdrNum, 1, sTamper, 1, sOffline, 1, sIsolated);
	else
		pFile->AddTH(hCount, 1, sRdrNum, 1, sTamper, 1, sOffline, 1, sIsolated, 
			1, sDevType, 1, sPhysAddr, 1, sPhysPort, 1, sFirmware, 1, sBootLoader);
	
	m_devInfo.Reset();
	for(int i=0; i<m_devInfo.GetCount(); i++) {
		pFile->SetBgColor(colors[i & 1 ? 1 : 0]);
		sRdrNum.Format(_T("%d"), i + 1);
		if (s_bCardReaderFirmware) {
			pFile->AddTD(7, 1, sRdrNum,
				1, m_devInfo.GetTamperStatus(),
				1, m_devInfo.GetOfflineStatus(),
				1, m_devInfo.GetIsolatedStatus(), 
				1, GetDeviceTypeString(i),
				1, GetDevicePhysicalAddressString(s_cardReaderFirmware[i].physicalAddress),
				1, GetDevicePhysicalPortString(s_cardReaderFirmware[i].physicalPort),
				1, GetFirmwareVersionString(i),
				1, GetBootloaderVersionString(i));
		}
		else {
			pFile->AddTD(4, 1, sRdrNum,
				1, m_devInfo.GetTamperStatus(),
				1, m_devInfo.GetOfflineStatus(),
				1, m_devInfo.GetIsolatedStatus());
		}
			
		m_devInfo.MoveNext();
	}

	pFile->EndTags(); delete pFile; pFile = NULL;
	RtuLib::FileExecute(GetSafeHwnd(), fname, _T("open"));
}

#pragma endregion CRtuCardRdrPage2

/*------------------------------------------------------------------------------*/
/*					Input Status Page Class										*/
/*------------------------------------------------------------------------------*/
#pragma region CRtuInpStsPage2

CRtuInpStsPage2::CRtuInpStsPage2() : CRtuStatusBase2(CRtuInpStsPage2::IDD)
{
	m_numInputs=0; 
	m_curInputNum=0; 
	memset(m_inputStatus, 0, sizeof(m_inputStatus));

	m_numLatches=0;
	
	memset(m_latchedStatus, 0, sizeof(m_latchedStatus));

	m_numSoaks=0;
	
	memset(m_soakedStatus, 0, sizeof(m_soakedStatus));

	m_hasInputExtendedStatus = FALSE;
	m_numInputExtendedStatus = 0;
	memset(m_inputExtendedStatus, 0, sizeof(m_inputExtendedStatus));
	m_nNumColumns = 0;
}


IMPLEMENT_DYNCREATE(CRtuInpStsPage2, CXTPPropertyPage)

void CRtuInpStsPage2::DoDataExchange(CDataExchange* pDX)
{
	CXTPPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CRtuInpStsPage2)
	DDX_Control(pDX, IDC_LIST, m_inputList);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CRtuInpStsPage2, CXTPPropertyPage)
	//{{AFX_MSG_MAP(CRtuInpStsPage2)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


BOOL CRtuInpStsPage2::OnInitDialog()
{
	CDialog::OnInitDialog();
	CWnd* pWnd = GetDlgItem(IDC_RTU_INPTOTAL);
	if (pWnd) {
		pWnd->ShowWindow(SW_HIDE);
	}
	
	m_imgList.Create(IDB_INPUTS, 12, 0, RGB(0x00, 0x80, 0x80));

	UpdateInputList();

	return TRUE;
}

void CRtuInpStsPage2::UpdateInputList()
{
	m_inputList.DeleteAllItems();
	if (m_nNumColumns) {
		for(int col=m_nNumColumns-1; col>=0; col--) {
			m_inputList.DeleteColumn(col);
		}
	}

	UINT nStrIDs[] = {IDS_NUMBER, IDS_POINT_STS, IDS_ISOLATED, IDS_SOAK_STS, IDS_LATCH_STS};
	CString strTxt;
	for(int i=0; i<3; i++) {
		strTxt = RES_STRING(nStrIDs[i]);
		CSize size = ((CDC*)this->GetDC())->GetTextExtent(strTxt);
		m_inputList.InsertColumn(i, strTxt, LVCFMT_CENTER, size.cx + TXT_EXTENT);
	}
	
	int nextColumn = 3;
	if (m_numSoaks && m_numLatches) {
		for(int i=3; i<5; i++) {
			strTxt = RES_STRING(nStrIDs[i]);
			CSize size = ((CDC*)this->GetDC())->GetTextExtent(strTxt);
			m_inputList.InsertColumn(i, strTxt, LVCFMT_CENTER, size.cx + TXT_EXTENT);
		}
		nextColumn = 5;
	}

	else if (m_numSoaks) {
		strTxt = RES_STRING(nStrIDs[3]);
		CSize size = ((CDC*)this->GetDC())->GetTextExtent(strTxt);
		m_inputList.InsertColumn(3, strTxt, LVCFMT_CENTER, size.cx + TXT_EXTENT);
		nextColumn = 4;
	}

	else if (m_numLatches) {
		strTxt = RES_STRING(nStrIDs[4]);
		CSize size = ((CDC*)this->GetDC())->GetTextExtent(strTxt);
		m_inputList.InsertColumn(3, strTxt, LVCFMT_CENTER, size.cx + TXT_EXTENT);
		nextColumn = 4;
	}

	int nNumColumns = nextColumn;

	if (m_hasInputExtendedStatus) {
		UINT nStrID2s[] = {IDS_TX_STATUS_LEVEL, IDS_TAMPER_ALARM, IDS_BATT_LOW_ALARM, IDS_SUSPICION_ACTIVE};
		for(int i=0; i<4; i++) {
			strTxt = RES_STRING(nStrID2s[i]);
			CSize size = ((CDC*)this->GetDC())->GetTextExtent(strTxt);
			m_inputList.InsertColumn(nextColumn + i, strTxt, LVCFMT_CENTER, size.cx + TXT_EXTENT);
		}
		nNumColumns += 4;
	}

	m_inputList.SetGridLines(TRUE);
	m_inputList.SetImageList(&m_imgList, LVSIL_SMALL);

	m_nNumColumns = nNumColumns;
}

BOOL CRtuInpStsPage2::OnSetActive()
{
	ShowStatus();
	return CXTPPropertyPage::OnSetActive();
}

LPBYTE CRtuInpStsPage2::SetStatus(LPBYTE lpData, int, BOOL)
{
	return SetInpStsData(lpData);
}

LPBYTE CRtuInpStsPage2::SetInpStsData(LPBYTE lpData)
{
	LPBYTE p = lpData;
	m_numInputs = *p;
	
	GmsOutputDebugString(__FUNCTIONW__, __LINE__, L"Count=%d", *lpData);
	if (m_numInputs > MAX_RTU_ALMPNTS)
		m_numInputs = MAX_RTU_ALMPNTS;

	if (m_numInputs == 0) // since max inputs is 256, more than 1 byte.
		m_numInputs = MAX_RTU_ALMPNTS;
	try
	{
		memset(&m_inputStatus, 0, sizeof(m_inputStatus));

		int cnt = (m_numInputs>>1) + ((m_numInputs%2) ? 1 : 0);
	
		_OutputDebugMemory(L"CRtuInpStsPage2::SetInpStsData", lpData, cnt+1);

		memcpy(m_inputStatus, p+1, cnt);

		lpData += (1 + cnt);		//.I/P status bytes
	}
	catch (...)
	{
		m_numInputs  = 0;
		OutputDebugString(L"Exception in CRtuInpStsPage2::SetStatus()\n");
	}
	return lpData;
}

LPBYTE CRtuInpStsPage2::SetLatchStsData(LPBYTE lpData)
{
	LPBYTE p = lpData;
	m_numLatches = *p;

	try
	{
		if (m_numLatches == 0) 
		{
			m_numLatches = MAX_RTU_ALMPNTS;
		}
	
		int cnt = ((m_numLatches - 1) / 8) + 1;
		memcpy(&m_latchedStatus[0], p+1, cnt);
	
		lpData += 1 + cnt;
	}
	catch (...)
	{
		m_numLatches  = 0;
		OutputDebugString(L"Exception in CRtuInpStsPage2::SetLatchStsData()\n");
	}
	return lpData;
}

LPBYTE CRtuInpStsPage2::SetSoakStsData(LPBYTE lpData)
{
	LPBYTE p = lpData;
	m_numSoaks = *p;

	try
	{
		if (m_numSoaks == 0) {
			m_numSoaks = MAX_RTU_ALMPNTS;
		}
		int cnt = ((m_numSoaks - 1)/8) + 1;
		memcpy(&m_soakedStatus[0], p+1, cnt);
	
		lpData += 1 + cnt;
	}
	catch (...)
	{
		m_numSoaks  = 0;
		OutputDebugString(L"Exception in CRtuInpStsPage2::SetSoakStsData()\n");
	}
	return lpData;
}

LPBYTE CRtuInpStsPage2::SetExtendeInputData(LPBYTE lpData)
{
	if (lpData == NULL)
		return NULL;

	LPBYTE p = lpData;
	try {
		memset(m_inputExtendedStatus, 0, sizeof(m_inputExtendedStatus));
		m_hasInputExtendedStatus = TRUE;
		m_numInputExtendedStatus = *p++;
		if (m_numInputExtendedStatus == 0) {
			m_numInputExtendedStatus = MAX_RTU_ALMPNTS;
		}
		memcpy(m_inputExtendedStatus, p, m_numInputExtendedStatus);
		p += m_numInputExtendedStatus;
	}
	catch (...) { 
	}

	return p;
}

void CRtuInpStsPage2::ShowStatus()
{
	if (IsWindow(m_hWnd) == FALSE) return;

	CString sTmp = RES_STRING(IDS_TOT_INP);
	CString str; str.Format(sTmp, m_numInputs);
	GetDlgItem(IDC_RTU_INPTOTAL)->SetWindowText(str);

	UINT pntIDs[] = {IDS_NOT_DEFINED, IDS_SECURE, IDS_NORMAL, IDS_SHORT, 
		IDS_OPEN, IDS_TROUBLE, IDS_SHUNT, IDS_EMPTY};

	CString sYes = RES_STRING(IDS_YES_TXT);
	CString sNo = RES_STRING(IDS_NO_TXT);

	LVITEM lvi;
	CString strItem;
	lvi.mask =  LVIF_IMAGE | LVIF_TEXT;
	
	BYTE mask = 1;
	int imgNum=0;
	
	UpdateInputList();

	if (m_numInputs == 0) return;

	for(int i=0; i<m_numInputs; i++) {
		BYTE data = m_inputStatus[i/2];
		if (i & 1)
			data >>= 4;
		
		if (data & 8)
			imgNum = 2;
		else if ((data & 7) == 1 || (data & 7) == 0)		// input secured, not define
			imgNum = 0;
		else 
			imgNum = 1;

		lvi.iItem = i;
		lvi.iImage = imgNum;
		strItem.Format(_T("%d"), i+1);
		lvi.iSubItem = 0;
		lvi.pszText = (LPTSTR)(LPCTSTR)(strItem);
		m_inputList.InsertItem(&lvi);

		// Set subitem 1
		sTmp = RES_STRING(pntIDs[data & 7]);
		m_inputList.SetItemText(i, 1, sTmp);

		// Set subitem 2
		m_inputList.SetItemText(i, 2, data & 8 ? sYes : sNo);

		int nextSubItem = 3;
		if (m_numSoaks && m_numLatches) {
			// Set subitem 3
			data = m_soakedStatus[i/8];
			m_inputList.SetItemText(i, 3, data & mask ? sYes : sNo);

			// Set subitem 4
			data = m_latchedStatus[i/8];
			m_inputList.SetItemText(i, 4, data & mask ? sYes : sNo);

			nextSubItem = 5;
		}
		else if (m_numSoaks) {
			data = m_soakedStatus[i/8];
			m_inputList.SetItemText(i, 3, data & mask ? sYes : sNo);
			nextSubItem = 4;
		}
		else if (m_numLatches) {
			data = m_latchedStatus[i/8];
			m_inputList.SetItemText(i, 3, data & mask ? sYes : sNo);
			nextSubItem = 4;
		}
		 
		mask <<= 1;
		if (mask == 0)
			mask = 1;

		if (m_hasInputExtendedStatus) {
			int stsLevel = m_inputExtendedStatus[i] & 0x07;
			if (stsLevel == 0)
				strItem = _T("--");
			else
				strItem.Format(_T("%d"), stsLevel);
			m_inputList.SetItemText(i, nextSubItem++, strItem);
			

			m_inputList.SetItemText(i, nextSubItem++, m_inputExtendedStatus[i] & 0x08 ? sYes : sNo);
			m_inputList.SetItemText(i, nextSubItem++, m_inputExtendedStatus[i] & 0x10 ? sYes : sNo);
			m_inputList.SetItemText(i, nextSubItem++, m_inputExtendedStatus[i] & 0x20 ? sYes : sNo);
		}

	}
}

void CRtuInpStsPage2::Print()
{
	TCHAR fname[MAX_PATH] = _T("");
	if (!RtuLib::GetPrintFileName(fname, _T(".html")))
		return;

	CHtmlFile* pFile = new CHtmlFile(hrInst, fname);
	pFile->StartTags(IsRtu8002Type()? RTU_8002_TYPE: realRtuType, gRtuNo, IDS_RTU_STATUS, IDS_INPUT_STS);

	BOOL bSoak = FALSE;
	BOOL bLatch = FALSE;
	int iCount = 3;

	UINT pntIDs[] = {IDS_NOT_DEFINED, IDS_SECURE, IDS_NORMAL, IDS_SHORT, 
		IDS_OPEN, IDS_TROUBLE, IDS_SHUNT, IDS_EMPTY};

   	if (m_numSoaks && m_numLatches) {
		bSoak = TRUE; bLatch = TRUE; iCount = 5;
	}
	else if (m_numSoaks) {
		bSoak = TRUE; iCount = 4;
	}
	else if (m_numLatches) {
		bLatch = TRUE; iCount = 4;
	}

	CString sYes = RES_STRING(IDS_YES_TXT);
	CString sNo = RES_STRING(IDS_NO_TXT);
	CString sInpNum = RES_STRING(IDS_INPUT_NUMBER);
	CString sPntSts = RES_STRING(IDS_POINT_STS);
	CString sIsolated = RES_STRING(IDS_ISOLATED);
	CString sSoakSts = RES_STRING(IDS_SOAK_STS);
	CString sLatchSts = RES_STRING(IDS_LATCH_STS);

	pFile->SetBgColor(colors[2]);
	pFile->AddTH(iCount, 1, sInpNum, 1, sPntSts, 1, sIsolated, 1, sSoakSts, 1, sLatchSts);

	BYTE mask = 1;
	for(int i=0; i<m_numInputs; i++) {
	
		pFile->SetBgColor(colors[i & 1 ? 1 : 0]);
		
		BYTE data = m_inputStatus[i/2];
		if (i & 1)
			data >>= 4;
		sInpNum.Format(_T("%d"), i+1);
		sPntSts = RES_STRING(pntIDs[data & 7]);
		sIsolated = data & 8 ? sYes : sNo;

		if (bSoak && bLatch) {
			sSoakSts = m_soakedStatus[i/8] & mask ? sYes : sNo;
			sLatchSts = m_latchedStatus[i/8] & mask ? sYes : sNo;
		}
		else if (bSoak) {
			sSoakSts = m_soakedStatus[i/8] & mask ? sYes : sNo;
		}
		else if (bLatch) {
			sSoakSts = m_latchedStatus[i/8] & mask ? sYes : sNo;
		}

		mask <<= 1;
		if (mask == 0)
			mask = 1;

		pFile->AddTD(iCount, 1, sInpNum, 1, sPntSts, 1, sIsolated, 1, sSoakSts, 1, sLatchSts);
	}

	pFile->EndTags(); delete pFile; pFile = NULL;
	RtuLib::FileExecute(GetSafeHwnd(), fname, _T("open"));
}

#pragma endregion CRtuInpStsPage2

/*------------------------------------------------------------------------------*/
/*					Output Status Page Class									*/
/*------------------------------------------------------------------------------*/
#pragma region CRtuOpStsPage2

IMPLEMENT_DYNCREATE(CRtuOpStsPage2, CXTPPropertyPage)

void CRtuOpStsPage2::DoDataExchange(CDataExchange* pDX)
{
	CXTPPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CRtuOpStsPage2)
	DDX_Control(pDX, IDC_LIST, m_outputList);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CRtuOpStsPage2, CXTPPropertyPage)
	//{{AFX_MSG_MAP(CRtuOpStsPage2)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


BOOL CRtuOpStsPage2::OnInitDialog()
{
	CDialog::OnInitDialog();
	CWnd* pWnd = GetDlgItem(IDC_RTU_TOTAL);
	if (pWnd) {
		pWnd->ShowWindow(SW_HIDE);
	}

	m_imgList.Create(IDB_OUTPUTS, 12, 0, RGB(0x00, 0x80, 0x80));
	UINT nStrIDs[] = {IDS_NUMBER, IDS_POINT_STS, IDS_ISOLATED};
	for(int i=0; i<3; i++) {
		CString strTxt = RES_STRING(nStrIDs[i]);
		CSize size = ((CDC*)this->GetDC())->GetTextExtent(strTxt);
		m_outputList.InsertColumn(i, strTxt, LVCFMT_CENTER, size.cx + TXT_EXTENT);
	}

	m_outputList.SetGridLines(TRUE);
	m_outputList.SetImageList(&m_imgList, LVSIL_SMALL);

	return TRUE;
}

BOOL CRtuOpStsPage2::OnSetActive()
{
	ShowStatus();
	return CXTPPropertyPage::OnSetActive();
}

LPBYTE CRtuOpStsPage2::SetStatus(LPBYTE lpData, int, BOOL)
{
	LPBYTE p = lpData;
	m_numOutputs = *p;
	GmsOutputDebugString(__FUNCTIONW__, __LINE__, L"Count=%d", *lpData);
	if (m_numOutputs > MAXOPS)
		m_numOutputs = MAXOPS;
	try
	{
		int cnt = (m_numOutputs % 4) ? m_numOutputs/4 + 1 : m_numOutputs/4;
		memset(&m_outputStatus, 0, sizeof(m_outputStatus));

		_OutputDebugMemory(L"CRtuOutputStatusPage2::SetStatus", lpData, cnt+1);

		memcpy(m_outputStatus, p+1, cnt);
		lpData += 1 + cnt;
	}
	catch (...)
	{
		m_numOutputs = 0;
		OutputDebugString(L"Exception in CRtuOutputStatusPage2::SetStatus\n");
	}
	return lpData;
}

void CRtuOpStsPage2::ShowStatus()
{
	if (IsWindow(m_hWnd) == FALSE) return;

	m_outputList.DeleteAllItems();
	LVITEM lvi;
	CString strItem;

	CString str = RES_STRING(IDS_TOT_OUT);
	strItem.Format(str, m_numOutputs);
	GetDlgItem(IDC_RTU_TOTAL)->SetWindowText(strItem);
	lvi.mask = LVIF_IMAGE | LVIF_TEXT;

	int imgNum=0;
	BYTE data = 0;

	CString sYes = RES_STRING(IDS_YES_TXT);
	CString sNo = RES_STRING(IDS_NO_TXT);
	CString sOn = RES_STRING(IDS_ON);
	CString sOff = RES_STRING(IDS_OFF);

	for (int i=0; i<m_numOutputs; i++) {
		if ( (i % 4) == 0 ) {
			data = m_outputStatus[i/4];
		}

		if (data & 2)
			imgNum = 2;		// output isolated
		else if (data & 1)
			imgNum = 1;		// output ON
		else
			imgNum = 0;		// output OFF

		lvi.iItem = i;
		lvi.iImage = imgNum;

		strItem.Format(_T("%d"), i+1);
		lvi.iSubItem = 0;
		lvi.pszText = (LPTSTR)(LPCTSTR)(strItem);
		m_outputList.InsertItem(&lvi);

		// Set subitem 1
		m_outputList.SetItemText(i, 1, data & 1 ? sOn : sOff);

		// Set subitem 2
		m_outputList.SetItemText(i, 2, data & 2 ? sYes : sNo);

		data >>= 2;

	}
}

void CRtuOpStsPage2::Print()
{
	TCHAR fname[MAX_PATH] = _T("");
	if (!RtuLib::GetPrintFileName(fname, _T(".html")))
		return;

	CHtmlFile* pFile = new CHtmlFile(hrInst, fname);
	pFile->StartTags(IsRtu8002Type()? RTU_8002_TYPE: realRtuType, gRtuNo, IDS_RTU_STATUS, RTU_DB_STSTYPE8);

	CString sYes = RES_STRING(IDS_YES_TXT);
	CString sNo = RES_STRING(IDS_NO_TXT);
	CString sOn = RES_STRING(IDS_ON);
	CString sOff = RES_STRING(IDS_OFF);
	CString sOutNum = RES_STRING(IDS_OUT_NUM);
	CString sPntSts = RES_STRING(IDS_POINT_STS);
	CString sIsolated = RES_STRING(IDS_ISOLATED);

	pFile->SetBgColor(colors[2]);
	pFile->AddTH(3, 1, sOutNum, 1, sPntSts, 1, sIsolated);
	BYTE data = 0;
	for (int i=0; i<m_numOutputs; i++) {
		pFile->SetBgColor(colors[i & 1 ? 1 : 0]);
		if ( (i % 4) == 0 ) {
			data = m_outputStatus[i/4];
		}

		sOutNum.Format(_T("%d"), i+1);
		pFile->AddTD(3, 1, sOutNum, 
			1, data & 1 ? sOn : sOff,
			1, data & 2 ? sYes : sNo);
		data >>= 2;
	}

	pFile->EndTags(); delete pFile; pFile = NULL;
	RtuLib::FileExecute(GetSafeHwnd(), fname, _T("open"));
}

#pragma endregion CRtuOpStsPage2
/*------------------------------------------------------------------------------*/
/*					Camera Status Page Class									*/
/*------------------------------------------------------------------------------*/
#pragma region CRtuCamStsPage2

IMPLEMENT_DYNCREATE(CRtuCamStsPage2, CXTPPropertyPage)

void CRtuCamStsPage2::DoDataExchange(CDataExchange* pDX)
{
	CXTPPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CRtuCamStsPage2)
	DDX_Control(pDX, IDC_LIST, m_camerList);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CRtuCamStsPage2, CXTPPropertyPage)
	//{{AFX_MSG_MAP(CRtuCamStsPage2)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


BOOL CRtuCamStsPage2::OnInitDialog()
{
	CDialog::OnInitDialog();
	CWnd* pWnd = GetDlgItem(IDC_RTU_CAMTOTAL);
	if (pWnd) {
		pWnd->ShowWindow(SW_HIDE);
	}

	m_imgList.Create(IDB_CAMERAS, 18, 0, RGB(0, 0x80, 0x80));
	
	UINT nStrIDs[] = {IDS_NUMBER, IDS_POINT_STS, IDS_ISOLATED, 
		IDS_FILM_LOW, IDS_FILM_OUT, IDS_FRAME_CNT};

	for(int i=0; i<6; i++) {
		CString strTxt = RES_STRING(nStrIDs[i]);
		CSize size = ((CDC*)this->GetDC())->GetTextExtent(strTxt);
		m_camerList.InsertColumn(i, strTxt, LVCFMT_CENTER, size.cx + TXT_EXTENT);
	}

	m_camerList.SetGridLines(TRUE);
	m_camerList.SetImageList(&m_imgList, LVSIL_SMALL);
	return TRUE;
}

BOOL CRtuCamStsPage2::OnSetActive()
{
	ShowStatus();
	return CXTPPropertyPage::OnSetActive();
}

LPBYTE CRtuCamStsPage2::SetStatus(LPBYTE lpData, int, BOOL)
{
	LPBYTE p = lpData;
	
	GmsOutputDebugString(__FUNCTIONW__, __LINE__, L"Count=%d", *lpData);
	m_numCameras = *p++;
	memset(m_cameraStatus, 0, sizeof(m_cameraStatus));
	try
	{
		if (m_numCameras > MAX_RTU_CAMPNTS)
			m_numCameras = MAX_RTU_CAMPNTS;

		int nBytes = 0;
		if (m_numCameras != 0)
		{
			nBytes = m_numCameras * sizeof(RTU_CAMSTATS);
			memcpy(m_cameraStatus, p, nBytes);
			p += nBytes;
		}
		_OutputDebugMemory(L"CRtuCamStsPage2::SetStatus", lpData, nBytes+1);
	}
	catch (...)
	{
		m_numCameras = 0;
		OutputDebugString(L"Exception in CRtuCamStsPage2::SetStatus\n");
	}
	
	return p;
}

void CRtuCamStsPage2::ShowStatus()
{
	if (IsWindow(m_hWnd) == FALSE) return;
	CString strItem;
	CString str = RES_STRING(IDS_TOT_CAM);
	strItem.Format(str, m_numCameras);
	GetDlgItem(IDC_RTU_CAMTOTAL)->SetWindowText(strItem);

	m_camerList.DeleteAllItems();

	LVITEM lvi;
	lvi.mask = LVIF_IMAGE | LVIF_TEXT;
	int imgNum=0;

	CString sYes = RES_STRING(IDS_YES_TXT);
	CString sNo = RES_STRING(IDS_NO_TXT);
	CString sOn = RES_STRING(IDS_ON);
	CString sOff = RES_STRING(IDS_OFF);

	for (int i=0; i<m_numCameras; i++) {
		
		if (m_cameraStatus[i].status & 2)
			imgNum = 2;			// point isolated
		else if (m_cameraStatus[i].status & 1)
			imgNum = 1;			// camera ON
		else
			imgNum = 0;

		lvi.iImage = imgNum;
		lvi.iItem = i;

		strItem.Format(_T("%d"), i+1);
		lvi.pszText = (LPTSTR)(LPCTSTR)strItem;
		lvi.iSubItem = 0;
		m_camerList.InsertItem(&lvi);

		m_camerList.SetItemText(i, 1, m_cameraStatus[i].status & 1 ? sOn : sOff);
		m_camerList.SetItemText(i, 2, m_cameraStatus[i].status & 2 ? sYes : sNo);
		m_camerList.SetItemText(i, 3, m_cameraStatus[i].status & 4 ? sYes : sNo);
		m_camerList.SetItemText(i, 4, m_cameraStatus[i].status & 8 ? sYes : sNo);

		int fcnt = (m_cameraStatus[i].frameCntH << 8) + m_cameraStatus[i].frameCntL;
		strItem.Format(_T("%d"), fcnt);
		m_camerList.SetItemText(i, 5, strItem);
	}

}

void CRtuCamStsPage2::Print()
{
	TCHAR fname[MAX_PATH] = _T("");
	if (!RtuLib::GetPrintFileName(fname, _T(".html")))
		return;

	CHtmlFile* pFile = new CHtmlFile(hrInst, fname);
	pFile->StartTags(IsRtu8002Type()? RTU_8002_TYPE: realRtuType, gRtuNo, IDS_RTU_STATUS, IDS_CAMERA_STS);

	CString sYes = RES_STRING(IDS_YES_TXT);
	CString sNo = RES_STRING(IDS_NO_TXT);
	CString sOn = RES_STRING(IDS_ON);
	CString sOff = RES_STRING(IDS_OFF);
	CString sOutNum = RES_STRING(IDS_OUT_NUM);
	CString sPntSts = RES_STRING(IDS_POINT_STS);
	CString sIsolated = RES_STRING(IDS_ISOLATED);
	CString sFilmLow = RES_STRING(IDS_FILM_LOW);
	CString sFilmOut = RES_STRING(IDS_FILM_OUT);
	CString sFrameCnt = RES_STRING(IDS_FRAME_CNT);

	pFile->SetBgColor(colors[2]);
	pFile->AddTH(6, 1, sOutNum, 1, sPntSts, 1, sIsolated,
		1, sFilmLow, 1, sFilmOut, 1, sFrameCnt);
	
	for (int i=0; i<m_numCameras; i++) {
		pFile->SetBgColor(colors[i & 1 ? 1 : 0]);
		sOutNum.Format(_T("%d"), i+1);
		sFrameCnt.Format(_T("%d"), (m_cameraStatus[i].frameCntH << 8) + m_cameraStatus[i].frameCntL);
		pFile->AddTD(6, 1, sOutNum, 
			1, m_cameraStatus[i].status & 1 ? sOn : sOff,
			1, m_cameraStatus[i].status & 2 ? sYes : sNo,
			1, m_cameraStatus[i].status & 4 ? sYes : sNo,
			1, m_cameraStatus[i].status & 8 ? sYes : sNo,
			1, sFrameCnt);
	}

	pFile->EndTags(); delete pFile; pFile = NULL;
	RtuLib::FileExecute(GetSafeHwnd(), fname, _T("open"));
}

#pragma endregion CRtuCamStsPage2
/*------------------------------------------------------------------------------*/
/*					CCTV Status Page Class										*/
/*------------------------------------------------------------------------------*/
#pragma region CRtuCctvStsPage2

IMPLEMENT_DYNCREATE(CRtuCctvStsPage2, CPropertyPage)

void CRtuCctvStsPage2::DoDataExchange(CDataExchange* pDX)
{
	CXTPPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CRtuCctvStsPage2)
	DDX_Control(pDX, IDC_LIST, m_cctvList);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CRtuCctvStsPage2, CXTPPropertyPage)
	//{{AFX_MSG_MAP(CRtuCctvStsPage2)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


BOOL CRtuCctvStsPage2::OnInitDialog()
{
	CDialog::OnInitDialog();
	CWnd* pWnd = GetDlgItem(IDC_RTU_TOTAL);
	if (pWnd) {
		pWnd->ShowWindow(SW_HIDE);
	}

	m_imgList.Create(_T("CCTVCAMERA"), 23, 0 , RGB(0x00, 0x80, 0x80));
	
	UINT nStrIDs[] = {IDS_NUMBER, IDS_RECORDING, IDS_POINT_STS};
	for(int i=0; i<3; i++) {
		CString strTxt = RES_STRING(nStrIDs[i]);
		CSize size = ((CDC*)this->GetDC())->GetTextExtent(strTxt);
		m_cctvList.InsertColumn(i, strTxt, LVCFMT_CENTER, size.cx + TXT_EXTENT);
	}

	m_cctvList.SetGridLines(TRUE);
	m_cctvList.SetImageList(&m_imgList, LVSIL_SMALL);
	return TRUE;
}

BOOL CRtuCctvStsPage2::OnSetActive()
{
	ShowStatus();
	return CXTPPropertyPage::OnSetActive();
}

LPBYTE CRtuCctvStsPage2::SetStatus(LPBYTE lpData, int, BOOL)
{
	LPBYTE p = lpData;
	m_numCCTVs = *p;

	GmsOutputDebugString(__FUNCTIONW__, __LINE__, L"Count=%d", *lpData);

	memset(m_cctvStatus, 0, sizeof(m_cctvStatus));

	if (m_numCCTVs > MAXOPS)
		m_numCCTVs= MAXOPS;

	int cnt = 0;
	try
	{
		if (m_numCCTVs) {
			cnt = ((m_numCCTVs - 1) / 2) + 1;
			memcpy(m_cctvStatus, p+1, cnt);
		}

		_OutputDebugMemory(L"CRtuCctvStsPage2::SetStatus", lpData, cnt+1);
		lpData += 1 + cnt;
	}
	catch (...)
	{
		m_numCCTVs = 0;
		OutputDebugString(L"Exception in CRtuCctvStsPage2::SetStatus\n");
	}
	
	return lpData;
}

void CRtuCctvStsPage2::ShowStatus()
{
	if (IsWindow(m_hWnd) == FALSE) return;

	BYTE data = 0;
	CString str;
	UINT cctvIDs[] = {IDS_OFF, IDS_ON, IDS_CAM_SIGNAL_LOST, IDS_PNT_ON_IN_ALM};
	CString sOff = RES_STRING(IDS_OFF);
	CString sActivated = RES_STRING(IDS_ACTIVATED);

	m_cctvList.DeleteAllItems();
	LVITEM lvi;
	lvi.mask = LVIF_IMAGE | LVIF_TEXT;
	
	for (int i=0; i<m_numCCTVs; i++) {
		if ( (i % 2) == 0) {
			data = m_cctvStatus[i/2];
		}

		lvi.iItem = i;
		lvi.iImage = 0;

		str.Format(_T(" %d"), i+1);
		lvi.pszText = (LPTSTR)(LPCTSTR)str;
		lvi.iSubItem = 0;
		m_cctvList.InsertItem(&lvi);

		m_cctvList.SetItemText(i, 1, data & 8 ? sActivated : sOff);
		CString sPntSts = RES_STRING(cctvIDs[data & 3]);
		m_cctvList.SetItemText(i, 2, sPntSts);

		data >>= 4;
	}
}

void CRtuCctvStsPage2::Print()
{
	TCHAR fname[MAX_PATH] = _T("");
	if (!RtuLib::GetPrintFileName(fname, _T(".html")))
		return;

	CHtmlFile* pFile = new CHtmlFile(hrInst, fname);
	pFile->StartTags(IsRtu8002Type()? RTU_8002_TYPE: realRtuType, gRtuNo, IDS_RTU_STATUS, IDS_CCTV_STS);
	UINT cctvIDs[] = {IDS_OFF, IDS_ON, IDS_CAM_SIGNAL_LOST, IDS_PNT_ON_IN_ALM};

	CString sOff = RES_STRING(IDS_OFF);
	CString sActivated = RES_STRING(IDS_ACTIVATED);
	CString sCctvNum = RES_STRING(IDS_CCTV_NUMBER);
	CString sRecording = RES_STRING(IDS_RECORDING);
	CString sPntSts = RES_STRING(IDS_POINT_STS);

	pFile->SetBgColor(colors[2]);
	pFile->AddTH(3, 1, sCctvNum, 1, sRecording, 1, sPntSts);

	BYTE data = 0;
	for (int i=0; i<m_numCCTVs; i++) {
		pFile->SetBgColor(colors[i & 1 ? 1 : 0]);

		if ( (i % 2) == 0) {
			data = m_cctvStatus[i/2];
		}

		sCctvNum.Format(_T("%d"), i + 1);
		sPntSts = RES_STRING(cctvIDs[data & 3]);

		pFile->AddTD(3, 1, sCctvNum, 1, data & 8 ? sActivated : sOff, 1, sPntSts);
		data >>= 4;
	}

	pFile->EndTags(); delete pFile; pFile = NULL;
	RtuLib::FileExecute(GetSafeHwnd(), fname, _T("open"));
}

#pragma endregion CRtuCctvStsPage2

/*------------------------------------------------------------------------------*/
/*					Door Status Page Class									*/
/*------------------------------------------------------------------------------*/
#pragma region CRtuDoorStatusPage2

IMPLEMENT_DYNCREATE(CRtuDoorStatusPage2, CXTPPropertyPage)

void CRtuDoorStatusPage2::DoDataExchange(CDataExchange* pDX)
{
	CXTPPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CRtuDoorStatusPage2)
	DDX_Control(pDX, IDC_LIST, m_rdrList);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CRtuDoorStatusPage2, CXTPPropertyPage)
	//{{AFX_MSG_MAP(CRtuDoorStatusPage2)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


BOOL CRtuDoorStatusPage2::OnInitDialog()
{
	CDialog::OnInitDialog();
	CWnd* pWnd = GetDlgItem(IDC_RTU_TOTAL);
	if (pWnd) {
		pWnd->ShowWindow(SW_HIDE);
	}

	m_imgList.Create(IDB_DOORS, 12, 0, RGB(0x00, 0x80, 0x80));
	for(int i=0; i<6; i++) {
		CString str = RES_STRING(IDS_DOOR_NUM + i);
		CSize size = ((CDC*)this->GetDC())->GetTextExtent(str);
		m_rdrList.InsertColumn(i, str, LVCFMT_CENTER, size.cx);
	}

	m_rdrList.SetGridLines(TRUE);
	m_rdrList.SetImageList(&m_imgList, LVSIL_SMALL);
	return TRUE;
}

BOOL CRtuDoorStatusPage2::OnSetActive()
{
	ShowStatus();
	return CXTPPropertyPage::OnSetActive();
}

LPBYTE CRtuDoorStatusPage2::SetStatus(LPBYTE lpData, int, BOOL)
{
	m_numReaders = *lpData;
	GmsOutputDebugString(__FUNCTIONW__, __LINE__, L"Count=%d", *lpData);

	memset(m_readerStatus, 0, sizeof(m_readerStatus));
	try
	{
		if (m_numReaders > MAX_RTU_RDRS)
			m_numReaders = MAX_RTU_RDRS;

		memcpy(m_readerStatus, lpData+1, m_numReaders);

		_OutputDebugMemory(L"CRtuDoorStatusPage2::SetStatus", lpData, m_numReaders+1);

		lpData += 1 + m_numReaders;
	}
	catch (...)
	{
		m_numReaders = 0;
		OutputDebugString(L"Exception in CRtuDoorStatusPage2::SetStatus\n");
	}
	return lpData;
}

void CRtuDoorStatusPage2::ShowStatus(void)
{
	UINT  nStrikeIDs[] = {IDS_SECURE, IDS_ACTIVE, IDS_EMPTY, IDS_TROUBLE};

	CString sYes = RES_STRING(IDS_YES_TXT);
	CString sNo = RES_STRING(IDS_NO_TXT);
	CString str;
	LVITEM lvi;
	lvi.mask = LVIF_IMAGE | LVIF_TEXT;
	int imgNum=0;
	m_rdrList.DeleteAllItems();

	for (int i=0; i<m_numReaders; i++) {
		BYTE data = m_readerStatus[i];
		lvi.iItem = i;
	
		if (data & 0x40)
			imgNum = 2;
		else if ((data >> 2) & 3)
			imgNum = 1;
		else
			imgNum = 0;
		lvi.iImage = imgNum;

		// Reader number
		str.Format(_T("%d"), i+1);
		lvi.iSubItem = 0;
		lvi.pszText = (LPTSTR)(LPCTSTR)str;
		m_rdrList.InsertItem(&lvi);

		// Reader status
		str = RES_STRING(IDS_RDR_STS + (data & 3));
		lvi.iSubItem = 1;
		lvi.pszText = (LPTSTR)(LPCTSTR)str;
		m_rdrList.SetItem(&lvi);

		// Door contact status
		str = RES_STRING(IDS_SECURE + ((data >> 2) & 3));
		lvi.iSubItem = 2;
		lvi.pszText = (LPTSTR)(LPCTSTR)str;
		m_rdrList.SetItem(&lvi);

		// Door strike status
		str = RES_STRING(nStrikeIDs[(data >> 4) & 3]);
		lvi.iSubItem = 3;
		lvi.pszText = (LPTSTR)(LPCTSTR)str;
		m_rdrList.SetItem(&lvi);

		// Door contact isolated
		str = data & 0x40 ? sYes : sNo;
		lvi.iSubItem = 4;
		lvi.pszText = (LPTSTR)(LPCTSTR)str;
		m_rdrList.SetItem(&lvi);

		// Door strike isolated
		str = data & 0x80 ? sYes : sNo;
		lvi.iSubItem = 5;
		lvi.pszText = (LPTSTR)(LPCTSTR)str;
		m_rdrList.SetItem(&lvi);
	}

}

void CRtuDoorStatusPage2::Print()
{
	TCHAR fname[MAX_PATH] = _T("");
	if (!RtuLib::GetPrintFileName(fname, _T(".html")))
		return;

	CHtmlFile* pFile = new CHtmlFile(hrInst, fname);
	pFile->StartTags(IsRtu8002Type()? RTU_8002_TYPE: realRtuType, gRtuNo, IDS_RTU_STATUS, IDS_DOOR_STATUS);

	UINT contactStsIDs[] = {IDS_SECURE, IDS_AJAR_ALM, IDS_FORCE_ALM, IDS_TROUBLE};
	std::array<UINT, 3> strikeStsIDs = { IDS_SECURE, IDS_ACTIVE, IDS_TROUBLE };

	CString sYes = RES_STRING(IDS_YES_TXT);
	CString sNo = RES_STRING(IDS_NO_TXT);
	CString sDoorNum = RES_STRING(IDS_DOOR_NUM);
	CString sReaderSts = RES_STRING(IDS_READER_STATUS);
	CString sContactSts = RES_STRING(IDS_CONTACT_STATUS);
	CString sStrikeSts = RES_STRING(IDS_STRIKE_STATUS);
	CString sContactIsol = RES_STRING(IDS_CONTACT_ISOLATED);
	CString sStrikeIsol = RES_STRING(IDS_STRIKE_ISOLATED);

	pFile->SetBgColor(colors[2]);
	pFile->AddTH(6, 1, sDoorNum, 1, sReaderSts, 1, sContactSts,
		1, sStrikeSts, 1, sContactIsol, 1, sStrikeIsol);

	CString sTmp;
	for (int i=0; i<m_numReaders; i++) {
		pFile->SetBgColor(colors[i & 1 ? 1 : 0]);
		BYTE data = m_readerStatus[i];
		sTmp.Format(_T("%d"), i + 1);
		sReaderSts = RES_STRING(IDS_RDR_STS + (data & 3));
		sContactSts = RES_STRING(contactStsIDs[(data >> 2) & 3]);
		auto index = (data >> 4) & 3;
		sStrikeSts = index < (int)strikeStsIDs.size() ? RES_STRING(strikeStsIDs[index]) : _T("");

		pFile->AddTD(6, 1, sTmp,
			1, sReaderSts, 1, sContactSts, 1, sStrikeSts,
			1, data & 0x40 ? sYes : sNo, 1, data & 0x80 ? sYes : sNo);
	}

	pFile->EndTags(); delete pFile; pFile = NULL;
	RtuLib::FileExecute(GetSafeHwnd(), fname, _T("open"));
}

#pragma endregion CRtuDoorStatusPage2

/*------------------------------------------------------------------------------*/
/*					Elevator Floor Status Page Class							*/
/*------------------------------------------------------------------------------*/
#pragma region CRtuElevFlrPage2

IMPLEMENT_DYNCREATE(CRtuElevFlrPage2, CXTPPropertyPage)

void CRtuElevFlrPage2::DoDataExchange(CDataExchange* pDX)
{
	CXTPPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CRtuElevFlrPage2)
	DDX_Control(pDX, IDC_RTU_ID1, m_btn1);
	DDX_Control(pDX, IDC_RTU_ID2, m_btn2);
	DDX_Control(pDX, IDC_RTU_ID3, m_btn3);
	DDX_Control(pDX, IDC_RTU_ID4, m_btn4);
	DDX_Control(pDX, IDC_RTU_ID5, m_btn5);
	DDX_Control(pDX, IDC_RTU_ID6, m_btn6);
	DDX_Control(pDX, IDC_RTU_ID7, m_btn7);
	DDX_Control(pDX, IDC_RTU_ID8, m_btn8);
	DDX_Control(pDX, IDC_RTU_ID11, m_lblElevNum);
	DDX_Control(pDX, IDC_RTU_ID12, m_lstOffStatus);
	DDX_Control(pDX, IDC_RTU_ID13, m_chkFlrAccess);
	DDX_Control(pDX, IDC_RTU_ID14, m_chkFlrRestore);

	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CRtuElevFlrPage2, CXTPPropertyPage)
	//{{AFX_MSG_MAP(CRtuElevFlrPage2)
	ON_NOTIFY(UDN_DELTAPOS, IDC_RTU_ID9, OnUpDownElevSts)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


BOOL CRtuElevFlrPage2::OnInitDialog()
{
	CDialog::OnInitDialog();
	CWnd* pWnd = GetDlgItem(IDC_RTU_TOTAL);
	if (pWnd) {
		pWnd->ShowWindow(SW_HIDE);
	}
	
	CChkButton* pBtn[] = {&m_btn1, &m_btn2, &m_btn3, &m_btn4, &m_btn5, &m_btn6, &m_btn7, &m_btn8};
	for(int i=0; i<8; i++) {
		pBtn[i]->Init(1, 15);
		pBtn[i]->Init(2, &m_elevatorStatus[m_curElevatorNum].accessFloors[i*2], 16, 16, TRUE, TRUE);
		pBtn[i]->SetBitmapIDs(IDB_DOORS, IDB_DOORS);
	}


	TCHAR * strTxt[] = {_T("1065EC Number"),_T(" 1 "),_T(" 2 "), _T(" 3"), _T(" 4 "), 
		_T(" 5 "),_T(" 6 "), _T(" 7 "), _T(" 8 ")};

	for(int i=0; i<9; i++) {
		CSize size = ((CDC*)this->GetDC())->GetTextExtent(strTxt[i]);
		m_lstOffStatus.InsertColumn(i, strTxt[i], LVCFMT_CENTER, size.cx + 22);
	}
	m_lstOffStatus.SetGridLines(TRUE);

	BYTE data = 0;
	
	m_chkFlrRestore.Init(1, 1);
	m_chkFlrRestore.Init(1, &data, 1);
	m_chkFlrRestore.SetBitmapIDs(IDB_DOORS, IDB_DOORS);

	data = 0xff;
	m_chkFlrAccess.Init(1, 1);
	m_chkFlrAccess.Init(1, &data, 1);
	m_chkFlrAccess.SetBitmapIDs(IDB_DOORS, IDB_DOORS);

	return TRUE;
}

BOOL CRtuElevFlrPage2::OnSetActive()
{
	ShowStatus();
	return CXTPPropertyPage::OnSetActive();
}

LPBYTE CRtuElevFlrPage2::SetStatus(LPBYTE lpData, int, BOOL)
{
	LPBYTE p = lpData;
	
	GmsOutputDebugString(__FUNCTIONW__, __LINE__, L"Count=%d", *lpData);

	m_numElevators = *p++;
	try
	{
		memset(m_elevatorStatus, 0,sizeof(m_elevatorStatus));
		if (m_numElevators > MAX_RTU_ELEVRECS)
			m_numElevators = MAX_RTU_ELEVRECS;

		int size = sizeof(m_elevatorStatus[0]);
		for(int i=0; i<m_numElevators; i++) {
			BYTE cnt = *p;
			memcpy(&m_elevatorStatus[i], p, min(cnt+1, size));
			p += (cnt + 1);
		}
	}
	catch (...)
	{
		m_numElevators = 0;
		OutputDebugString(L"Exception in CRtuElevFlrPage2::SetStatus\n");
	}

	_OutputDebugMemory(L"CRtuElevFlrPage2::SetStatus", lpData, (p-lpData));
	return p;
}

void CRtuElevFlrPage2::ShowStatus(void)
{
	if (IsWindow(m_hWnd) == FALSE) return;

	GmsOutputDebugString(__FUNCTIONW__, __LINE__, L"Total Devices=%d", m_numElevators);
	CWnd* pWnd;
	//TT 8351
	UINT showOrHide = (m_numElevators == 0)? SW_HIDE : SW_SHOW;
	for(int i=0; i<17; i++) {
		if ((pWnd = GetDlgItem(IDC_RTU_ID1 + i)) != NULL) 
			pWnd->ShowWindow(showOrHide);
	
	}

	if (m_numElevators == 0) return;

	GetDlgItem(IDC_RTU_ID9)->ShowWindow((m_numElevators > 1)? SW_SHOW:SW_HIDE); // updown button  8351
	
	CString str;
	CString sElevFlrRng = RES_STRING(IDS_ELEV_FLR_RNG);
	str.Format(sElevFlrRng, m_curElevatorNum+1, m_numElevators);

	SetDlgItemText(IDC_RTU_TOTAL, str);

	int size = m_elevatorStatus[m_curElevatorNum].size;
	
	showOrHide = (size == 0) ? SW_HIDE : SW_SHOW;
	for(int i=0; i<8; i++) {
		GetDlgItem(IDC_RTU_ID1+i)->ShowWindow(showOrHide);
		GetDlgItem(IDC_RTU_ID10+i)->ShowWindow(showOrHide);
	}

	if (size >= 2) {
		str.Format(_T("%d"), m_elevatorStatus[m_curElevatorNum].elevatorNumber + 1);
		m_lblElevNum.SetText(str);
	}
	
	if (size >= 3) {
		CString sYes = RES_STRING(IDS_YES_TXT);
		CString sNo = RES_STRING(IDS_NO_TXT);
		CString sOnline = RES_STRING(IDS_ONLINE);
		LVITEM lvi;
		lvi.mask = LVIF_TEXT;
		m_lstOffStatus.DeleteAllItems();
		lvi.iItem = 0;
		BYTE mask=0x01;
		BYTE data = m_elevatorStatus[m_curElevatorNum].offlineStatus;

		lvi.iSubItem = 0;
		lvi.pszText = (LPTSTR)(LPCTSTR)sOnline;
		m_lstOffStatus.InsertItem(&lvi);

		for(int i=1; i<=8; i++) {
			lvi.iSubItem = i;
			CString str2 = data & mask ? sNo : sYes;
			lvi.pszText = (LPTSTR)(LPCTSTR)str2;
			m_lstOffStatus.SetItem(&lvi);
			mask <<= 1;
		}

		// re-calculate the group.
		size -= 3;
		size = (size / 2) + (size & 1 ? 1 : 0);
		CChkButton* pBtn[] = {&m_btn1, &m_btn2, &m_btn3, &m_btn4, &m_btn5, &m_btn6, &m_btn7, &m_btn8};
		for(int i=0; i<8; i++) {
			if (i < size) {
				pBtn[i]->ShowWindow(SW_SHOW);
				pBtn[i]->SetBitMap(2, &m_elevatorStatus[m_curElevatorNum].accessFloors[i*2], i*16 + 1);
				pBtn[i]->Invalidate();
			}
			else {
				pBtn[i]->ShowWindow(SW_HIDE);
			}
		}

		showOrHide = (size > 0) ? SW_SHOW : SW_HIDE;
		for(int i=0; i<5; i++) {
			if ((pWnd = GetDlgItem(IDC_RTU_ID13 + i)) != NULL) {
				pWnd->ShowWindow(showOrHide);
			}
		}

	}

}

void CRtuElevFlrPage2::OnUpDownElevSts(NMHDR* pNMHDR, LRESULT* pResult)
{
	NM_UPDOWN* pNMUpDown = (NM_UPDOWN*)pNMHDR;
	// TODO: Add your control notification handler code here
		
	if (pNMUpDown->iDelta == 1) {
		--m_curElevatorNum;
		if (m_curElevatorNum < 0)
			m_curElevatorNum = m_numElevators - 1;
	}
	else  {
		++m_curElevatorNum;
		if (m_curElevatorNum >= m_numElevators)
			m_curElevatorNum = 0;
	}

	ShowStatus();

	*pResult = 0;

}

void CRtuElevFlrPage2::Print()
{
	TCHAR fname[MAX_PATH] = _T("");
	if (!RtuLib::GetPrintFileName(fname, _T(".html")))
		return;

	CHtmlFile* pFile = new CHtmlFile(hrInst, fname);
	pFile->StartTags(IsRtu8002Type()? RTU_8002_TYPE: realRtuType, gRtuNo, IDS_RTU_STATUS, IDS_ELEVATOR_STATUS);

	CString sYes = RES_STRING(IDS_YES_TXT);
	CString sNo = RES_STRING(IDS_NO_TXT);
	CString sElevNum = RES_STRING(IDS_ELEV_NUM);
	CString sECNum = RES_STRING(IDS_1065EC_NUM);
	CString sOnline = RES_STRING(IDS_ONLINE);
	CString sOffline = RES_STRING(IDS_OFFLINE);
	CString sFlrAcc = RES_STRING(IDS_FLOOR_ACCESS);

	CString sTmp;
	for(int i=0; i<m_numElevators; i++) {
		pFile->SetBgColor(colors[i & 1 ? 1 : 0]);
		int size = m_elevatorStatus[i].size;
		if (size >= 2) {
			sTmp.Format(_T("%d"), m_elevatorStatus[i].elevatorNumber + 1);
			pFile->AddRow(1, 1, COL_SPAN | 2, sElevNum, COL_SPAN | 16, sTmp);
		}
		
		if (size >= 3) {
			BYTE data = m_elevatorStatus[i].offlineStatus;
			pFile->AddRow(2, 1, ROW_SPAN|8, sECNum, 1, _T("1"), 
				COL_SPAN | 16, data & 1 ? sOffline : sOnline);

			data >>= 1;
			for(int n=1; n<8; n++) {
				sTmp.Format(_T("%d"), n + 1);
				pFile->AddRow(1, 1, 1, sTmp, COL_SPAN | 16, data & 1 ? sOffline : sOnline);
				data >>= 1;
			}

			size -= 3;
			size = (size / 2) + (size & 1 ? 1 : 0);
			if (size > 0) {
				pFile->AddRow(1, 1, ROW_SPAN|(size+1)|COL_SPAN|(2<<7), sFlrAcc, COL_SPAN|16, _T("&nbsp;"));
				for(int j=0; j<8; j++) {
					if (j < size) {
						TCHAR faTxt[16][40];
						int st = (m_elevatorStatus[i].accessFloors[j*2 + 1] << 8) | (m_elevatorStatus[i].accessFloors[j*2]);
						for(int n=0; n<16; n++) {
							wsprintf(faTxt[n], _T("<b>%d</b> <br>%s"), n+1+j*16, st&1 ? (LPCTSTR)sYes : (LPCTSTR)sNo);
							st >>= 1;
						}
						pFile->AddTD(16, 
							1, faTxt[0], 1, faTxt[1], 1, faTxt[2], 1, faTxt[3],
							1, faTxt[4], 1, faTxt[5], 1, faTxt[6], 1, faTxt[7],
							1, faTxt[8], 1, faTxt[9], 1, faTxt[10], 1, faTxt[11],
							1, faTxt[12], 1, faTxt[13], 1, faTxt[14], 1, faTxt[15]);
					}
				}
			}
		}

	}

	pFile->EndTags(); delete pFile; pFile = NULL;
	RtuLib::FileExecute(GetSafeHwnd(), fname, _T("open"));
}

#pragma endregion CRtuElevFlrPage2

/*------------------------------------------------------------------------------*/
/*					Drive Status Page Class										*/
/*------------------------------------------------------------------------------*/
#pragma region CRtuDriveStatusPage2

IMPLEMENT_DYNCREATE(CRtuDriveStatusPage2, CXTPPropertyPage)

void CRtuDriveStatusPage2::DoDataExchange(CDataExchange* pDX)
{
	CXTPPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CRtuDriveStatusPage2)
	DDX_Control(pDX, IDC_RTU_ID3, m_lblDriveNum);
	DDX_Control(pDX, IDC_RTU_ID7, m_lblPhysSize);
	DDX_Control(pDX, IDC_RTU_ID9, m_lblPhysSizeFormatted);
	DDX_Control(pDX, IDC_RTU_ID11, m_lblPhysSizeRemain);
	DDX_Control(pDX, IDC_RTU_ID15, m_lblModelName);

	DDX_Control(pDX, IDC_RTU_ID18, m_lblCamNum);
	DDX_Control(pDX, IDC_RTU_ID20, m_lblCamOldestTime);
	DDX_Control(pDX, IDC_RTU_ID22, m_lblCamYoungestTime);

	DDX_Control(pDX, IDC_RTU_ID25, m_lblMicNum);
	DDX_Control(pDX, IDC_RTU_ID27, m_lblMicOldestTime);
	DDX_Control(pDX, IDC_RTU_ID29, m_lblMicYoungestTime);

	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CRtuDriveStatusPage2, CXTPPropertyPage)
	//{{AFX_MSG_MAP(CRtuDriveStatusPage2)
	ON_NOTIFY(UDN_DELTAPOS, IDC_RTU_ID30, OnUpDownCamRecTimes)
	ON_NOTIFY(UDN_DELTAPOS, IDC_RTU_ID31, OnUpDownMicRecTimes)
	ON_NOTIFY(UDN_DELTAPOS, IDC_RTU_ID32, OnUpDownDriveStatus)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CRtuDriveStatusPage message handlers
/////////////////////////////////////////////////////////////////////////////
BOOL CRtuDriveStatusPage2::OnInitDialog()
{
	CDialog::OnInitDialog();
	m_nCurDrive = 0;
	m_nCurCamRecTime = 0;
	m_nCurMicRecTime = 0;

	COLORREF txtColor = RGB(128, 0, 0);
	m_lblDriveNum.SetTextColor(txtColor);
	m_lblPhysSize.SetTextColor(txtColor);
	m_lblPhysSizeFormatted.SetTextColor(txtColor);
	m_lblPhysSizeRemain.SetTextColor(txtColor);
	m_lblModelName.SetTextColor(txtColor);
	
	m_lblCamNum.SetTextColor(txtColor);
	m_lblCamOldestTime.SetTextColor(txtColor);
	m_lblCamYoungestTime.SetTextColor(txtColor);
	m_lblMicNum.SetTextColor(txtColor);
	m_lblMicOldestTime.SetTextColor(txtColor);
	m_lblMicYoungestTime.SetTextColor(txtColor);

	m_lblDriveNum.SetBkColor(LL_YELLOW);
	m_lblPhysSize.SetBkColor(LL_YELLOW);
	m_lblPhysSizeFormatted.SetBkColor(LL_YELLOW);
	m_lblPhysSizeRemain.SetBkColor(LL_YELLOW);
	m_lblModelName.SetBkColor(LL_YELLOW);

	m_lblCamNum.SetBkColor(LL_YELLOW);
	m_lblCamOldestTime.SetBkColor(LL_YELLOW);
	m_lblCamYoungestTime.SetBkColor(LL_YELLOW);
	m_lblMicNum.SetBkColor(LL_YELLOW);
	m_lblMicOldestTime.SetBkColor(LL_YELLOW);
	m_lblMicYoungestTime.SetBkColor(LL_YELLOW);

	return TRUE;
}

BOOL CRtuDriveStatusPage2::OnSetActive()
{
	ShowStatus();
	return CXTPPropertyPage::OnSetActive();
}

void CRtuDriveStatusPage2::ShowStatus()
{
	if (IsWindow(m_hWnd) == FALSE) return;
	if (!m_ptrDriveStatus)
		return;

	RTU_DRIVESTATS* driveStatus = (m_ptrDriveStatus + m_nCurDrive);
	m_nCurCamRecTime = 0;
	m_nNumCamRecTimes = driveStatus->numOfCams;
	m_nCurMicRecTime = 0;
	m_nNumMicRecTimes = driveStatus->numOfMics;
   
	
	CString sTmp = RES_STRING(IDS_DRIVE_STS_RNG);
	CString str; str.Format(sTmp, m_nCurDrive + 1, m_nNumDrives);
	SetDlgItemText(IDC_RTU_ID1, str);
	GetDlgItem(IDC_RTU_ID32)->ShowWindow(m_nNumDrives > 1 ? SW_SHOW : SW_HIDE);

	str.Format(_T("%d"), driveStatus->driveNumber);
	m_lblDriveNum.SetText(str);
	
	str.Format(_T("%d"), driveStatus->physicalSize);
	m_lblPhysSize.SetText(str);
	
	str.Format(_T("%d %s"), driveStatus->totalSizeFormatted, _T("%"));
	m_lblPhysSizeFormatted.SetText(str);

	str.Format(_T("%d %s"), driveStatus->spaceRemain, _T("%"));
	m_lblPhysSizeRemain.SetText(str);

	TCHAR name[256];
	if (driveStatus->modelName != NULL) {
		wsprintf(name, _T("%hs"), driveStatus->modelName);
		m_lblModelName.SetText(name);
	}

	ShowCamRecTime();
	ShowMicRecTime();
}

void CRtuDriveStatusPage2::ShowCamRecTime()
{
	if (m_nNumCamRecTimes == 0 || m_ptrDriveStatus == NULL) {
		GetDlgItem(IDC_RTU_ID30)->ShowWindow(SW_HIDE);
		return;
	}

	RECORDINGTIME* pTime = ((m_ptrDriveStatus + m_nCurDrive)->camStatus + m_nCurCamRecTime);

	CString sTmp = RES_STRING(IDS_CAM_STS_RNG);
	CString str; str.Format(sTmp, m_nCurCamRecTime+1, m_nNumCamRecTimes);
	SetDlgItemText(IDC_RTU_ID16, str);
	GetDlgItem(IDC_RTU_ID30)->ShowWindow(m_nNumCamRecTimes > 1 ? SW_SHOW : SW_HIDE);

	str.Format(_T("%d"), pTime->number);
	m_lblCamNum.SetText(str);
	
	GetTime(str, &pTime->oldestTime);
	m_lblCamOldestTime.SetText(str);

	GetTime(str, &pTime->youngestTime); 
	m_lblCamYoungestTime.SetText(str);

}

void CRtuDriveStatusPage2::ShowMicRecTime()
{
	if (m_nNumMicRecTimes == 0) {
		GetDlgItem(IDC_RTU_ID31)->ShowWindow(SW_HIDE);
		return;
	}

	RECORDINGTIME* pTime = ((m_ptrDriveStatus + m_nCurDrive)->micStatus + m_nCurMicRecTime);

	CString sTmp = RES_STRING(IDS_MIC_PHONE_STS_RNG);
	CString str; str.Format(sTmp, m_nCurMicRecTime+1, m_nNumMicRecTimes);
	SetDlgItemText(IDC_RTU_ID23, str);
	GetDlgItem(IDC_RTU_ID31)->ShowWindow(m_nNumMicRecTimes > 1 ? SW_SHOW : SW_HIDE);

	str.Format(_T("%d"), pTime->number);
	m_lblMicNum.SetText(str);

	GetTime(str, &pTime->oldestTime);
	m_lblMicOldestTime.SetText(str);

	GetTime(str, &pTime->youngestTime); 
	m_lblMicYoungestTime.SetText(str);
}

void CRtuDriveStatusPage2::GetTime(CString& str, TIME* pTime)
{
	CStringArray strMonths; GetMonthStr(strMonths);
	TCHAR sMonth[50];
	int nMonth = pTime->month & 0x0f;
	if (nMonth > 12)
		wsprintf(sMonth, _T(""));
	else
		wsprintf(sMonth, _T("%s"), (LPCTSTR)strMonths.GetAt(nMonth));

	str.Format(_T("%.2d %s %.4d, %.2d:%.2d:%.2d"),
		pTime->day & 0x1f, sMonth, 2000 + (pTime->year & 0x7f), 
		pTime->hour & 0x1f, pTime->min & 0x3f, pTime->sec & 0x3f);
}

LPBYTE CRtuDriveStatusPage2::SetStatus(LPBYTE lpData, int, BOOL)
{
	BYTE* p = lpData;
	m_nNumDrives = *p++;

	GmsOutputDebugString(__FUNCTIONW__, __LINE__, L"Count=%d", *lpData);

	if (m_ptrDriveStatus != NULL)
	{
		delete [] m_ptrDriveStatus;
		m_ptrDriveStatus = NULL;
	}

	if (m_nNumDrives == 0)
		return p;

	try
	{
		m_ptrDriveStatus = new RTU_DRIVESTATS[m_nNumDrives];
	
		RTU_DRIVESTATS* driveStatus;
		BYTE* p2 = p;

		for(int i=0; i<m_nNumDrives; i++) {
			driveStatus = (m_ptrDriveStatus + i);
			memset(driveStatus, 0, sizeof(RTU_DRIVESTATS));

			int dataSize = *(p + 1);
			driveStatus->driveNumber = *p++;
			driveStatus->dataSize = *p++;
			driveStatus->flags = *p++;

			memcpy(&driveStatus->physicalSize, p, 4);
			RtuLib::SwapByteOrder(driveStatus->physicalSize);
			p += 4;
			driveStatus->totalSizeFormatted = *p++;
			driveStatus->spaceRemain = *p++;
		
			int driveModelNameSize = *p++;
			memcpy(&driveStatus->modelName, p, driveModelNameSize);
			p += driveModelNameSize;

			driveStatus->numOfCams = *p++;
			if (driveStatus->numOfCams > 8)
				driveStatus->numOfCams = 8;

			for(int j=0; j<driveStatus->numOfCams; j++) {
				driveStatus->camStatus[j].number = *p++;
				memcpy(&driveStatus->camStatus[j].oldestTime, p, 7);
				p += 7;
				memcpy(&driveStatus->camStatus[j].youngestTime, p, 7);
				p += 7;
			}

			driveStatus->numOfMics = *p++;
			if (driveStatus->numOfMics > 2)
				driveStatus->numOfMics = 2;

			for(int k=0; k<driveStatus->numOfMics; k++) {
				driveStatus->micStatus[k].number = *p++;
				memcpy(&driveStatus->micStatus[k].oldestTime, p, 7);
				p += 7;
				memcpy(&driveStatus->micStatus[k].youngestTime, p, 7);
				p += 7;
			}
		
			p2 += dataSize;
			p = p2;
		}

		_OutputDebugMemory(L"CRtuDriveStatusPage2::SetStatus", lpData, p-lpData + 1);
	}
	catch (...)
	{
		m_nNumDrives = 0;
		OutputDebugString(L"Exception in CRtuDriveStatusPage2::SetStatus\n");
	}
	return p+1;
}


void CRtuDriveStatusPage2::OnUpDownCamRecTimes(NMHDR* pNMHDR, LRESULT* pResult)
{
	NM_UPDOWN* pNMUpDown = (NM_UPDOWN*)pNMHDR;
	// TODO: Add your control notification handler code here
	if (pNMUpDown->iDelta == 1) {
		--m_nCurCamRecTime;
		if (m_nCurCamRecTime < 0)
			m_nCurCamRecTime = m_nNumCamRecTimes - 1;
	}
	else  {
		++m_nCurCamRecTime;
		if (m_nCurCamRecTime >= m_nNumCamRecTimes)
			m_nCurCamRecTime = 0;
	}

	ShowCamRecTime();
	*pResult = 0;

}

void CRtuDriveStatusPage2::OnUpDownMicRecTimes(NMHDR* pNMHDR, LRESULT* pResult)
{
	NM_UPDOWN* pNMUpDown = (NM_UPDOWN*)pNMHDR;
	// TODO: Add your control notification handler code here
	if (pNMUpDown->iDelta == 1) {
		--m_nCurMicRecTime;
		if (m_nCurMicRecTime < 0)
			m_nCurMicRecTime = m_nNumMicRecTimes - 1;
	}
	else  {
		++m_nCurMicRecTime;
		if (m_nCurMicRecTime >= m_nNumMicRecTimes)
			m_nCurMicRecTime = 0;
	}
	
	ShowMicRecTime();
	*pResult = 0;

}


void CRtuDriveStatusPage2::OnUpDownDriveStatus(NMHDR* pNMHDR, LRESULT* pResult)
{
	NM_UPDOWN* pNMUpDown = (NM_UPDOWN*)pNMHDR;
	// TODO: Add your control notification handler code here
	
	if (pNMUpDown->iDelta == 1) {
		--m_nCurDrive;
		if (m_nCurDrive < 0)
			m_nCurDrive = m_nNumDrives - 1;
	}
	else  {
		++m_nCurDrive;
		if (m_nCurDrive >= m_nNumDrives)
			m_nCurDrive = 0;
	}

	ShowStatus();
	*pResult = 0;

}

void CRtuDriveStatusPage2::Print()
{
	TCHAR fname[MAX_PATH] = _T("");
	if (!RtuLib::GetPrintFileName(fname, _T(".html")))
		return;

	CHtmlFile* pFile = new CHtmlFile(hrInst, fname);
	pFile->StartTags(IsRtu8002Type()? RTU_8002_TYPE: realRtuType, gRtuNo, IDS_RTU_STATUS, IDS_DRIVE_STS);

	CString sDriveNum = RES_STRING(IDS_DRIVE_NUM);
	CString sPhysSize = RES_STRING(IDS_PHYS_SIZE_MB);
	CString sPhysSizeFmt = RES_STRING(IDS_PHYS_SIZE_FMT);
	CString sSpaceRemain = RES_STRING(IDS_SPACE_REMAIN);
	CString sDriveModel = RES_STRING(IDS_DRIVE_MODEL);
	CString sCamNum = RES_STRING(IDS_CAMERA_NUM);
	CString sStartRecTime = RES_STRING(IDS_START_REC_TIME);
	CString sEndRecTime = RES_STRING(IDS_END_REC_TIME);
	CString sMicNum = RES_STRING(IDS_MIC_NUM);

	CString sTmp, sTmp2;
	for(int curDrive=0; curDrive<m_nNumDrives; curDrive++) {
		pFile->SetBgColor(colors[curDrive & 1 ? 1 : 0]);

		RTU_DRIVESTATS* driveStatus = (m_ptrDriveStatus + curDrive);
		m_nCurCamRecTime = 0;
		m_nNumCamRecTimes = driveStatus->numOfCams;
		m_nCurMicRecTime = 0;
		m_nNumMicRecTimes = driveStatus->numOfMics;

		int rowCnt = 4 + m_nNumCamRecTimes*2 + m_nNumMicRecTimes*2;
		sTmp.Format(_T("%s %d"), (LPCTSTR)sDriveNum, driveStatus->driveNumber);
		sTmp2.Format(_T("%d"), driveStatus->physicalSize);
		pFile->AddRow(2, 1, ROW_SPAN|rowCnt, sTmp, COL_SPAN|2, sPhysSize, 1, sTmp2);

		sTmp.Format(_T("%d %s"), driveStatus->totalSizeFormatted, _T("%"));
		pFile->AddRow(1, 1, COL_SPAN|2, sPhysSizeFmt, 1, sTmp);

		sTmp.Format(_T("%d %s"), driveStatus->spaceRemain, _T("%"));
		pFile->AddRow(1, 1, COL_SPAN|2, sSpaceRemain, 1, sTmp);

		sTmp.Format(_T("%hs"), driveStatus->modelName);
		pFile->AddRow(1, 1, COL_SPAN|2, sDriveModel, 1, sTmp);

		CString str;
		// Cam Config
		for(m_nCurCamRecTime = 0; m_nCurCamRecTime < m_nNumCamRecTimes; m_nCurCamRecTime++) {
			pFile->SetBgColor(colors[m_nCurCamRecTime & 1 ? 2 : 3]);
			RECORDINGTIME* pTime = ((m_ptrDriveStatus + curDrive)->camStatus + m_nCurCamRecTime);

			sTmp.Format(_T("%s %d"), (LPCTSTR)sCamNum, pTime->number);
			
			GetTime(str, &pTime->oldestTime);
			pFile->AddRow(2, 1, ROW_SPAN|2, sTmp, 1, sStartRecTime, 1, str);
			
			GetTime(str, &pTime->youngestTime);
			pFile->AddRow(sEndRecTime, str);
		}
		// Micro Config
		for(m_nCurMicRecTime = 0; m_nCurMicRecTime < m_nNumMicRecTimes; m_nCurMicRecTime++) {
			pFile->SetBgColor(colors[m_nCurMicRecTime & 1 ? 0 : 1]);
			RECORDINGTIME* pTime = ((m_ptrDriveStatus + curDrive)->micStatus + m_nCurMicRecTime);
			
			sTmp.Format(_T("%s %d"), (LPCTSTR)sMicNum, pTime->number);
			
			GetTime(str, &pTime->oldestTime);
			pFile->AddRow(2, 1, ROW_SPAN|2, sTmp, 1, sStartRecTime, 1, str);
			
			GetTime(str, &pTime->youngestTime); 
			pFile->AddRow(sEndRecTime, str);
		}
	}

	pFile->EndTags(); delete pFile; pFile = NULL;
	RtuLib::FileExecute(GetSafeHwnd(), fname, _T("open"));
}

#pragma endregion CRtuDriveStatusPage2

/*------------------------------------------------------------------------------*/
/*					New Rtu PowerMonitor status Page Class									*/
/*------------------------------------------------------------------------------*/
#pragma region CRtuPowerMonitorStatusPage2

CRtuPowerMonitorStatusPage2::CRtuPowerMonitorStatusPage2() : CRtuStatusBase2(CRtuPowerMonitorStatusPage2::IDD)
{
	m_pStatus = NULL;
	m_nNumDevices = 0; m_nCurDevice = 0;
	m_Flag1 = m_Flag2 = 0;
};
CRtuPowerMonitorStatusPage2::~CRtuPowerMonitorStatusPage2()
{
	if (m_pStatus != NULL) {
		delete[] m_pStatus;
	}
};

IMPLEMENT_DYNCREATE(CRtuPowerMonitorStatusPage2, CXTPPropertyPage)

void CRtuPowerMonitorStatusPage2::DoDataExchange(CDataExchange* pDX)
{
	CXTPPropertyPage::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_RTU_ID1, m_lblDevNum);
	DDX_Control(pDX, IDC_RTU_ID2, m_lblFlags);
	DDX_Control(pDX, IDC_RTU_ID3, m_lblFlags1);
	DDX_Control(pDX, IDC_RTU_ID4, m_lblFlags1Text);
	DDX_Control(pDX, IDC_RTU_ID5, m_lblFlags2);
	DDX_Control(pDX, IDC_RTU_ID6, m_lblFlags2Text);
	DDX_Control(pDX, IDC_RTU_ID7, m_lblGen);
	DDX_Control(pDX, IDC_RTU_ID8, m_lblGenText);
	DDX_Control(pDX, IDC_RTU_ID9, m_lblGenStatus);
	DDX_Control(pDX, IDC_RTU_ID10, m_lblGenText2);
	DDX_Control(pDX, IDC_RTU_ID11, m_lblGenStatus2);
	DDX_Control(pDX, IDC_RTU_ID12, m_lblGenGroup1);
	DDX_Control(pDX, IDC_RTU_ID13, m_lblGenGroup2);
}

BEGIN_MESSAGE_MAP(CRtuPowerMonitorStatusPage2, CXTPPropertyPage)
	//{{AFX_MSG_MAP(CRtuPowerMonitorStatusPage2)
	ON_NOTIFY(UDN_DELTAPOS, IDC_RTU_ID32, OnUpDownDeviceStatus)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CRtuPowerMonitorStatusPage message handlers
/////////////////////////////////////////////////////////////////////////////
BOOL CRtuPowerMonitorStatusPage2::OnInitDialog()
{
	CDialog::OnInitDialog();

	GetDlgItem(IDC_RTU_ID32)->ShowWindow(SW_SHOW);

	CFont* font = new CFont;
	font->CreateFont(
	   15,                        // nHeight
	   0,                         // nWidth
	   0,                         // nEscapement
	   0,                         // nOrientation
	   FW_REGULAR,                   // nWeight
	   FALSE,                     // bItalic
	   FALSE,                     // bUnderline
	   0,                         // cStrikeOut
	   ANSI_CHARSET,              // nCharSet
	   OUT_DEFAULT_PRECIS,        // nOutPrecision
	   CLIP_DEFAULT_PRECIS,       // nClipPrecision
	   DEFAULT_QUALITY,           // nQuality
	   DEFAULT_PITCH | FF_SWISS,  // nPitchAndFamily
	   _T("Courier New"));

	m_lblGenStatus.SetFont(font);
	

	return TRUE;
}

BOOL CRtuPowerMonitorStatusPage2::OnSetActive()
{
	ShowStatus();
	return CXTPPropertyPage::OnSetActive();
}

CString CRtuPowerMonitorStatusPage2::GetStatusString(int index, int value)
{
	int types[] = {
		E_TYPE_BATTERY,
		E_TYPE_POWER,
		E_TYPE_TEMPERATURE,
		E_TYPE_BATTERY,
		E_TYPE_BATTERY,
		E_TYPE_BATTERY,
		E_TYPE_BATTERY,
		E_TYPE_POWER,
		E_TYPE_POWER,
		E_TYPE_TEMPERATURE,
		E_TYPE_TEMPERATURE,
	};
	
	CString strResult = _T("");
	float v1 = (float)(value);
	if (index < sizeof(types)/sizeof(types[0])) {
		int type = types[index];
		switch(type) {
		case E_TYPE_BATTERY:
			strResult.Format(_T("%4d  (%6.2f V )"), value, (float)(v1 * 16.0) / 0x3ff);
			break;
		case E_TYPE_POWER:
			strResult.Format(_T("%4d  (%6.2f V )"), value, (float)(v1 * 24.5) / 0x3ff);
			break;
		case E_TYPE_TEMPERATURE:
			strResult.Format(_T("%4d  (%6.2f�C )"), value, (float)(v1 * 100.0) / 0x3ff);
			break;
		default:
			break;
		}
	}

	return strResult;
}

void CRtuPowerMonitorStatusPage2::ShowStatus()
{
	if (IsWindow(m_hWnd) == FALSE) return;
	GmsOutputDebugString(__FUNCTIONW__, __LINE__, L"Total Devices=%d", m_nNumDevices);
	if (m_nCurDevice >= m_nNumDevices)
		return;
	if (m_pStatus == NULL)
		return;
	
	m_Flag1 = m_pStatus[m_nCurDevice].flag1;
	m_Flag2 = m_pStatus[m_nCurDevice].flag2;

	ShowText();
	ShowFlags();
	ShowGeneralParams();

	GetDlgItem(IDC_RTU_ID32)->EnableWindow((m_nNumDevices <= 1) ? FALSE : TRUE);
}

LPBYTE CRtuPowerMonitorStatusPage2::SetStatus(LPBYTE lpData, int, BOOL)
{
	GmsOutputDebugString(__FUNCTIONW__, __LINE__, L"Count=%d", *lpData);

	LPBYTE p1 = lpData;

	m_nNumDevices = *p1++;
	if (m_pStatus != NULL) 
	{
		delete[] m_pStatus; m_pStatus = NULL;
	}
	try
	{
		if (m_nNumDevices > 0) {
			m_pStatus = new POWER_MONITOR_STATUS[m_nNumDevices];
			if (m_pStatus != NULL) {
				int size = sizeof(POWER_MONITOR_STATUS);
				memset(m_pStatus, 0, size * m_nNumDevices);
				for(int x=0; x<m_nNumDevices; x++) {
					LPPOWER_MONITOR_STATUS pPM = &m_pStatus[x];
					int cnt = *(p1 + 1);
					int bc = cnt + 2;	// Logical number + size + data
					memcpy(pPM, p1, min(bc, size));
					p1 += bc;
				}
			}
			else {
				DispMessageBox(GetSafeHwnd(), IDS_NOT_ENOUGH_MEM, IDS_ERROR, MB_OK|MB_ICONSTOP);
			}
		}

		_OutputDebugMemory(L"CRtuPowerMonitorStatusPage2::SetStatus", lpData, p1-lpData);
		}
	catch (...)
	{
		m_nNumDevices = 0;
		OutputDebugString(L"Exception in CRtuPowerMonitorStatusPage2::SetStatus\n");
	}
	return p1;
}

void CRtuPowerMonitorStatusPage2::OnUpDownDeviceStatus(NMHDR* pNMHDR, LRESULT* pResult)
{
	NM_UPDOWN* pNMUpDown = (NM_UPDOWN*)pNMHDR;
	
	if (pNMUpDown->iDelta == 1) {	// previous
		if (m_nCurDevice > 0) {
			m_nCurDevice--;
		}
		else {
			m_nCurDevice = m_nNumDevices - 1;
		}
	}
	else  {
		if (++m_nCurDevice >= m_nNumDevices)
			m_nCurDevice = 0;
	}

	ShowStatus();
	*pResult = 0;

}

void CRtuPowerMonitorStatusPage2::ShowText()
{
	CString s, strText;
	strText.Format(_T("%s %d of %d"), RES_STRING(IDS_DEVICE), m_nCurDevice+1, m_nNumDevices);
	m_lblDevNum.SetText(strText);

	m_lblFlags.SetText(RES_STRING(IDS_FLAGS));
	m_lblGen.SetText(RES_STRING(IDS_GENERAL_STS));

	UINT GenParamsIDs[] = {
		IDS_BATTERY_ADC_READING, 
		IDS_POWER_SUPPLY_ADC_READING, 
		IDS_TEMPERATURE_ADC_READING, 
		IDS_MIN_BATTERY_ADC_READING, 
		IDS_MAX_BATTERY_ADC_READING, 
		IDS_MIN_LOADED_BATTERY_ADC_READING, 
		IDS_MAX_LOADED_BATTERY_ADC_READING, 
		IDS_MIN_POWER_ADC_READING, 
		IDS_MAX_POWER_ADC_READING, 
		IDS_MIN_TEMPERATURE_ADC_READING, 
		IDS_MAX_TEMPERATURE_ADC_READING, 
		
	};
	UINT GenParamsIDs2[] = {
		IDS_FIRMWARE_VER, 
		IDS_BOOT_LOADER_VER,
		IDS_CONTROLLER_PORT_NUMBER,
	};

	UINT flags1IDs[] = {
		IDS_OFFLINE,
		IDS_TAMPER,
		IDS_NO_BATTERY_DETECTED,
		IDS_BATTERY_VOLTAGE_OUT_OF_RANGE,
		IDS_BATTERY_ALARM_ISOLATED,
		IDS_ISOLATED,
		IDS_CHARGER_FAILED	//TT 7043

	};
	UINT flags2IDs[] = {
		IDS_AC_VOLTAGE_OUT_OF_RANGE,
		IDS_AC_ALARM_ISOLATED,
		IDS_TEMPERATURE_OUT_OF_RANGE,
		IDS_MAIN_FUSE_FAILED,
		IDS_AUXILIARY_FUSE_FAILED,
		IDS_UPS_MAIN_FAIL,
	};

	CString strFormat = 
		_T("       <StackPanel Margin='0, 2, 0, 0' Orientation='Horizontal'>")
		_T("           <TextBlock Margin='5, 0, 0, 0' VerticalAlignment='Center'>%s: </TextBlock>")
		_T("       </StackPanel>");

#pragma region GeneralParams
	m_lblGenGroup1.SetText(_T(""), FALSE);
	m_lblGenGroup2.SetText(_T(""), FALSE);

	strText = _T("");
	for(int i=0; i<_COUNTOF(GenParamsIDs); i++) {
		s.Format(strFormat, RES_STRING(GenParamsIDs[i]));
		strText += s;
	}

	CString str;
	str.Format( 
		_T("<Border Padding='1' BorderThickness='0' BorderBrush='#767676' Background='#e4ecf7'>")
		_T("<StackPanel TextBlock.FontFamily='Tahoma' TextBlock.FontSize='11'>")
		_T(" <StackPanel Orientation='Horizontal' TextBlock.FontFamily='Tahoma'>")
		_T("   <StackPanel Margin='0, 0, 0, 0' Orientation='Vertical'>")
		_T("		%s")
		_T("   </StackPanel>")
		_T(" </StackPanel>")
		_T("</StackPanel>")
		_T("</Border>"),  
		(LPCTSTR)strText 
	);
	m_lblGenText.SetMarkupText(str);


	strText = _T("");
	for(int i=0; i<_COUNTOF(GenParamsIDs2); i++) {
		s.Format(strFormat, RES_STRING(GenParamsIDs2[i]));
		strText += s;
	}
	str.Format( 
		_T("<Border Padding='1' BorderThickness='0' BorderBrush='#767676' Background='#e4ecf7'>")
		_T("<StackPanel TextBlock.FontFamily='Tahoma' TextBlock.FontSize='11'>")
		_T(" <StackPanel Orientation='Horizontal' TextBlock.FontFamily='Tahoma'>")
		_T("   <StackPanel Margin='0, 0, 0, 0' Orientation='Vertical'>")
		_T("		%s")
		_T("   </StackPanel>")
		_T(" </StackPanel>")
		_T("</StackPanel>")
		_T("</Border>"),  
		(LPCTSTR)strText 
	);
	m_lblGenText2.SetMarkupText(str);
#pragma endregion

#pragma region User Flags
	strFormat = 
		_T("       <StackPanel Margin='0, 0, 0, 1' Orientation='Horizontal'>")
		_T("           <TextBlock Margin='0, 0, 0, 0' VerticalAlignment='Center'>%s</TextBlock>")
		_T("       </StackPanel>");

	strText = _T("");
	for(int i=0; i<_COUNTOF(flags1IDs); i++) {
		s.Format(strFormat, RES_STRING(flags1IDs[i]));
		strText += s;
	}
	str.Format( 
		_T("<Border Padding='1' BorderThickness='0' BorderBrush='#767676' Background='#e4ecf7'>")
		_T("<StackPanel TextBlock.FontFamily='Tahoma' TextBlock.FontSize='11'>")
		_T("   <StackPanel Margin='0, 0, 0, 0' Orientation='Vertical'>")
		_T("		%s")
		_T("   </StackPanel>")
		_T("</StackPanel>")
		_T("</Border>"), 
		(LPCTSTR)strText
	);
	m_lblFlags1Text.SetMarkupText(str);


	strText = _T("");
	for(int i=0; i<_COUNTOF(flags2IDs); i++) {
		s.Format(strFormat, RES_STRING(flags2IDs[i]));
		strText += s;
	}
	str.Format( 
		_T("<Border Padding='1' BorderThickness='0' BorderBrush='#767676' Background='#e4ecf7'>")
		_T("<StackPanel TextBlock.FontFamily='Tahoma' TextBlock.FontSize='11'>")
		_T("   <StackPanel Margin='0, 0, 0, 0' Orientation='Vertical'>")
		_T("		%s")
		_T("   </StackPanel>")
		_T("</StackPanel>")
		_T("</Border>"), 
		(LPCTSTR)strText
	);
	m_lblFlags2Text.SetMarkupText(str);
#pragma endregion
}


void CRtuPowerMonitorStatusPage2::ShowFlags()
{
	CString strFormat = 
		_T("       <StackPanel Margin='1, 1, 1, 1' Orientation='Horizontal'>")
		_T("	       <Image Source='%d'/>")
		_T("       </StackPanel>");
	CString strStatus = _T("");
	CString s;
	ushort flags = (ushort)((m_Flag2 << 8) | m_Flag1);
	
	for(int i=0; i<5; i++) {
		if (i==0) { // Offline
			s.Format(strFormat, flags & 1 ? IDB_CHKBOX_UNCHECKED : IDB_CHKBOX_CHECKED);
		}
		else {
			s.Format(strFormat, flags & 1 ? IDB_CHKBOX_CHECKED : IDB_CHKBOX_UNCHECKED);
		}
		strStatus += s;
		flags >>= 1;
	}

	// Isolate
	s.Format(strFormat, m_pStatus[m_nCurDevice].flag2 & 8 ? IDB_CHKBOX_CHECKED : IDB_CHKBOX_UNCHECKED);
	strStatus += s;

	// Charger failed TT7043
	s.Format(strFormat, m_pStatus[m_nCurDevice].flag2 & 0x10 ? IDB_CHKBOX_CHECKED : IDB_CHKBOX_UNCHECKED);
	strStatus += s;

	CString str;
	str.Format( 
		_T("<Border Padding='1' BorderThickness='0' BorderBrush='#767676' Background='#e4ecf7'>")
		_T("   <StackPanel Margin='0, 0, 0, 0' Orientation='Vertical'>")
		_T("		%s")
		_T("   </StackPanel>")
		_T("</Border>"), 
		(LPCTSTR)strStatus
	);
	m_lblFlags1.SetMarkupText(str);

	strStatus = _T("");
	for(int i=0; i<5; i++) {
		s.Format(strFormat, flags & 1 ? IDB_CHKBOX_CHECKED : IDB_CHKBOX_UNCHECKED);
		strStatus += s;
		flags >>= 1;
	}

	// UPS main fail
	s.Format(strFormat, m_pStatus[m_nCurDevice].flag2 & 4 ? IDB_CHKBOX_CHECKED : IDB_CHKBOX_UNCHECKED);
	strStatus += s;
	str.Format( 
		_T("<Border Padding='1' BorderThickness='0' BorderBrush='#767676' Background='#e4ecf7'>")
		_T("   <StackPanel Margin='0, 0, 0, 0' Orientation='Vertical'>")
		_T("		%s")
		_T("   </StackPanel>")
		_T("</Border>"), 
		(LPCTSTR)strStatus
	);
	m_lblFlags2.SetMarkupText(str);
}

void CRtuPowerMonitorStatusPage2::ShowGeneralParams()
{
#pragma region General Parameters 1...
	CString strFormat = 
		_T("       <StackPanel Margin='0, 2, 0, 0' Orientation='Horizontal'>")
		_T("           <TextBlock Margin='5, 0, 0, 0' VerticalAlignment='Center'>%s</TextBlock>")
		_T("       </StackPanel>");

	LPBYTE p = &m_pStatus[m_nCurDevice].adcBattLo;
	CString strStatus = _T("");
	CString s;
	for(int i=0; i<E_NUM_STATUS_READINGS; i++) {
		int n = *p++;
		n |= ((*p++) << 8);
		s.Format(strFormat, GetStatusString(i, n&0x3ff));
		strStatus += s;
	}

	CString str;
	str.Format( 
		_T("<Border Padding='1' BorderThickness='0' BorderBrush='#767676' Background='#e4ecf7'>")
		_T("<StackPanel TextBlock.FontFamily='Tahoma' TextBlock.FontSize='11'>")
		_T(" <StackPanel Orientation='Horizontal' TextBlock.FontFamily='Tahoma'>")
		_T("   <StackPanel Margin='0, 0, 0, 0' Orientation='Vertical'>")
		_T("		%s")
		_T("   </StackPanel>")
		_T(" </StackPanel>")
		_T("</StackPanel>")
		_T("</Border>"), 
		(LPCTSTR)strStatus
	);
	m_lblGenStatus.SetMarkupText(str);
#pragma endregion General Parameters 1...

#pragma region General Parameters 2...
	strStatus = _T("");
	CString strText;
	if (m_pStatus[m_nCurDevice].size > 24) {
		strText.Format(_T("%02d.%02d"), m_pStatus[m_nCurDevice].firmwareVersionMajor, m_pStatus[m_nCurDevice].firmwareVersionMinor);
		s.Format(strFormat, strText);
		strStatus += s;
		strText.Format(_T("%02d.%02d"), m_pStatus[m_nCurDevice].bootloadVersionMajor, m_pStatus[m_nCurDevice].bootloadVersionMinor);
		s.Format(strFormat, strText);
		strStatus += s;
	}
	else {
		s.Format(strFormat, _T("--"));
		strStatus += s;
		strStatus += s;
	}

	strText = _T("--");
	if (m_pStatus[m_nCurDevice].size > 28) {
		strText.Format(_T("%d"), m_pStatus[m_nCurDevice].controllerPortNumber);
	}
	s.Format(strFormat, strText);
	strStatus += s;

	str.Format( 
		_T("<Border Padding='1' BorderThickness='0' BorderBrush='#767676' Background='#e4ecf7'>")
		_T("<StackPanel TextBlock.FontFamily='Tahoma' TextBlock.FontSize='11'>")
		_T(" <StackPanel Orientation='Horizontal' TextBlock.FontFamily='Tahoma'>")
		_T("   <StackPanel Margin='0, 0, 0, 0' Orientation='Vertical'>")
		_T("		%s")
		_T("   </StackPanel>")
		_T(" </StackPanel>")
		_T("</StackPanel>")
		_T("</Border>"), 
		(LPCTSTR)strStatus
	);

	m_lblGenStatus2.SetMarkupText(str);

#pragma endregion General Parameters 2...


}
void CRtuPowerMonitorStatusPage2::Print()
{
}

#pragma endregion CRtuPowerMonitorStatusPage2

/*------------------------------------------------------------------------------*/
/*					New Rtu Vault controller Page Class									*/
/*------------------------------------------------------------------------------*/
#pragma region CRtuVaultControllerStatusPage2

CRtuVaultControllerStatusPage2::CRtuVaultControllerStatusPage2() : CRtuStatusBase2(CRtuVaultControllerStatusPage2::IDD)
{
	m_pStatus = NULL;
	m_nNumDevices = 0; m_nCurDevice = 0;
	m_Flag1 = 0;
};
CRtuVaultControllerStatusPage2::~CRtuVaultControllerStatusPage2()
{
	if (m_pStatus != NULL) {
		delete[] m_pStatus; m_pStatus = NULL;
	}
};

IMPLEMENT_DYNCREATE(CRtuVaultControllerStatusPage2, CXTPPropertyPage)

void CRtuVaultControllerStatusPage2::DoDataExchange(CDataExchange* pDX)
{
	CXTPPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CRtuVaultControllerStatusPage2)
	DDX_Control(pDX, IDC_RTU_ID1, m_lblVaultNum);

	DDX_Control(pDX, IDC_RTU_ID2, m_lblFlags);
	DDX_Control(pDX, IDC_RTU_ID3, m_lblFlagsCheck);
	DDX_Control(pDX, IDC_RTU_ID4, m_lblFlagsText);

	DDX_Control(pDX, IDC_RTU_ID5, m_lblVault);
	DDX_Control(pDX, IDC_RTU_ID6, m_lblVaultText);
	DDX_Control(pDX, IDC_RTU_ID7, m_lblVaultStatus);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CRtuVaultControllerStatusPage2, CXTPPropertyPage)
	//{{AFX_MSG_MAP(CRtuVaultControllerStatusPage2)
	ON_NOTIFY(UDN_DELTAPOS, IDC_RTU_ID32, OnUpDownDeviceStatus)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CRtuVaultControllerStatusPage message handlers
/////////////////////////////////////////////////////////////////////////////
BOOL CRtuVaultControllerStatusPage2::OnInitDialog()
{
	CDialog::OnInitDialog();

	GetDlgItem(IDC_RTU_ID32)->ShowWindow(SW_SHOW);
	
	m_strArrVaultStatus.RemoveAll();
	m_strArrVaultStatus.Add(CString(LPTSTR(IDS_IDLE)));
	m_strArrVaultStatus.Add(CString(LPTSTR(IDS_TIMING_DOWN)));
	m_strArrVaultStatus.Add(CString(LPTSTR(IDS_INTERLOCKED)));
	m_strArrVaultStatus.Add(CString(LPTSTR(IDS_UNLOCKED)));
	m_strArrVaultStatus.Add(CString(LPTSTR(IDS_OPEN)));
	m_strArrVaultStatus.Add(CString(LPTSTR(IDS_HASTENING)));
	m_strArrVaultStatus.Add(CString(LPTSTR(IDS_ALARM)));
	for(int i=0; i<8; i++) {
		m_strArrVaultStatus.Add(_T(""));
	}
	m_strArrVaultStatus.Add(CString(LPTSTR(IDS_UNKNOWN_STATE)));

	return TRUE;
}

BOOL CRtuVaultControllerStatusPage2::OnSetActive()
{
	ShowStatus();
	return CXTPPropertyPage::OnSetActive();
}

void CRtuVaultControllerStatusPage2::ShowStatus()
{
	if (IsWindow(m_hWnd) == FALSE)
		return;

	GmsOutputDebugString(__FUNCTIONW__, __LINE__, L"Total Devices=%d", m_nNumDevices);
	GetDlgItem(IDC_RTU_ID32)->EnableWindow((m_nNumDevices <= 1) ? FALSE : TRUE);

	if (m_nCurDevice >= m_nNumDevices || m_pStatus == NULL)
		return;
	
	CString strText;
	strText.Format(_T("%s %d of %d"), RES_STRING(IDS_DEVICE), m_nCurDevice+1, m_nNumDevices);
	m_lblVaultNum.SetText(strText);

	m_Flag1 = m_pStatus[m_nCurDevice].byte1;
	ShowFlags();
	ShowGenStatus();

}

LPBYTE CRtuVaultControllerStatusPage2::SetStatus(LPBYTE lpData, int, BOOL)
{
	GmsOutputDebugString(__FUNCTIONW__, __LINE__, L"Count=%d", *lpData);

	LPBYTE p1 = lpData;

	m_nNumDevices = *p1++;

	try
	{

		if (m_pStatus)
		{
			delete [] m_pStatus;
			m_pStatus = NULL;
		}

		if (m_nNumDevices > 0) {
			int size = sizeof(VAULT_CONTROLLER);
			m_pStatus = new VAULT_CONTROLLER[m_nNumDevices];
			memset(m_pStatus, 0, size * m_nNumDevices);
			for(int x=0; x<m_nNumDevices; x++) {
				LPVAULT_CONTROLLER pVC = &m_pStatus[x];
				int cnt = *(p1 + 1);
				int bc = cnt + 2;	// Logical number + size + data
				memcpy(pVC, p1, min(bc, size));
				p1 += bc;
			}
		}

		_OutputDebugMemory(L"CRtuVaultControllerStatusPage2::SetStatus", lpData, p1-lpData);
	}
	catch (...)
	{
		m_nNumDevices = 0;
		OutputDebugString(L"Exception in CRtuVaultControllerStatusPage2::SetStatus\n");
	}
	return p1;
}

void CRtuVaultControllerStatusPage2::OnUpDownDeviceStatus(NMHDR* pNMHDR, LRESULT* pResult)
{
	NM_UPDOWN* pNMUpDown = (NM_UPDOWN*)pNMHDR;
	// TODO: Add your control notification handler code here
	
	if (pNMUpDown->iDelta == 1) {	// previous
		if (m_nCurDevice > 0) {
			m_nCurDevice--;
		}
		else {
			m_nCurDevice = m_nNumDevices - 1;
		}
	}
	else  {
		if (++m_nCurDevice >= m_nNumDevices)
			m_nCurDevice = 0;
	}

	ShowStatus();
	*pResult = 0;
}

void CRtuVaultControllerStatusPage2::ShowFlags()
{
	CString s, strText;
	m_lblFlags.SetText(RES_STRING(IDS_FLAGS));

	CString strFormat = 
		_T("       <StackPanel Margin='1, 1, 1, 2' Orientation='Horizontal'>")
		_T("	       <Image Source='%d'/>")
		_T("       </StackPanel>");
	strText = _T("");
	int flags = m_Flag1;
	for(int i=0; i<8; i++) {
		if (i==0) { // Offline
			s.Format(strFormat, flags & 1 ? IDB_CHKBOX_UNCHECKED : IDB_CHKBOX_CHECKED);
		}
		else {
			s.Format(strFormat, flags & 1 ? IDB_CHKBOX_CHECKED : IDB_CHKBOX_UNCHECKED);
		}
		flags >>= 1;
		strText += s;
	}
	flags = m_pStatus[m_nCurDevice].flags;

	// Isolated
	s.Format(strFormat, flags & 1 ? IDB_CHKBOX_CHECKED : IDB_CHKBOX_UNCHECKED);
	strText += s;

	CString str;
	str.Format( 
		_T("<Border Padding='1' BorderThickness='0' BorderBrush='#767676' Background='#e4ecf7'>")
		_T("   <StackPanel Margin='0, 0, 0, 0' Orientation='Vertical'>")
		_T("		%s")
		_T("   </StackPanel>")
		_T("</Border>"), 
		(LPCTSTR)strText
	);
	m_lblFlagsCheck.SetMarkupText(str);

	strFormat = 
		_T("       <StackPanel Margin='1, 1, 1, 1' Orientation='Horizontal'>")
		_T("	       <TextBlock Margin='0, 0, 0, 0' VerticalAlignment='Center'>%s</TextBlock>")
		_T("       </StackPanel>");
	strText = _T("");
	UINT flagsIDs[] = {
		IDS_OFFLINE, 
		IDS_TAMPER, 
		IDS_SEISMIC_ALARM_ON,
		IDS_SOLENOID_ALARM_ON, 
		IDS_DOOR_OPEN_ALARM,
		IDS_DOOR_UNLOCKED_ALARM,
		IDS_EMERGENCY_BUTTON_ALARM,
		IDS_DISPLAY_TAMPER,
		IDS_ISOLATED
	};
	for(int i=0; i<_COUNTOF(flagsIDs); i++) {
		s.Format(strFormat, RES_STRING(flagsIDs[i]));
		strText += s;
	}
	str.Format( 
		_T("<Border Padding='1' BorderThickness='0' BorderBrush='#767676' Background='#e4ecf7'>")
		_T("<StackPanel TextBlock.FontFamily='Tahoma' TextBlock.FontSize='11'>")
		_T("   <StackPanel Margin='0, 0, 0, 0' Orientation='Vertical'>")
		_T("		%s")
		_T("   </StackPanel>")
		_T("</StackPanel>")
		_T("</Border>"), 
		(LPCTSTR)strText
	);
	m_lblFlagsText.SetMarkupText(str);
}

void CRtuVaultControllerStatusPage2::ShowGenStatus()
{
	CString s, str, strText;
	m_lblVault.SetText(RES_STRING(IDS_GENERAL_STS));
	UINT genStatusIDs[] = {
		IDS_VAULT_STATUS, 
		IDS_FIRMWARE_VER, 
		IDS_BOOT_LOADER_VER,
		IDS_CONTROLLER_PORT_NUMBER
	};
	CString strFormat = 
		_T("       <StackPanel Margin='1, 1, 1, 1' Orientation='Horizontal'>")
		_T("	       <TextBlock Margin='0, 0, 0, 0' VerticalAlignment='Center'>%s: </TextBlock>")
		_T("       </StackPanel>");
	strText = _T("");
	for(int i=0; i<_COUNTOF(genStatusIDs); i++) {
		s.Format(strFormat, RES_STRING(genStatusIDs[i]));
		strText += s;
	}

	str.Format( 
		_T("<Border Padding='1' BorderThickness='0' BorderBrush='#767676' Background='#e4ecf7'>")
		_T("<StackPanel TextBlock.FontFamily='Tahoma' TextBlock.FontSize='11'>")
		_T("   <StackPanel Margin='0, 0, 0, 0' Orientation='Vertical'>")
		_T("		%s")
		_T("   </StackPanel>")
		_T("   </StackPanel>")
		_T("</Border>"),  
		(LPCTSTR)strText
	);
	m_lblVaultText.SetMarkupText(str);

	int vaultState = m_pStatus[m_nCurDevice].byte2 >> 4;
	CStringArray strArr; strArr.RemoveAll();
	strArr.Add(vaultState < m_strArrVaultStatus.GetSize() ? m_strArrVaultStatus.GetAt(vaultState) : _T(""));

	if (m_pStatus[m_nCurDevice].size > 2) {
		s.Format(_T("%02d.%02d"), m_pStatus[m_nCurDevice].firmwareVersionMajor, m_pStatus[m_nCurDevice].firmwareVersionMinor);
		strArr.Add(s);
		s.Format(_T("%02d.%02d"), m_pStatus[m_nCurDevice].bootloadVersionMajor, m_pStatus[m_nCurDevice].bootloadVersionMinor);
		strArr.Add(s);
	}
	else {
		strArr.Add(_T("--"));
		strArr.Add(_T("--"));
	}

	if (m_pStatus[m_nCurDevice].size >= 8) {
		s.Format(_T("%d"), m_pStatus[m_nCurDevice].controllerPortNumber);
		strArr.Add(s);
	}
	else {
		strArr.Add(_T("--"));
	}
	strFormat = 
		_T("       <StackPanel Margin='1, 1, 1, 1' Orientation='Horizontal'>")
		_T("	       <TextBlock Margin='0, 0, 0, 0' VerticalAlignment='Center'>%s</TextBlock>")
		_T("       </StackPanel>");
	strText = _T("");
	for(int i=0; i<strArr.GetCount(); i++) {
		s.Format(strFormat, strArr.GetAt(i));
		strText += s;
	}
	str.Format( 
		_T("<Border Padding='1' BorderThickness='0' BorderBrush='#767676' Background='#e4ecf7'>")
		_T("<StackPanel TextBlock.FontFamily='Tahoma' TextBlock.FontSize='11'>")
		_T("   <StackPanel Margin='0, 0, 0, 0' Orientation='Vertical'>")
		_T("		%s")
		_T("   </StackPanel>")
		_T("</StackPanel>")
		_T("</Border>"), 
		(LPCTSTR)strText
	);
	m_lblVaultStatus.SetMarkupText(str);
}

void CRtuVaultControllerStatusPage2::Print()
{
}

#pragma endregion CRtuVaultControllerStatusPage2

/*------------------------------------------------------------------------------*/
/*					New Rtu device full status Page Class									*/
/*------------------------------------------------------------------------------*/
#pragma region CRtuFullDeviceStatusPage2
extern SETUPPARM rtuSetup;
void SaveUserListHeaderConfig(int* indices, int count)
{
	if (count <= 0)
		return;
	
	int UserNo = 0;
	if (Globals->m_pUsers)
		UserNo = Globals->m_pUsers->m_UserInfo.UserNo;

	CMyFile customHdrFile;
	TCHAR sFileName[MAX_PATH];
	wsprintf(sFileName, L"Customer\\Data\\FullDeviceStatus.d%u", UserNo); 
	if (customHdrFile.Open(DefaultLocation(sFileName), FILE_READWRITE|FILE_DENYNONE|FILE_CREATE, 0))
	{
		char s[500] = "", *ptr;
		int len = 0, sLen = 500;

		ptr = s;
		for (int i = 0; i < count; i++)
		{
			len = sprintf_s(ptr, sLen, "%d,", indices[i]);
			ptr += len;
			sLen -= len;

		}

		if (ptr != s) 
		{
			*(ptr-1) = 0;

			customHdrFile.SetLength(0);
			customHdrFile.Write(s, strlen(s));
		}

		customHdrFile.Close();
	}
}


int GetUserListHeaderConfig(int* indices, int count)
{
	if (count <= 0)
		return 0;
	
	int totalItems = 0;

	int UserNo = 0;
	if (Globals->m_pUsers)
		UserNo = Globals->m_pUsers->m_UserInfo.UserNo;

	CMyFile customHdrFile;
	TCHAR sFileName[MAX_PATH];
	wsprintf(sFileName, L"Customer\\Data\\FullDeviceStatus.d%u", UserNo); 
	if (customHdrFile.Open(DefaultLocation(sFileName), FILE_READ|FILE_DENYNONE, 0))
	{
		char *s, *ptr;
		int len = (int)customHdrFile.GetLength();

		if (len > 0)
		{
			s = new char[len+1];
			if (s)
			{
				customHdrFile.Read(s, len);
				*(s+len) = 0;

				ptr = s;
				do
				{
					if (totalItems >= count)
						break;

					char *comas = strchr(ptr, ',');
					if (comas != NULL)
						*comas ++ = '\0';
					
					int ind = atoi(ptr);
					*(indices+totalItems++) = ind;

					ptr = comas;
				} while (ptr != NULL && *ptr != '\0');
			delete [] s;
			}
		}

		
		customHdrFile.Close();
	}

	return totalItems;
}


/*------------------------------------------------------------------------------*/
/*					Full Status device Page Class									*/
/*------------------------------------------------------------------------------*/


#define FullDeviceStatusHeaderSize	(FIELDOFFSET(_fullDvcStatusData, dvcPropertyBytes)+1)

IMPLEMENT_DYNCREATE(CRtuFullDeviceStatusPage2, CXTPPropertyPage)

void CRtuFullDeviceStatusPage2::DoDataExchange(CDataExchange* pDX)
{
	CXTPPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CRtuFullDeviceStatusPage2)
	//DDX_Control(pDX, IDC_LIST, m_deviceList);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CRtuFullDeviceStatusPage2, CXTPPropertyPage)
	//{{AFX_MSG_MAP(CRtuFullDeviceStatusPage2)
	ON_WM_DESTROY()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

#define FULLSTS_COLUMN_FILENAME L"FullStatusDeviceColumns.txt"

BOOL CRtuFullDeviceStatusPage2::OnInitDialog()
{
	CXTPPropertyPage::OnInitDialog();
	m_deviceList.SubclassDlgItem(IDC_LIST, this);
	CWnd* pWnd = GetDlgItem(IDC_RTU_TOTAL);
	if (pWnd) {
		pWnd->ShowWindow(SW_HIDE);
	}


	m_imgList.Create(IDB_DVCSTATUS, 12, 30, RGB(0, 0x80, 0x80)); 
	
	m_deviceList.SetImageList(&m_imgList, LVSIL_SMALL);

	DWORD dwStyle = m_deviceList.GetExtendedStyle();
	dwStyle |= LVS_EX_HEADERDRAGDROP|LVS_EX_GRIDLINES|LVS_EX_FULLROWSELECT;
	m_deviceList.SetExtendedStyle(dwStyle);

	InitColumns();
	
	m_strYes = RES_STRING(IDS_YES_TXT);
	m_strNo = RES_STRING(IDS_NO_TXT);
	return TRUE;
}

BOOL CRtuFullDeviceStatusPage2::IsExpansionProperty(int colHeaderType)
{
	switch (colHeaderType)
	{
		case eExpansionOffline:
		case eExpansionFuseFail:
		return TRUE;
	}
	return FALSE;
}
void CRtuFullDeviceStatusPage2::GetStandardColumnNameAndIDs()
{
	TCHAR columnHeaderFileName[MAX_PATH] = {0};

	wsprintf(columnHeaderFileName, L"%s\\%s", GetLngOverwriteFolder(), FULLSTS_COLUMN_FILENAME);

	CStringArray headerTxts;
	CMyFile file;

	if (file.Open(DefaultLocation(columnHeaderFileName), FILE_READ|FILE_DENYNONE, 0) == NULL)
		return;
	try
	{
		TCHAR sColumn[128], line[128];
		int ind = 0;
		do
		{
			sColumn[0] = _T('\0');
			line[0] =  _T('\0'); 

			if (file.ReadString(line, 128) == NULL)
				break;

			if (line[0] == ';' || line[0] == _T('\0'))
				continue;

			LPTSTR pComas = lstrchr(line, _T('.'));
			if (pComas != NULL)
			{
				*pComas++ = _T('\0');

				int colId = _tstoi(line);
				
				CString s(pComas);
				if (s.Trim().IsEmpty() == true)
					continue;
				
				if (IsExpansionProperty(colId) == TRUE)
					m_ExIdAndNames[colId] = s;
				else
					m_IdAndNames[colId] = s;
			}

		} while (ind < 255);
	}
	catch (...)
	{
	}
	
	file.Abort();
}

int _idCompare( const void *arg1, const void *arg2 )
{
  	DWORD id1 = *(const int*)arg1;
	DWORD id2 = *(const int*)arg2;
	
	return (id1 - id2);
}

void CRtuFullDeviceStatusPage2::InitColumns()
{
	if (IsWindow(m_hWnd) == FALSE || m_isColumnInit == TRUE || m_IdAndNames.IsEmpty() || m_pStatus == NULL)
		return;
	
	int orders[255]={0};
	int col_count = m_deviceList.GetHeaderCtrl()->GetItemCount();
	
	m_deviceList.GetHeaderCtrl()->GetOrderArray(orders, col_count);
		
	m_isColumnInit = TRUE;
	m_colCount = 0;
	
	int items[255];
	int count = col_count;
	while (count > 0)
	{
		m_deviceList.DeleteColumn(--count);
	}
	
	// this for sorting. 
	// Order of item in the m_IdAndNames is not the order of item when it is inserted. Damn!
	POSITION pos = m_IdAndNames.GetStartPosition();
	int id;
	CString s;
	count = 0;
	while (pos != NULL)
	{
		m_IdAndNames.GetNextAssoc(pos, id, s);
		items[count++] = id;
	}
	
	if (count>1)
		qsort(items, count, sizeof(int), _idCompare);
	
	for (int ind = 0; ind < count ; ind++)
	{
		AddColumn(items[ind], m_IdAndNames[items[ind]]);
	}

	int ids[] = {eExpansionOffline, eExpansionFuseFail};
	for (int card = 0; card < MAX_EXPANSION_STS; card++)
	{
		if (m_expansionSlot[card] == TRUE)
		{
			for (int prop = 0; prop < _COUNTOF(ids); prop++)
			{
				if (m_ExIdAndNames.Lookup(ids[prop], s))
				{
					s.AppendFormat(L"-%d", card+1);
					AddColumn(MAKEWORD(ids[prop], card), s);		
				}
			}
		}
	}
	
	if (col_count == 0)	
	{
		int colOrders[255];
		col_count = GetUserListHeaderConfig(colOrders, 255);
	
		if (col_count == 0)
			return;
		
		int n = 0;		
		for (int colId = 0; colId < m_colCount; colId++)		
		{
			for (int i = 0; i < col_count; i++)
			{			
				if (colOrders[i] == m_colIds[colId])
				{
					orders[n++] = i;
					break;
				}
			}
		}
		
		col_count = n;
	}
	else
	{
		// this needs to be done or the columns are duplicated when number of item in the arrays are different.
		if (col_count > m_colCount)
		{
			for (int i = 0; i < col_count; i++)
			{			
				if (orders[i] > m_colCount)
				{
					memcpy(&orders[i], &orders[i+1], col_count-i+1);
					i--;
					col_count--;
					break;
				}
			}
		}
		else if (col_count >= 0)
		{
			for (int i = col_count; i < m_colCount; i++)
			{			
				orders[i] = i;
			}		
		}
		col_count = m_colCount;
	}
	
	m_deviceList.GetHeaderCtrl()->SetOrderArray(col_count, orders);
}

void CRtuFullDeviceStatusPage2::AddColumn(int colId, CString& text)
{

	CSize size = ((CDC*)this->GetDC())->GetTextExtent(text);
	int ind = m_deviceList.InsertColumn(m_colCount, text, LVCFMT_CENTER, size.cx);

	HDITEM item;
	memset(&item, 0, sizeof(item));
	item.mask = HDI_LPARAM;
	item.lParam = colId;
	m_deviceList.GetHeaderCtrl()->SetItem(ind, &item);		
	
	m_colIds[m_colCount++] = colId;
}

void CRtuFullDeviceStatusPage2::OnDestroy()
{
	CHeaderCtrl* header = m_deviceList.GetHeaderCtrl();

	if (header != NULL && IsWindow(header->m_hWnd))
	{
		int count = header->GetItemCount();

		int ids[255]={0};
		if (header->GetOrderArray(ids, count) == TRUE)
		{
			int colIds[255];
			for (int ind = 0; ind < count; ind++)
			{
				colIds[ind] = m_colIds[ids[ind]];
			}
			SaveUserListHeaderConfig(colIds, count);
		}	
	}
}

BOOL CRtuFullDeviceStatusPage2::OnSetActive()
{
	ShowStatus();
	return CXTPPropertyPage::OnSetActive();
}

LPBYTE CRtuFullDeviceStatusPage2::SetStatus(LPBYTE lpData, int, BOOL)
{
	m_isColumnInit = 0;
	
	memset(m_expansionSlot, 0, sizeof(m_expansionSlot));
	
	delete [] m_pStatus;
	m_pStatus = NULL;

	m_numDevices = *(LPWORD)lpData;
	LPBYTE pDvcStatus = lpData + 2;
	
	if (m_numDevices == 0)
		return pDvcStatus;
	
	int bc = 0;
	int dvcSize = 0;
	
	try
	{

	int expCountOffset = FIELDOFFSET(_fullDvcStatusData, expansionCardCount);

	for (int ind = 0; ind < m_numDevices; ind++)
	{			
		dvcSize = GetDeviceStructSize(pDvcStatus); // whole structure.
		
		//if (dvcSize > maxStsSize)
		//{
		//	CString db; db.Format(L"Attention:FullDeviceStatus dvc-%d has struct size=%d (coded size=%d)!!!!\n", ind+1, dvcSize, maxStsSize);
		//	OutputDebugString(db);
		//}
		if (dvcSize > expCountOffset)
		{
			_fullDvcStatusData * dvcStsPtr = (_fullDvcStatusData*)pDvcStatus;
			
			LPBYTE expPtr = &dvcStsPtr->expansionCardCount + 1;
			for (int i = 0; i < dvcStsPtr->expansionCardCount && i < MAX_EXPANSION_STS; i++)
			{
				BYTE size = *(expPtr);
				if (size != 0)
				{
					m_expansionSlot[i] = TRUE;				
					size = 1;// at this moment size should be 1
				}
				expPtr += (size + 1); 		// + 1 byte size			
			}
		}
		
		bc += dvcSize; 
		pDvcStatus += dvcSize;	
	}

	m_pStatus = new BYTE[bc];
	if (m_pStatus == NULL)
	{
		m_numDevices = 0;
	}
	else
	{
		memcpy(m_pStatus, lpData + 2, bc); 
	}

	pDvcStatus = lpData + bc + 2;
	
	_OutputDebugMemory(L"CRtuFullDeviceStatusPage2::SetStatus", lpData, bc+2);
	}
	catch (...)
	{
		OutputDebugString(L"Exception in parsing data from CRtuFullDeviceStatusPage2::SetStatus.\n");
		m_numDevices = 0;
	}
	return pDvcStatus; // return the pointer points to the end of section block.
}

int CRtuFullDeviceStatusPage2::GetDeviceStructSize(LPBYTE pDvcStatus)
{
	BYTE dvcPropertyBytes = ((_fullDvcStatusData*) pDvcStatus)->dvcPropertyBytes;

	return (dvcPropertyBytes + FullDeviceStatusHeaderSize);
}

void CRtuFullDeviceStatusPage2::ShowStatus(void)
{
	if (m_pStatus == NULL || m_numDevices == 0)
		return;

	// it will add the column headers if it has not do so.
	InitColumns();
		
	m_deviceList.DeleteAllItems();

	_fullDvcStatusData sts;
	
	int dvcSize = 0;
	int nBytes = sizeof(sts) - sizeof(sts.expansion); // include expansionCardCount
	int structSize = sizeof(sts);
	
	LPBYTE pDvcStatus = m_pStatus;
	
	for (int ind = 0; ind < m_numDevices; ind++) 
	{
		memset(&sts, 0, structSize);

		dvcSize = GetDeviceStructSize(pDvcStatus);
		
		memcpy(&sts, pDvcStatus, min(dvcSize, nBytes)); // maximum up to expansionCardCount (included)
		
		//CString db;db.Format(L"Device-%d : %d bytes: byte8=x%02x, byte9=x%02x", ind, dvcSize,sts.byte8, sts.byte9);
		if (dvcSize > nBytes)
		{
			LPBYTE pExpansion = pDvcStatus + nBytes; // point to byte size of the 1st expansion
			for (int id = 0; id < sts.expansionCardCount && id < MAX_EXPANSION_STS; id++)
			{
				sts.expansion[id].size = *pExpansion++;
				if (sts.expansion[id].size > 0)
				{
					sts.expansion[id].properties = *pExpansion++;
				}
				//db.AppendFormat(L",expansion-%d: size=%d, property=x%02x", id, sts.expansion[id].size, sts.expansion[id].properties);
			} 
		}
		
		//GmsOutputDebugString(__FUNCTIONW__, __LINE__, L"Device-%d : %d bytes: byte8=x%02x, byte9=x%02x\n", ind, dvcSize,
		//sts.byte8, sts.byte9);

		AddDeviceStatus(ind, sts);

		pDvcStatus += dvcSize;
	}
	m_deviceList.SetRedraw();
}

// dvcSize includes 5 bytes structure + extended properties
CString GetDeviceNumString(BYTE deviceNum)
{
	CString num = L"----";
	if (deviceNum < 255)
	{
		num.Format(L"%d", deviceNum+1);
	}

	return num;
}

CString CRtuFullDeviceStatusPage2::FormatColumnText(int columnId, _fullDvcStatusData& dvc)
{

	CString sText = L"";

	switch (columnId)
	{
	case ePacomtype: 
		{
			return GetPacomDeviceName(dvc.pacomType);
		}
	case eDeviceLoopType: 
		{
			return GetDevTypeString(dvc.dvcLoopType);
		}
	case eDeviceLoopAddress: 
		{
			return GetDevicePhysicalAddressString(dvc.dvcLoopAddress);
		}
	case eLogicalDeviceNumber: 
		{
			return GetDeviceNumString(dvc.dvcNum);
		}
	case eCR1IndexNum: 
		{
			return GetDeviceNumString(dvc.cr1Num);
		}
	case eCR2IndexNum: 
		{
			return GetDeviceNumString(dvc.cr2Num);
		}
	case eOffline: 
	case eOfflineReportLatched: 
	case eTamper: 
	case eTamperReportLatched: 
	case eIsolated: 
	case eCR1Isolated: 
	case eCR2Isolated:
	case eVoltageFailed: 
		{
			if (dvc.dvcPropertyBytes > 0)
			{
				sText = (dvc.byte8 & (1<<(columnId - eOffline)))? m_strYes : m_strNo;
			}
			break;
		}
	case eNoBattery: 
	case eBatteryLow: 
	case eLANConnected:
	case eDownLoadInProgress:
		{
			if (dvc.dvcPropertyBytes > 1)
			{
				sText = (dvc.byte9 & (1<<(columnId - eNoBattery)))? m_strYes : m_strNo;
			}
			break;
		}
	case eFirmwareVersion: 
		{
			if (dvc.dvcPropertyBytes > 5)
				return GetVersionString(dvc.fwareMajorVersion, dvc.fwareMinorVersion); // major.minor
			break;
		}
	case eBootloadVersion: 
		{
			if (dvc.dvcPropertyBytes > 7)
				return GetVersionString(dvc.bootloadMajorVersion, dvc.bootloadMinorVersion); // major.minor
			break;
		}
	case eRtuPortNum: 
		{
			if (dvc.dvcPropertyBytes >= 9)
				return GetDevicePhysicalPortString(dvc.portNum);
			break;
		}
		
	case eOfflineCount: 
		{
			if (dvc.dvcPropertyBytes >=10)
				sText.Format(L"%d", dvc.offlineCount);
			break;
		}
	case eTamperCount: 
		{
			if (dvc.dvcPropertyBytes >= 11)
				sText.Format(L"%d", dvc.tamperCount);
			break;
		}
	case eDeviceSerialNum: // 16 chars: byte19..byte34
		{
			if (dvc.dvcPropertyBytes >= 27)
			{
				char serialNum[17];
				memcpy(serialNum, dvc.serialNum, 16);
				serialNum[16] = '\0';

				sText = serialNum;
			}
		break;
		}
	case eAlternateRtuPortNum: 
		{
			if (dvc.dvcPropertyBytes >= 28)
				return GetDevicePhysicalPortString(dvc.alternatePortNum);
			break;
		}
	case eIPAddress: 
		{
			if (dvc.dvcPropertyBytes >= 32)
				sText.Format(L"%d.%d.%d.%d", dvc.ipAddress[0], dvc.ipAddress[1], dvc.ipAddress[2], dvc.ipAddress[3]);
			break;
		}
	case eNumExpansionCards:
		{
			if (dvc.dvcPropertyBytes >= 33)
				sText.Format(L"%d", dvc.expansionCardCount);
			break;
		}
	default:
		
		BYTE propertyId = columnId & 0xff;
		switch (propertyId)
		{
		case eExpansionOffline: 
		case eExpansionFuseFail: 
			{
				BYTE expansionNo = (BYTE)(columnId >> 8);
				BYTE propertyMask = (1<<(propertyId-eExpansionOffline));
			
				if (dvc.dvcPropertyBytes > 34 && //at least 35
					dvc.expansionCardCount > expansionNo && 
					expansionNo < MAX_EXPANSION_STS && dvc.expansion[expansionNo].size)  // check outbound.
				{		
					sText = (dvc.expansion[expansionNo].properties & propertyMask)? m_strYes : m_strNo;		
				}
				break;
			}
		}


	}

	return sText;
}

void CRtuFullDeviceStatusPage2::AddDeviceStatus(int item, _fullDvcStatusData& sts)
{
	int colCount = m_deviceList.GetHeaderCtrl()->GetItemCount();
	
	ASSERT(colCount < 255);
	
	LVITEM lvi;
	lvi.mask = LVIF_TEXT;
	lvi.iItem = item;

	for (int ind = 0; ind < colCount; ind++)
	{

		HDITEM hdi;
		hdi.mask = HDI_LPARAM;
	
		if (m_deviceList.GetHeaderCtrl()->GetItem(ind, &hdi) == FALSE)
			continue;
			
		lvi.iSubItem = ind;
		
		CString Text = FormatColumnText(hdi.lParam, sts);
		lvi.pszText = Text.GetBuffer();
		if (ind == 0)
			m_deviceList.InsertItem(&lvi);
		else
			m_deviceList.SetItem(&lvi);

		if (hdi.lParam == ePacomtype)
		{
			lvi.mask = LVIF_IMAGE;
			lvi.iImage = GetDviceBmpIndex(sts);
			m_deviceList.SetItem(&lvi);
			lvi.mask = LVIF_TEXT;
		}
	}
}

int		CRtuFullDeviceStatusPage2::GetDviceBmpIndex(_fullDvcStatusData& sts)
{
	_deviceBmpType dvcType = /*_deviceBmpType::*/DVC_BMP;
	switch (sts.pacomType)
	{
		case 3: 
			dvcType = /*_deviceBmpType::*/KP_BMP;
			break;
		case 4:
		case 75: 
			dvcType = /*_deviceBmpType::*/IO_BMP;
			break;
		case 34:
		case 41:
		case 81: 
			dvcType = /*_deviceBmpType::*/CR_BMP;
			break;
		case 50:
		case 64:
		case 66:
			dvcType = /*_deviceBmpType::*/FL_BMP;
			break;
		case 31:
			dvcType = /*_deviceBmpType::*/DOOR_BMP;
			break;
	}

	int status = GetDeviceStatus(sts);

	return (status*MAX_BMP_TYPE + dvcType);
}

int	CRtuFullDeviceStatusPage2::GetDeviceStatus(_fullDvcStatusData& sts)
{
	#define TAMPER_BIT				0x0c
	#define ISOLATE_BIT				0x10
	#define CR1_ISOLATE_BIT			0x20
	#define CR2_ISOLATE_BIT			0x40

	_deviceStatusType status = /*_deviceStatusType::*/STS_NORMAL;

	if (sts.dvcPropertyBytes > 0)
	{
		if ((sts.byte8 & (1|2|0x80)) || (sts.byte9 & 0x3))
			status = /*_deviceStatusType::*/STS_ALARM;

		for (BYTE ind = 0; ind < sts.expansionCardCount && ind < MAX_EXPANSION_STS; ind++)
		{
			if (sts.expansion[ind].size > 0 && (sts.expansion[ind].properties & 0x3))
			{
				status = STS_ALARM;
				break;	// one is enough to mark the device is in "Alarm"
			}
		}
			
		if (sts.byte8 & TAMPER_BIT) // offline / tamper
			status = /*_deviceStatusType::*/STS_TAMPERED; //Red

		if ((sts.byte8 & ISOLATE_BIT) ||
			(sts.cr1Num != 255 && (sts.byte8 & CR1_ISOLATE_BIT)) ||
			(sts.cr2Num != 255 && (sts.byte8 & CR2_ISOLATE_BIT)))
		{
			status = /*_deviceStatusType::*/STS_ISOLATE;
		}
	}

	//GmsOutputDebugString(__FUNCTIONW__, __LINE__, L"dev-%d: propertyBytes=%d, byte8=%#c, byte9=%#c => status=%d", sts.dvcNum, sts.dvcPropertyBytes, sts.byte8, sts.byte9, status);
	return status;
}

void CRtuFullDeviceStatusPage2::Print()
{
}

CString CRtuFullDeviceStatusPage2::GetPacomDeviceName(int deviceId)
{
	if (m_PacomDevNames.GetSize() == 0)
	{
		RtuLib::GetFileStrings(DEVICE_TYPE_MSG_FILE, m_PacomDevNames, 1);
	}

	if (deviceId >= 0 && deviceId < m_PacomDevNames.GetSize())
		return m_PacomDevNames.GetAt(deviceId);
	return _T("");
}

#pragma endregion CRtuFullDeviceStatusPage2

#pragma endregion 