#pragma once


class CMarkupStatic : public CStatic, public CXTPMarkupContext
{
public:
	CMarkupStatic();
	virtual ~CMarkupStatic();
	
	void SetMarkupText(LPCSTR lpszMarkup);
	void SetMarkupText(LPCWSTR lpszMarkup);
	void SetMarkupText(LPCWSTR lpszMarkup, CString content);
	CString GetContent() { return m_strContent; }

protected:
	DECLARE_MESSAGE_MAP()
	//{{AFX_VIRTUAL(CMarkupStatic)
	BOOL OnWndMsg(UINT message, WPARAM wParam, LPARAM lParam, LRESULT* pResult);
	//}}AFX_VIRTUAL

	//{{AFX_MSG(CMarkupStatic)
	afx_msg void OnPaint();
	//}}AFX_MSG

	CXTPMarkupUIElement* m_pUIElement;
	CString m_strContent;
};

class CMarkupLabel : public CMarkupStatic
{
public:
	CMarkupLabel();
	virtual ~CMarkupLabel(){}
	void SetText(CString strText, CString strTextColor=_T(""));
	void SetBorderColor(CString strColor);
	void SetBackgroundColor(CString strColor);
	void SetTextColor(CString strColor);
	void Setup(int borderThickness, CString strBorderColor, CString strBackgroundColor, CString strFontWeight, BOOL bItalic=FALSE);
	void Setup(int borderThickness, CString strFontWeight, BOOL bItalic=FALSE);
	void SetItalic(BOOL bItalic);
	void Render();
	void SetBorderThickness(int borderThickness);
private:
	CString m_strText;
	CString m_strTextAlignment;
	CString m_strBorderColor;
	CString m_strBackgroundColor;
	CString m_strTextColor;
	CString m_strFontWeight;
	BOOL	m_bItalic;

	int m_borderThickness;

	void UpdateControl();
	CString GetTextBlock();
};

class CMarkupBox : public CMarkupStatic
{
public:
	CMarkupBox();
	virtual ~CMarkupBox(){}
	void SetText(CString strText, BOOL bRule=TRUE);
	void SetText(CString strText, CString strTextColor);
	void SetBorderColor(CString strColor);
	void SetBackgroundColor(CString strColor);
	void SetTextColor(CString strColor);
	void SetBorder(int left, int top, int right, int bottom);
	void Setup(int left, int top, int right, int bottom, BOOL bRule, CString strBorderColor, CString strBackgroundColor, CString strFontWeight);
	void Setup(int borderThickness, BOOL bRule, CString strFontWeight);
private:
	CString m_strText;
	CString m_strBorderColor;
	CString m_strBackgroundColor;
	CString m_strTextColor;
	CString m_strFontWeight;
	BOOL	m_bRule;
	int m_leftBorder;
	int m_rightBorder;
	int m_topBorder;
	int m_bottomBorder;

	void UpdateControl();
};

