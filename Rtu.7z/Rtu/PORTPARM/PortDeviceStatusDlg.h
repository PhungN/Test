#pragma once


#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PortDeviceStatusDlg.h : header file
//

#include "GMS\CommonUse\GenericHardwareConfigDataEnvelope.h"
#include "RtuRes\Resource.h"

static const int C_COLUMNS  = 6;

typedef struct myitem_tag { 
   LPSTR aCols[C_COLUMNS]; 
} MYITEM; 


/////////////////////////////////////////////////////////////////////////////
// PortDeviceStatusDlg dialog

class PortDeviceStatusDlg : public CDialog
{

protected:
	CImageList m_cImageList;

// Construction
public:
	
	PortDeviceStatusDlg(CWnd* pParent = NULL, LPPARMPROC lpps = NULL, BYTE ByteCount = NULL,UINT uiPort = 1);   // standard constructor


// Dialog Data
	//{{AFX_DATA(PortDeviceStatusDlg)
	enum { IDD = IDD_1057_PORTDEVICESTATUS };
	CListCtrl	m_cList;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(PortDeviceStatusDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(PortDeviceStatusDlg)
	afx_msg void OnPortdeviceOkbutton();
	afx_msg void OnPortdeviceMoreinfoButton();
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

