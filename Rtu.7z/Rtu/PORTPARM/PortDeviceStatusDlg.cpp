// PortDeviceStatusDlg.cpp : implementation file
//

#include "stdafx.h"

#include "PortDeviceStatusDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


extern BOOL g_ModalFlg;

/////////////////////////////////////////////////////////////////////////////
// PortDeviceStatusDlg dialog


PortDeviceStatusDlg::PortDeviceStatusDlg(CWnd* pParent, LPPARMPROC /* lpps */, BYTE /* ByteCount */, UINT /* port */)
	: CDialog(PortDeviceStatusDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(PortDeviceStatusDlg)
	//}}AFX_DATA_INIT
}

void PortDeviceStatusDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(PortDeviceStatusDlg)
	DDX_Control(pDX, IDC_PORTDEVICE_LIST, m_cList);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(PortDeviceStatusDlg, CDialog)
	//{{AFX_MSG_MAP(PortDeviceStatusDlg)
	ON_BN_CLICKED(IDC_PORTDEVICE_OKBUTTON, OnPortdeviceOkbutton)
	ON_BN_CLICKED(IDC_PORTDEVICE_MOREINFO_BUTTON, OnPortdeviceMoreinfoButton)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

////////////////////////////////////////////////////////////////////////////
// show dialog definition

void WINAPI ShowPortDeviceStatusDlg(CWnd *pWnd, LPPARMPROC lpps, BYTE ByteCount, UINT port) {

	PortDeviceStatusDlg pdStatusdlg(pWnd , lpps, ByteCount, port);

	g_ModalFlg = TRUE;
	pdStatusdlg.DoModal();
	g_ModalFlg = FALSE;
}

/////////////////////////////////////////////////////////////////////////////
// PortDeviceStatusDlg message handlers

void PortDeviceStatusDlg::OnPortdeviceOkbutton() 
{
	// TODO: Add your control notification handler code here
	
	// quit from dialog
	OnOK();
}

void PortDeviceStatusDlg::OnPortdeviceMoreinfoButton() 
{
	// TODO: Add your control notification handler code here
	
	// test code
	AfxMessageBox( _T(" More Information needed ") );
}

BOOL PortDeviceStatusDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here

	// initialise the list control

	// intialise the bitmap for the icons
	m_cImageList.Create( IDB_BITMAP1, 16, 10 , 0);

	// initialise the columns
	m_cList.InsertColumn(0, _T("Device List"), LVCFMT_LEFT, 250 );
	m_cList.InsertColumn(1, _T("Status"), LVCFMT_LEFT, 50 );

	//attach an imagelist to the lists
	m_cList.SetImageList( &m_cImageList, LVSIL_SMALL);
	LPCTSTR pszListItems[] = {	_T("Door Controller"),
							_T("Elevator Controller"),
							_T("Boom Controller"),
							_T("Fire Panel"),
							_T("Air Conditioner Unit"),
							NULL };
	int nListTypes[] = {0, 1, 2, 3, 4};

	// insert all the labels, icons and items

	for (int i=0; pszListItems[i] != NULL; i++)
	{
		m_cList.InsertItem(i, pszListItems[i], nListTypes[i] );
	}

	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
