/********************************************************************************************************
 *		PACOM SYSTEMS PTY LTD 	Copyright 2002
 *		File/Class Name:
 *		Description:
 *		
 *		$Revision: 40 $
 *		$History: STRUCTS.H $
 * 
 * *****************  Version 40  *****************
 * User: Michaelz     Date: 15/12/10   Time: 2:30p
 * Updated in $/GMS/Releases/v4.07/Code/WSETUP/Rtu/PORTPARM
 * TT 6946
 * 
 * *****************  Version 39  *****************
 * User: Phungn       Date: 13/08/10   Time: 2:48p
 * Updated in $/GMS/Releases/v4.07/Code/WSETUP/Rtu/PORTPARM
 * TT 6353 & 6343
 * 
 * *****************  Version 38  *****************
 * User: Phungn       Date: 23/07/10   Time: 5:21p
 * Updated in $/GMS/Releases/v4.07/Code/WSETUP/Rtu/PORTPARM
 * TT 6308
 * 
 * *****************  Version 34  *****************
 * User: Phungn       Date: 3/09/09    Time: 6:55p
 * Updated in $/GMS/Development (Mainstream)/Code V4/WSETUP/Rtu/PORTPARM
 * Add support for Aperio operation (TT #5882)
 * 
 * *****************  Version 27  *****************
 * User: Phungn       Date: 30/11/05   Time: 11:23a
 * Updated in $/GMS/Code v3/WSETUP/Rtu/PORTPARM
 * Added new drive type "Instotech Clock Display" for general purpose
 * driver (item #4375)
*******************************************************************************************************/

// Structs.h
//////////////////////////////////////////////////////////////////////////////
// contains all the data structures used by the Property page classes.
//////////////////////////////////////////////////////////////////////////////
// Change History
// 18/10/2000	Added DEVSLV_PARM, DEVSLV_ERR, AVCU_PARM, AVCU_ERR - M.A.Madrio

#pragma once

#include "GMS\CommonUse\TypedefsStdTypes.h"

typedef struct ASNA_PARM		ASNAPARM;
typedef struct ASNA_ERR			ASNAERR;
typedef struct AX25_PARM		AX25PARM;
typedef struct AX25_ERR			AX25ERR;
typedef struct ANIP_PARM		ANIPPARM;
typedef struct ANIP_ERR			ANIPERR;

typedef struct SSNA_ERR			SSNAERR;
typedef struct SSNA_PARM		SSNAPARM;
typedef struct SX25_ERR			SX25ERR;
typedef struct SX25_PARM		SX25PARM;
typedef struct IP_ERR			SIPERR;
typedef struct IP_PARM			SIPPARM;
typedef struct SFEP_ERR			SFEPERR;
typedef struct SFEP_PARM		SFEPPARM;

typedef struct PCP_PARM			PCPPARM;
typedef struct PCP_ERR			PCPERR;  
typedef struct EPCP_PARM		EPCPPARM;
typedef struct EPCP_ERR			EPCPERR; 
typedef struct DEV_PARM			DEVPARM;
typedef struct DEV_ERR			DEVERR;
typedef struct DEV_ERR1			DEVERR1;
typedef struct DEV_ERR2			DEVERR2;
typedef struct DEVSLV_PARM		DEVSLVPARM;
typedef struct DEVSLV_ERR		DEVSLVERR;
typedef struct DEVSLV_ERR1		DEVSLVERR1;
typedef struct DEVSLV_ERR2		DEVSLVERR2;
typedef struct HDLC_PARM		HDLCPARM; 
typedef struct HDLC_ERR			HDLCERR;
typedef struct MAC_PARM			MACPARM;
typedef struct MAC_ERR			MACERR;
typedef struct ADAPT_PARM		ADAPTPARM;
typedef struct ADAPT_ERR		ADAPTERR;
typedef struct ETHDRV_PARM		ETHDRVPARM;
typedef struct ETHDRV_ERR		ETHDRVERR;

typedef	struct ASC_ERR			ASCERR;
typedef	struct IRIS_ERR			IRISERR;
typedef	struct PAGER_ERR		PAGERERR;
typedef	struct GENC_ERR			GENCERR;
typedef	struct MXL_ERR			MXLERR;
typedef struct LDIAL_ERR		LDIALERR;

typedef struct VCS_PARM			VCSPARM;
typedef struct VCS_ERR			VCSERR;

typedef struct AVCS_PARM		AVCSPARM;
typedef struct AVCS_ERR			AVCSERR;

typedef struct AVCU_PARM		AVCUPARM;
typedef struct AVCU_ERR			AVCUERR;

typedef struct IEC_PARM			IECPARM;
//typedef struct IEC_ERR IECERR;

typedef struct BMS_PARM			BMSPARM;
typedef struct BMS_ERR			BMSERR;

typedef struct PORT_DIS_PARM	PORTDISPARM;
typedef struct PTZ_PARM			PTZPARM;
typedef struct PTZ_ERR			PTZERR;

typedef struct INOVONICS_PARM	INOVOCNICSPARM;
typedef struct INOVONICS_ERR	INOVOCNICSERR;

typedef struct SECURITEL_PARM	SECURITELPARM;
typedef struct SECURITEL_ERR	SECURITELERR;

typedef struct GDVR_PARM		GDVRPARM;
typedef struct GDVR_ERR			GDVRERR;

typedef struct MODBUS_PARM		MODBUSPARM;
typedef struct MODBUS_ERR		MODBUSERR;
typedef struct MODBUS_ERR1		MODBUSERR1;
typedef struct MODBUS_ERR2		MODBUSERR2;

typedef struct WYRELESS_PARM	WYRELESSPARM;
typedef struct WYRELESS_ERR		WYRELESSERR;
typedef struct WYRELESS_FERR	WYRELESSFERR;


#define	MAX_NUM_BYTES	10

#pragma pack(1)

//----------------------------------------------------------------
//----------------------------------------------------------------

typedef struct tagPORT_PROTOCOL
{
	BYTE link;
	BYTE session;
	BYTE application;
}PORT_PROTOCOL, *LPPORT_PROTOCOL;

//      Driver structures 

// for Async driver 
typedef struct SER_CFG {
    uchar brate;                    //  Baud rate
    uchar bits;                     //  Number of data bits
    uchar stops;                    //  Number of stop bits
    uchar parity;                   //  Parity code
    uchar rxBuffSize;               //  Receive buffer size (mult of 16)
    uchar maxIdle;                  //  Maximum idle time
    uchar physProt;                 //  physical layer protocol
    } SERCFG;

// for HDLC Sync driver 

 typedef struct SER_CFGH {
    uchar encType;                  //  Encoding type
    uchar hdlcAddr;                 //  HDLC/SDLC address
    uchar rxBuffSize;               //  Receive buffer size (mul of 16)
    uchar brate;                    //  Baud rate ( for provide clocks )
    uchar physProt;                 //  physical layer protocol
    } SERCFGH;


// for ethernet driver 

 typedef struct SER_CFGE {
    uchar flags;                    //  initialise flags
    uchar pers;                     //  persistence variable
    uchar rxBuffSize;               //  Receive buffer size (mul of 16)
    ushort phyAddrH;                //  Ethernet address MS
    ushort phyAddrM;                //  Ethernet address 
    ushort phyAddrL;                //  Ethernet address LS
    } SERCFGE;

//----------------------------------------------------------------
//----------------------------------------------------------------
//          Application level
//----------------------------------------------------------------
//----------------------------------------------------------------

//  APPLIC SNA parameters structure ...

struct ASNA_PARM {
    uchar   contactTme;         //  message response timer
    };

//  SNA error counter structure ...

struct ASNA_ERR {
    ushort msgBuffErr;              //  Message buffer allocation error
    ushort contactFail;             //  initial fail
    ushort contactTout;             //  contact timeout
    ushort rspErr;                  //  response errors
    ushort retryErr;                //  response errors

    ushort invSessRx;               //  invalid session 
    ushort invNetType;              //  invalid type of data
    ushort invDataBcRx;             //  invalid message size
    ushort resDefParm;              //  Reset default parameters
    ushort storeParm;               //  Store new parameters
    };


//  APPLIC X25 parameters structure ...

struct AX25_PARM {
    uchar   contactTme;         //  message response timer
    };


//  X25 error counter structure ...

struct AX25_ERR {
    ushort msgBuffErr;              //  Message buffer allocation error
    ushort contactFail;             //  initial fail
    ushort contactTout;             //  contact timeout
    ushort rspErr;                  //  response errors
    ushort retryErr;                //  response errors

    ushort invSessRx;               //  invalid session 
    ushort invNetType;              //  invalid type of data
    ushort invDataBcRx;             //  invalid message size
    ushort resDefParm;              //  Reset default parameters
    ushort storeParm;               //  Store new parameters
    };


//  Applic Network IP parameters structure ...

struct ANIP_PARM_OLD {
	uchar   contactTme;         //  message response timer Bit 7 - set for enable Base Station keep-alives ( 6 x contact time ). Bit 0..6 is the contact time
};
struct ANIP_PARM {
	uchar   contactTme;         //  message response timer Bit 7 - set for enable Base Station keep-alives ( 6 x contact time ). Bit 0..6 is the contact time
	uchar 	flags;
	uchar	retryTimer;			// time in seconds to wait between retrying connections
	uchar   retrySleepTimer;	// time in multiple of 10 seconds to wait during sleep between retries.
	uchar	retryCount;			// count of retries before going to sleep
	uchar 	spare[8];
	uchar	cs;
    };


//  IP error counter structure ...

struct ANIP_ERR {
    ushort msgBuffErr;              //  Message buffer allocation error
    ushort bindingTout;             //  binding timeout
    ushort contactFail;             //  initial fail
    ushort contactTout;             //  contact timeout
    ushort rspErr;                  //  response errors
    ushort retryErr;                //  response errors

    ushort invSessRx;               //  invalid session 
    ushort invNetType;              //  Message buffer allocation error
    ushort invDataBcRx;             //  invalid message size
    ushort resDefParm;              //  Reset default parameters
    ushort storeParm;               //  Store new parameters

	ushort    invContReqRx;		  // invalid contact request received
	ushort	  invContResRx;		  // invalid contact response received
    };

//  SDLC POLL parameters structure ...

struct ANSP_PARM {
    uchar   contactTme;         //  message response timer
    };


//  SDLC POLL error counter structure ...

struct ANSP_ERR {
    ushort msgBuffErr;              //  Message buffer allocation error
    ushort bindingTout;             //  binding timeout
    ushort contactFail;             //  initial fail
    ushort contactTout;             //  contact timeout
    ushort rspErr;                  //  response errors
    ushort retryErr;                //  response errors

	ushort invContactRqs;			//  invalid request
	ushort invContactRsp;			//  invalid response
    ushort invSessRx;               //  invalid session 
    ushort invNetType;              //  Message buffer allocation error
    ushort invDataBcRx;             //  invalid message size
    ushort resDefParm;              //  Reset default parameters
    ushort storeParm;               //  Store new parameters
    };



//  Dialup error counter structure ... (no params struct)

struct ADIAL_ERR {
	ushort memFail;
    ushort dialFail;             //  Dial out connection failed
    ushort dialConnect;          //  Dialup connection made

    ushort dialMsgSent;          //  Number of Dailup messages sent 
    ushort dialMsgResent;        //  Number of Dailup messages resent 
    ushort dialAck;              //  Dialup messages acked
    ushort dialNakCnt;           //  Messages NAK by dial card

    ushort dialHiAck;            //  Dialup messages high level acked
    ushort dialNotAck;           //  Dialup messages neg acked
    ushort dialRspTimeOut;       //  Timeout on dailup message hi acks
    
    ushort msgRx;                //  Messages received
    ushort resDefParm;           //  Reset default parameters
    ushort storeParm;            //  Store new parameters
    
    ushort stxErr;               //  STX not the first byte
    ushort invalCtrlCode;        //  Invalid control code
    ushort invalDialbackType;    //  Invalid dialback command type
    ushort failWrDisk;           //  Failed to write to disk
    ushort invalMsgType;         //  Invaild message type received
    ushort macErr;               //  CRC errors during dialout
    ushort csErr;                //  Checksum errors during dialout
    ushort inCompleteMsg;        //  Incomplete message
    
    //  Dialout errors

    ushort outBcCsTimeout;       //  BC to CS timeout
    ushort outPollTimeout;       //  Timed out waiting for poll
    ushort lostCarrier;          //  Lost carrier without a command

    //  Dialin errors

    ushort ansConnect;           //  Incoming connection made
    ushort ansFail;              //  Failed to answer a call
    ushort inBcCsTimeout;        //  BC to CS timeout
    ushort inPollTimeout;        //  Timed out waiting for poll

    //  Dial test errors

    ushort dialTestFail;         //  Dial test fail
    ushort dialTestPass;         //  Dial test passed
    ushort dialTestConnect;      //  Dial test connect
    ushort lostTestCarrier;      //  Dial test lost carrier
    ushort testOutPollTimeout;   //  Timed out waiting for test poll
    };

struct ADIAL_ERR1 {
	ushort memFail;
    ushort dialFail;             //  Dial out connection failed
    ushort dialConnect;          //  Dialup connection made
    ushort dialMsgSent;          //  Number of Dailup messages sent 
    ushort dialMsgResent;        //  Number of Dailup messages resent 
    ushort dialAck;              //  Dialup messages acked
    ushort dialNakCnt;           //  Messages NAK by dial card
    ushort dialHiAck;            //  Dialup messages high level acked
    ushort dialNotAck;           //  Dialup messages neg acked
    ushort dialRspTimeOut;       //  Timeout on dailup message hi acks
    ushort msgRx;                //  Messages received
    ushort resDefParm;           //  Reset default parameters
    ushort storeParm;            //  Store new parameters
    ushort stxErr;               //  STX not the first byte
    ushort invalCtrlCode;        //  Invalid control code
    ushort invalDialbackType;    //  Invalid dialback command type
    ushort failWrDisk;           //  Failed to write to disk
    };

struct ADIAL_ERR2 {
    ushort invalMsgType;         //  Invaild message type received
    ushort macErr;               //  CRC errors during dialout
    ushort csErr;                //  Checksum errors during dialout
    ushort inCompleteMsg;        //  Incomplete message
    ushort outBcCsTimeout;       //  BC to CS timeout
    ushort outPollTimeout;       //  Timed out waiting for poll
    ushort lostCarrier;          //  Lost carrier without a command
    ushort ansConnect;           //  Incoming connection made
    ushort ansFail;              //  Failed to answer a call
    ushort inBcCsTimeout;        //  BC to CS timeout
    ushort inPollTimeout;        //  Timed out waiting for poll
    ushort dialTestFail;         //  Dial test fail
    ushort dialTestPass;         //  Dial test passed
    ushort dialTestConnect;      //  Dial test connect
    ushort lostTestCarrier;      //  Dial test lost carrier
    ushort testOutPollTimeout;   //  Timed out waiting for test poll
    };

typedef	struct ADIAL_ERR1 ADIALERR1;
typedef struct ADIAL_ERR2 ADIALERR2;


//----------------------------------------------------------------
//----------------------------------------------------------------
//          Session level
//----------------------------------------------------------------
//----------------------------------------------------------------


//  SNA parameter structure ...

struct SSNA_PARM {
    uchar rspTime;              //  Timer to use for respnse to messages
    uchar maxRetx;              //  number of retxs
    uchar ourLuName[8];
    uchar cpName[8];
    uchar netId[8];
    uchar flags;
    uchar pacWin;
    uchar bindRspTime;
    };

//  SNA packet error counter structure ...

struct SSNA_ERR {
    ushort   memErr;             //  Fep memory error
    ushort   minDataErr;         //  Fep minimum rx error
    ushort   maxDataErr;         //  Fep maximum rx error
    ushort   fidErr;             //  Fep FID error
    ushort   sessIndexErr;       //  Session index error
    ushort   puMsgToutErr;       //  Timeout error
    ushort   dluMsgToutErr;      //  Timeout error
    ushort   iluMsgToutErr;      //  Timeout error
	ushort	 iluBindToutErr;	 //  Timeout error
    ushort   dataRxErr;          //  Neg rsp rx error
    ushort   dactLuRxErr;        //  Dactlu rx error in active state
    ushort   unbindRxErr;        //  Unbind rx error in active state
	//	New Errors
	ushort   pacingErr;				//	Pacing error ocurred. Window full
	ushort   invalidScRxErr;		//	Invalid Session Control RU Received
	ushort   invalidUnbindRxErr;	//	Unbind received with no session active
	ushort   invalidBindRxErr;		//	Invalid LU6.2 Bind received
	ushort   invalidBindPluSizeErr;	//	Invalid PLU name format
	ushort   invalidBindUserRxErr;	//	Invalid user data format
	ushort   invalidBindSluSizeErr;	//	Invalid SLU name format
	ushort   invalidBindPluRxErr;	//	Invalid PLU name
	ushort   invalidBindSluRxErr;	//	Invalid SLU name
	ushort   invalidBindUserLthRxErr;	//	Invalid user data types
	ushort   invalidBindUserCallRxErr;
	ushort   invalidBindUserRtuRxErr;
	ushort   invalidBindUserCodeRxErr;
	ushort   bindNrspRxErr;			//	Negative bind response received
	ushort   bindPrspRxErr;			//	Invalid format positive response
	ushort   bindNRspSluSizeRxErr;	//	SLU name wrong in bind request
	ushort   bindNRspPluRxErr;		//	PLU name wrong in bind request
	ushort   bindNRspSluRxErr;		//	SLU name wrong in bind request
	ushort   bindNRspUserLthRxErr;	//	Bind request user data error types
	ushort   bindNRspUserCallRxErr;
	ushort   bindNRspUserRtuRxErr;
	ushort   bindNRspUserCodeRxErr;
	ushort   bindNRspUserRxErr;
    };

struct SSNA_ERR1 {
    ushort   memErr;             //  Fep memory error
    ushort   minDataErr;         //  Fep minimum rx error
    ushort   maxDataErr;         //  Fep maximum rx error
    ushort   fidErr;             //  Fep FID error
    ushort   sessIndexErr;       //  Session index error
    ushort   puMsgToutErr;       //  Timeout error
    ushort   dluMsgToutErr;      //  Timeout error
    ushort   iluMsgToutErr;      //  Timeout error
	ushort	 iluBindToutErr;	 //  Timeout error
    ushort   dataRxErr;          //  Neg rsp rx error
    ushort   dactLuRxErr;        //  Dactlu rx error in active state
    ushort   unbindRxErr;        //  Unbind rx error in active state
	ushort   pacingErr;				//	Pacing error ocurred. Window full
	ushort   invalidScRxErr;		//	Invalid Session Control RU Received
	ushort   invalidUnbindRxErr;	//	Unbind received with no session active
	ushort   invalidBindRxErr;		//	Invalid LU6.2 Bind received
};

struct SSNA_ERR2 {
	ushort   invalidBindPluSizeErr;	//	Invalid PLU name format
	ushort   invalidBindUserRxErr;	//	Invalid user data format
	ushort   invalidBindSluSizeErr;	//	Invalid SLU name format
	ushort   invalidBindPluRxErr;	//	Invalid PLU name
	ushort   invalidBindSluRxErr;	//	Invalid SLU name
	ushort   invalidBindUserLthRxErr;	//	Invalid user data types
	ushort   invalidBindUserCallRxErr;
	ushort   invalidBindUserRtuRxErr;
	ushort   invalidBindUserCodeRxErr;
	ushort   bindNrspRxErr;			//	Negative bind response received
	ushort   bindPrspRxErr;			//	Invalid format positive response
	ushort   bindNRspSluSizeRxErr;	//	SLU name wrong in bind request
	ushort   bindNRspPluRxErr;		//	PLU name wrong in bind request
	ushort   bindNRspSluRxErr;		//	SLU name wrong in bind request
	ushort   bindNRspUserLthRxErr;	//	Bind request user data error types
	ushort   bindNRspUserCallRxErr;
};

struct SSNA_ERR3 {
	ushort   bindNRspUserRtuRxErr;
	ushort   bindNRspUserCodeRxErr;
	ushort   bindNRspUserRxErr;
};

typedef	struct SSNA_ERR1 SSNAERR1;
typedef struct SSNA_ERR2 SSNAERR2;
typedef	struct SSNA_ERR3 SSNAERR3;


//  X25 parameter structure ...

struct SX25_PARM {
    ushort npvcValue;
    ushort nicValue;
    ushort ltcValue;
    ushort ntcValue;
    ushort logValue;
    ushort nogValue;
    ushort n1Value;
    uchar pktWindowSize;
    uchar T20Timer;
    uchar T21Timer;
    uchar T22Timer;
    uchar T23Timer;
    uchar dataTimer;
    uchar intrTimer;
    uchar ourAddr[8];
    };


//  X25 packet error counter structure ...

struct SX25_ERR {
    ushort memErr;               //  Memory allocate error
    ushort pktRestartErr;        //  Data reieved - no RESTART yet 
    ushort diagErr;              //  Diagnostic packet reieved
    ushort resetRxErr;
    ushort seqErr;
    ushort linkTxSeqErr;
    ushort linkMsgSizeErr;
    ushort minDataErr;           //  Minimum rx error 
    ushort maxDataErr;           //  Maximum rx error
    ushort gfiErr;               //  GFI error 
    ushort sessIndexErr;         //  Indexing error 
    ushort allocateErr;          //  Session allocate error 
    ushort callInfoErr;          //  Session allocate error 
    ushort cmdOffErr;            //  Command off error 
    ushort t20Err;               //  Timer error 
    ushort t21Err;               //  Timer error 
    ushort t22Err;               //  Timer error 
    ushort t23Err;               //  Timer error 
    ushort dataTmErr;            //  Timer error 
    ushort intrTmErr;            //  Timer error 
    ushort pvcTmErr;             //  Timer error 
    ushort invDataRxErr;         //  Data receive error 
    ushort invRspRxErr;          //  Response receive error 
    };

struct SX25_ERR1 {
    ushort memErr;               //  Memory allocate error
    ushort pktRestartErr;        //  Data reieved - no RESTART yet 
    ushort diagErr;              //  Diagnostic packet reieved
    ushort resetRxErr;
    ushort seqErr;
    ushort linkTxSeqErr;
    ushort linkMsgSizeErr;
    ushort minDataErr;           //  Minimum rx error 
    ushort maxDataErr;           //  Maximum rx error
    ushort gfiErr;               //  GFI error 
    ushort sessIndexErr;         //  Indexing error 
    ushort allocateErr;          //  Session allocate error 
    ushort callInfoErr;          //  Session allocate error 
    ushort cmdOffErr;            //  Command off error 
    ushort t20Err;               //  Timer error 
    ushort t21Err;               //  Timer error 
    };

struct SX25_ERR2 {
    ushort t22Err;               //  Timer error 
    ushort t23Err;               //  Timer error 
    ushort dataTmErr;            //  Timer error 
    ushort intrTmErr;            //  Timer error 
    ushort pvcTmErr;             //  Timer error 
    ushort invDataRxErr;         //  Data receive error 
    ushort invRspRxErr;          //  Response receive error 
    };

typedef	struct SX25_ERR1 SX25ERR1;
typedef struct SX25_ERR2 SX25ERR2;


//  IP parameter structure ...

struct IP_PARM {
    ushort  uport;              //  Udp port to send data to 
    uchar   ttl;                //  time to live 
    uchar   myIpAddr[4];        //  storage for my ip address 
    uchar   myIpMask[4];        //  storage for my ip mask 
    uchar   rIpAddr1[4];        //  storage for router ip address 
    uchar   rIpAddr2[4];        //  storage for router ip address 

    uchar   msgRspTme;          // current time for waiting response 
    uchar   msgRetry;           // current time for waiting response

    uchar   pingTme;            // time for pinging 
    uchar   pingRspTme;         // time for ping rsp 
    uchar   pingRetry;          // retry cnt for pinging 

    uchar   rpingTme;           // time for router ping 
    uchar   rpingRspTme;        // time for router response 
    uchar   rpingRetry;         // retry cnt for router ping 	
    };

// IP_PARM::rpingRetry.
#define IP_DISABLE_SNMP		0x10		// Bit4 (10000)
#define IP_ENABLE_DHCP		0x20		// Bit5 
#define IP_ENABLE_WEB		0x40		// Bit6


struct TCP_PARM {
	uchar numTCPRetrans;		// Number of attempted TCP retransmissions
	uchar numConnAttp;
	ushort emptyACKTime;
	uchar defRetxPeriod;
	uchar initRetxPeriod;
	uchar synPktRetxPeriod;
	uchar TCPServiceType;
	ushort defIdleTime;
	uchar spare[6];
};
//  IP packet error counter structure ...

struct IP_ERR {
    ushort    memErr;             // memory allocate error

    ushort    ipSend;             // total number sent 
    ushort    ipRecv;             // total number received 
    ushort    ipCheck;            // ip checksum error 
    ushort    ipAddr;             // incorrect address received 
    ushort    ipLength;           // incorrect header length received 
    ushort    ipProt;             // incorrect ptotocol type received 
    ushort    ipFrag;             // ip message rx with fragmentation 

    ushort    icmpSend;           // icmp sends 
    ushort    icmpRecv;           // icmp receives 
    ushort    icmpCheck;          // icmp checksum error 
    ushort    icmpType;           // icmp type error 
    ushort    icmpEchoReqRecv;    // icmp echo req reveive 
    ushort    icmpEchoRepRecv;    // icmp echo reply receive 
    ushort    icmpEchoReqSend;    // icmp echo req send 
    ushort    icmpEchoRepSend;    // icmp echo rep send 
    ushort    icmpRedirRecv;      // icmp redirect receive 
    ushort    icmpTimeSRecv;      // icmp timestamp request receive 
    ushort    icmpTimeRRecv;      // icmp timestamp response receive 
    ushort    icmpTimeRepSend;    // icmp timestamp reply send 
    ushort    icmpAdrmRqRecv;     // icmp address mask request reveive 
    ushort    icmpAdrmRsRecv;     // icmp address mask response receive 
    ushort    icmpDestUnRecv;     // icmp destination unreach 
    ushort    icmpSrsQRecv;       // icmp src quench 
    ushort    icmpTimeXRecv;      // icmp time exceeds 
    ushort    icmpParmPRecv;      // icmp parameter probe 

    ushort    udpSend;            // total UDP datagrams sent 
    ushort    udpRecv;            // total udp datagrams received 
    ushort    udpPort;            // incorrect port type received 
    ushort    udpCheck;           // incorrect checksum received 
    ushort    udpMsgSize;         // invalid message size to send

    ushort    snmpSend;           // total snmp send messages 
    ushort    snmpRecv;           // total snmp receive messages 
    ushort    snmpLength;         // total snmp length error 
    ushort    snmpBadVer;         // total snmp bad vers 
    ushort    snmpComm;           // total snmp bad community 
    ushort    snmpGenErr;         // total snmp general errs 
    ushort    snmpROErr;          // total snmp read only 
    ushort    snmpInSet;          // total snmp in set messages 
    ushort    snmpInGet;          // total snmp in get messages 
    ushort    snmpMsgSize;        // invalid message size to send
    };


struct IP_ERR1 {
    ushort    memErr;             // memory allocate error

    ushort    ipSend;             // total number sent 
    ushort    ipRecv;             // total number received 
    ushort    ipCheck;            // ip checksum error 
    ushort    ipAddr;             // incorrect address received 
    ushort    ipLength;           // incorrect header length received 
    ushort    ipProt;             // incorrect ptotocol type received 
    ushort    ipFrag;             // ip message rx with fragmentation 

    ushort    icmpSend;           // icmp sends 
    ushort    icmpRecv;           // icmp receives 
    ushort    icmpCheck;          // icmp checksum error 
    ushort    icmpType;           // icmp type error 
    ushort    icmpEchoReqRecv;    // icmp echo req reveive 
    ushort    icmpEchoRepRecv;    // icmp echo reply receive 
    ushort    icmpEchoReqSend;    // icmp echo req send 
    ushort    icmpEchoRepSend;    // icmp echo rep send    
    };

struct IP_ERR2 {
    ushort    icmpRedirRecv;      // icmp redirect receive 
    ushort    icmpTimeSRecv;      // icmp timestamp request receive 
    ushort    icmpTimeRRecv;      // icmp timestamp response receive 
    ushort    icmpTimeRepSend;    // icmp timestamp reply send 
    ushort    icmpAdrmRqRecv;     // icmp address mask request reveive 
    ushort    icmpAdrmRsRecv;     // icmp address mask response receive 
    ushort    icmpDestUnRecv;     // icmp destination unreach 
    ushort    icmpSrsQRecv;       // icmp src quench 
    ushort    icmpTimeXRecv;      // icmp time exceeds 
    ushort    icmpParmPRecv;      // icmp parameter probe 

    ushort    udpSend;            // total UDP datagrams sent 
    ushort    udpRecv;            // total udp datagrams received 
    ushort    udpPort;            // incorrect port type received 
    ushort    udpCheck;           // incorrect checksum received 
    ushort    udpMsgSize;         // invalid message size to send

    ushort    snmpSend;           // total snmp send messages    
    };

struct IP_ERR3 {
    ushort    snmpRecv;           // total snmp receive messages 
    ushort    snmpLength;         // total snmp length error 
    ushort    snmpBadVer;         // total snmp bad vers 
    ushort    snmpComm;           // total snmp bad community 
    ushort    snmpGenErr;         // total snmp general errs 
    ushort    snmpROErr;          // total snmp read only 
    ushort    snmpInSet;          // total snmp in set messages 
    ushort    snmpInGet;          // total snmp in get messages 
    ushort    snmpMsgSize;        // invalid message size to send
    };

typedef	struct IP_ERR1 IPERR1;
typedef struct IP_ERR2 IPERR2;
typedef struct IP_ERR3 IPERR3;


//  FEP parameter structure ...

struct SFEP_PARM {
    uchar rspTime;              //  Timer to use for respnse to messages
    uchar maxRetx;              //  number of retxs
    uchar ourLuName[8];
    uchar cpName[8];
    uchar netId[8];
    uchar flags;
    uchar pacWin;
    uchar bindRspTime;
    };

//  FEP packet error counter structure ...

struct SFEP_ERR {
    ushort   memErr;             //  Fep memory error
    ushort   minDataErr;         //  Fep minimum rx error
    ushort   maxDataErr;         //  Fep maximum rx error
    ushort   fidErr;             //  Fep FID error
    ushort   sessIndexErr;       //  Session index error
    ushort   puMsgToutErr;       //  Timeout error
    ushort   dluMsgToutErr;      //  Timeout error
    ushort   iluMsgToutErr;      //  Timeout error
    ushort   dataRxErr;          //  Neg rsp rx error
    ushort   dactLuRxErr;        //  Dactlu rx error in active state
    ushort   unbindRxErr;        //  Unbind rx error in active state
    };



//----------------------------------------------------------------
//----------------------------------------------------------------
//          Link level
//----------------------------------------------------------------
//----------------------------------------------------------------

//  PCP parameters structure ...

struct PCP_PARM {
    uchar   pollT1;             //  Poll delay when off line
    uchar   pollT2;             //  Poll delay during transitions
    uchar   pollT3;             //  Poll delay when on line
    uchar   msgTime;            //  Message response timeout time
    uchar   rxTime;             //  Receive character timeout time (not used)
    uchar   offRsp;             //  Number of no responses till off line
    uchar   invRsp;             //  Number of inv responses till off line
    uchar   maxNak;             //  Maximum NAKs before delete message
    uchar   maxRetx;            //  Maximum retx before delete message
    uchar   echoTime;           //  Echo Timer
    uchar   offPollCnt;         //  Number of off line polls to use
    uchar   sccResTime;         //  SCC off line reset time (in mins)
    SERCFG  cfg;                //  Port configuration
    };


//  PCP error counter structure ...

struct PCP_ERR {
    ushort   memErr;             //  Memory error
    ushort   syncErr;            //  Invalid control character
    ushort   msgCntErr;
    ushort   bcErr;              //  Byte count errors
    ushort   ctrlOvrn;           //  Control character overrun
    ushort   pollRspOverRunErr;  //  Buffer overrun errors
    ushort   dataOvrn;           //  Data message overrun
    ushort   msgNoRsp;           //  No responses to messages
    ushort   notSendMsgDel;      //  Messages deleted as not sending
    ushort   nakRx;              //  Number of NAKs received
    ushort   nakMsgDel;          //  Messages deleted due to too many NAKs
    ushort   xoffRx;             //  Number of XOFFs received
    ushort   xoffUs;             //  Number of times we went XOFF
    ushort   xoffErr;            //  Received data while XOFF
    ushort   csumErr;            //  Received message checksum errors
    ushort   portOff;            //  Number of times port off line
    ushort   invCharErr;
    ushort   resSeqErr;
    ushort   rxSeqErr;
    ushort   seqFail;

    ushort   dvrMemErr;          //  Memory error
    ushort   overRunErr;         //  Received character overrun errors
    ushort   frameErr;           //  Received character framing errors
    ushort   parityErr;          //  Received character parity errors
    ushort   buffOverRunErr;     //  Received buffer overrun errors
    ushort   ctsLost;
    ushort   dcdLost;
    ushort   txSccEvErr;         //  Transmitter event errors
    ushort   rxSccEvErr;         //  Receiver event errors
    };


//  EPCP parameters structure ...

struct EPCP_PARM {
    uchar   offlinePollTime;		//  Poll delay when off line (100 ms)
    uchar   transitionPollTime;     //  Poll delay during transitions (100 ms)
    uchar   onlinePollTime;         //  Poll delay when on line (100 ms)
    uchar   msgRspTime;				//  Message response timeout time (100 ms)
    uchar   msgDelimTime;           //  Time delay to delimit messages (100 ms)
    uchar   maxNoRsp;				//  Number of no responses till off line
    uchar   maxInvRsp;				//  Number of inv responses till off line
    uchar   maxNak;					//  Not used
    uchar   maxRetx;				//  Not used
    uchar   echoTime;				//  Echo Timer
    uchar   offlinePollCnt;         //  Number of off line polls to use
    uchar   sccResTime;				//  SCC off line reset time (in mins)
    SERCFG  cfg;					//  Port configuration
    };

//  PCP error counter structure ...

struct EPCP_ERR {
    ushort   memErr;             //  Memory error
    ushort   syncErr;            //  Invalid control character
    ushort   msgCntErr;
    ushort   bcErr;              //  Byte count errors
    ushort   ctrlOvrn;           //  Control character overrun
    ushort   pollRspOverRunErr;  //  Buffer overrun errors
    ushort   dataOvrn;           //  Data message overrun
    ushort   msgNoRsp;           //  No responses to messages
    ushort   notSendMsgDel;      //  Messages deleted as not sending
    ushort   nakRx;              //  Number of NAKs received
    ushort   nakMsgDel;          //  Messages deleted due to too many NAKs
    ushort   xoffRx;             //  Number of XOFFs received
    ushort   xoffUs;             //  Number of times we went XOFF
    ushort   xoffErr;            //  Received data while XOFF
    ushort   csumErr;            //  Received message checksum errors
    ushort   portOff;            //  Number of times port off line
    ushort   invCharErr;		 //  Not used
    ushort   resSeqErr;
    ushort   rxSeqErr;
    ushort   seqFail;			 //  Not used

    ushort   dvrMemErr;          //  Not used
    ushort   overRunErr;         //  Received character overrun errors
    ushort   frameErr;           //  Received character framing errors
    ushort   parityErr;          //  Received character parity errors
    ushort   buffOverRunErr;     //  Received buffer overrun errors
    ushort   ctsLost;
    ushort   dcdLost;
    ushort   txSccEvErr;         //  Transmitter event errors
    ushort   rxSccEvErr;         //  Receiver event errors
    };

//  GPD parameters structure ...

struct GPD_PARM {
    uchar   pollTime;           //  Time between idle polls ( x100msec )
    uchar   type;               //  Driver type 
    uchar   flags;              //  Flags for connection
    uchar   sccResTime;         //  SCC off line reset time (mins)
    SERCFG  cfg;                //  Port configuration
    };


// type parameter = 0 for no driver specified
//			  1 for europlex panel driver

// flags parameter = unused at present

//  GPD error counter structure ...

struct GPD_ERR {
    ushort  frameErr;           //  Received character framing errors
    ushort  overRunErr;         //  Received character overrun errors
    ushort  parityErr;          //  Received character parity errors
    ushort  dataOvrn;           //  Data message overrun errors
    ushort  crcErr;             //  CRC errors
    ushort  txSccEvErr;         //  Transmitter event errors
    ushort  rxSccEvErr;         //  Receiver event errors
    };



//  DEV parameters structure ...

struct DEV_PARM {
    uchar   devRange;           //  Start device address range
    uchar   pollTimer;          //  Poll delay for poll all devices
    uchar   pollWait;           //  Poll cycles before offline
    uchar   rspTime;            //  time in 10msec to wait for rsp
    uchar   offRsp;             //  Number of no responses till off line
    uchar   txDelay;            //  time in 10msec to wait for tx out of cont
    uchar   txcDelay;           //  time in 10msec to wait for tx in cont
    uchar   sccResTime;         //  SCC off line reset time (in mins)
    SERCFG  cfg;                //  Port configuration
    };


//  Device error counter structure ...

struct DEV_ERR {
    ushort   memErr;             //  Memory allocate errors
    ushort   rxAddrErr;          //  Received address errors
    ushort   rxBcErr;            //  Received byte count errors
    ushort   devRxFCErr;         //  Received FC errors
    ushort   rxCsErr;            //  Received checksum errors
    ushort   stateErr;           //  state machine state error
    ushort   devRxBufErr;        //  Received Buffer errors
    ushort   devTxBufErr;        //  Transmit Buffer errors
    ushort   txDiskErr;          //  Error checking space on disk
    ushort   rdDiskErr;          //  Error reading message from disk
    ushort   txMsgErr;           //  Error writing message to disk
    ushort   txMsgOk;            //  OK writing message to disk
    ushort   rdMsgOk;            //  OK reading message from disk
    ushort   msgTxLineErr;       //  message sent on comms line

    ushort   memDvrErr;          //  Memory driver allocate errors
    ushort   overRunErr;         //  Received character overrun errors
    ushort   frameErr;           //  Received character framing errors
    ushort   parityErr;          //  Received character parity errors
    ushort   rxOverFlowErr;      //  Receive char overflow
    ushort   ctsLostErr;
    ushort   dcdLostErr;
    ushort   txSccEvErr;         //  Transmitter event errors
    ushort   rxSccEvErr;         //  Receiver event errors
    };

struct DEV_ERR1 {
    ushort   memErr;             //  Memory allocate errors
    ushort   rxAddrErr;          //  Received address errors
    ushort   rxBcErr;            //  Received byte count errors
    ushort   devRxFCErr;         //  Received FC errors
    ushort   rxCsErr;            //  Received checksum errors
    ushort   stateErr;           //  state machine state error
    ushort   devRxBufErr;        //  Received Buffer errors
    ushort   devTxBufErr;        //  Transmit Buffer errors
    ushort   txDiskErr;          //  Error checking space on disk
    ushort   rdDiskErr;          //  Error reading message from disk
    ushort   txMsgErr;           //  Error writing message to disk
    ushort   txMsgOk;            //  OK writing message to disk
    ushort   rdMsgOk;            //  OK reading message from disk
    ushort   msgTxLineErr;       //  message sent on comms line

    ushort   memDvrErr;          //  Memory driver allocate errors
    ushort   overRunErr;         //  Received character overrun errors
    };

struct DEV_ERR2 {
    ushort   frameErr;           //  Received character framing errors
    ushort   parityErr;          //  Received character parity errors
    ushort   rxOverFlowErr;      //  Receive char overflow
    ushort   ctsLostErr;
    ushort   dcdLostErr;
    ushort   txSccEvErr;         //  Transmitter event errors
    ushort   rxSccEvErr;         //  Receiver event errors
    };


// RS485 DEVICE SLAVE LOOP Data structure

struct DEVSLV_PARM
{
	uchar	baudChangeRetry;	// the retry count after which the baud rate will  be changed to detect new baudrate
	uchar	contTime;			// the contention  time (multiple of 10ms)
	uchar	respWait;			// the time to wait for the response
	uchar	offTime;			// the time without poll from BAU to mark offline
	uchar	encryptEn;			// encryption enable flag
	uchar	txTimeOut;			// trasmitter timeout to reset tx if all data not sent
	uchar	txDelay;			// time in 10 ms to wait for tx out of cont
	uchar	txcDelay;			// time in 10 ms to wait for tx in cont
	uchar	sccResTime;			// is SCC offline reset time (in min)
	SERCFG	cfg;
};

//  RS485 Device Slave error counter structure ...

struct DEVSLV_ERR 
{
    ushort   memErr;             //  Memory allocate errors
    ushort   rxAddrErr;          //  Received address errors
    ushort   rxBcErr;            //  Received byte count errors
    ushort   devRxFCErr;         //  Received FC errors
    ushort   rxCsErr;            //  Received checksum errors
    ushort   stateErr;           //  state machine state error
    ushort   devRxBufErr;        //  Received Buffer errors
    ushort   devTxBufErr;        //  Transmit Buffer errors
    ushort   txDiskErr;          //  Error checking space on disk
    ushort   rdDiskErr;          //  Error reading message from disk
    ushort   txMsgErr;           //  Error writing message to disk
    ushort   txMsgOk;            //  OK writing message to disk
    ushort   rdMsgOk;            //  OK reading message from disk
    ushort   msgTxLineErr;       //  message sent on comms line

    ushort   memDvrErr;          //  Memory driver allocate errors
    ushort   overRunErr;         //  Received character overrun errors
    ushort   frameErr;           //  Received character framing errors
    ushort   parityErr;          //  Received character parity errors
    ushort   rxOverFlowErr;      //  Receive char overflow
    ushort   ctsLostErr;
    ushort   dcdLostErr;
    ushort   txSccEvErr;         //  Transmitter event errors
    ushort   rxSccEvErr;         //  Receiver event errors
};

struct DEVSLV_ERR1 
{
    ushort   memErr;             //  Memory allocate errors
    ushort   rxAddrErr;          //  Received address errors
    ushort   rxBcErr;            //  Received byte count errors
    ushort   devRxFCErr;         //  Received FC errors
    ushort   rxCsErr;            //  Received checksum errors
    ushort   stateErr;           //  state machine state error
    ushort   devRxBufErr;        //  Received Buffer errors
    ushort   devTxBufErr;        //  Transmit Buffer errors
    ushort   txDiskErr;          //  Error checking space on disk
    ushort   rdDiskErr;          //  Error reading message from disk
    ushort   txMsgErr;           //  Error writing message to disk
    ushort   txMsgOk;            //  OK writing message to disk
    ushort   rdMsgOk;            //  OK reading message from disk
    ushort   msgTxLineErr;       //  message sent on comms line

    ushort   memDvrErr;          //  Memory driver allocate errors
    ushort   overRunErr;         //  Received character overrun errors
};

struct DEVSLV_ERR2 
{
    ushort   frameErr;           //  Received character framing errors
    ushort   parityErr;          //  Received character parity errors
    ushort   rxOverFlowErr;      //  Receive char overflow
    ushort   ctsLostErr;
    ushort   dcdLostErr;
    ushort   txSccEvErr;         //  Transmitter event errors
    ushort   rxSccEvErr;         //  Receiver event errors
};


//  HDLC Frame parameter structure ...

struct HDLC_PARM {
    uchar mode;                 //  Operating Mode
    ushort timerT1;             //  T1 timer low byte (100mS)
    ushort timerT3;             //  T3 timer low byte (100mS)
    ushort pollTime;            //  Time between FEP/X25 polls Low byte (100mS)
    uchar noRspCnt;             //  No responses till link level fail
    uchar windowSize;           //  Window size
    uchar slowPollCyc;          //  Slow poll SNRM cycles
    uchar sccResTime;           //  Time to reset SCC (mins)
    uchar lineName[8];          //  Line name parameter.
    uchar blkNumId[4];          //  XID parameter.
    SERCFGH scfg;               //  Hardware configuration - synchronous comms
	SERCFG cfg;					//	Hardware configuration - asynchronous comms
    };


//  HDLC Frame error counter structure ...

struct HDLC_ERR {
    ushort   memError;           //  Memory allocation errors
    ushort   rxSizeErr;          //  Received character framing errors
    ushort   nsRrChange;         //  modify ns from rr
    ushort   nsRejChange;        //  modify ns from reject
    ushort   nsToutChange;       //  modify ns from timeout
    ushort   retryErr;           //  No response retransmit errors
    ushort   rnrTxErr;           //  Number of RNRs sent
    ushort   invBytes;           //  Attempt to send message with with non matching bytes
    ushort   failErr;            //  Link level fails
    ushort   stateErr;           //  Receive processing state error

    ushort   rxMsgOvrn;          //  Received message overrun
    ushort   rxOverrun;          //  Receiver overrun errors
    ushort   rxOverFlow;         //  Receive buffer overflow errors
    ushort   txUnderrun;         //  Transmit underrun errors
    ushort   rxShortFrame;       //  Incomplete frame errors
    ushort   rxLongFrame;        //  Over-length frame errors
    ushort   rxAbort;            //  Received frames aborted errors
    ushort   rxCrcErr;           //  Received CRC errors
    ushort   ctsLost;            //  CTS lost during transmission errors
    ushort   dcdLost;            //  DCD lost during reception errors
    ushort   txcGlitch;          //  Glitch detected on tx clock
    ushort   rxcGlitch;          //  Glitch detected on rx clock
    ushort   flagChange;         //  Flag searching state stopped or started 
    ushort   idleChange;         //  Status change on serial line 
    ushort   txSccEvErr;         //  Transmitter event errors
    ushort   rxSccEvErr;         //  Receiver event errors
    };

struct HDLC_ERR1 {
    ushort   memError;           //  Memory allocation errors
    ushort   rxSizeErr;          //  Received character framing errors
    ushort   nsRrChange;         //  modify ns from rr
    ushort   nsRejChange;        //  modify ns from reject
    ushort   nsToutChange;       //  modify ns from timeout
    ushort   retryErr;           //  No response retransmit errors
    ushort   rnrTxErr;           //  Number of RNRs sent
    ushort   invBytes;           //  Attempt to send message with with non matching bytes
    ushort   failErr;            //  Link level fails
    ushort   stateErr;           //  Receive processing state error

    ushort   rxMsgOvrn;          //  Received message overrun
    ushort   rxOverrun;          //  Receiver overrun errors
    ushort   rxOverFlow;         //  Receive buffer overflow errors
    ushort   txUnderrun;         //  Transmit underrun errors
    ushort   rxShortFrame;       //  Incomplete frame errors
    ushort   rxLongFrame;        //  Over-length frame errors
    };

struct HDLC_ERR2 {
    ushort   rxAbort;            //  Received frames aborted errors
    ushort   rxCrcErr;           //  Received CRC errors
    ushort   ctsLost;            //  CTS lost during transmission errors
    ushort   dcdLost;            //  DCD lost during reception errors
    ushort   txcGlitch;          //  Glitch detected on tx clock
    ushort   rxcGlitch;          //  Glitch detected on rx clock
    ushort   flagChange;         //  Flag searching state stopped or started 
    ushort   idleChange;         //  Status change on serial line 
    ushort   txSccEvErr;         //  Transmitter event errors
    ushort   rxSccEvErr;         //  Receiver event errors
    };

typedef struct HDLC_ERR1 HDLCERR1;
typedef struct HDLC_ERR2 HDLCERR2;

//  MAC parameters structure ...

struct MAC_PARM {
    uchar   llcSap;             //  SAP to use for LLC data 
    uchar   llcWin;             //  Window size 
    uchar   llcT1;              //  T1 timer - time to wait for iframe ack 
    uchar   llcN2;              //  n2 retry - times to retry sending ifarme 
    uchar   llcUPoll;           //  SABME polling freq ( secs ) 
    uchar   llcRPoll;           //  RR polling freq ( secs ) 
    uchar   llcFlags;           //  flags - bit 0 set for SABME tx enabled

    uchar   macFlags;           //  Mac flags
    uchar   testTimer;          //  LLC Test timer 
    uchar   macAddr[6];         //  Local mac address
    //MACDVRPARM dvr;             //  Union of mac driver parameters
    };


//  MAC error counter structure ...

struct MAC_ERR {
    ushort   invBuff;
    ushort   invAddr;
    ushort   invSize;
    ushort   invLoad;
    ushort   invCache;
    ushort   invPtr;
    ushort   nsToutChange;       //  LLC timeout sending iframe
    };


//  P105x MAC Adapter parameters structure ...

struct ADAPT_PARM {
    uchar   pollT1;             //  Poll delay when off line
    uchar   pollT2;             //  Poll delay during transitions
    uchar   pollT3;             //  Poll delay when on line
    uchar   msgTime;            //  Message response timeout time
    uchar   rxTime;             //  Receive character timeout time (not used)
    uchar   offRsp;             //  Number of no responses till off line
    uchar   invRsp;             //  Number of inv responses till off line
    uchar   maxNak;             //  Maximum NAKs before delete message
    uchar   maxRetx;            //  Maximum retx before delete message
    uchar   echoTime;           //  Echo Timer
    uchar   offPollCnt;         //  Number of off line polls to use
    uchar   sccResTime;         //  SCC off line reset time (in mins)
    SERCFG  cfg;                //  Port configuration
    };

//  P105x adapter error counter structure ...

struct ADAPT_ERR {
    ushort   memErr;             //  Memory error
    ushort   syncErr;            //  Invalid control character
    ushort   msgCntErr;
    ushort   bcErr;              //  Byte count errors
    ushort   ctrlOvrn;           //  Control character overrun
    ushort   pollRspOverRunErr;  //  Buffer overrun errors
    ushort   dataOvrn;           //  Data message overrun
    ushort   msgNoRsp;           //  No responses to messages
    ushort   notSendMsgDel;      //  Messages deleted as not sending
    ushort   nakRx;              //  Number of NAKs received
    ushort   nakMsgDel;          //  Messages deleted due to too many NAKs
    ushort   xoffRx;             //  Number of XOFFs received
    ushort   xoffUs;             //  Number of times we went XOFF
    ushort   xoffErr;            //  Received data while XOFF
    ushort   csumErr;            //  Received message checksum errors
    ushort   portOff;            //  Number of times port off line
    ushort   syncErr1;
    ushort   resSeqErr;
    ushort   rxSeqErr;
    ushort   seqFail;

    ushort   dvrMemErr;          //  Memory error
    ushort   overRunErr;         //  Received character overrun errors
    ushort   frameErr;           //  Received character framing errors
    ushort   parityErr;          //  Received character parity errors
    ushort   rxOverFlowErr;      //  Received buffer overrun errors
    ushort   ctsLost;
    ushort   dcdLost;
    ushort   txSccEvErr;         //  Transmitter event errors
    ushort   rxSccEvErr;         //  Receiver event errors
    };

struct ADAPT_ERR1 {
    ushort   memErr;             //  Memory error
    ushort   syncErr;            //  Invalid control character
    ushort   msgCntErr;
    ushort   bcErr;              //  Byte count errors
    ushort   ctrlOvrn;           //  Control character overrun
    ushort   pollRspOverRunErr;  //  Buffer overrun errors
    ushort   dataOvrn;           //  Data message overrun
    ushort   msgNoRsp;           //  No responses to messages
    ushort   notSendMsgDel;      //  Messages deleted as not sending
    ushort   nakRx;              //  Number of NAKs received
    ushort   nakMsgDel;          //  Messages deleted due to too many NAKs
    ushort   xoffRx;             //  Number of XOFFs received
    ushort   xoffUs;             //  Number of times we went XOFF
    ushort   xoffErr;            //  Received data while XOFF
    ushort   csumErr;            //  Received message checksum errors
    ushort   portOff;            //  Number of times port off line
    };

struct ADAPT_ERR2 {
    ushort   syncErr1;
    ushort   resSeqErr;
    ushort   rxSeqErr;
    ushort   seqFail;

    ushort   dvrMemErr;          //  Memory error
    ushort   overRunErr;         //  Received character overrun errors
    ushort   frameErr;           //  Received character framing errors
    ushort   parityErr;          //  Received character parity errors
    ushort   rxOverFlowErr;      //  Received buffer overrun errors
    ushort   ctsLost;
    ushort   dcdLost;
    ushort   txSccEvErr;         //  Transmitter event errors
    ushort   rxSccEvErr;         //  Receiver event errors
    };

typedef	struct ADAPT_ERR1 ADAPTERR1;
typedef struct ADAPT_ERR2 ADAPTERR2;

//  Ethernet MAC parameters structure ...

struct ETHDRV_PARM {
    uchar flags;
    uchar pers;
    uchar rxBuffSize;
    uchar sccResTime;
    };


//  Ethernet MAC error structure ...

struct ETHDRV_ERR {
    ushort   memErr;             //  Memory error
    ushort   overRunErr;         //  Received character overrun errors
    ushort   rxOverFlowErr;      //  Received buffer overrun errors
    ushort   txUnderrunErr;
    ushort   frameTooShortErr;
    ushort   frameTooLongErr;
    ushort   nonOctetAlignFrameErr;
    ushort   incompleteFrameErr;
    ushort   crcRxErr;
    ushort   ctsLostErr;
    ushort   dcdLostErr;
    ushort   txSccEvErr;         //  Transmitter event errors
    ushort   rxSccEvErr;         //  Receiver event errors
	ushort	 retxLimitErr;
	ushort	 lateCollisionErr;
	ushort	 heartBeatErr;
	ushort	 deferredErr;
    };

struct ETHDRV_ERR1 {
    ushort   memErr;             //  Memory error
    ushort   overRunErr;         //  Received character overrun errors
    ushort   rxOverFlowErr;      //  Received buffer overrun errors
    ushort   txUnderrunErr;
    ushort   frameTooShortErr;
    ushort   frameTooLongErr;
    ushort   nonOctetAlignFrameErr;
    ushort   incompleteFrameErr;
    ushort   crcRxErr;
    ushort   ctsLostErr;
    ushort   dcdLostErr;
    ushort   txSccEvErr;         //  Transmitter event errors
    ushort   rxSccEvErr;         //  Receiver event errors
	ushort	 retxLimitErr;
	ushort	 lateCollisionErr;
	ushort	 heartBeatErr;
    };

struct ETHDRV_ERR2 {
	ushort	 deferredErr;
    };

typedef	struct ETHDRV_ERR1 ETHDRVERR1;
typedef struct ETHDRV_ERR2 ETHDRVERR2;


//  Link level DIALUP parameter structure ...

struct LDIAL_PARM {
    uchar 	ourTelNum[MAX_NUM_BYTES];   //  DLU Telephone number
    uchar   msgRspTime;         //  Message response timeout time
    uchar   maxNoRsp;           //  Max. no. of no responses to poll messages
                                //  before marking device offline 
    uchar   maxInvResp;         //  Max no of invalid polls from master before
                                //  marking master offline
    uchar   dialFlags;//maxNak;             //  Max no of consecutive naks before message
                                //  is marked as undeliverable
    uchar   maxRetx;            //  Max num of times to attempt tx
    uchar   echoTime;           //  Time between reporting the port in loopback mode
    uchar   modemTypeIx;        //  Modem type index into the system modem init
                                //  string table (0x7f for default operation),
                                //  BIT7 for DTMF dialling flag
    uchar   callEstabTime;      //  Max time to wait for DCD after dialling
    uchar   ringAnswer;         //  No. rings until answering an incoming call
    uchar   ansEstabTime;       //  Max time to wait for DCD after answering a call
    uchar   estabInactivityTime;    //  Max time to wait for first data message
    uchar   dataInactivityTime;     //  Max time allowed between data messages
    uchar   cmdPollTime;        //  Time between polls to modem in command mode
    uchar   cmdOffRsp;          //  No. of no responses before marking modem failed
    uchar   cmdRspTime;         //  Max time to wait for an ack resp to a tx command
    uchar   telTestTime;        //  Time between dial tone tests for dedicated line
    uchar   sccResTime;         //  Time between SCC resets in command mode

    SERCFG  cfg;                //  Port configuration
    };

struct LDIAL1_PARM {
    uchar 	ourTelNum[MAX_NUM_BYTES];   //  DLU Telephone number
    uchar   msgRspTime;         //  Message response timeout time
    uchar   maxNoRsp;           //  Max. no. of no responses to poll messages
                                //  before marking device offline 
    uchar   maxInvResp;         //  Max no of invalid polls from master before
                                //  marking master offline
    uchar   dialFlags; //maxNak;             //  Max no of consecutive naks before message
                                //  is marked as undeliverable
    uchar   maxRetx;            //  Max num of times to attempt tx
    uchar   echoTime;           //  Time between reporting the port in loopback mode

    };

struct LDIAL2_PARM {
    uchar   modemTypeIx;        //  Modem type index into the system modem init
                                //  string table (0x7f for default operation),
                                //  BIT7 for DTMF dialling flag
    uchar   callEstabTime;      //  Max time to wait for DCD after dialling
    uchar   ringAnswer;         //  No. rings until answering an incoming call
    uchar   ansEstabTime;       //  Max time to wait for DCD after answering a call
    uchar   estabInactivityTime;    //  Max time to wait for first data message
    uchar   dataInactivityTime;     //  Max time allowed between data messages
    uchar   cmdPollTime;        //  Time between polls to modem in command mode
    uchar   cmdOffRsp;          //  No. of no responses before marking modem failed
    uchar   cmdRspTime;         //  Max time to wait for an ack resp to a tx command
    uchar   telTestTime;        //  Time between dial tone tests for dedicated line
    uchar   sccResTime;         //  Time between SCC resets in command mode

    };

struct LDIAL3_PARM {

    SERCFG  cfg;                //  Port configuration
    };

//  DIALUP link level error counter structure ...

struct LDIAL_ERR {
    ushort   memErr;             //  Memory error
    ushort  sendMsgErr;         //  Can not send message
    ushort  datahdrErr;         //  Data header error
    ushort  noDialTone;         //  No dial tone error
    ushort  dialState;			//	Unknown dialout state
	ushort  dialAnsState;		//	Unknown dial answer state
	ushort  dialDigitState;		//	Unknown dial digit state

    ushort   dvrMemErr;          //  Memory error
    ushort   overRunErr;         //  Received character overrun errors
    ushort   frameErr;           //  Received character framing errors
    ushort   parityErr;          //  Received character parity errors
    ushort   buffOverRunErr;     //  Received buffer overrun errors
    ushort   ctsLost;
    ushort   dcdLost;
    ushort   txSccEvErr;         //  Transmitter event errors
    ushort   rxSccEvErr;         //  Receiver event errors
    };




//  PPP parameters

struct PPP_PARM {
    uchar   pppFlags;           //  flags - bit 0 
    uchar   rspTimer;           //  LCP ping/rsp timer
    uchar   rspRetry;           //  LCP ping/retry
    uchar   rxMsgTime;          //  Waiting for rx character
    uchar   sccResTime;         //  SCC reset timer
    SERCFG  cfg;                //  Serial definitions
    };


//  PPP error counter structure ...

struct PPP_ERR {
    ushort  memErr;
    ushort  invRxCrc;
    ushort  invRxMsgSize;
    ushort  dataOvrn;
    ushort  frameErr;
    ushort  parityErr;
    ushort  overRunErr;
    ushort  invRxCtrl;
    ushort  invRxIpMsg;
    ushort  invRxProtocol;
    ushort  invLCPRxType;
    ushort  invLCPRxLength;
    ushort  LCPCCfgAckIdentErrRx;
    ushort  LCPCCfgNakRx;
    ushort  LCPCCfgRejRx;
    ushort  LCPCodeRejRx;
    ushort  LCPProtRejRx;
    ushort  LCPDiscRqsRx;
    ushort  IpcpCfgAckIdentErrRx;
    ushort  IpcpCCfgNakRx;
    ushort  IpcpCCfgRejRx;
    ushort  IpcpCodeRejRx;
    };

struct PPP_ERR1 {
    ushort  memErr;
    ushort  invRxCrc;
    ushort  invRxMsgSize;
    ushort  dataOvrn;
    ushort  frameErr;
    ushort  parityErr;
    ushort  overRunErr;
    ushort  invRxCtrl;
    ushort  invRxIpMsg;
    ushort  invRxProtocol;
    ushort  invLCPRxType;
    ushort  invLCPRxLength;
    ushort  LCPCCfgAckIdentErrRx;
    ushort  LCPCCfgNakRx;
    ushort  LCPCCfgRejRx;
    ushort  LCPCodeRejRx;
    };

struct PPP_ERR2 {
    ushort  LCPProtRejRx;
    ushort  LCPDiscRqsRx;
    ushort  IpcpCfgAckIdentErrRx;
    ushort  IpcpCCfgNakRx;
    ushort  IpcpCCfgRejRx;
    ushort  IpcpCodeRejRx;
    };

typedef struct PPP_ERR1 PPPERR1;
typedef struct PPP_ERR2 PPPERR2;


//  MXL parameters structure ...


struct MXL_PARM {
    uchar   offLineTime;        //  Time for off line when no rx (secs)
    uchar   rspTime;            //  Message response time (100mS)
    uchar   delimTime;          //  Message delim (100mS)
    uchar   maxNak;             //  Maximum NAKs before delete
    uchar   maxRetx;            //  Maximum retx before delete
    uchar   echoTime;           //  echo timer
    uchar   sccResTime;         //  SCC off line reset time (mins)
    SERCFG  cfg;                //  Port configuration
    };

//  MXL error counter structure ...

struct MXL_ERR {
    ushort  memErr;             //  Memory error
    ushort  crcErr;             //  CRC errors

    ushort   dvrMemErr;          //  Memory error
    ushort   overRunErr;         //  Received character overrun errors
    ushort   frameErr;           //  Received character framing errors
    ushort   parityErr;          //  Received character parity errors
    ushort   buffOverRunErr;     //  Received buffer overrun errors
    ushort   ctsLost;
    ushort   dcdLost;
    ushort   txSccEvErr;         //  Transmitter event errors
    ushort   rxSccEvErr;         //  Receiver event errors
    };


//  GENC parameters structure ...

struct GENC_PARM {
    uchar offlinePollTime;          //  Off line poll delay (100mS)
    uchar transitionPollTime;       //  Transition poll delay (100mS)
    uchar onlinePollTime;           //  On line poll delay (100mS)
    uchar msgRspTime;               //  Message ACK timeout (100mS)
    uchar msgDelimTime;             //  Message delimit time (secs)
    uchar maxNoRsp;                 //  No responses till off line
    uchar maxInvRsp;                //  Invalid responses till off line
    uchar maxNak;                   //  Maximum NAKs allowed
    uchar maxRetx;                  //  Message retry count
    uchar echoTime;                 //  Echo repeat time (mins)
    uchar offlinePollCnt;           //  Number of off line polls to use
    uchar sccResTime;               //  SCC reset time when off line (mins)
    SERCFG cfg;                     //  Port configuration parameters
    };

/*  GENC error counter structure ...
*/

struct GENC_ERR {
    ushort memErr;                   //  Memory allocation errors
    ushort syncErr;                  //  Message STX errors
    ushort msgCntErr;                //  Message count errors
    ushort bcErr;                    //  Byte count errors
    ushort pollOverrun;              //  Poll character overruns
    ushort pollRspOverrun;           //  Poll response character overruns
    ushort dataRspOverrun;           //  Data response character overruns
    ushort msgNoRsp;                 //  No responses to messages
    ushort notSendDel;               //  Messages aborted due to no response
    ushort nakRx;                    //  NAK responses to messages
    ushort nakMsgDel;                //  Messages aborted due to max NAKs
    ushort xoffRx;                   //  XOFF responses received
    ushort xoffUs;                   //  Times we went XOFF
    ushort xoffErr;                  //  Data received while XOFF
    ushort crcErr;                   //  CRC errors received
    ushort portOff;                  //  Number of times port off line
    ushort invCharErr;               //  Invalid characters received
    ushort resetSeq;                 //  Times seq numbers have been reset
    ushort rxSeqErr;                 //  Received seq number errors
    ushort seqFail;                  //  Times sequencing failed

    ushort memErrA;                  //  Async driver memory errors
    ushort rxOverrun;                //  Receiver overruns
    ushort rxFrameErr;               //  Receiver framing errors
    ushort rxParityErr;              //  Receiver parity errors
    ushort buffOverrun;              //  Buffer overrun errors
    ushort ctsLost;                  //  CTS lost during transmission
    ushort dcdLost;                  //  DCD lost during reception
    ushort txSccEvErr;               //  Transmit event errors
    ushort rxSccEvErr;               //  Receive event errors
    };

struct GENC_ERR1 {
    ushort memErr;                   //  Memory allocation errors
    ushort syncErr;                  //  Message STX errors
    ushort msgCntErr;                //  Message count errors
    ushort bcErr;                    //  Byte count errors
    ushort pollOverrun;              //  Poll character overruns
    ushort pollRspOverrun;           //  Poll response character overruns
    ushort dataRspOverrun;           //  Data response character overruns
    ushort msgNoRsp;                 //  No responses to messages
    ushort notSendDel;               //  Messages aborted due to no response
    ushort nakRx;                    //  NAK responses to messages
    ushort nakMsgDel;                //  Messages aborted due to max NAKs
    ushort xoffRx;                   //  XOFF responses received
    ushort xoffUs;                   //  Times we went XOFF
    ushort xoffErr;                  //  Data received while XOFF
    ushort crcErr;                   //  CRC errors received
    ushort portOff;                  //  Number of times port off line
    };

struct GENC_ERR2 {
    ushort invCharErr;               //  Invalid characters received
    ushort resetSeq;                 //  Times seq numbers have been reset
    ushort rxSeqErr;                 //  Received seq number errors
    ushort seqFail;                  //  Times sequencing failed

    ushort memErrA;                  //  Async driver memory errors
    ushort rxOverrun;                //  Receiver overruns
    ushort rxFrameErr;               //  Receiver framing errors
    ushort rxParityErr;              //  Receiver parity errors
    ushort buffOverrun;              //  Buffer overrun errors
    ushort ctsLost;                  //  CTS lost during transmission
    ushort dcdLost;                  //  DCD lost during reception
    ushort txSccEvErr;               //  Transmit event errors
    ushort rxSccEvErr;               //  Receive event errors
    };

typedef struct GENC_ERR1 GENCERR1;
typedef struct GENC_ERR2 GENCERR2;


//  IRIS parameter structure  

struct IRIS_PARM {
    uchar   offLineRet;         //  No. of retries before off line 
    uchar   sccResTime;         //  SCC off line reset time (mins)
    SERCFG  cfg;                //  Port configuration
    };

//  IRIS error counter structure  

struct IRIS_ERR {
    ushort  memErr;                 //  memory allocate error
    ushort  rxCsumErr;              //  received messages checksum error  
    ushort  rxMsgErr;               //  received message overrun   
    ushort  txMsgErr;               //  tx message error   

    ushort   dvrMemErr;          //  Memory error
    ushort   overRunErr;         //  Received character overrun errors
    ushort   frameErr;           //  Received character framing errors
    ushort   parityErr;          //  Received character parity errors
    ushort   buffOverRunErr;     //  Received buffer overrun errors
    ushort   ctsLost;
    ushort   dcdLost;
    ushort   txSccEvErr;         //  Transmitter event errors
    ushort   rxSccEvErr;         //  Receiver event errors
    };

//  BMS parameter structure  

struct BMS_PARM {
    uchar   offLineRet;         //  No. of retries before off line
	uchar	pollRate;			//	freq. of polling BMS device in secs.
	uchar	respTime;			//	time to wait for resp. (100 ms) before transmission
	uchar	address;			//	address of the polling device
    uchar   sccResTime;         //  SCC off line reset time (mins)
    SERCFG  cfg;                //  Port configuration
    };

//  BMS error counter structure  

struct BMS_ERR {
    ushort  memErr;              //  memory allocate errors
    ushort  addrErr;             //  received address errors
    ushort  csumErr;             //  received messages checksum errors
    ushort  rxBuffErr;           //  received message buffer errors

    ushort   dvrMemErr;          //  Memory error
    ushort   overRunErr;         //  Received character overrun errors
    ushort   frameErr;           //  Received character framing errors
    ushort   parityErr;          //  Received character parity errors
    ushort   buffOverRunErr;     //  Received buffer overrun errors
    ushort   ctsLost;
    ushort   dcdLost;
    ushort   txSccEvErr;         //  Transmitter event errors
    ushort   rxSccEvErr;         //  Receiver event errors
    };


//  Generic Fire Alarm parameter structure  

struct GEN_PARM {
    uchar   offLineTime;        //  Time to wait for a message before panel offline
    uchar   gentPnts;           //  No. of gent points  
    uchar   gentPnls;           //  No. of gent panels  
    uchar   sccResTime;         //  SCC off line reset time (mins)
    SERCFG  cfg;                //  Port configuration
    };

//  Generic Fire Alarm error counter structure  

struct GEN_ERR {
    ushort  memErr;                 //  memory allocate error
    ushort  rxCsumErr;              //  received messages checksum error  
    ushort  rxMsgErr;               //  received message overrun   
    ushort  txMsgErr;               //  tx message error   

    ushort   dvrMemErr;          //  Memory error
    ushort   overRunErr;         //  Received character overrun errors
    ushort   frameErr;           //  Received character framing errors
    ushort   parityErr;          //  Received character parity errors
    ushort   buffOverRunErr;     //  Received buffer overrun errors
    ushort   ctsLost;
    ushort   dcdLost;
    ushort   txSccEvErr;         //  Transmitter event errors
    ushort   rxSccEvErr;         //  Receiver event errors
    };


//  VCS parameter structure  

struct VCS_PARM {
    uchar   offLineTime;        //  Offline timer (secs)
    uchar   msgRspTme;          //  Message response time (secs)  
    uchar   maxRetransMsg;      //  Max. retransmits of message
	uchar	pollTime;			//	Poll time (secs)
	uchar	isdnNum[24];		//	ISDN number to call (24 ASCII values)

	uchar	startCamAddr;		//	Start address of camera on switcher
	uchar	noCameras;			//	Number of cameras on switcher
	uchar	physInput;			//	Physical Input on remote switcher
	uchar	monOutput;			//	Physical output on local switcher
	uchar	flags;				//	Flags
    uchar   sccResTime;         //  SCC off line reset time (mins)
    SERCFG  cfg;                //  Port configuration
    };

//  VCS error counter structure  

struct VCS_ERR {
    ushort	rxGrpTypeCmdErr;	//  Receive group command type errors
    ushort	rxGrpTypeMsgErr;	//  Receive group message type errors

    ushort	frameErr;			//  Received character framing errors
    ushort	overRunErr;			//  Received character overrun errors
    ushort	parityErr;			//  Received character parity errors
    ushort	dataOvrn;			//  Data message overrun errors
    ushort	crcErr;				//  CRC errors
    ushort	txSccEvErr;			//  Transmitter event errors
    ushort	rxSccEvErr;			//  Receiver event errors
    };

//  VCS parameter structure  

struct AVCS_PARM {
    uchar   offLineTime;        //  Offline timer (secs)
    uchar   msgRspTme;          //  Message response time (secs)  
    uchar   maxRetransMsg;      //  Max. retransmits of message
	uchar	pollTime;			//	Poll time (secs)
	uchar	isdnNum[24];		//	ISDN number to call (24 ASCII values)

	uchar	startCamAddr;		//	Start address of camera on switcher
	uchar	noCameras;			//	Number of cameras on switcher
	uchar	physInput;			//	Physical Input on remote switcher
	uchar	monOutput;			//	Physical output on local switcher
	uchar	flags;				//	Flags
    //uchar   sccResTime;         //  SCC off line reset time (mins)
    };

//  VCS error counter structure  

struct AVCS_ERR {
    ushort	rxGrpTypeCmdErr;	//  Receive group command type errors
    ushort	rxGrpTypeMsgErr;	//  Receive group message type errors

    ushort	frameErr;			//  Received character framing errors
    ushort	overRunErr;			//  Received character overrun errors
    ushort	parityErr;			//  Received character parity errors
    ushort	dataOvrn;			//  Data message overrun errors
    ushort	crcErr;				//  CRC errors
    ushort	txSccEvErr;			//  Transmitter event errors
    ushort	rxSccEvErr;			//  Receiver event errors
    };

// VCU Parameter structure

const int	MAX_ADDR_CHAR	= 4;
const int	MAX_LOOP_DEVICE	= 8;

struct DeviceTable
{
	uchar	type;				// device type
	uchar	addr[MAX_ADDR_CHAR];// address of the device
};

struct AVCU_PARM
{
	DeviceTable  devtable[MAX_LOOP_DEVICE];	// table containing device connected to and addresses
	uchar	contactTime;		// time to stream video without acknowledgement (min)
	uchar	msgRespTime;		// message response time
	uchar	msgRetry;			// number of times to retry
	ushort	ourPort;			// UDP port number for this application (16 bit number)
};

// VCU Error conunter structure

struct AVCU_ERR
{
	ushort	msgRx;				// number of messages received
	ushort	contactRx;			// number of contacts received
	ushort	resDefParm;			// number of reset default parameters
	ushort	storeParm;			// number of store new parameters
	ushort	msgDel;				// number of messages deleted from retries
	ushort	contactOut;			// number of contact timeout
	ushort	rspTout;			// number of responce timeouts
	ushort	rspErr;				// number of response errors
	ushort	icPortErr;			// number of ic wrong UDP port number
	ushort	icTypeErr;			// number of ic data type errors
	ushort	csumErr;			// number of ic message in Checksum error
	ushort	bcErr;				// number of ic message bc error
};

//  Printer parameters structure ...


struct PRN_PARM {
    uchar flags;                //  Operating flags
    uchar filters;              //  Alarm filters
    uchar sccResTime;           //  SCC reset time ( mins )
    SERCFG  cfg;                //  Port configuration
    };


//  Printer error counter structure ...

struct PRN_ERR {
    ushort  memErr;             //  memory error
    ushort  portOff;            //  Number of times port off line

    ushort   dvrMemErr;          //  Memory error
    ushort   overRunErr;         //  Received character overrun errors
    ushort   frameErr;           //  Received character framing errors
    ushort   parityErr;          //  Received character parity errors
    ushort   buffOverRunErr;     //  Received buffer overrun errors
    ushort   ctsLost;
    ushort   dcdLost;
    ushort   txSccEvErr;         //  Transmitter event errors
    ushort   rxSccEvErr;         //  Receiver event errors
    };




//  PAGER parameters structure ...

struct PAGER_PARM {
    uchar pagerNo[7];           //  Pager number
    uchar buzzer;               //  Buzzer type
    uchar almTimer;             //  Time between sending messages
    uchar flags;                //  Operating flags
    uchar filters;              //  Alarm filters
    uchar sccResTime;           //  SCC reset time ( mins )
    SERCFG  cfg;                //  Port configuration
    };


//  PAGER error counter structure ...

struct PAGER_ERR {
    ushort  memErr;             //  Memory error
    ushort  portOff;            //  Number of times port off line

    ushort   dvrMemErr;          //  Memory error
    ushort   overRunErr;         //  Received character overrun errors
    ushort   frameErr;           //  Received character framing errors
    ushort   parityErr;          //  Received character parity errors
    ushort   buffOverRunErr;     //  Received buffer overrun errors
    ushort   ctsLost;
    ushort   dcdLost;
    ushort   txSccEvErr;         //  Transmitter event errors
    ushort   rxSccEvErr;         //  Receiver event errors
    };


//  ASYNC_POLL parameters structure ...

struct ASYNCPOLL_PARM {
    uchar lineIdleTimer;        //  line idle timers (secs)
    uchar responseTimer;        //  response timer (secs)
    uchar msgRetryCounter;      //  message retry counter
    uchar flags;                //  Operating flags
    uchar devAddr;              //  address of device
    uchar sccResTime;           //  SCC reset time ( mins )
    SERCFG  cfg;                //  Port configuration
    };


//  ASYNC_POLL error counter structure ...

struct ASYNCPOLL_ERR {
	ushort	invNetType;			//	Network Priority errors
	ushort	invMsgType;			//	Message Type errors.
	ushort	invMsgRetx;			//	Message retransmit errors
	ushort	invDataBcRx;		//	Invalid message size
	ushort	invMsgRx;			//	Message RX error
	ushort	resDefparm;			//	Reset default params
	ushort	storeParm;			//	Store new params

	ushort	frameErr;			//	Received character framing errors
	ushort	overRunErr;			//	Received character overrun errors
	ushort	parityErr;			//	Received character parity errors
	ushort	dataOvrn;			//	Data message overrun errors
	ushort	crcErr;				//	CRC errors
	ushort	txSccEvErr;			//	Transmitter event errors
	ushort	rxSccEvErr;			//	Receiver event errors
    };


//  IEC parameters structure ...

struct IEC_PARM {
    uchar offLineTime;			//  Time for off line when no rx (secs)
    uchar rspTime;				//  response time (secs)
    uchar maxNak;				//  max. NAKs before delete
    uchar pollTime;				//  time between idle polls

	uchar startCamAddr;			//	Start address of camera on switcher
	uchar noCameras;			//	Number of cameras on switcher

    uchar physInput;			//  physical input on remote switcher
    uchar monOutput;			//  physical output on local switcher
	uchar alarmDirectorySize;	//	Alarm Directory Size
	uchar callFlgs;				//  flags for connection
    uchar sccResTime;			//  SCC reset time ( mins )
    SERCFG  cfg;                //  Port configuration
    };


//  IEC error counter structure ...

struct IEC_ERR {
	ushort	rxCmdErr;			//	Receive command type error
	ushort	rxMsgErr;			//	Receive message type error

	ushort	rxRangeErr;
	ushort	rxEquipmentErr;
	ushort	rxExecutionErr;
	ushort	unknownMsgErr;

	ushort	frameErr;			//	received character framing errors
	ushort	overRunErr;			//	received character overrun errors
	ushort	parityErr;			//	received character parity errors
	ushort	dataOvrn;			//	Data message overrun errors
	ushort	crcErr;				//	CRC Errors
	ushort	txSccEvErr;			//	Transmitter event errors
	ushort	rxSccEvErr;			//	Receiver event errors
    };


struct PORT_DIS_PARM
{
	uchar byte1;
	uchar byte2;
	uchar byte3;
};

//  ASC parameters structure ...

struct ASC_PARM {
    uchar   pflag;              //  Parameter flags
    uchar   fwdTime;            //  Message forwarding time (100mS)
    uchar   fwdChar;            //  Message forwarding character
    uchar   sccResTime;         //  SCC off line reset time (in mins)
    SERCFG  cfg;                //  Port configuration parameters
    };

//  PTZ parameters structure ...
struct PTZ_PARM {
    uchar   ptzType;			//  PTZ Type
    uchar   ptzFlags;			//  Flags
    uchar   sccResTime;			//  SCC off line reset time (in mins)
    SERCFG  cfg;				//  Port configuration
    };

struct PTZ_ERR {
	ushort rxCmdErr; // Received command type error
	ushort rxRangeErr; // Command parameter out of range error
	ushort frameErr; //Received character framing errors
	ushort overRunErr; // Received character overrun errors
	ushort parityErr; // Received character parity errors
	ushort dataOvrn; // Data message overrun errors
	ushort crcErr; // CRC errors
	ushort txSccEvErr; // Transmitter event errors
	ushort rxSccEvErr; // Receiver event errors
};

//  ELEV_IFACE parameters structure ...
struct ELEV_IFACE_PARM {
	uchar   type;               //  Elevator type  Kone = 0, Otis = 1, Schindler = 2
	uchar   groupMask;          //  Mask of group connected to this port (for Otis / Kone systems)
	uchar   maxLanding;         //  Maximum landings of the elevator with the most landings (for Otis systems)
	uchar   slowPollTime;       //  Slow poll time (secs)
	uchar   rspTime;            //  Message response time (100mS)
	uchar   maxRetry;           //  Maximum retries before marking offline
    SERCFG  cfg;				//  Port configuration

	//.. tt #7659
	uchar   flags;              //  Flags options. ProcMultiResp = 0x1; IgnoreNoResp = 0x2
	uchar   pollDelay;          //  100ms delay count before sending next poll. [0 - 15]
	uchar   ResendAccessed;     //  Resend accessed floors in minutes. [0-255]
	uchar   RestoreFloorsSecs;  //  Resend accessed floors after a card swipe in seconds (TT 8214)

	ELEV_IFACE_PARM()
	{
		type = 0;               //  Elevator type  Kone = 0, Otis = 1, Schindler = 2
		groupMask = 0;          //  Mask of group connected to this port (for Otis / Kone systems)
		maxLanding = 0;         //  Maximum landings of the elevator with the most landings (for Otis systems)
		slowPollTime = 0;       //  Slow poll time (secs)
		rspTime = 0;            //  Message response time (100mS)
		maxRetry = 0;           //  Maximum retries before marking offline
	    
		memset(&cfg, 0, sizeof(cfg));				//  Port configuration

		//.. tt #7659
		flags = 0;              //  Flags options
		pollDelay = 0;          //  100ms delay count before sending next poll
		ResendAccessed = 0;     //  Resend accessed floors in minutes
		RestoreFloorsSecs = 0;  //  Resend accessed floors after a card swipe in seconds

	};

    };

//  Elevator error counter structure ...
struct ELEV_IFACE_ERR_MIN {
	ushort  rxPktSizeErr;       //  Recv packet size error
	ushort  txCommLost;         //  Tx packet not recvd error
	ushort  rxChkSumErr;        //  Recv packet check sum error
	ushort  txChkSumErr;        //  Tx packet check sum error
	ushort  rxDataErr;          //  Data error in recv packet
	ushort  txDataErr;          //  Data error in tx packet
	ushort  overRunErr;         //  Received character overrun errors
	ushort  frameErr;           //  Received character framing errors
	ushort  parityErr;          //  Received character parity errors
	ushort  buffOverRunErr;     //  Received buffer overrun errors
	ushort  ctsLost;
	ushort  dcdLost;
	ushort  txSccEvErr;         //  Transmitter event errors
	ushort  rxSccEvErr;         //  Receiver event errors
	};

struct ELEV_IFACE_ERR : ELEV_IFACE_ERR_MIN {
	ushort  lostAccess;         //  Communication with elevator is too slow for rate of access messages, access messages thrown away
	ushort  offlineAccessLost;  //  Communication with elevator is has failed and access messages can not be sent
	ushort  noResponse;         //  Elevator controller did not respond to a poll/access pkt
};

//  IRISYS People Counter parameters structure ...
struct IRISYS_PARM {
	uchar   enableStatusMsgs;   //  Enable status messages
	uchar   logicalNum;         //  Logical number for People counter attached to this port
	uchar   area;               //  Area number for this People counter
	uchar   spare;            //  Spare (puts cfg on long word boundary)
	SERCFG  cfg;                //  Port configuration
	};

//  IRISYS People Counter error counter structure ...
struct IRISYS_ERR {
	ushort  rxBufferOverflow;   //  Recv buffer overflow errors
	ushort  rxPktUnknownErr;    //  Recv unknown packet errors
	ushort  rxDataErr;          //  Data error in recv packet
	ushort  overRunErr;         //  Received character overrun errors
	ushort  frameErr;           //  Received character framing errors
	ushort  parityErr;          //  Received character parity errors
	ushort  buffOverRunErr;     //  Received buffer overrun errors
	ushort  ctsLost;
	ushort  dcdLost;
	ushort  txSccEvErr;         //  Transmitter event errors
	ushort  rxSccEvErr;         //  Receiver event errors
	};


//  "pflag" bits: ...

#define ASC_LACK_EN 4           //  local acks enable
#define APF_FWDCHR 2            //  Forward message on character enable
#define APF_FWDTMR 1            //  Forward message on timer enable


//  ASC error counter structure ...

struct ASC_ERR {
    ushort   memErr;             //  Memory error
    ushort   rxMsgErr;           //  Received messages returned error
    ushort   xoffUs;             //  Number of times we went XOFF
    ushort   xoffErr;            //  Received data while XOFF

    ushort   dvrMemErr;          //  Memory error
    ushort   overRunErr;         //  Received character overrun errors
    ushort   frameErr;           //  Received character framing errors
    ushort   parityErr;          //  Received character parity errors
    ushort   buffOverRunErr;     //  Received buffer overrun errors
    ushort   ctsLost;
    ushort   dcdLost;
    ushort   txSccEvErr;         //  Transmitter event errors
    ushort   rxSccEvErr;         //  Receiver event errors
    };


//*** Comms parameters */

struct PRIORITY_PARM1 {
	//linecard addresses
	BYTE	lcardALine1En;
	BYTE	lcardALine1Addr[9];
	BYTE	lcardALine2En;
	BYTE	lcardALine2Addr[9];
	BYTE	lcardBLine1En;
	BYTE	lcardBLine1Addr[9];
	BYTE	lcardBLine2En;
	BYTE	lcardBLine2Addr[9];
	BYTE	lcardBackupLine1En;
	BYTE	lcardBackupLine1Addr[9];
	BYTE	lcardBackupLine2En;
	BYTE	lcardBackupLine2Addr[9];
	BYTE	netIdCard1[8];
	BYTE	netIdCard2[8];
	BYTE	netIdCardBackup[8];
};

struct PRIORITY_PARM2 {
	//parameters
	BYTE	flags;
	BYTE	contactSleepTme;
	BYTE	contactSleepWindow;
	BYTE	contactRspTme;
	BYTE	contactRetry;
	BYTE	timeBetwRetry;
	BYTE	msgRspTime;
	BYTE	msgRetry;
	BYTE	waitHeartbeatTme;
	BYTE	dialupType;
	ushort	secActivate;
	ushort	tertActivate;
};

typedef struct PRIORITY_PARM1 PRIORITYPARM1;
typedef struct PRIORITY_PARM2 PRIORITYPARM2;

struct SECONDARY_PARM1 {
	//Tel numbers
	BYTE	commsTel1En;
	BYTE	commsTel1[9];
	BYTE	alarmTel1En;
	BYTE	alarmTel1[9];
	BYTE	commsTel2En;
	BYTE	commsTel2[9];
	BYTE	alarmTel2En;
	BYTE	alarmTel2[9];
	BYTE	disasterTel1En;
	BYTE	disasterTel1[9];
	BYTE	disasterTel2En;
	BYTE	disasterTel2[9];
	BYTE	preTel1[4];
	BYTE	postTel1[4];
	BYTE	preTel2[4];
	BYTE	postTel2[4];
	BYTE	preDisast[4];
	BYTE	postDisast[4];
};

typedef struct SECONDARY_PARM1 SECONDARYPARM1;

//  error information structure ....

typedef struct NET_ERR {
    ushort callRx;                  //  I/C call message 
    ushort invCallBcRx;             //  invalid I/C call message size
    ushort invCallRtuRx;            //  invalid I/C RTU data
    ushort invCallMacRx;            //  invalid I/C MAC data
    ushort invCallTypeRx;           //  invalid I/C type of message
    ushort icTypeErr;               //  ic call data type errors
    ushort contactRx;               //  contact rx 
    ushort contactFail;             //  conatct fail - already call active 

    ushort dataRx;                  //  I/C Data message 
    ushort invDataBcRx;             //  invalid data message size
    ushort invHndRx;                //  invalid session handle
    ushort invRtuRx;                //  invalid RTU data
    ushort invMacRx;                //  invalid MAC data
    ushort invTypeRx;               //  invalid type of message
    ushort invSeqRx;                //  invalid Seq rx
    ushort invSeqTx;                //  invalid Seq Tx
    ushort invBSeqRx;               //  invalid bcast Seq rx
    ushort xoffRx;                  //  XOFF Messages received
    ushort msgRx;                   //  Rqs Messages received
    ushort msgRxBcast;              //  Bcast Rqs Messages received
    ushort invRtuMsgTypeRx;         //  Invalid RTU message type received

    ushort dataTx;                  //  TX Data message 
    ushort invDataBcTx;             //  invalid data message size
    ushort rspTout;                 //  timeout waiting for message ACK
    ushort retxMsg;                 //  retransmit last message

    ushort lineChngCmd;             //  Line change command RX
    ushort waitSleepRetry;          //  Wait for sllep time before retry

    ushort netPortFail1;            //  Prim port fail type 1
    ushort netPortFail2;            //  Prim port fail type 2
    ushort netPortFail3;            //  Prim port fail type 3
    ushort netPortFail4;            //  Prim port fail type 4
    ushort netPortFail5;            //  Prim port fail type 5
    ushort netPortFail6;            //  Prim port fail type 6
} NETERR;

typedef struct NET_ERR1 {
    ushort callRx;                  //  I/C call message 
    ushort invCallBcRx;             //  invalid I/C call message size
    ushort invCallRtuRx;            //  invalid I/C RTU data
    ushort invCallMacRx;            //  invalid I/C MAC data
    ushort invCallTypeRx;           //  invalid I/C type of message
    ushort icTypeErr;               //  ic call data type errors
    ushort contactRx;               //  contact rx 
    ushort contactFail;             //  conatct fail - already call active 

    ushort dataRx;                  //  I/C Data message 
    ushort invDataBcRx;             //  invalid data message size
    ushort invHndRx;                //  invalid session handle
    ushort invRtuRx;                //  invalid RTU data
    ushort invMacRx;                //  invalid MAC data
    ushort invTypeRx;               //  invalid type of message
    ushort invSeqRx;                //  invalid Seq rx
    ushort invSeqTx;                //  invalid Seq Tx
} NETERR1;

typedef struct NET_ERR2 {
    ushort invBSeqRx;               //  invalid bcast Seq rx
    ushort xoffRx;                  //  XOFF Messages received
    ushort msgRx;                   //  Rqs Messages received
    ushort msgRxBcast;              //  Bcast Rqs Messages received
    ushort invRtuMsgTypeRx;         //  Invalid RTU message type received

    ushort dataTx;                  //  TX Data message 
    ushort invDataBcTx;             //  invalid data message size
    ushort rspTout;                 //  timeout waiting for message ACK
    ushort retxMsg;                 //  retransmit last message

    ushort lineChngCmd;             //  Line change command RX
    ushort waitSleepRetry;          //  Wait for sllep time before retry

    ushort netPortFail1;            //  Prim port fail type 1
    ushort netPortFail2;            //  Prim port fail type 2
    ushort netPortFail3;            //  Prim port fail type 3
    ushort netPortFail4;            //  Prim port fail type 4
    ushort netPortFail5;            //  Prim port fail type 5
} NETERR2;

typedef struct NET_ERR3 {
    ushort netPortFail6;            //  Prim port fail type 6
} NETERR3;


//  EPCP parameters structure ...

struct INOVONICS_PARM {
    ushort  superviseWindow;			//  Supervise Window (secs)
    uchar   rxPollTime;				//  Receiver Poll Time (secs)
	uchar	logDevNum;				//	Logical device number
    uchar   sccResTime;				//  SCC off line reset time (in mins)
	uchar	appID;					//	Application ID
	uchar	spare[2];
    SERCFG  cfg;					//  Port configuration
    };

//  PCP error counter structure ...

struct INOVONICS_ERR {
	ushort  rxBufferOverflow;   //  Recv buffer overflow errors
	ushort  rxPktUnknownErr;    //  Recv unknown packet errors
	ushort  rxDataErr;          //  Data error in recv packet
	ushort  overRunErr;         //  Received character overrun errors
	ushort  frameErr;           //  Received character framing errors
	ushort  parityErr;          //  Received character parity errors
	ushort  buffOverRunErr;     //  Received buffer overrun errors
	ushort  ctsLost;
	ushort  dcdLost;
	ushort  txSccEvErr;         //  Transmitter event errors
	ushort  rxSccEvErr;         //  Receiver event errors

    };


struct SECURITEL_PARM {
    uchar	receiverType;			
    uchar   flags;				
	uchar	receiverOfflineTime;				
    uchar	hdiskUpdateTime;
	ushort	accountID;
	uchar	sccResTime;
	uchar	spare[6];
    SERCFG  cfg;					
    };


struct SECURITEL_ERR {
	ushort  rxSPollFromSTU;		
	ushort  rxPPollFromSTU;		
	ushort  rxInvalidPoll;      
	ushort  datBufFull;    
	ushort  rxNullPoll;    
	ushort  txInitResp;    
	ushort  txDatResp;    
	ushort  reTxDat;
	ushort  rxFrameErr;
	ushort  rxOverrunErr;    
	ushort  rxParityErr;
    ushort	datMsgOverrunErr;
	ushort	bufAllocErr;
	ushort	rxIncorrectBcnt;
	ushort	crcErr;
	ushort	txEventErr;
	ushort  rxEventErr;
    };


struct GDVR_PARM {
    uchar dvrType;				// DVR device type
    uchar dvrFlags;				// Flags for connection
    uchar sccResTime;			// SCC reset time ( mins )
    SERCFG  cfg;                // Port configuration
    uchar dvrDeviceID;			// DVR device ID
    uchar pollTime;				//  time between idle polls
	uchar maxNak;				//  max. NAKs before delete
	uchar dvrBuffers[30];		// DVR spare buffer for future use
    };

struct GDVR_ERR {
    ushort  rxCmdErr;           //  Receive command type error
    ushort  rxMsgErr;           //  Receive message type error
    ushort  rxRangeErr;
    ushort  frameErr;           //  Received character framing errors
    ushort  overRunErr;         //  Received character overrun errors
    ushort  parityErr;          //  Received character parity errors
    ushort  dataOvrn;           //  Data message overrun errors
    ushort  crcErr;             //  CRC errors
    ushort  txSccEvErr;         //  Transmitter event errors
    ushort  rxSccEvErr;         //  Receiver event errors
    };

struct MODBUS_PARM {
	uchar transmissionMode;		// Layer 2 transmission encoding mode
	uchar busInterfaceMode;		// Bus master (or just listening in)
	uchar devicePollRate;		// Poll rate (secs) for all device on this port
	uchar responseTime;			// Timeout period for polled device to respond
	SERCFG cfg;					// Serial config;
};

struct MODBUS_ERR
{
     ushort fcsError;            // Frame Check Sequence errors
     ushort deviceReplyTimeout;  // # of device reply timeouts
     ushort replyProcessingError;// # of errors processing replies
     ushort illegalFunction;     // # of illegal function exceptions
     ushort illegalDataAddress;  // # of illegal address exceptions
     ushort illegalDataValue;    // # of illegal data exceptions
     ushort slaveDeviceFailures; // # of slave device failure exceptions
     ushort ackExceptions;       // # of acknowledge exceptions
     ushort slaveDeviceBusy;     // # of slave device busy exceptions
     ushort memoryParityError;   // # of memory parity error exceptions
     ushort gatewayPathUnavail;  // # of gateway path unavailable exceptions
     ushort gatewayTargetNoResp; // # of gateway target failed respond exceptions

	 ushort dvrMemErr;           // Memory error
     ushort frameErr;            // Received character framing errors
     ushort overRunErr;          // Received character overrun errors
     ushort parityErr;           // Received character parity errors
     ushort dataOvrn;            // Data message overrun errors
     ushort crcErr;              // CRC errors
     ushort txSccEvErr;          // Transmitter event errors
     ushort rxSccEvErr;          // Receiver event errors
};

struct MODBUS_ERR1
{
     ushort fcsError;            // Frame Check Sequence errors
     ushort deviceReplyTimeout;  // # of device reply timeouts
     ushort replyProcessingError;// # of errors processing replies
     ushort illegalFunction;     // # of illegal function exceptions
     ushort illegalDataAddress;  // # of illegal address exceptions
     ushort illegalDataValue;    // # of illegal data exceptions
     ushort slaveDeviceFailures; // # of slave device failure exceptions
     ushort ackExceptions;       // # of acknowledge exceptions
     ushort slaveDeviceBusy;     // # of slave device busy exceptions
     ushort memoryParityError;   // # of memory parity error exceptions
     ushort gatewayPathUnavail;  // # of gateway path unavailable exceptions
     ushort gatewayTargetNoResp; // # of gateway target failed respond exceptions
};

struct MODBUS_ERR2
{
     ushort dvrMemErr;           // Memory error
     ushort frameErr;            // Received character framing errors
     ushort overRunErr;          // Received character overrun errors
     ushort parityErr;           // Received character parity errors
     ushort dataOvrn;            // Data message overrun errors
     ushort crcErr;              // CRC errors
     ushort txSccEvErr;          // Transmitter event errors
     ushort rxSccEvErr;          // Receiver event errors
};


struct WYRELESS_PARM
{
     uchar  addressRange;       // Range of address (0 = 1-64, 1 = 65 - 128...)
     uchar  devicePollRate;     // Poll rate (x100 mSecs) for all device on this port
	 uchar  respondTimeOut;		// Response time out
	 uchar  spare;				// Spare
     SERCFG cfg;                // Port configuration
};


//  WYRELESS error counter structure ...
struct WYRELESS_ERR
{
     ushort fcsError;            // Frame Check Sequence errors
     ushort deviceReplyTimeout;  // # of device reply timeouts
     ushort replyProcessingError;// # of errors processing replies

     ushort dvrMemErr;           // Memory error
     ushort frameErr;            // Received character framing errors
     ushort overRunErr;          // Received character overrun errors
     ushort parityErr;           // Received character parity errors
     ushort dataOvrn;            // Data message overrun errors
     ushort crcErr;              // CRC errors
     ushort txSccEvErr;          // Transmitter event errors
     ushort rxSccEvErr;          // Receiver event errors
};


//  WYRELESS fatal error counter structure ...
struct WYRELESS_FERR
{
     ushort  fatalErrors;        // Fatal errors
};

typedef struct _TimeconTTC 
{
	uchar msgRetries;			// #retries for each msg
	uchar hostPortNumber;		// Ethernet port number for connection to Timecon Host.
	uchar responseTime;			// Timeout value in x100 mSecs for device to respond to a poll
	uchar connectTo;
	ulong hostAddress;			// IP Address of the Timecon Host
	uchar spare2;
	uchar spare3;
	SERCFG serCfg;				// Port configuration
} TIMECON_TCC;

typedef struct _TimeconTTC_ERR
{
	ushort msgReceivedOK; 
	ushort checksumErrors;
	ushort msgProcessFailure;
	ushort spuriousErrors;
	ushort deviceReplyTimeout;
	ushort replyProcessingErrors;
	ushort msgTransmitOK;
	ushort badPayload;
	ushort dvrMemErrors;
	ushort frameErrors;
	ushort overrunErrors;
	ushort parityErrors;
	ushort dataOverrun;
	ushort crcErrors;
	ushort txSccEvErrors;
	ushort rxSccEvErrors;
} TIMECON_TCC_ERR;

typedef struct _TimeconTTC_FERR
{
	ushort fatalErrors;
} TIMECON_TCC_FERR;

#pragma region AperioParams

typedef struct _APERIO_PARM {
	SERCFG  serCfg;					//  Port configuration
	uchar	deviceAddressRange;		// Start of device address range (0 - 63)
}APERIO_PARM;

//  Aperio error counter structure
typedef struct _APERIO_ERR {
	ushort  NoStxErr;           //  Recv data without a STX character
	ushort  NoEtxErr;           //  Recv data without a ETX character
	ushort  InvalidSizeErr;     //  Invalid packet size
	ushort  DataSizeErr;        //  Data size field does not match true data size
	ushort  BccErr;             //  Block check character is failed
	ushort  DevResartCnt;       //  Devices restart counts
	ushort  RadioInterference;  //  Devices readio interference counts
	ushort  DevProgTool;        //  Device accessed by programming tool counts
	ushort  DevRtcFailCnt;      //  Device RTC failure counts
	ushort  DevWatchDogCnt;     //  Device watch dog counts
	ushort  DevMajorFailCnt;    //  Device serious failure counts
	ushort  DevCmdFailed;       //  Command failed
	ushort  DevUnknownCmd;      //  Unknown command
	ushort  DevInvalidField;    //  Invalid format or parameter out of range
	ushort  DevNoTag;           //  No tag in field
	ushort  DevOpFail;          //  Operation mode failure

	ushort  OverRunErr;         //  Received character overrun errors
	ushort  FrameErr;           //  Received character framing errors
	ushort  ParityErr;          //  Received character parity errors
	ushort  BuffOverRunErr;     //  Received buffer overrun errors
	ushort  TxStoreMsgErr;      //  Message could not be stored for TX
}APERIO_ERR;

#define APERIO_ERR_CNT (sizeof(APERIO_ERR)/sizeof(ushort))

//  Aperio fatal error counter structure
typedef struct _APERIO_FERR {
	uchar   FErrMakeDir;        //  Could not create a message storage directory
}APERIO_FERR;

#pragma endregion AperioParams

#pragma region LikonParams

typedef struct _LIKON_PARM {
	SERCFG  serCfg;					//  Port configuration
}LIKON_PARM;

typedef struct _LIKON_ERR {
      ushort  NoStxErr;           //  Recv data without a STX character
      ushort  NoEtxErr;           //  Recv data without a ETX character
      ushort  NoDleErr;           //  Recv data without a DLE character
      ushort  InvalidReaderErr;   //  Reader ID is out of range, should be within 1~64
      ushort  DataSizeErr;        //  Data size field does not match true data size
      ushort  PktSizeErr;         //  Package size does not match as spec defines
      ushort  BccErr;             //  Block checksum is failed
      ushort  DevCmdFailed;       //  Command failed
      ushort  AuthFailed;         //  Authentication failed

      ushort  OverRunErr;         //  Received character overrun errors
      ushort  FrameErr;           //  Received character framing errors
      ushort  ParityErr;          //  Received character parity errors
      ushort  BuffOverRunErr;     //  Received buffer overrun errors
      ushort  TxStoreMsgErr;      //  Message could not be stored for TX
}LIKON_ERR;

#pragma endregion LikonParams

//....................................................................................................
#define MAX_BYTES 256
typedef struct _PortNewCfg
{
	BYTE appBC;
	BYTE appDat[MAX_BYTES];
	BYTE sesBC;
	BYTE sesDat[MAX_BYTES];
	BYTE lnkBC;
	BYTE lnkDat[MAX_BYTES];
	BYTE lnk2BC;
	BYTE lnk2Dat[MAX_BYTES];
}PortNewCfg;

typedef struct _Port_Params
{
	BYTE nPortNumber;
	BYTE nPriority;
	BYTE nApp;
	BYTE nSes;
	BYTE nLnk;
	BYTE data[3 + MAX_BYTES + MAX_BYTES + MAX_BYTES];
	int nCurLnkPtr;
	int nByteCount;
}PortParams;

#pragma pack()



