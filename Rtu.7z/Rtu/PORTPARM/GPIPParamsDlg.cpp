/********************************************************************************************************
 *		PACOM SYSTEMS PTY LTD 	Copyright 2012
 *		File/Class Name:
 *		Description:
 *		
 *		$Revision: 4 $
 *		$History: GPIPParamsDlg.cpp $
 * 
 * *****************  Version 4  *****************
 * User: Lienl        Date: 19/03/12   Time: 12:55p
 * Updated in $/GMS/HotFixes/V4.07/Code/WSETUP/RTU/PORTPARM
 * Name space changed
 * 
 * *****************  Version 3  *****************
 * User: Lienl        Date: 3/12/12    Time: 4:51p
 * Updated in $/GMS/HotFixes/V4.07/Code/WSETUP/Rtu/PORTPARM
 * Fix: Set environment for .Net app picking up the server folder.
 * 
 * *****************  Version 2  *****************
 * User: Lienl        Date: 3/07/12    Time: 12:29p
 * Updated in $/GMS/HotFixes/V4.07/Code/WSETUP/Rtu/PORTPARM
 * Fix: use protocol Id for reference
 * 
 * *****************  Version 1  *****************
 * User: Lienl        Date: 22/02/12   Time: 3:06p
 * Created in $/GMS/HotFixes/V4.07/Code/WSETUP/RTU/PORTPARM
 * TT#7297: new file for class CGPIPParamsDlg (this class used to be in
 * SYSPARAM.CPP)

  ********************************************************************************************************/
#include "stdafx.h"

#undef WaitForSingleObject // have to do it in order to compile with MutexTrace
#include "SYSPARAM.H"
#include "atlsafe.h"

extern BOOL g_ModalFlg;
extern int realRtuType;

extern int nAccNumSize;
extern HINSTANCE hrInst;

CGPIPParamsDlg::CGPIPParamsDlg(CWnd* pParent, LPPARMPROC lpps, BYTE ByteCount)
	: CDialog(CGPIPParamsDlg::IDD, pParent)
{
	if(lpps == NULL)
		return;

	m_lppDownloadData = lpps;
	m_nByteCount = ByteCount;
	m_nIndex = 0;
	memset(&m_cfg[0], 0, sizeof(m_cfg));
	memcpy(&m_cfg[0], &lpps->lpData[1], sizeof(m_cfg));
}


void CGPIPParamsDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CGPIPParamsDlg)
	DDX_Control(pDX, IDC_CBO_PROTOCOL, m_cboProtocol);
	DDX_Control(pDX, IDC_CBO_TCP_UDP, m_cboTcpUdp);
	
	DDX_Control(pDX, IDC_IPA_ADDRESS, m_ipAddress);
	DDX_Control(pDX, IDC_TXT_TCP_UDP_PORT1, m_txtTcpUdpPort1);
	DDX_Control(pDX, IDC_TXT_TCP_UDP_PORT2, m_txtTcpUdpPort2);
	DDX_Control(pDX, IDC_CBO_LOCAL_PORT, m_cboLocalPorts);

	DDX_Control(pDX, IDC_TXT_LOG_DEV_NUM, m_txtLogicalDeviceNumber);
	DDX_Control(pDX, IDC_TXT_SUPERVISE_TIME, m_txtSuperviseTime);
	DDX_Control(pDX, IDC_CBO_PASSWORD_INDEX, m_cboPasswordIndex);
	DDX_Control(pDX, IDC_TXT_LOGIN_NAME, m_txtLoginName);

	RtuLib::DDX_Text(pDX, IDC_TXT_TCP_UDP_PORT1, m_cfg[m_nIndex].tcpUdpPort[0]);
	RtuLib::DDX_Text(pDX, IDC_TXT_TCP_UDP_PORT2, m_cfg[m_nIndex].tcpUdpPort[1]);
	
	//DDX_Text(pDX, IDC_TXT_LOCAL_PORT, m_cfg.localPort);
	//RtuLib::DDX_CBIndex(pDX, IDC_CBO_PASSWORD_INDEX, m_cfg[m_nIndex].passwordIndex);
	//}}AFX_DATA_MAP
}

#define IDC_EXTENDEDCONFIG	1000 //TT#7297
BEGIN_MESSAGE_MAP(CGPIPParamsDlg, CDialog)
	//{{AFX_MSG_MAP(CGPIPParamsDlg)
	ON_BN_CLICKED(IDCANCEL, OnCancel)
	ON_BN_CLICKED(IDOK, OnBtnDownload)
	ON_BN_CLICKED(IDC_EXTENDEDCONFIG, OnShowExtendedConfig)
	ON_CBN_SELCHANGE(IDC_CBO_PROTOCOL, OnSelChangedProtocol)
	ON_NOTIFY(UDN_DELTAPOS, IDC_SPN_NAVIGATE, OnDeltaposNavigate)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CGPIPParamsDlg message handlers
BOOL CGPIPParamsDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	//SendDlgItemMessage(IDC_TXT_LOCAL_PORT, EM_LIMITTEXT, 3);
	SendDlgItemMessage(IDC_TXT_LOGIN_NAME, EM_LIMITTEXT, GPIP_LOGIN_NAME_SIZE);
	m_txtTcpUdpPort1.SetMinMaxLimit(0, 0xffff, 5);
	m_txtTcpUdpPort2.SetMinMaxLimit(0, 0xffff, 5);
	

	InitComboBox(GetSafeHwnd(), IDC_CBO_PROTOCOL, CB_ADDSTRING, GPIPPROTOCOL_MSG_FILE);

	CStringArray strArrPorts;
	GetRtuPortList(strArrPorts, realRtuType, IsRtu8002Type());
	for(int i=0; i<strArrPorts.GetSize(); i++) {
		m_cboLocalPorts.AddString(strArrPorts.GetAt(i));
	}
	
	// extra
	m_txtLogicalDeviceNumber.SetMinMaxLimit(1, 256, 3);
	m_txtSuperviseTime.SetMinMaxLimit(0, 0xff, 3);

	CString s;
	for(int i=0; i<MAX_SYS_PWDS; i++) {
		s.Format(_T("%d"), i+1);
		m_cboPasswordIndex.AddString(s);
	}
	
	m_cboTcpUdp.AddString((CString)(LPTSTR)IDS_UDP);
	m_cboTcpUdp.AddString((CString)(LPTSTR)IDS_TCP);

	
	CRect rec;
	GetDlgItem(IDC_TXT_LOGIN_NAME)->GetWindowRect(&rec);
	ScreenToClient(&rec);
	rec.OffsetRect(rec.Width() + 5, 0);
	rec.right = rec.left + rec.Height();
	m_BtnExtended.Create(L"...", BS_PUSHBUTTON|WS_CHILD|WS_VISIBLE, rec, this, IDC_EXTENDEDCONFIG);

	ShowConfig();
	EnableExtendedConfigButton();	
	
	CheckPortEditPriv(this, FALSE);
	return TRUE;
}
void CGPIPParamsDlg::EnableExtendedConfigButton()
{
	TCHAR settings[1024] = _T("");
	BOOL bEnable = 0;
	
	CString protocolName;
	int index = m_cboProtocol.GetCurSel();
	if (index != CB_ERR)
	{
		#define GPIP_EXTENDED_SETTINGS_FILE_NAME L"GPIPExtendedSettings.config"

		TCHAR protocolNum[10] = {0};

		int protocolId = m_cboProtocol.GetItemData(index);

		wsprintf(protocolNum, L"%u", protocolId);

		if (GetPrivateProfileString(L"GPIP Protocol", protocolNum, _T(""), settings, _COUNTOF(settings), DefaultLocation(GPIP_EXTENDED_SETTINGS_FILE_NAME).Path)>10)
		{
			bEnable = 1;
		}
	}
	m_sExtendedSettings = settings;

	m_BtnExtended.EnableWindow(bEnable);
	m_BtnExtended.ShowWindow((bEnable)?SW_SHOW:SW_HIDE);
}

//////////////////////////////////////////////////////////////////////////////////////////////////////
#pragma region GPIP Extended Configuration

#import "Pacom.GMS.ExtendedConfiguration.tlb" no_namespace named_guids
LPTSTR GetApplicationPath()
{
	static TCHAR sAppPath[MAX_PATH];
	
	if (sAppPath[0] == NULL_CHR)
	{
		GetModuleFileName(NULL, sAppPath, MAX_PATH);
		LPTSTR pStr = lstrrchr(sAppPath, _T('\\'));
		if (pStr != NULL && pStr != sAppPath && *(pStr-1) != _T(':'))
			*pStr = _T('\0');
	}
	return sAppPath;
}
void CGPIPParamsDlg::OnShowExtendedConfig()
{
	if (m_sExtendedSettings.IsEmpty() == TRUE)
		return;

	CString assemblyPath = CString("");
	CString className = CString("");
	
	int semiColon = m_sExtendedSettings.Find(L";");
	if (semiColon <= 0)
		return;
	
	CString assemblyName = m_sExtendedSettings.Left(semiColon);
	className = m_sExtendedSettings.Right(m_sExtendedSettings.GetLength() - (semiColon+1));
	
	if (assemblyName.Trim().IsEmpty() == TRUE ||
		className.Trim().IsEmpty() == TRUE)
		return;

	GPIP_PARAMS_CFG cfg;
	memcpy(&cfg, &m_cfg[m_nIndex], sizeof(cfg));
	if (CoInitialize(NULL) == 0) {}
	CLSID rclsid;
	HRESULT result = CLSIDFromProgID(L"progid_Pacom.GMS.ExtendedConfiguration", &rclsid);
	
	TCHAR serverPath[MAX_PATH] = {0};

	GetGMSServerFolderPath(serverPath);

	SetEnvironmentVariable(L"GMS_SERVER_PATH", serverPath);
	try
	{
		if (SUCCEEDED(result))
		{
			IExtendedConfigurationPtr pIpController;
			pIpController.CreateInstance(rclsid);
			if (pIpController == NULL)
				return;
			
			int param_size = sizeof(cfg.params);
			
			CComSafeArray<BYTE> aData(param_size);
			for (int i = 0; i < param_size; i++)
			{
				aData[i] = cfg.params[i];
			}
		
			SAFEARRAY ** psa = aData.GetSafeArrayPtr();
			CString sAssemblyPath = assemblyName;
			if (sAssemblyPath.Find(L":") == -1)
				sAssemblyPath.Format(L"%s\\%s", GetApplicationPath(), (LPCTSTR)assemblyName);

			CString protocolName;
			m_cboProtocol.GetWindowText(protocolName);
			pIpController->ShowUserControl((LPCTSTR)protocolName, (LPCTSTR)sAssemblyPath, (LPCTSTR)className, psa);
			
			{
				for (int i = 0; i < aData.GetUpperBound(); i++)
				{
					cfg.params[i] = aData[i];
				}
			
			}
			aData.Detach();
			
			if (memcmp(cfg.params, m_cfg[m_nIndex].params, param_size) != 0)
			{
				memcpy(m_cfg[m_nIndex].params, cfg.params, param_size); // don't want to copy if it is new protocol & protocol id has not been set to the struct.
				UpdateGPIPParamWindows(cfg);
			}
		}
	}
	catch (...)
	{
		AfxMessageBox(L"Exception in handling Com GPIP configuration");
	}

	SetEnvironmentVariable(L"GMS_SERVER_PATH", NULL);
}

void CGPIPParamsDlg::UpdateGPIPParamWindows(GPIP_PARAMS_CFG& cfg)
{
	int protocol = cfg.protocol & 0x7f;

	if (protocol == E_ONSAFE_PROT ||
		protocol == E_IP_LOCK_PROT ||
		protocol == E_INOVONICS_PROT )
	{
		char loginName[GPIP_LOGIN_NAME_SIZE + 1];
		memcpy(loginName, cfg.loginName, GPIP_LOGIN_NAME_SIZE);
		loginName[GPIP_LOGIN_NAME_SIZE] = 0;
		
		SetDlgItemTextA(GetSafeHwnd(), IDC_TXT_LOGIN_NAME, loginName);
		m_cboPasswordIndex.SetCurSel(cfg.passwordIndex);
		m_txtLogicalDeviceNumber.SetValue(cfg.params[0] + 1);
		m_txtSuperviseTime.SetValue(cfg.params[1]);
	}
	else if (protocol == E_SPIDER_LOCK_PROT) // tt 8102
	{
		m_cboPasswordIndex.SetCurSel(cfg.passwordIndex);
	}
}


void CGPIPParamsDlg::UpdateLocalPortList()
{
	int nProtocol = m_cboProtocol.GetCurSel();
	int ProtocolId = 0;
	if (nProtocol != CB_ERR)
		ProtocolId = m_cboProtocol.GetItemData(nProtocol);

	BOOL bEnable = ProtocolId == E_INOVONICS_PROT ? FALSE : TRUE;
	for(int i=0; i<m_cboLocalPorts.GetCount(); i++) {
		if(!bEnable) {
			m_cboLocalPorts.SetCurItem(i, GetEnable(i));
		}
		else {
			m_cboLocalPorts.SetCurItem(i, TRUE);
		}
	}
}

#pragma endregion GPIP Extended Configuration

BOOL CGPIPParamsDlg::GetEnable(int nIndex)
{
	BOOL bResult = TRUE;
	if(realRtuType == RTU_1057_TYPE) {
		if( nIndex==1 ||		// Modem Port
			nIndex==6 ||		// Mezzanine 2 Port
			nIndex==7 ||		// Diagnostics Port
			nIndex==9 ||		// RS485 Device Loop 1
			nIndex==10) {		// RS485 Device Loop 2
			bResult = FALSE;
		}
	}
	else if(realRtuType == RTU_1058_TYPE) {
		if( nIndex==1 ||		// Modem Port 
			nIndex==4 ||		// Mezzanine Port
			nIndex==5) {		// Diagnostics Port
			bResult = FALSE;
		}
	}

	return bResult;
}

void CGPIPParamsDlg::OnSelChangedProtocol()
{
	int selectItem = m_cboProtocol.GetCurSel();
	if (selectItem == CB_ERR)
		return;
	DWORD protocolId = m_cboProtocol.GetItemData(selectItem);
	if (protocolId != m_cfg[m_nIndex].protocol)
		memset(m_cfg[m_nIndex].params, 0, sizeof(m_cfg[m_nIndex].params));

	ShowWindows((uchar)protocolId);	
	
	EnableExtendedConfigButton();
	UpdateLocalPortList();
}

void CGPIPParamsDlg::ShowWindows(uchar protocol)
{
	int nShowLoginPwd = SW_HIDE;
	int nShowDevAndTime = SW_HIDE;

	protocol &= 0x7f;
	if((protocol == E_ONSAFE_PROT) || (protocol == E_IP_LOCK_PROT)) {
		nShowLoginPwd = SW_SHOWNORMAL;

		SetDlgItemText(IDC_LBL_LOGIN_NAME, RES_STRING(IDS_LOGIN_NAME));
		SetDlgItemText(IDC_LBL_PASSWORD_INDEX, RES_STRING(IDS_PASSWORD_INDEX));
	}
	else if(protocol == E_INOVONICS_PROT) {
		nShowDevAndTime = SW_SHOWNORMAL;

		SetDlgItemText(IDC_LBL_LOGIN_NAME, RES_STRING(IDS_LOG_DEV_NUM));
		SetDlgItemText(IDC_LBL_PASSWORD_INDEX, RES_STRING(IDS_SUPERVISE_TIME));	
	}
	else if (protocol == E_SPIDER_LOCK_PROT) { // tt 8102
		SetDlgItemText(IDC_LBL_LOGIN_NAME, L"");
		SetDlgItemText(IDC_LBL_PASSWORD_INDEX, RES_STRING(IDS_MASTER_PWD_INDEX));
	}
	else
	{
		SetDlgItemText(IDC_LBL_LOGIN_NAME, L"");
		SetDlgItemText(IDC_LBL_PASSWORD_INDEX,L"");
	}

	m_txtLoginName.ShowWindow(nShowLoginPwd);

	//TT 8413: password index 0-8 for IP LOCK
	BOOL showPassInd = nShowLoginPwd || (protocol == E_SPIDER_LOCK_PROT);
	if (showPassInd == TRUE)
	{
		int defaultZeroInd =  m_cboPasswordIndex.FindString(-1, L"0");
		if (defaultZeroInd != -1 && protocol != E_IP_LOCK_PROT)
		{
			m_cboPasswordIndex.DeleteString(defaultZeroInd);
			m_cboPasswordIndex.SetCurSel(0);
		}
		else if (defaultZeroInd == -1 && protocol == E_IP_LOCK_PROT)
		{
			m_cboPasswordIndex.InsertString(0, L"0");
			m_cboPasswordIndex.SetCurSel(0);
		}
	}

	m_cboPasswordIndex.ShowWindow(showPassInd); 
	m_txtLogicalDeviceNumber.ShowWindow(nShowDevAndTime);
	m_txtSuperviseTime.ShowWindow(nShowDevAndTime);
}


void CGPIPParamsDlg::OnBtnDownload() 
{
	if(!StoreConfig())
		return;

	//  Download Params
	m_lppDownloadData->lpData[0] = PP_GPIP_PARAMS_BLK;		// Block number
	m_lppDownloadData->BC = (BYTE)(m_nByteCount + 1);	// Byte count

	send_rtuport_parms(m_lppDownloadData);
	
	CDialog::OnOK();
}

void CGPIPParamsDlg::OnCancel()
{
	CDialog::OnCancel();
}

int RTU8001_GetPortIndexFromPortNumber(int portNumber);
void CGPIPParamsDlg::ShowConfig()
{
	CString strWndText;
	strWndText.Format(RES_STRING(IDS_GPIP_PARAMS), m_nIndex+1, MAX_GPIP_PARM_DEF);
	SetWindowText(strWndText);

	ShowWindows(m_cfg[m_nIndex].protocol);

	UpdateData(FALSE);

	m_cboProtocol.SetCurSel(m_cfg[m_nIndex].protocol & 0x7f);
	m_cboTcpUdp.SetCurSel(m_cfg[m_nIndex].protocol & 0x80 ? 1 : 0);
	m_ipAddress.SetAddress(m_cfg[m_nIndex].ipAddress[0], m_cfg[m_nIndex].ipAddress[1], 
		m_cfg[m_nIndex].ipAddress[2], m_cfg[m_nIndex].ipAddress[3]);

	try
	{
		// this part will show the settings depends on the protocol type.
		// Don't know why IsWindowVisible() does not work!
		//if (m_txtLoginName.IsWindowVisible())
		{
			char loginName[GPIP_LOGIN_NAME_SIZE + 1];
			memcpy(loginName, m_cfg[m_nIndex].loginName, GPIP_LOGIN_NAME_SIZE);
			loginName[GPIP_LOGIN_NAME_SIZE] = 0;
			SetDlgItemTextA(GetSafeHwnd(), IDC_TXT_LOGIN_NAME, loginName);
		}

		//if (m_cboPasswordIndex.IsWindowVisible())
			m_cboPasswordIndex.SetCurSel(m_cfg[m_nIndex].passwordIndex);

		//if (m_txtLogicalDeviceNumber.IsWindowVisible())
			m_txtLogicalDeviceNumber.SetValue(m_cfg[m_nIndex].params[0] + 1);

		//if (m_txtSuperviseTime.IsWindowVisible())
			m_txtSuperviseTime.SetValue(m_cfg[m_nIndex].params[1]);
	}
	catch (...)
	{
	}

	int sel = m_cfg[m_nIndex].localPort;
	if(realRtuType == RTU_1058_TYPE) {
		if(sel > 3)
			sel -= 4;
	} else if(realRtuType == RTU_8001_TYPE) {
		sel = RTU8001_GetPortIndexFromPortNumber(sel);
		//switch(sel) {
		//case 0: sel = 0; break;
		//case  2: sel = 1; break;
		//case  3: sel = 2; break;
		//case  8: sel = 3; break;
		//case  9: sel = 4; break;
		//case 10: sel = 5; break;
		//case 11: sel = 6; break;
		//default: sel = -1; break;
		//}
	}

	//UpdateData(FALSE);
	UpdateLocalPortList();
	m_cboLocalPorts.SetCurSel(sel);
}

BOOL CGPIPParamsDlg::CheckConfig()
{
	if(m_txtTcpUdpPort1.GetValue() > 0xffff) {
		DispMessageBox2(GetSafeHwnd(), IDS_ENTER_RANGE, IDS_ERROR, MB_OK|MB_ICONEXCLAMATION, 0, 0xffff);
		m_txtTcpUdpPort1.SetFocus();
		m_txtTcpUdpPort1.SetSel(0, 5);
		return FALSE;
	}
		

	if(m_txtTcpUdpPort2.GetValue() > 0xffff) {
		DispMessageBox2(GetSafeHwnd(), IDS_ENTER_RANGE, IDS_ERROR, MB_OK|MB_ICONEXCLAMATION, 0, 0xffff);
		m_txtTcpUdpPort2.SetFocus();
		m_txtTcpUdpPort2.SetSel(0, 5);
		return FALSE;
	}
		
	if (m_txtLogicalDeviceNumber.IsWindowVisible())
	{
		int nLogDevNum = (int)m_txtLogicalDeviceNumber.GetValue();
		if(nLogDevNum < 1 || nLogDevNum > 256) {
			DispMessageBox2(GetSafeHwnd(), IDS_ENTER_RANGE, IDS_ERROR, MB_OK|MB_ICONEXCLAMATION, 1, 256);
			m_txtLogicalDeviceNumber.SetFocus();
			m_txtLogicalDeviceNumber.SetSel(0, 3);
			return FALSE;
		}
	}

	if(m_txtSuperviseTime.IsWindowVisible() && m_txtSuperviseTime.GetValue() > 0xff) {
		DispMessageBox2(GetSafeHwnd(), IDS_ENTER_RANGE, IDS_ERROR, MB_OK|MB_ICONEXCLAMATION, 0, 0xff);
		m_txtSuperviseTime.SetFocus();
		m_txtSuperviseTime.SetSel(0, 3);
		return FALSE;
	}

	return TRUE;
}

BOOL CGPIPParamsDlg::StoreConfig()
{	
	if(!UpdateData(TRUE))
		return FALSE;

	if(!CheckConfig()) {
		return FALSE;
	}

	int selectedItem = m_cboProtocol.GetCurSel();

	int ProtocolId = 0;
	if (selectedItem != CB_ERR)
		ProtocolId = m_cboProtocol.GetItemData(selectedItem);

	uchar protocol = (uchar)(ProtocolId/*m_cboProtocol.GetCurSel()*/ & 0x7f);

	if(m_cboTcpUdp.GetCurSel() == 1)
		protocol |= 0x80;

	m_cfg[m_nIndex].protocol = protocol;

	if(((protocol & 0x7f) == E_ONSAFE_PROT) && !(protocol & 0x80)) {
		DispMessageBox(GetSafeHwnd(), IDS_ONSAFE_PROT_WARNING, IDS_WARNING, MB_OK | MB_ICONEXCLAMATION);
	}

	m_ipAddress.GetAddress(m_cfg[m_nIndex].ipAddress[0], m_cfg[m_nIndex].ipAddress[1], 
		m_cfg[m_nIndex].ipAddress[2], m_cfg[m_nIndex].ipAddress[3]);

	protocol = (uchar)(protocol & 0x7f);

	if((protocol == E_ONSAFE_PROT) || (protocol == E_IP_LOCK_PROT)) {
		char loginName[GPIP_LOGIN_NAME_SIZE + 1];
		GetDlgItemTextA(GetSafeHwnd(), IDC_TXT_LOGIN_NAME, loginName, GPIP_LOGIN_NAME_SIZE+1);
		memcpy(m_cfg[m_nIndex].loginName, loginName, GPIP_LOGIN_NAME_SIZE);
		m_cfg[m_nIndex].passwordIndex = (BYTE)m_cboPasswordIndex.GetCurSel();
	}
	else if(protocol == E_INOVONICS_PROT) {
		m_cfg[m_nIndex].params[0] = (BYTE)(m_txtLogicalDeviceNumber.GetValue() - 1);
		m_cfg[m_nIndex].params[1] = (BYTE)m_txtSuperviseTime.GetValue();
	}
	else if (protocol == E_SPIDER_LOCK_PROT) { // tt 8102
		m_cfg[m_nIndex].passwordIndex = (BYTE)m_cboPasswordIndex.GetCurSel();
	}
	
		
	int sel = m_cboLocalPorts.GetCurSel();
	if(realRtuType == RTU_1058_TYPE) {
		if(sel >= 4)
			sel += 4;
	} 
	else if(realRtuType == RTU_8001_TYPE) {
		switch(sel) {
		case  1: sel = 2 ; break;
		case  2: sel = 3 ; break;
		case  3: sel = 8 ; break;
		case  4: sel = 9 ; break;
		case  5: sel = 10; break;
		case  6: sel = 11; break;
		default: sel = 0 ; break;
		}
	}
	m_cfg[m_nIndex].localPort = (BYTE)sel;

	memcpy(&m_lppDownloadData->lpData[1], &m_cfg, sizeof(m_cfg));
	
	return TRUE;
}

void CGPIPParamsDlg::OnDeltaposNavigate(NMHDR* pNMHDR, LRESULT* pResult) 
{
	if(StoreConfig()) {
		NM_UPDOWN* pNMUpDown = (NM_UPDOWN*)pNMHDR;
		if(pNMUpDown->iDelta == 1) {
			if(m_nIndex) {
				m_nIndex -= 1;
			} else {
				m_nIndex = MAX_GPIP_PARM_DEF - 1;
			}
		}
		else {
			if(++m_nIndex >= MAX_GPIP_PARM_DEF) {
				m_nIndex = 0;
			}
		}
		ShowConfig();
		EnableExtendedConfigButton();	
	}

	*pResult = 0;
}
