/*----------------------------------------------------------------------------
			HEADER FILE FOR RTU PARAMETER EDIT FILES
----------------------------------------------------------------------------*/
/*------------------------ GENERAL EQUATES ---------------------------------*/
#pragma once

#include "MyLib\SetupParmsStructs.h"
#include "StaticColor.h"
#include "NumEditEx.h"
#include "Setup.h"
#include "GMS\CommonUse\TypedefsStdTypes.h"


#define	UWM_EXE_SYS_CMD					(WM_GMS + 1)
#define UWM_ALARM_HARDWARE_CFG_UPLOADED (WM_GMS + 2)
#define UWM_CONFIG_UPLOADED				(WM_GMS + 3)
#define UWM_CONFIG_DOWNLOADED			(WM_GMS + 4)
#define UWM_ALARM_HARDWARE_CFG_DWLOADED (WM_GMS + 5)
#define UWM_CONFIG_CHANGED				(WM_GMS + 6)
#define UWM_CONFIG_DOWNLOADING			(WM_GMS + 7)

#define CONFIG_START_DOWNLOADING	1
#define CONFIG_FINISH_DOWNLOADING	2

// Upload/download config type
#define ALARM_CONFIG_TYPE		1
#define CARD_ACCESS_CONFIG_TYPE	2
#define BMS_CONFIG_TYPE			3
#define PORT_CONFIG_TYPE		4

// Bms config type
#define BMS_GEN_CFG		0
#define BMS_PCNT_CFG	1
#define BMS_BACNET_CFG	2
#define BMS_MODBUS_CFG	3
#define BMS_MACROS_CFG	4

#define		TOTAL_MODELESS_DLGS		1
#define		TOTAL_MODAL_DLGS		5
#define		RTU_CMD_DLG		0
#define		RTU_ADD_DLG		1
#define		RTU_DIAL_DLG	2
#define		RTU_ACCT_DLG	3
#define		RTU_BCAST_DLG	4

#define	OSNA_COMM_SIZE		80
#define	SNA_COMM_SIZE		84
#define	NSNA_COMM_SIZE		(84+2*9)	//.New SNA parms size (9/11/98)
#define	X25_COMM_SIZE		77
#define	UDP_COMM_SIZE		(81+5)
#define	ASYNC_COMM_SIZE		6
#define	RTU_OPNCNT		20


#define		MAX_ALARM_TYPE	128

#define	MAX_X25_LEN		18			//.X25 address length

#define PRM_BSIZE_CNT 4             /*  Number of parameter block sizes  */
#define PBS_MAX PRM_BSIZE_CNT+13    /*  Max no of data bytes in blk size msg  */
#define PBS_MIN PRM_BSIZE_CNT       /*  Min no of data bytes in blk size msg  */
#define PRM_BSIZE_DEF 1             /*  Default block size to select  */
#define PRM_BSIZE_DEF1 2            /*  Default block size to select for SNA*/
#define PRM_BSIZE1 6                /*  Default RTU parameter block size 1  */
#define PRM_BSIZE2 12               /*  Default RTU parameter block size 2  */
#define PRM_BSIZE3 18               /*  Default RTU parameter block size 3  */
#define PRM_BSIZE4 24               /*  Default RTU parameter block size 4  */
#define MAX_PBLK_SIZE 240           /*  Maximum parameter block size  */

#define RTU_BUFF_SIZE 250



  	/*------- 1. For SETUP5.C ------------*/
#define		Far		5

#define		MAX_ALM_CNT		256
#define		ALM_PER_PAGE	16
#define		MAX_ALM_PG		(MAX_ALM_CNT/ALM_PER_PAGE)
#define		MAX_RELAY_DEF_CNT 4

#define		EXTALM_CNT		16
#define		MAX_VOCAB		251
#define		MAX_OUTV		128
#define		SV_LEN			17			/* 17 chars/Special vocab */
#define		SV_NO			251			/* Starting special vocab# */
#define		RTU_MENU_CNT	16
#define		ALM_CFG_CNT		15			/* 15 parameters in ALM_CFG screen*/

#define		PEND_PT		1					/*0*/
#define		DAY_PT		2					/*1*/
#define		NIGHT_PT	4					/*2*/
#define		C_PT		DAY_PT+NIGHT_PT		/*1*/
#define		LATCH_PT	8					/*3*/
#define		ATM_PT		0x10
#define		CLNR_PT		0x20
#define		PRIMARY_PT	0x40
#define		SECOND_PT	0x80
#define		MAINT_PT	0x0100		/* SECOND BYTE OF 'IN_CONFIG' */
#define		PA_PT		0x0200		/* Bit#1 */
#define		TAMP_PT		0x0400		/* Bit#2 */
#define		FORCED_ZONE	0x0800
#define		AUX_PT		0x1000

#define		RELAY_1		0		/* BITS IN 'IN_RELAYS' */
#define		RELAY_2		1
#define		RELAY_3		2
#define		RELAY_4		3

#define		PROG		0	/* CODES FOR 'RELAY_DEF' BYTE. */
#define		SIREN		1
#define		STROBE		2
#define		FCAMERA		3
#define		VIDEO		4
#define		WARNLGT		5
#define		SCREEN		6
#define		EX_BELL		7
#define		IN_BELL		8

	/*------- SYS_FLAG BIT ASSIGNMENT -------*/

#define		BELL_LF		1
#define		BELL_CF		2
#define		LOCISL		4
#define		ISOALL		8
#define		ORNSEAL		0X10
#define		LOCPCLS		0X20
#define		DA_SONA		0X40
#define		ENGISL		0X80
#define		DIALTST		1
#define		AUX_ENAB	0x80

		   /*--------- For SETUP52.C -----------*/

#define		MAX_FLTRS	21
#define		MAX_DLY 800			/* Min 3 digits in an ID */
#define		MIN_DLY	200

#define		MAXTELDGT	18

/*--------------------------------------------------------------------------*/
  	/*------- 1. For NEW_S5.C ------------*/

#define		nMAXALM_CNT		256
#define		nMAXPG			16
#define		nMAXPG1			4
#define		nEXTALM_CNT		16
#define		nOUTV_CNT		64
#define		nMAX_VOCAB		251
#define		nMAX_OUTV		128
#define		nSV_LEN			21			/* 17 chars/Special vocab */
#define		nSV_NO			251			/* Starting special vocab# */
#define		nRTU_MENU_CNT	16
#define		nALM_CFG_CNT 	17			/* 15 parameters in ALM_CFG screen*/
#define		nLINK_CFG_CNT	16
#define		nMAX_IC			14
#define		nMAX_OG			14

#define		nDAY_PT			1				/*1*/
#define		nNIGHT_PT		2				/*2*/
#define		nC_PT			nDAY_PT+nNIGHT_PT
#define		nCLNR_PT		4				/*3*/
#define		nATM_PT 		8
#define		nRA_PT			0x10
#define		nTA_PT			0x20
#define		nTEMP1_PT		0x40
#define		nTEMP2_PT		0x80
#define		nSELFT_PT		0x0100		/* SECOND BYTE OF 'IN_CONFIG' */
#define		nEED_PT			0x0200		/* Bit#1 */
#define		nTEST_PT		0x0400		/* Bit#2 */
#define		nTAMP_PT		0X0800
#define		nPIR_PT			0X1000

#define		rtu_no_loc	18

#define		nFac		18
#define		nFar		5
#define		nLar		nFar+nALM_CFG_CNT-1
#define		nMAX_PA		17

#define		Lfc			8
#define		Lfc1		27
#define		Lfc2		Lfc1+16
#define		Lfr			6
#define		Llr			21

#define		Ofc		26
#define		OCM		40
#define		Ofr		5
#define		Olr		20


#define		nvfc	27				/* clm# to get vocab# */
#define		nvfr	5
#define		nvlr	nvfr+5
#define		nvmc	29

#define		ndvc	45				/* First clm for time delays */
#define		ndfr	5
#define		ndlr	ndfr+10

#define		ngfc	45				/* First clm for general parameters */
#define		ngfr	5
#define		nglr	ngfr+4

#define		bhfr	6					//.Default branch hours.
#define		bhlr	bhfr+6
#define		bhfc	12
#define		schfr	5
#define		schlr	11
#define		schfc	12

#define		tdofr	5					//.Time driven outputs.
#define		tdolr	5+15

#define     tspfr   5					//.Temp schedule pool
#define     tsplr   tspfr+9

#define     verfc   37					//.Config version etc.
#define     verfr   5
#define     verlr   verfr+8

		   /*--------- For NEW_S53.C -----------*/
#define		ncfr		5
#define		nclr		ncfr+6
#define		nclr1		ncfr+7
#define		ncfc		38
#define		ncfc1		32

		   /*--------- For SETUP0.C -----------*/

#define		NO_OF_PW	8
#define		pwfr		5
#define		pwfc		35
#define		pwlr		pwfr+7


		/*+++++++++++++++ End of SETUP5.H +++++++++++++*/

#define PRN_FMT_EXCEL 1
#define PRN_FMT_HTML  2
//#define RTU_1026_TYPE 4
//#define RTU_1057_TYPE 19
//#define RTU_2000_TYPE 22
//#define RTU_1058_TYPE 23
//#define RTU_PX8_TYPE  24
//#define RTU_8001_TYPE 25
//#define RTU_8002_TYPE (RTU_8001_TYPE | 0x1000) // TT 7516: RTU_8001_TYPE with 2 Ethernet ports, this value should not use for realRtuType.
//
//#define PANEL_8001_TYPE 65

#ifndef RC_INVOKED
#pragma	pack(1)
typedef struct AlmData {
	short	in_config[MAX_ALM_CNT];
	BYTE	in_vocab [MAX_ALM_CNT];
	BYTE	in_relay [MAX_ALM_CNT];
	char	relay_def[MAX_RELAY_DEF_CNT];
	BYTE	out_vocab[5];
	char	reset_type;
	char	set_zone;
	BYTE	sys_flags[2];

	WORD	SE , EE;			/* DELAY VALUE */
	BYTE	ED1,ED2,XD1,XD2,PD,TD;
	WORD	AD,MD;
	BYTE	LD,SD,FD,HD,BD;
	WORD	CD;

	short	max_frame;
	short	film_low;
	BYTE	susp_time;
	
	BYTE	ATMCode[4];			//.These 3 parms are for MP1003-TYPE RAP 
	BYTE	CAMCode[4];
	BYTE	CamTime;			//.Actually its just before 'max_frame'
	}ALMDATA;

typedef struct tagDIParm {
	char	Proto;
	WORD	Acct;
	BYTE	Point[16*3];
	BYTE	Codes[6];
	}DIPARM;

typedef struct _R2000_PARMS_U {
    BYTE	PointNo;
	BYTE	PointType;
	BYTE	Users;
	BYTE	RSD;
	BYTE	Vocab;
	BYTE	Block;
	BYTE	BlockPoint;
	BYTE	Outputs;
	}R2000APS_U, far *LPR2000APSU;


typedef struct _R2000_PARMS_D {
    BYTE	PointNo;
	BYTE	PointType;
	BYTE	Users;
	BYTE	RSD;
	BYTE	Vocab;
	BYTE	Block;
	BYTE	BlockPoint;
	BYTE	spare1_3[3];
	BYTE	Outputs;
	}R2000APS_D, far *LPR2000APSD;

#pragma	pack()
#endif

/*--------------------------------------------------------------------------*/

/*--------------------------------------------------------------------------*/
int GetNumAreas();
int GetMaxAreas();

BOOL WINAPI GetVocab(HWND, UINT, WPARAM, LPARAM);
BOOL WINAPI ProcSaveDef(HWND, UINT, WPARAM, LPARAM);

#ifndef _WIN32
void WINAPI Pack_Tel(LPTSTR str, LPBYTE tel);
#endif

int		GetAlarmTypes(HWND hWnd, int ipType, LPTSTR p1);
int		ReadAlmFiles(HWND hWnd);
int		SelectVocab(HWND hWnd, int vType, int cVocab);
void	DisVocab(HDC hdc, int i, int c5, int row, int clm);
LPTSTR	Deflt_Rtn(LPPARMPROC lpps, int FN,void far *ptr, int size, int acc);
int 	InitSoftData(HWND hWnd);
int 	DeleteSoftData();
int 	MakeX25Addr(LPTSTR lpistr, LPBYTE lpostr);
void  	GetX25Str(LPBYTE pPacked, LPTSTR pUnpacked);
void 	InitAddressDlg(HWND hDlg, int nSel, int nFlg, int nBaud);
void 	InitEncodeType(HWND hDlg, UINT NetType, UINT type);

/*--------------------------------------------------------------------------*/
BOOL WINAPI GetListenInParm(HWND, UINT, WPARAM, LPARAM);

BOOL WINAPI GetRtuConfig(HWND, UINT, WPARAM, LPARAM);
long WINAPI EditAlarmParms(HWND, UINT, WPARAM, LPARAM);
long WINAPI DisRtuStatus(HWND, UINT, WPARAM, LPARAM);
long WINAPI EditCommParms(HWND, UINT, WPARAM, LPARAM);
long WINAPI EditClnrSch(HWND, UINT, WPARAM, LPARAM);
long WINAPI EditClientIds(HWND, UINT, WPARAM, LPARAM);
long WINAPI	DisDiagErrs(HWND, UINT, WPARAM, LPARAM);
BOOL WINAPI EditRtuPanelType(HWND, UINT, WPARAM, LPARAM);
long WINAPI EditFltrDly(HWND, UINT, WPARAM, LPARAM);
BOOL WINAPI	ExecSoftCmds(HWND, UINT, WPARAM, LPARAM);
BOOL /*WINAPI*/ ProcSoftUL(HWND, UINT, WPARAM, LPARAM);
BOOL /*WINAPI*/ ProcSoftDL(HWND, UINT, WPARAM, LPARAM);

BOOL WINAPI EditTimeSchdl(HWND, UINT, WPARAM, LPARAM);
BOOL WINAPI EditRtuAddress(HWND, UINT, WPARAM, LPARAM);
BOOL WINAPI ProcRtuAcctDlg(HWND, UINT, WPARAM, LPARAM);
BOOL WINAPI ExecRtuCmds(HWND, UINT, WPARAM, LPARAM);
BOOL WINAPI Edit1026Ports(HWND, UINT, WPARAM, LPARAM);
BOOL WINAPI EditModemPort(HWND, UINT, WPARAM, LPARAM);
BOOL WINAPI EditRtuPortCfg(HWND, UINT, WPARAM, LPARAM);
BOOL WINAPI EditR2000AlmParms(HWND, UINT, WPARAM, LPARAM); 
BOOL WINAPI EditR2000CommParms(HWND, UINT, WPARAM, LPARAM); 
BOOL WINAPI EditR2000EETimes(HWND, UINT, WPARAM, LPARAM); 
BOOL WINAPI EditM1003TimeZone(HWND, UINT, WPARAM, LPARAM); 

int	 EditRtuParams(LPPARMPROC lpps, int option);
int	 EditEuroParams(LPPARMPROC lpps, int option);
int	 ViewRtuStats(LPPARMPROC lpps, int option);
BOOL EditListeninParms(HWND hpWnd, LPPARMPROC lpps);

void ShowAlarmParm(PDATAINPUT pdi, HWND hWnd, HDC hdc);
void MakeAlarmParm(PDATAINPUT pdi, int rp, int cp, int key);
void ShowAlarmParm1(PDATAINPUT pdi, HWND hWnd, HDC hdc);
void MakeAlarmParm1(PDATAINPUT pdi, int rp, int cp, int key);
void ShowAlarmVocabs(PDATAINPUT pdi, HWND hWnd, HDC hdc);
void MakeAlarmVocabs(PDATAINPUT pdi, int rp, int cp, int key);
void ShowAlarmDelays(PDATAINPUT pdi, HWND hWnd, HDC hdc);
void MakeAlarmDelays(PDATAINPUT pdi, int rp, int cp, int key);
void ShowAlarmGPs(PDATAINPUT pdi, HWND hWnd, HDC hdc);
void MakeAlarmGPs(PDATAINPUT pdi, int rp, int cp, int key);

void 	read_struct(UINT RtuNo);
void 	write_struct(LPTSTR lpfile);
void 	DisSpcVocab(HWND hWnd, int voc, int row);
int 	GetRtuLUN(LPTSTR line);
BOOL 	ProcDIMouse(LPDATAINPUT lpdi, LPARAM lParam, int idx);

void	ShowAlarmGP1(PDATAINPUT pdi, HWND hWnd, HDC hdc);
void	ShowAlarmParms2(PDATAINPUT pdi, HWND hWnd, HDC hdc);
void	ShowAlarmGP2(PDATAINPUT pdi, HWND hWnd, HDC hdc);
void	MakeAlarmGP1(PDATAINPUT pdi, int rp, int cp, int key);
void	MakeAlarmParms2(PDATAINPUT pdi, int rp, int cp, int key);
void	MakeAlarmGP2(PDATAINPUT pdi, int rp, int cp, int key);

void	ShowSNARtuParms1(LPDATAINPUT pdi, HDC hdc, LPBYTE lpgp);
void	ShowSNARtuParms2(LPDATAINPUT pdi, HDC hdc, LPBYTE lpgp);
void	ShowX25RtuParms1(LPDATAINPUT pdi, HDC hdc, LPBYTE lpgp);
void	ShowX25RtuParms2(LPDATAINPUT pdi, HDC hdc, LPBYTE lpgp);

void	MakeSNARtuParms1(LPDATAINPUT pdi, LPBYTE lpgp, int key);
void	MakeSNARtuParms2(LPDATAINPUT pdi, LPBYTE lpgp, int key);
void	MakeX25RtuParms1(LPDATAINPUT pdi, LPBYTE lpgp, int key);
void	MakeX25RtuParms2(LPDATAINPUT pdi, LPBYTE lpgp, int key);

void	ShowUDPRtuParms(LPDATAINPUT pdi, HDC hdc, LPBYTE lpgp);
void	MakeUDPRtuParms(LPDATAINPUT pdi, LPBYTE lpgp, int key);

void 	ShowAsyncRtuParms(LPDATAINPUT pdi, HDC hdc, LPBYTE lpgp);
void 	MakeAsyncRtuParms(LPDATAINPUT pdi, LPBYTE lpgp, int key);

void	Show1057RtuParms1(LPDATAINPUT pdi, HDC hdc, LPBYTE lpgp);
void	Make1057RtuParms1(LPDATAINPUT pdi, LPBYTE lpgp, int key);
void	Show1057RtuParms2(LPDATAINPUT pdi, HDC hdc, LPBYTE lpgp);
void	Make1057RtuParms2(LPDATAINPUT pdi, LPBYTE lpgp, int key);

/*----------------------- Europlex Panel Routines --------------------------*/

BOOL ReadEuroAlmFiles(HWND hWnd, UINT RtuNo);
void WriteEuroAlmFiles(LPPARMPROC lpps, LPTSTR lpFile, int bDL);
void ShowAlarmParm3(PDATAINPUT pdi, HWND hWnd, HDC hdc);
void MakeAlarmParm3(PDATAINPUT pdi, int rp, int cp, int key);
void ShowAlarmVocabs3(PDATAINPUT pdi, HWND hWnd, HDC hdc);
void MakeAlarmVocabs3(PDATAINPUT pdi, int rp, int cp, int key);
void ShowAlarmDelays3(PDATAINPUT pdi, HWND hWnd, HDC hdc);
void MakeAlarmDelays3(PDATAINPUT pdi, int rp, int cp, int key);
void ShowOutputVocabs(PDATAINPUT pdi, HWND hWnd, HDC hdc);
void MakeOutputVocabs(PDATAINPUT pdi, int rp, int cp, int key);

BOOL ReadEuroSchFiles(HWND, int, UINT);
void WriteEuroSchFiles(LPPARMPROC lpps, LPTSTR lpFile, int bDown);
void ShowEuroSch(PDATAINPUT pdi, HWND hWnd, HDC hdc, int id);
void MakeEuroSch(LPPARMPROC lpps, PDATAINPUT pdi, int rp, int cp, int key);
void ShowEuroCal(PDATAINPUT pdi, HWND hWnd, HDC hdc, LPBYTE lpcal, BOOL cType);
void MakeEuroCal(LPPARMPROC lpps, PDATAINPUT pdi, int rp, int cp,
				int key, LPBYTE lpcal);
void ProcEuroCalMouse( LPDATAINPUT lpdi, LPARAM lParam);

BOOL ReadEuroUserFiles(HWND, UINT);
void WriteEuroUserFiles(LPPARMPROC lpps, LPTSTR lpFile, int bDown);
void ShowEuroUsers( PDATAINPUT pdi, HWND hWnd, HDC hdc);
void MakeEuroUsers(LPPARMPROC lpps,  PDATAINPUT pdi, int rp, int cp, int key);
//void WINAPI TranslateEuroText(LPSTR lpText, UINT size, BOOL bEuro);
BOOL WINAPI ProcUserOptions(HWND, UINT, WPARAM, LPARAM);
BOOL WINAPI EditLiteral(HWND, UINT, WPARAM, LPARAM);
long WINAPI EditMonthlyCal(HWND, UINT, WPARAM, LPARAM);
BOOL WINAPI ViewSystemLog(HWND, UINT, WPARAM, LPARAM);

BOOL WINAPI EditUserIDs(HWND, UINT, WPARAM, LPARAM);
BOOL WINAPI EditUserSchedule(HWND, UINT, WPARAM, LPARAM);
BOOL WINAPI EditMosClnrSch(HWND, UINT, WPARAM, LPARAM); 
BOOL WINAPI EditAuxSchedule(HWND, UINT, WPARAM, LPARAM); 
BOOL WINAPI EditMosUserIDs(HWND, UINT, WPARAM, LPARAM);  
//...............................................
void display_id(HDC hdc, int row, int col, LPBYTE idbuff, int Bytes);
int  Get_id (HWND hWnd, int rp, int cp, int fr, int fc, LPBYTE idbuff, int Bytes);

//#ifdef __cplusplus
//}
//#endif

#ifdef _WIN32
#define	PACOM_EXT_API	//AFX_EXT_API
PACOM_EXT_API void WINAPI SendRTZBcastCmd(HWND hDlg, LPPARMPROC lcps);
PACOM_EXT_API void WINAPI SendRTZBcastCmd2(int idx, LPTSTR str, LPPARMPROC lcps);
PACOM_EXT_API int  WINAPI InitTimeZone(HWND hDlg, UINT dlgId);
PACOM_EXT_API int  WINAPI GetAlmParms(LPPARMPROC lpps, int RtuType, uint blksize);
PACOM_EXT_API void WINAPI GetRtuVocab(LPPARMPROC lpps); // written for TT#5950
PACOM_EXT_API void WINAPI SaveRtuVocab(LPPARMPROC lpps); // written for TT#5950
PACOM_EXT_API int  WINAPI ReadVocabData(HWND hWnd, LPBYTE p1, uint cnt, UINT bPsp);
PACOM_EXT_API void WINAPI ConvertOld2New1003(LPBYTE p1);
PACOM_EXT_API LPSTR WINAPI GetPanelType(int iType, LPTSTR lpRtuType=NULL);
PACOM_EXT_API int  WINAPI SendRtuDialoutCmd(HWND hWnd, int RtuNo);
PACOM_EXT_API BOOL WINAPI SetRtuAddress(HWND hpWnd/*, SETUPPARM* lpSetup*/);
PACOM_EXT_API HWND WINAPI DisplayRTUConfiguration(HWND hpWnd, SETUPPARM* rtuParams);
PACOM_EXT_API BOOL WINAPI ExecRtuCommands(HWND hpWnd, SETUPPARM* rtuParams);
PACOM_EXT_API BOOL WINAPI ShowRtuAcctDetail(HWND hpWnd, DWORD rtuNo_rtuType);
PACOM_EXT_API void WINAPI SendBMS(LPBYTE lpData, int count);
PACOM_EXT_API BOOL WINAPI EditCCUPortParams(HWND hDlg, LPPARMPROC lpps);
PACOM_EXT_API LPTSTR WINAPI GetRTUType(int RtuType);

#else
void WINAPI SendRTZBcastCmd(HWND hDlg, LPPARMPROC lcps);
void WINAPI SendRTZBcastCmd2(int idx, LPTSTR str, LPPARMPROC lcps);
int  WINAPI InitTimeZone(HWND hDlg, UINT dlgId);
int  WINAPI GetAlmParms(LPPARMPROC lpps, int RtuType, uint blksize);
void WINAPI GetRtuVocab(LPPARMPROC lpps); // written for TT#5950
void WINAPI SaveRtuVocab(LPPARMPROC lpps); // written for TT#5950
int  WINAPI ReadVocabData(HWND hWnd, LPBYTE p1, uint cnt, UINT bPsp);
void WINAPI ConvertOld2New1003(LPBYTE p1);
LPSTR WINAPI GetPanelType(int iType);
int  WINAPI SendRtuDialoutCmd(HWND hWnd, int RtuNo);
BOOL WINAPI SetRtuAddress(HWND hpWnd, SETUPPARM* lpSetup);
HWND WINAPI DisplayRTUConfiguration(HWND hpWnd, SETUPPARM* lpSetup);
BOOL WINAPI ExecRtuCommands(HWND hpWnd, SETUPPARM* lpSetup);
BOOL WINAPI ShowRtuAcctDetail(HWND hpWnd, LPARAM lParam);
LPTSTR WINAPI GetRTUType(int RtuType);
#endif

void CheckPortEditPriv(CWnd*, BOOL);			
BOOL SaveAddress(BYTE type, LPBYTE address, TCHAR *string);
BOOL ValidateEdtCtrl(HWND hDlg, UINT ctrlID, int min, int max);

class CRtu
{
public:
	static void	DisP1026Version(HWND hWnd, LPRTUVERSION p1, BOOL hwRevFlag, BOOL bRijndaelVer=FALSE);
	static void DisplayControllerLicenseOptions(CWnd* pParentWnd, LPBYTE lpData, BYTE address1, BYTE address2);
};

/*--------------------------------------------------------------------------*/
/*==========================================================================*/
/////////////////////////////////////////////////////////////////////////////
// CRTULicenceRenew
class CRTULicenceRenew : public CDialog
{
// Construction
public:
	CRTULicenceRenew(int option, BYTE addr1, BYTE addr2, CWnd* pParent = NULL, BOOL bLicenceLimit = FALSE, BYTE nLicenceNum = 0) : 
	  CDialog(CRTULicenceRenew::IDD, pParent)
	  { 
		  m_nOption = option;
		  m_nAddress1 = addr1;
		  m_nAddress2 = addr2;
		  m_bLicenceLimit = bLicenceLimit;
		  m_nLicenceNum = nLicenceNum;
		  m_nLimits = 0;
		  m_hParent = pParent->GetSafeHwnd();
	  };  

	  ushort GetLicenceLimit();
// Dialog Data
	//{{AFX_DATA(CRTULicenceRenew)
	enum { IDD = IDD_RTU_LICENCE_RENEW };
	//}}AFX_DATA

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CRTULicenceRenew)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CRTULicenceRenew)
	virtual BOOL OnInitDialog();
	afx_msg void OnCancel();
	afx_msg void OnOK();
	//afx_msg LRESULT OnGms(WPARAM wParam, LPARAM lParam);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	int m_nOption;
	HWND m_hParent;
	BYTE m_nAddress1, m_nAddress2;
	BOOL m_bLicenceLimit;
	BYTE m_nLicenceNum;
	CNumEditEx m_txtLicenceNum;
	ushort m_nLimits;

	void GetLicenceCode(LPBYTE pData);
};

#define NUM_SER_OPTION 7
/*==========================================================================*/
/////////////////////////////////////////////////////////////////////////////
// CRTUSernoData
class CRTUSernoData : public CDialog
{
// Construction
public:
	enum {E_NUM_OPTIONS = 13, E_NUM_MEZZ = 6};

	CRTUSernoData(LPBYTE pLicenceData, BYTE addr1, BYTE addr2, UINT nDlgID, CWnd* pParent = NULL);
	void SetLicenceOption(char* ptr);
	void ShowLicenceOption(void);
// Dialog Data
	//{{AFX_DATA(CRTUSernoData)
	//enum { IDD = IDD_RTU_SERNO_DLG };
	//}}AFX_DATA

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CRTUSernoData)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CRTUSernoData)
	virtual BOOL OnInitDialog();
	afx_msg void OnOK();
	afx_msg void OnBtnEthernet(){ChangeOption(0);};
	afx_msg void OnBtnAccess(){ChangeOption(1);};
	afx_msg void OnBtnAlmPanel(){ChangeOption(2);};	
	afx_msg void OnBtnElevator(){ChangeOption(3);};
	afx_msg void OnBtnIriProt(){ChangeOption(4);};
	afx_msg void OnBtnDualRpt(){ChangeOption(5);};
	afx_msg void OnBtnMultiFormat(){ChangeOption(6);};
	afx_msg void OnBtnPtzDriver(){ChangeOption(7);};
	afx_msg void OnBtnInnovonics(){ChangeOption(8);};
	afx_msg void OnBtnHostHLI(){ChangeOption(9);};
	afx_msg void OnBtnRemoteMaint(){ChangeOption(10);};
	afx_msg void OnBtnGenDVRInterface(){ChangeOption(11);};
	afx_msg void OnBtnEPAP(){ChangeOption(12);};
	//afx_msg void OnBtnUpdateOemIP(){ m_nLicenceLimitNumber = 0; ChangeLicenceLimit();};
	afx_msg void OnBtnUpdateNumberOfAperioReaders(){ m_nLicenceLimitNumber = 1; ChangeLicenceLimit();};
	afx_msg LRESULT OnGms(WPARAM wParam, LPARAM lParam);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	CStaticColor m_lblLicences[E_NUM_OPTIONS];
	CString m_sSerialNum;
	CString m_strLicenceGrace;
	CString m_strMezzSerNum[E_NUM_MEZZ];
	char m_licence[16];
	ushort m_licenceLimits[16];
	int m_nCurOp;
	int m_bOpStat;
	BYTE m_nAddress1;
	BYTE m_nAddress2;
	int m_nByteCount;
	BOOL m_bChangeLicenceLimit;
	BOOL m_bLicenceLimit;
	BYTE m_nLicenceLimitNumber;
	ushort m_nLimits;

	void UpdateOption(UINT id1, UINT id2, int index, BOOL flag);
	void ChangeOption(int opNum);
	void ChangeLicenceLimit();
	void GetEnabledStrings(CStringArray& strEn);
	void GetDisabledStrings(CStringArray& strDis);
};



/////////////////////////////////////////////////////////////////////////////
// CRtuDataLineErr
class CRtuDataLineErr : public CDialog
{
// Construction
public:
	CRtuDataLineErr	(LPPARMPROC lpps, int pgno, int lastpage, 
		DATAINPUT* di, CWnd* pParent = NULL) : 
		CDialog(CRtuDataLineErr::IDD, pParent){
		m_lpps = lpps; m_pgno = pgno; m_lastpage = lastpage; m_di = di;
		};   // standard constructor
// Dialog Data
	//{{AFX_DATA(CRtuDataLineErr)
	enum { IDD = IDD_RTU_DATALINE_ERR_DLG };
	//}}AFX_DATA
	/*
	CMyColorStatic m_lblErr1;
	CMyColorStatic m_lblErr2;
	CMyColorStatic m_lblErr3;
	CMyColorStatic m_lblErr4;
	CMyColorStatic m_txtErr1;
	CMyColorStatic m_txtErr2;
	CMyColorStatic m_txtErr3;
	CMyColorStatic m_txtErr4;
	*/
	CStaticColor m_lblErr1;//(LIGHTLIGHTBLUE, BLUE);
	CStaticColor m_txtErr1;//(LIGHTYELLOW, RED);
	CStaticColor m_lblErr2;//(LIGHTLIGHTBLUE, BLUE);
	CStaticColor m_txtErr2;//(LIGHTLIGHTBLUE, BLUE);

	CStaticColor m_lblErr3;//(LIGHTYELLOW, RED);
	CStaticColor m_txtErr3;//(LIGHTYELLOW, RED);
	CStaticColor m_lblErr4;//(LIGHTLIGHTBLUE, BLUE);
	CStaticColor m_txtErr4;//(LIGHTLIGHTBLUE, BLUE);
							   
	CStaticColor m_lblErr5;//(LIGHTYELLOW, RED);
	CStaticColor m_txtErr5;//(LIGHTYELLOW, RED);
	CStaticColor m_lblErr6;//(LIGHTLIGHTBLUE, BLUE);
	CStaticColor m_txtErr6;//(LIGHTLIGHTBLUE, BLUE);
							   
	CStaticColor m_lblErr7;//(LIGHTYELLOW, RED);
	CStaticColor m_txtErr7;//(LIGHTYELLOW, RED);
	CStaticColor m_lblErr8;//(LIGHTLIGHTBLUE, BLUE);
	CStaticColor m_txtErr8;//(LIGHTLIGHTBLUE, BLUE);
							   
	CStaticColor m_lblErr9;//(LIGHTYELLOW, RED);
	CStaticColor m_txtErr9;//(LIGHTYELLOW, RED);
	CStaticColor m_lblErr10;//(LIGHTLIGHTBLUE, BLUE);
	CStaticColor m_txtErr10;//(LIGHTLIGHTBLUE, BLUE);

	CStaticColor m_lblErr11;//(LIGHTYELLOW, RED);
	CStaticColor m_txtErr11;//(LIGHTYELLOW, RED);
	CStaticColor m_lblErr12;//(LIGHTLIGHTBLUE, BLUE);
	CStaticColor m_txtErr12;//(LIGHTLIGHTBLUE, BLUE);
							    
	CStaticColor m_lblErr13;//(LIGHTYELLOW, RED);
	CStaticColor m_txtErr13;//(LIGHTYELLOW, RED);
	CStaticColor m_lblErr14;//(LIGHTLIGHTBLUE, BLUE);
	CStaticColor m_txtErr14;//(LIGHTLIGHTBLUE, BLUE);
							    
	CStaticColor m_lblErr15;//(LIGHTYELLOW, RED);
	CStaticColor m_txtErr15;//(LIGHTYELLOW, RED);
	CStaticColor m_lblErr16;//(LIGHTLIGHTBLUE, BLUE);
	CStaticColor m_txtErr16;//(LIGHTLIGHTBLUE, BLUE);
							    
	CStaticColor m_lblErr17;//(LIGHTYELLOW, RED);
	CStaticColor m_txtErr17;//(LIGHTYELLOW, RED);
	CStaticColor m_lblErr18;//(LIGHTLIGHTBLUE, BLUE);
	CStaticColor m_txtErr18;//(LIGHTLIGHTBLUE, BLUE);
							    
	CStaticColor m_lblErr19;//(LIGHTYELLOW, RED);
	CStaticColor m_txtErr19;//(LIGHTYELLOW, RED);
	CStaticColor m_lblErr20;//(LIGHTLIGHTBLUE, BLUE);
	CStaticColor m_txtErr20;//(LIGHTLIGHTBLUE, BLUE);
							    
	CStaticColor m_lblErr21;//(LIGHTYELLOW, RED);
	CStaticColor m_txtErr21;//(LIGHTYELLOW, RED);
	CStaticColor m_lblErr22;//(LIGHTLIGHTBLUE, BLUE);
	CStaticColor m_txtErr22;//(LIGHTLIGHTBLUE, BLUE);
							    
	CStaticColor m_lblErr23;//(LIGHTYELLOW, RED);
	CStaticColor m_txtErr23;//(LIGHTYELLOW, RED);
	CStaticColor m_lblErr24;//(LIGHTLIGHTBLUE, BLUE);
	CStaticColor m_txtErr24;//(LIGHTLIGHTBLUE, BLUE);
							    
	CStaticColor m_lblErr25;//(LIGHTYELLOW, RED);
	CStaticColor m_txtErr25;//(LIGHTYELLOW, RED);
	CStaticColor m_lblErr26;//(LIGHTLIGHTBLUE, BLUE);
	CStaticColor m_txtErr26;//(LIGHTLIGHTBLUE, BLUE);
							    
	CStaticColor m_lblErr27;//(LIGHTYELLOW, RED);
	CStaticColor m_txtErr27;//(LIGHTYELLOW, RED);
	CStaticColor m_lblErr28;//(LIGHTLIGHTBLUE, BLUE);
	CStaticColor m_txtErr28;//(LIGHTLIGHTBLUE, BLUE);
							    
	CStaticColor m_lblErr29;//(LIGHTYELLOW, RED);
	CStaticColor m_txtErr29;//(LIGHTYELLOW, RED);
	CStaticColor m_lblErr30;//(LIGHTLIGHTBLUE, BLUE);
	CStaticColor m_txtErr30;//(LIGHTLIGHTBLUE, BLUE);
							    
	CStaticColor m_lblErr31;//(LIGHTYELLOW, RED);
	CStaticColor m_txtErr31;//(LIGHTYELLOW, RED);
	//CMyColorStatic m_lblErr32(LIGHTLIGHTBLUE, BLUE);
	//CMyColorStatic m_txtErr32(LIGHTLIGHTBLUE, BLUE);
							    
	CStaticColor m_lblHdr;



// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CRtuDataLineErr)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CRtuDataLineErr)
	virtual BOOL OnInitDialog();
	afx_msg void OnExit();
	afx_msg void OnClose();
	afx_msg void OnPageDown();
	afx_msg void OnPageUp();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	void get_sna_rtu_errs(LPBYTE p1, int pgno);
	void get_x25_rtu_errs(LPBYTE p1, int pgno);
	void get_poll_rtu_errs(LPBYTE p1, int pgno);
	void get_async_rtu_errs(LPBYTE p1, int pgno);

	void ShowAlarmError(LPBYTE p1);
	void ShowDataLineError(LPBYTE p1);
	void ShowDialupError(LPBYTE p1);
	
private:
	LPPARMPROC m_lpps;
	int m_pgno, m_lastpage;
	DATAINPUT* m_di;
};

