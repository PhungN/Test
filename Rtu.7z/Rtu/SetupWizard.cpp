 // ***************************************************************************
 //		PACOM SYSTEMS PTY LTD 	Copyright 2005
 //		File/Class Name: SetupWizard.CPP
 //		Description:
 //		
 //		$History: SetupWizard.cpp $
 // 
 
#include "stdafx.h"
#include "SetupWizard.h"
#include "Inc\TracedMutexEtc.h"
#include "Gms\CommonUse\GmsCommandLineParams.h"
#include "Gms\CommonUse\CommandMsg.h"
#include "HardwareConfig\PSPDefs.h"
#include "HardwareConfig\Rtu\PORTPARM\PortParamBlockIds.H"

/*--------------------------------------------------------------------------*/

#define SET_RTU_TO_DEFAULT		0
#define ENTER_ENABLE_CODES		1
#define CHANGE_RTU_NUMBER		2
#define PROGRAM_DIALUP_PARAMS	3
#define MESSAGE_FILTERS			4
#define PROGRAM_ETHERNET_PARAMS 5
#define DOWNLOAD_CFG_TEMPLATES	6
//#define RAP_CONFIGURATION		7
#define PROGRAM_ETHERNET_2_PARAMS (PROGRAM_ETHERNET_PARAMS|0x80)

#define MAX_CONFIGS 7

#define WM_RTU_SET_DEFAULT		WM_GMS + 1
#define WM_CHANGE_RTU_ADDRESS	WM_GMS + 2
#define WM_UPLOAD_CONFIG		WM_GMS + 3
#define WM_ENABLE_WINDOWS		WM_GMS + 4
#define WM_UPLOADING   			WM_GMS + 5

#define ID_UPLOAD_TIMER		1000
#define ID_UPLOAD_TIMEOUT	1001

#define UPLOAD_TIMEOUT		30000		//  30 seconds
#define UPLOAD_TIMEOUT_10S	10000		//  10 seconds
#define MAX_UPLOAD_RETRIES	3

// Dialer Type 
#define DT_SECONDARY	0
#define DT_TERTIARY		1
#define DT_BACKUP_OP	2
#define DT_DIALER_ONLY	3

// Dialer Protocol Constant
#define DP_PACOM		0
#define DP_CONTACT_ID	1
#define DP_SIA			2
#define DP_SMS			3

#define ACT_CODE_STARTUP	BIT0	// Activation Code
#define DIALUP_STARTUP		BIT1	// Dialup Parameters
#define MSG_FLTR_STARTUP	BIT2	// Message Filters
#define ETHERNET_STARTUP	BIT3	// Ethernet Parameters
#define UPLOAD_SN_STARTUP	BIT4	// Serial Number

extern BYTE	pblk_size[4], iblk;
extern HINSTANCE	hrInst;
extern BYTE nReportCode;
extern int Deflt_no, FileCount;
extern TCHAR *Deflt_Files[];
extern int realRtuType;



static volatile BOOL bWait;
static volatile BOOL bCancel;
static volatile BOOL bRunning;
static volatile BOOL bDownloading;

int	wFileCopy(int RtuNo, int INX, int DefNo, BOOL bUp, LPBYTE lpData, UINT bc);

BYTE GetEthernetBlockNumber(int nRtuType)
{
	if(nRtuType == RTU_8001_TYPE)
		return 10 + 3;				//TT 7516: port 11. (ethernet 1)
	return ETHERNET_PARAMS_BLK;
}

BYTE GetDialupBlockNumber(int nRtuType)
{
	if(nRtuType == RTU_2000_TYPE)
		return DIALUP_PARAMS_BLK+1;
	else if(nRtuType == RTU_8001_TYPE)
		return 3;
	else
		return DIALUP_PARAMS_BLK;
}

BYTE GetEthernetPortPriorityNumber(int nRtuType)
{
	BYTE nPortPriorityNumber = 0;
	switch(nRtuType) {
		case RTU_1057_TYPE: nPortPriorityNumber = 0; break;
		case RTU_1058_TYPE: nPortPriorityNumber = 0; break;
		case RTU_2000_TYPE: nPortPriorityNumber = 0; break;
		case RTU_8001_TYPE: nPortPriorityNumber = 5; break;
	}

	return nPortPriorityNumber;
}

BYTE GetDialupPortPriorityNumber(int nRtuType)
{
	BYTE nPortPrioritNumber = 0;
	switch(nRtuType) {
		case RTU_1057_TYPE: nPortPrioritNumber = 1; break;
		case RTU_1058_TYPE: nPortPrioritNumber = 1; break;
		case RTU_2000_TYPE: nPortPrioritNumber = 2; break;
		case RTU_8001_TYPE: nPortPrioritNumber = 0; break;
	}

	return nPortPrioritNumber;
}
/*=========================================================================*/
/*=========================================================================*/
CRtuSetupWizard::CRtuSetupWizard(HINSTANCE, HWND, int , LPPARMPROC lpps, CWnd* pParent)
	: CDialog(CRtuSetupWizard::IDD, pParent)
{
	memcpy(&m_glpps, lpps, sizeof(m_glpps));
	m_nCurrentStep = -1;
	m_bIsValid = FALSE;
	m_bPortPrio = FALSE;
	m_bMsgFilter = FALSE;
	m_fUploadStatus = 0;
	m_nParams = PARAM_GEN_SYS;
	m_nRetries = m_nRtuNo = m_nByteCount = 0;
	m_pBigFont = NULL; m_pCurDlg = NULL; m_pWndUploadThread = NULL; m_pWndDownloadThread = NULL;
	bDownloading = FALSE;
	m_bSysParams = TRUE;
	memset(&m_DluParams, 0, sizeof(m_DluParams));
	memset(m_data, 0, sizeof(m_data));
	m_MaxConfigSteps = 0;
	for(int i=0; i<8; i++) { m_cDlgs[i] = NULL; m_programIds[i] = 0;}
}

CRtuSetupWizard::~CRtuSetupWizard()
{
	if(m_pWndUploadThread) {
		m_pWndUploadThread->m_bAutoDelete = FALSE;
		if(bRunning) {
			while((int)m_pWndUploadThread->ResumeThread() > 0);
			bRunning = FALSE;
			WaitForSingleObject(m_pWndUploadThread->m_hThread, INFINITE);
		}
		delete m_pWndUploadThread;
		m_pWndUploadThread = NULL;
	}
}

void CRtuSetupWizard::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CRtuSetupWizard)
	DDX_Control(pDX, IDC_LBL_CFG_MSG, m_lblCfgMsg);
	DDX_Control(pDX, IDC_PRG_BAR_UPLOAD, m_prgUpload);
	DDX_Control(pDX, IDC_LBL_UPLOAD, m_lblUpload);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CRtuSetupWizard, CDialog)
	//{{AFX_MSG_MAP(CRtuSetupWizard)
	ON_MESSAGE(WM_GMS, OnGms)
	ON_MESSAGE(WM_CHANGE_RTU_ADDRESS, OnChangeRtuAddress)
	ON_MESSAGE(WM_UPLOAD_CONFIG, OnRtuUpload)
	ON_MESSAGE(WM_UPLOADING, UploadConfig)
	ON_BN_CLICKED(IDC_BTN_BACK, OnBtnBack)
	ON_BN_CLICKED(IDC_BTN_NEXT, OnBtnNext)
	ON_BN_CLICKED(IDOK, OnOK)
	ON_BN_CLICKED(IDCANCEL, OnCancel)
	ON_WM_TIMER()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CRtuSetupWizard message handlers
BOOL CRtuSetupWizard::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	m_glpps.heDlg = GetSafeHwnd();
	m_glpps.hmDlg = m_glpps.heDlg;
	memcpy(&m_lpps, &m_glpps, sizeof(m_lpps));
	m_nRtuNo = MAKERTUNO(m_lpps.eType, m_lpps.eNo);

	m_pBigFont = new CFont;
	m_pBigFont->CreateFont(
	   20,                        // nHeight
	   0,                         // nWidth
	   0,                         // nEscapement
	   0,                         // nOrientation
	   FW_BOLD,                   // nWeight
	   FALSE,                     // bItalic
	   FALSE,                     // bUnderline
	   0,                         // cStrikeOut
	   ANSI_CHARSET,              // nCharSet
	   OUT_DEFAULT_PRECIS,        // nOutPrecision
	   CLIP_DEFAULT_PRECIS,       // nClipPrecision
	   DEFAULT_QUALITY,           // nQuality
	   DEFAULT_PITCH | FF_SWISS,  // nPitchAndFamily
	   _T("Arial")); 

	m_pCurDlg = NULL; 
	m_MaxConfigSteps = 0;
	m_defDlg.CreateGenericChildDialog(this, IDC_DLG_FRAME, 0, NULL);
	SetSetupType(m_MaxConfigSteps++, SET_RTU_TO_DEFAULT, &m_defDlg);
	m_actCodDlg.CreateGenericChildDialog(this, IDC_DLG_FRAME, 0, NULL);
	SetSetupType(m_MaxConfigSteps++, ENTER_ENABLE_CODES, &m_actCodDlg);
	m_addrDlg.CreateGenericChildDialog(this, IDC_DLG_FRAME, 0, NULL);
	SetSetupType(m_MaxConfigSteps++, CHANGE_RTU_NUMBER, &m_addrDlg);
	m_dluDlg.CreateGenericChildDialog(this, IDC_DLG_FRAME, 0, NULL);
	SetSetupType(m_MaxConfigSteps++, PROGRAM_DIALUP_PARAMS, &m_dluDlg);
	m_msgFtrDlg.CreateGenericChildDialog(this, IDC_DLG_FRAME, 0, NULL);
	SetSetupType(m_MaxConfigSteps++, MESSAGE_FILTERS, &m_msgFtrDlg);
	m_ethDlg.CreateGenericChildDialog(this, IDC_DLG_FRAME, 0, NULL);
	SetSetupType(m_MaxConfigSteps++, PROGRAM_ETHERNET_PARAMS, &m_ethDlg);
	if (IsRtu8002Type()) {
		m_ethernet2_Dlg.CreateGenericChildDialog(this, IDC_DLG_FRAME, 0, NULL);
		SetSetupType(m_MaxConfigSteps++, PROGRAM_ETHERNET_2_PARAMS, &m_ethernet2_Dlg);
		}
	m_tmpDlg.CreateGenericChildDialog(this, IDC_DLG_FRAME, 0, NULL);
	SetSetupType(m_MaxConfigSteps++, DOWNLOAD_CFG_TEMPLATES, &m_tmpDlg);
	
	//m_cDlgs[SET_RTU_TO_DEFAULT] = &m_defDlg;
	//m_cDlgs[ENTER_ENABLE_CODES] = &m_actCodDlg;
	//m_cDlgs[CHANGE_RTU_NUMBER] = &m_addrDlg;
	//m_cDlgs[PROGRAM_DIALUP_PARAMS] = &m_dluDlg;
	//m_cDlgs[MESSAGE_FILTERS] = &m_msgFtrDlg;
	//m_cDlgs[PROGRAM_ETHERNET_PARAMS] = &m_ethDlg;
	//m_cDlgs[DOWNLOAD_CFG_TEMPLATES] = &m_tmpDlg;

	m_lblCfgMsg.SetFont(m_pBigFont);

	m_prgUpload.SetRange(1, 10);
	m_prgUpload.SetPos(1);
	m_prgUpload.SetStep(1);
	m_prgUpload.StepIt();

	bWait = FALSE;
	bCancel = TRUE;
	bRunning = TRUE;
	m_pWndUploadThread =  _AFXBEGINTHREAD_TRACED(UploadThread, this, 0, 0, 0, 0);
	m_pWndUploadThread->SuspendThread();

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CRtuSetupWizard::OnTimer(UINT nIDEvent) 
{
	// TODO: Add your message handler code here and/or call default
	if(nIDEvent == ID_UPLOAD_TIMER) {
		m_prgUpload.StepIt();
	}

	if(nIDEvent == ID_UPLOAD_TIMEOUT) {
		KillTimer(nIDEvent);

		if( GetCurrentSetupType()==SET_RTU_TO_DEFAULT || 
			GetCurrentSetupType() ==CHANGE_RTU_NUMBER || 
			GetCurrentSetupType() ==DOWNLOAD_CFG_TEMPLATES )
			return;


		if(++m_nRetries < MAX_UPLOAD_RETRIES) {
			if(!m_bIsValid) {
				SetTimer(nIDEvent, UPLOAD_TIMEOUT, NULL);
				OnConfigure();
			}
		}
		else {
			m_nRetries = 0;
			if(!m_bIsValid) {
				TCHAR sMsg[MAX_BUFF], sCaption[MAX_BUFF];
				LoadString(hrInst, IDS_RTU_WZ_STEP, sMsg, MAX_BUFF);
				wsprintf(sCaption, sMsg, m_nCurrentStep+1, m_MaxConfigSteps);
				LoadString(hrInst, IDS_TOUT_WAIT_RESP, sMsg, MAX_BUFF);
				MessageBox(sMsg, sCaption);
				DisplayUploadStatus(FALSE);
				UploadConfig(FALSE, 1);
			}
		}
	}
	
	CDialog::OnTimer(nIDEvent);
}

LRESULT CRtuSetupWizard::OnChangeRtuAddress(WPARAM, LPARAM lParam)
{
 	GetDlgItem(IDC_BTN_BACK)->EnableWindow(FALSE);
	GetDlgItem(IDC_BTN_NEXT)->EnableWindow(FALSE);
	GetDlgItem(IDOK)->EnableWindow(FALSE);

	if(GetCurrentSetupType() == SET_RTU_TO_DEFAULT) {
		m_nRtuNo = (int)0;
	}
	else {
		m_nRtuNo = (int)lParam;
	}
	m_bIsValid = TRUE;
	m_glpps.eType = (BYTE)(m_nRtuNo / 50);
	m_glpps.eNo = (BYTE)(m_nRtuNo % 50);
	ThisGMS->SetCmdLineFlag(RTU_CONNECT);

	return 0;
}

LRESULT CRtuSetupWizard::OnRtuUpload(WPARAM, LPARAM)
{
	OnConfigure();
	m_prgUpload.ShowWindow(SW_HIDE);
	m_lblUpload.ShowWindow(SW_HIDE);

	// TT 7516 : stop user changes page before the upload finished.
	m_pCurDlg->PostMessage(WM_ENABLE_WINDOWS, 0, 0);
	bWait = TRUE;
	bCancel = FALSE;
	while((int)m_pWndUploadThread->ResumeThread() > 0);

	return 0;
}

LRESULT CRtuSetupWizard::UploadConfig(WPARAM wParam, LPARAM lParam)
{
	BOOL flag = (BOOL)lParam;
	//m_bBusy = !flag;
	GetDlgItem(IDC_BTN_BACK)->EnableWindow(flag);
	GetDlgItem(IDC_BTN_NEXT)->EnableWindow(flag);
	GetDlgItem(IDOK)->EnableWindow(flag);

	BOOL bUpload = (BOOL)wParam;
	if(bUpload) {
		OnConfigure();
		SetTimer(ID_UPLOAD_TIMEOUT, UPLOAD_TIMEOUT_10S, NULL);
		m_pWndUploadThread->SuspendThread();
	}

	return 0;
}

LRESULT CRtuSetupWizard::OnGms(WPARAM wParam, LPARAM lParam)
{
	LPBYTE	p;
	UINT id = GET_WM_COMMAND_ID(wParam, lParam);
	LONG retCod = lParam;
	
	byte commover_data[256];

	switch(id) {
		case IDD_COMMOVR_ERROR:
			break;
		case IDD_COMMOVR_DATA1:
			memcpy(commover_data, (LPBYTE)lParam, 256);
			delete[] (LPBYTE)lParam;
			lParam = (LPARAM)(commover_data+5);
			// note: no break;
		case IDD_COMMOVR_DATA:
			if ((p=(LPBYTE)lParam) == NULL)
				break;

			if ((m_lpps.Id==REQ_SRNO_CMD) &&(GetCurrentSetupType() == ENTER_ENABLE_CODES)) {
				EnableActivationCode(lParam);
			}
			else if(GetCurrentSetupType() == PROGRAM_DIALUP_PARAMS) {
				GetPrgDialupParams(lParam);
			}
			else if(GetCurrentSetupType() == MESSAGE_FILTERS) {
				GetPrgMsgFilterParams(lParam);
			}
			else if(GetCurrentSetupType() == PROGRAM_ETHERNET_PARAMS) {
				if(!(m_fUploadStatus & UPLOAD_SN_STARTUP)) {
					CString strSn;
					if(!GetUnitSerialNumber(strSn, p+8)) {
						break;
					}
					
					m_fUploadStatus |= UPLOAD_SN_STARTUP;

					char c = *(p+16);
					if(c == 'E' || realRtuType == RTU_8001_TYPE) {
						m_lpps.BC = 6;
						m_lpps.lpData[0] = GetEthernetBlockNumber(realRtuType); // ETHERNET_PARAMS_BLK;
						BYTE setupType = GetCurrentSetupType(FALSE);
						if (setupType == PROGRAM_ETHERNET_2_PARAMS)
							m_lpps.lpData[0]++;
						CString db;db.Format(L"CRtuSetupWizard::setupType=%x, step=%d, get_rtuport_parms: BlockNo=%d\n", setupType, m_nCurrentStep, 
							m_lpps.lpData[0]); GmsOutputDebugString(__FUNCTIONW__, __LINE__, db);
						m_lpps.lpData[1] = 0;
						m_lpps.lpData[5] = 1;
						get_rtuport_parms(&m_lpps, 0, 0);
					}
					else {
						CString db;db.Format(L"CRtuSetupWizard:: PROGRAM_ETHERNET_PARAMS c=%d\n", c); GmsOutputDebugString(__FUNCTIONW__, __LINE__, db);

						DisplayUploadStatus(FALSE);
						m_ethDlg.EnableCtrls(FALSE);
						m_pCurDlg->ShowWindow(SW_SHOW);
						m_fUploadStatus &= ~UPLOAD_SN_STARTUP;
						m_bIsValid = TRUE;
						UploadConfig(FALSE, 1);
					}

				}
				else {
					GetPrgEthernetParams(lParam);
				}
			}
			break;
		
		case COMM_ONLINEMSG:
			if(GetCurrentSetupType() == SET_RTU_TO_DEFAULT) {
				if(retCod == 0) {
					GetDlgItem(IDC_BTN_BACK)->EnableWindow(TRUE);
					GetDlgItem(IDC_BTN_NEXT)->EnableWindow(TRUE);
					GetDlgItem(IDOK)->EnableWindow(TRUE);
					m_nRtuNo = (int)0;
					m_glpps.eType = (BYTE)(m_nRtuNo / 50);
					m_glpps.eNo = (BYTE)(m_nRtuNo % 50);

					SetRtuTime();
					TCHAR sMsg[MAX_BUFF];
					LoadString(hrInst, IDS_TURN_SW_1_4_OFF, sMsg, MAX_BUFF);
					MessageBox(sMsg);
				}
			}
			else if(GetCurrentSetupType() == CHANGE_RTU_NUMBER) {
				if(retCod == m_nRtuNo) {
					GetDlgItem(IDC_BTN_BACK)->EnableWindow(TRUE);
					GetDlgItem(IDC_BTN_NEXT)->EnableWindow(TRUE);
					GetDlgItem(IDOK)->EnableWindow(TRUE);

					m_lpps.eType = (BYTE)(m_nRtuNo / 50);
					m_lpps.eNo = (BYTE)(m_nRtuNo % 50);
					m_pCurDlg->ShowConfig(&m_lpps, TRUE, NULL, 0, NULL);
				}
			}
			break;

		default:
			break;
	}
	
	return(0);
}

void CRtuSetupWizard::OnConfigure()
{
	memcpy(&m_lpps, &m_glpps, sizeof(m_lpps));
	m_lpps.Id = 0;

	switch(GetCurrentSetupType()) {
		case SET_RTU_TO_DEFAULT:
			m_pCurDlg->ShowWindow(SW_SHOW);
			break;

		case ENTER_ENABLE_CODES:
			InitUploadStatus();
			m_lpps.Id = REQ_SRNO_CMD;
			m_lpps.BlkNo = 0;
			GetRtuSerialNo(&m_lpps);
			break;

		case CHANGE_RTU_NUMBER:
			m_pCurDlg->ShowConfig(&m_lpps, FALSE, NULL, 0, NULL);
			break;

		case PROGRAM_DIALUP_PARAMS:
			InitUploadStatus();
			m_nParams = PARAM_GEN_SYS;
			m_lpps.BC = 2;
			m_lpps.lpData[0] = GENERAL_SYSTEM_PARAMS_BLK;
			m_lpps.lpData[1] = 0;
			get_rtuport_parms(&m_lpps, 0, 0);
			break;

		case MESSAGE_FILTERS:
			InitUploadStatus();
			m_bMsgFilter = TRUE;
			m_lpps.BC = 2;
			m_lpps.lpData[0] = MESSAGE_FILTER_PARAMS_BLK;
			m_lpps.lpData[1] = 0;
			get_rtuport_parms(&m_lpps, 0, 0);
			break;

		case PROGRAM_ETHERNET_PARAMS:
			InitUploadStatus();
			if(!(m_fUploadStatus & UPLOAD_SN_STARTUP)) {
				m_lpps.Id = REQ_SRNO_CMD;
				m_lpps.BlkNo = 0;
				GetRtuSerialNo(&m_lpps);
			}

			break;

		case DOWNLOAD_CFG_TEMPLATES:
			m_pCurDlg->ShowConfig(&m_lpps, 0, NULL, 0, NULL);
			break;

		default:
			break;
	}
	
}

void CRtuSetupWizard::DisplayUploadStatus(BOOL bUploading)
{
	if(bUploading) {
		m_prgUpload.SetPos(1);
		m_prgUpload.ShowWindow(SW_SHOW);
		m_lblUpload.ShowWindow(SW_SHOW);
		SetTimer(ID_UPLOAD_TIMER, 500, NULL);
		KillTimer(ID_UPLOAD_TIMEOUT);
	}
	else {
		KillTimer(ID_UPLOAD_TIMER);
		m_prgUpload.ShowWindow(SW_HIDE);
		m_lblUpload.ShowWindow(SW_HIDE);
	}
}

void CRtuSetupWizard::OnBtnBack()
{
	if(m_pCurDlg && m_bIsValid) {
		if(!m_pCurDlg->StoreConfig(FALSE))
			return;
	}

	while (true) {

		if(m_nCurrentStep) {
			--m_nCurrentStep;
			if(m_nCurrentStep == 0) {
				GetDlgItem(IDC_BTN_BACK)->ShowWindow(SW_HIDE);
			}
			
			GetDlgItem(IDC_BTN_NEXT)->ShowWindow(SW_SHOW);
			GetDlgItem(IDOK)->ShowWindow(SW_HIDE);

			// Skip Ethernet if protocol is dialer only
			if(GetCurrentSetupType() == PROGRAM_ETHERNET_PARAMS) {
				if(m_dluDlg.IsDialerOnly())
					continue;
					//m_nCurrentStep--;
			}

			// Skip Message Filter if Dialer Type is Pacom
			if(GetCurrentSetupType() == MESSAGE_FILTERS) {
				if(m_dluDlg.IsPacomProtocol())
					continue;
					//m_nCurrentStep--;
			}

			UpdateWindows();
		}
		break;
	}
}

void CRtuSetupWizard::OnBtnNext()
{
	if(m_pCurDlg && m_bIsValid)	{
		if(!m_pCurDlg->StoreConfig(FALSE))
			return;
	}

	while (1){
		++m_nCurrentStep;
		if(m_nCurrentStep >= m_MaxConfigSteps - 1) {
			m_nCurrentStep = m_MaxConfigSteps - 1;
			GetDlgItem(IDC_BTN_NEXT)->ShowWindow(SW_HIDE);
			GetDlgItem(IDOK)->ShowWindow(SW_SHOW);
		}
		else {
			if(m_nCurrentStep) {
				GetDlgItem(IDC_BTN_BACK)->ShowWindow(SW_SHOW);
				GetDlgItem(IDOK)->ShowWindow(SW_HIDE);
			}
		}

		// Skip Ethernet if protocol is dialer only
		if(GetCurrentSetupType() == MESSAGE_FILTERS) {
			if(m_dluDlg.IsPacomProtocol())
				//m_nCurrentStep++;
				continue;
		}
		
		// Skip Message Filter if Dialer Type is Pacom
		if(GetCurrentSetupType() == PROGRAM_ETHERNET_PARAMS) {
			if(m_dluDlg.IsDialerOnly()) {
				continue;
				/*if(++m_nCurrentStep == m_MaxConfigSteps - 1) {
					GetDlgItem(IDC_BTN_NEXT)->ShowWindow(SW_HIDE);
					GetDlgItem(IDOK)->ShowWindow(SW_SHOW);
				}*/
			}
		}
		
		UpdateWindows();
		break;
		}
}

void CRtuSetupWizard::OnOK()
{
    SetRtuConfigOK(m_nRtuNo, CFG_BLKSIZE, 0);
	CDialog::OnOK();
}

void CRtuSetupWizard::OnCancel()
{
	//if(m_bBusy)
	//	return;
	
	CDialog::OnCancel();
}

void CRtuSetupWizard::UpdateWindows()
{
	if(m_pCurDlg) {
		m_pCurDlg->ShowWindow(SW_HIDE);
	}

	CString db; db.Format(L"UpdateWindows current step=%d, type = %x\n", m_nCurrentStep, GetCurrentSetupType(FALSE));GmsOutputDebugString(__FUNCTIONW__, __LINE__, db);

	m_pCurDlg = m_cDlgs[m_nCurrentStep];

	CString strWndText;
	TCHAR sTmp[MAX_BUFF];
	LoadString(hrInst, IDS_RTU_WZ_STEP, sTmp, MAX_BUFF);
	strWndText.Format(sTmp, m_nCurrentStep+1, m_MaxConfigSteps);
	SetWindowText(strWndText);

	LoadString(hrInst, IDS_RTU_WZ_STEP_1 + GetCurrentSetupType(), sTmp, MAX_BUFF);
	if (IsRtu8002Type() && GetCurrentSetupType() == PROGRAM_ETHERNET_PARAMS)
	{
		lstrcat (sTmp, (GetCurrentSetupType(FALSE) == PROGRAM_ETHERNET_PARAMS)? L" (1)": L" (2)");
	}
	SetDlgItemText(IDC_LBL_CFG_MSG, sTmp);
	SetDlgItemText(IDC_LBL_DEFAULT, _T(""));
	GetDlgItem(IDC_LBL_DEFAULT)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_LBL_MSG3)->ShowWindow(SW_HIDE);

	m_bIsValid = FALSE;
	

	if((GetCurrentSetupType() == SET_RTU_TO_DEFAULT) || 
		(GetCurrentSetupType() == CHANGE_RTU_NUMBER) || 
		(GetCurrentSetupType() == DOWNLOAD_CFG_TEMPLATES))	{
		DisplayUploadStatus(FALSE);
		bCancel = TRUE;
		m_pWndUploadThread->SuspendThread();
		OnConfigure();
		}
	else {
		DisplayUploadStatus(TRUE);
		bWait = TRUE;
		bCancel = FALSE;
		while((int)m_pWndUploadThread->ResumeThread() > 0);
	}

}

UINT CRtuSetupWizard::UploadThread(LPVOID p)
{
	CRtuSetupWizard* pWnd = (CRtuSetupWizard*)p;
	while(bRunning) {
		if(bWait) {
			bWait = FALSE;
			if(bDownloading) {
				bDownloading = FALSE;
				Sleep(10000);	// Wait for rtu reboot
			}
			else
				Sleep(1000);
			if(!bCancel) {
				pWnd->SendMessage(WM_UPLOADING, TRUE, 0);
			}
		}
	}

	return TRUE;
}

BOOL CRtuSetupWizard::GetUnitSerialNumber(CString& strSn, LPBYTE p)
{
	CString sTemp(p-8);
	CString strPu = sTemp.Mid(0, 8);
	strSn = (realRtuType == RTU_8001_TYPE) ? sTemp.Mid(32, 16) : sTemp.Mid(8, 8);
	return strSn.GetLength() > 0 && strPu.GetLength() > 0;
}

void CRtuSetupWizard::SetRtuTime()
{
	SYSTEMTIME st;
	BYTE time[10];
	GetTimenDate(&st);
	time[0] = (BYTE)st.wSecond;
	time[1] = (BYTE)st.wMinute;
	time[2] = (BYTE)st.wHour;
	time[3] = (BYTE)st.wDay;
	time[4] = (BYTE)st.wMonth;
	time[5] = (BYTE)(st.wYear%100);
	time[6] = (BYTE)st.wDayOfWeek;
	time[7] = 0;					//.time difference
	SendTimeSetCmd(time);

}

void CRtuSetupWizard::InitUploadStatus()
{
	switch(GetCurrentSetupType()) {
		case ENTER_ENABLE_CODES:
			m_fUploadStatus = 0;
			m_fUploadStatus |= ACT_CODE_STARTUP; 
			break;

		case PROGRAM_DIALUP_PARAMS:
			m_fUploadStatus = 0;
			m_fUploadStatus |= DIALUP_STARTUP; 
			break;

		case MESSAGE_FILTERS:
			m_fUploadStatus = 0;
			m_fUploadStatus |= MSG_FLTR_STARTUP; 
			break;

		case PROGRAM_ETHERNET_PARAMS:
			m_fUploadStatus |= ETHERNET_STARTUP; 
			break;
			
		default:
			m_fUploadStatus = 0;
			break;
	}
}

void CRtuSetupWizard::EnableActivationCode(LPARAM lParam)
{
	if(!(m_fUploadStatus & ACT_CODE_STARTUP))
		return;

	BYTE data[RTU_BUFF_SIZE];
	PARMPROC pps;
	LPBYTE p = (LPBYTE)lParam;
	memcpy(&pps, &m_lpps, sizeof(pps));
	memcpy(data, (LPBYTE)lParam, sizeof(data));
	pps.lpData = data;
	
	CString strSn;
	if(!GetUnitSerialNumber(strSn, p+8)) {
		return;
	}
	DisplayUploadStatus(FALSE);
	m_pCurDlg->ShowConfig(&pps, *(p - 5), p, 0, NULL);
	m_bIsValid = TRUE;
	m_fUploadStatus &= ~ACT_CODE_STARTUP;

	UploadConfig(FALSE, 1);
}

void CRtuSetupWizard::GetPrgEthernetParams(LPARAM lParam)
{
	if(!(m_fUploadStatus & ETHERNET_STARTUP)) {
		m_fUploadStatus &= ~UPLOAD_SN_STARTUP;
		m_bPortPrio = FALSE;
		GmsOutputDebugString(__FUNCTIONW__, __LINE__, L"CRtuSetupWizard::GetPrgEthernetParams => do nothing\n");
		return;
	}

	LPBYTE p = (LPBYTE)lParam;
	if(NULL == p)
		return;

	if(!m_bPortPrio) {
		memcpy(&m_data[0], (LPSTR)lParam, sizeof(m_data));
		memcpy(&m_EthParams.portParamBuff[0], (LPSTR)lParam, sizeof(m_data));
		m_nByteCount = *((LPSTR)lParam - 5);
		m_nByteCount = (BYTE)(m_nByteCount - 10);

		// Get port priority data
		m_bPortPrio = TRUE;
		m_lpps.BC = 2;
		m_lpps.lpData[0] = (BYTE)(PRIMARY_PRIORITY_PARAMS_BLK);	// primary bs data
		m_lpps.lpData[1] = 0;
		get_rtuport_parms(&m_lpps, 0, 0);
	}
	else {
		DisplayUploadStatus(FALSE);
		m_bPortPrio = FALSE;
		memcpy((LPBYTE)&m_EthParams.bsParam1, p+1, sizeof(PRIORITY_PARM1) + sizeof(PRIORITY_PARM2));
		m_lpps.lpData = &m_data[0];
		m_pCurDlg->PostMessage(WM_ENABLE_WINDOWS, 0, TRUE);
		m_pCurDlg->ShowConfig(&m_lpps, m_nByteCount, (LPBYTE)&m_EthParams, 0, NULL);
		m_bIsValid = TRUE;
		m_fUploadStatus &= ~(UPLOAD_SN_STARTUP | ETHERNET_STARTUP);

		UploadConfig(FALSE, 1);
	}
}

void CRtuSetupWizard::GetPrgDialupParams(LPARAM lParam)
{
	if(!(m_fUploadStatus & DIALUP_STARTUP)) {
		m_nParams = PARAM_GEN_SYS;
		return;
	}

	LPBYTE p = (LPBYTE)(LPSTR)lParam;
	if (p == NULL)
		return;

	switch (m_nParams) {
		case PARAM_GEN_SYS:
			BYTE BC;
			BC = *((LPSTR)lParam - 5);
			BC = (BYTE)(BC - 6);
			if (BC <= sizeof(SYSPARM2000))	{
				memcpy(&m_DluParams.sysParams.p2, p+1, sizeof(SYSPARM2000));
				m_bSysParams = FALSE;
			}
			else if (BC <= sizeof(SYSPARM)) {
				memcpy(&m_DluParams.sysParams.p1, p+1, sizeof(SYSPARM));
				m_bSysParams = TRUE;
			}

			// Get Dialup Parameters
			m_nParams = PARAM_DIALUP;
			m_lpps.lpData[0] = GetDialupBlockNumber(realRtuType);
			m_lpps.lpData[1] = 0;
			get_rtuport_parms(&m_lpps, 0, 0);
			break;

		case PARAM_DIALUP:
			memcpy(&m_DluParams.nPortNum, p, sizeof(LDIAL_PARM) + 5 + sizeof(m_DluParams.bArrDummy));
			m_nParams = PARAM_DIALUP_NEWCFG;
			m_lpps.BC = 6;
			m_lpps.lpData[0] = GetDialupBlockNumber(realRtuType);
			m_lpps.lpData[1] = 0;
			m_lpps.lpData[5] = 1; // For new cfg
			get_rtuport_parms(&m_lpps, 0, 0);
			break;

		case PARAM_DIALUP_NEWCFG:
			memcpy(&m_dialupData[0], p, sizeof(m_dialupData));
			m_nDialupByteCount = *((LPSTR)lParam - 5);
			m_nDialupByteCount = (BYTE)(m_nDialupByteCount - 10);

			// Get Priority Parameters
			m_nParams = PARAM_PRIORITY;
			BYTE nBlock, nDialupPortPriorityNumber, nPriority;
			nDialupPortPriorityNumber = GetDialupPortPriorityNumber(realRtuType);

			nPriority = m_bSysParams ? 
				m_DluParams.sysParams.p1.portPrty_Bx[nDialupPortPriorityNumber] : 
				m_DluParams.sysParams.p2.portPrty_Bx[nDialupPortPriorityNumber];
			if(nPriority == PORT_PRIO_TERTIARY) 
				nBlock = TERTIARY_PRIORITY_PARAMS_BLK;
			else if(nPriority == PORT_PRIO_DUAL_RPT)
				nBlock = BACKUP_OPARATION_PARAMS_BLK;
			else
				nBlock = SECONDARY_PRIORITY_PARAMS_BLK;
			m_lpps.lpData[0] = nBlock;
			m_lpps.lpData[1] = 0;
			get_rtuport_parms(&m_lpps, 0, 0);
			break;

		case PARAM_PRIORITY:
			memcpy(&m_DluParams.bsParams1, p+1, sizeof(SECONDARYPARM1) + sizeof(PRIORITY_PARM2));
			// Get Message Filter Parameters
			m_nParams = PARAM_MSG_FILTER;
			m_lpps.lpData[0] = MESSAGE_FILTER_PARAMS_BLK;
			m_lpps.lpData[1] = 0;
			get_rtuport_parms(&m_lpps, 0, 0);

			break;

		case PARAM_MSG_FILTER:
			if(m_nCurrentStep != PROGRAM_DIALUP_PARAMS)
				break;

			DisplayUploadStatus(FALSE);
			m_nByteCount = *((LPSTR)lParam - 5);
			m_nByteCount = (BYTE)(m_nByteCount - 6);
			m_nParams = PARAM_GEN_SYS;
			memcpy(&m_DluParams.msgFtrParams, p+1, sizeof(MSGFILTERPARM));

			m_DluParams.nByteCount = m_nByteCount;
			m_pCurDlg->ShowConfig(&m_lpps, m_bSysParams ? BYTE(1) : (BYTE)0, (LPBYTE)&m_DluParams, m_nDialupByteCount, m_dialupData);
			m_bIsValid = TRUE;
			m_fUploadStatus &= ~DIALUP_STARTUP;

			UploadConfig(FALSE, 1);
			break;
			
		default:
			break;
	}
}

void CRtuSetupWizard::GetPrgMsgFilterParams(LPARAM lParam)
{
	if(!(m_fUploadStatus & MSG_FLTR_STARTUP))	{
		m_bMsgFilter = TRUE;
		return;
	}

	LPBYTE p = (LPBYTE)(LPSTR)lParam;
	if(NULL == p)
		return;

	if(m_bMsgFilter) {
		m_bMsgFilter = FALSE;
		memcpy(&m_msgFtrParams.msgFtrParams, p+1, sizeof(MSGFILTERPARM));
		// Get General System Params
		m_lpps.BC = 2;
		m_lpps.lpData[0] = GENERAL_SYSTEM_PARAMS_BLK;
		m_lpps.lpData[1] = 0;
		get_rtuport_parms(&m_lpps, 0, 0);

	}
	else {
		DisplayUploadStatus(FALSE);
		m_nByteCount = *((LPSTR)lParam - 5);
		m_nByteCount = (BYTE)(m_nByteCount - 6);
		
		BYTE bSys=0;
		if (m_nByteCount <= sizeof(SYSPARM2000))	{
			memcpy(&m_msgFtrParams.sysParams2, p+1, m_nByteCount);
		}
		else if (m_nByteCount <= sizeof(SYSPARM)) {
			memcpy(&m_msgFtrParams.sysParams, p+1, m_nByteCount);
			bSys = 1;
		}								

		m_pCurDlg->ShowConfig(&m_lpps, bSys, (LPBYTE)&m_msgFtrParams, 0, NULL);
		m_bIsValid = TRUE;
		m_fUploadStatus &= ~MSG_FLTR_STARTUP;

		UploadConfig(FALSE, 1);
	}
}

/*=========================================================================*/
/*=========================================================================*/
CSetRtuDefault::CSetRtuDefault(CWnd* pParent)
	: CSWZDialog(CSetRtuDefault::IDD, pParent)
{
}

void CSetRtuDefault::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CSetRtuDefault)
	DDX_Control(pDX, IDC_PIC_RTU_WZ, m_icon);
	//}}AFX_DATA_MAP
	DDX_Control(pDX, IDC_LBL_MSG, m_lblMsg);
}

BEGIN_MESSAGE_MAP(CSetRtuDefault, CDialog)
	//{{AFX_MSG_MAP(CSetRtuDefault)
	//ON_BN_CLICKED(IDOK, OnOK)
	//ON_BN_CLICKED(IDCANCEL, OnCancel)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()
/////////////////////////////////////////////////////////////////////////////
// CSetRtuDefault message handlers
BOOL CSetRtuDefault::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	HICON hIcon = ::LoadIcon(NULL, IDI_EXCLAMATION);
	m_icon.ModifyStyle(m_icon.GetStyle(), WS_CHILD|WS_VISIBLE|SS_ICON|SS_CENTERIMAGE, 1);
	m_icon.SetIcon(hIcon);

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

/*=========================================================================*/
/*=========================================================================*/
CPrgRtuAddress::CPrgRtuAddress(int nRtuNo, CWnd* pParent)
	: CSWZDialog(CPrgRtuAddress::IDD, pParent)
{
	m_nNewRtuNo = nRtuNo; m_pFont = NULL;
}

void CPrgRtuAddress::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPrgRtuAddress)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CPrgRtuAddress, CDialog)
	//{{AFX_MSG_MAP(CPrgRtuAddress)
	ON_BN_CLICKED(IDOK, OnOK)
	//}}AFX_MSG_MAP
	ON_MESSAGE(WM_GMS, OnGms)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPrgRtuAddress message handlers
BOOL CPrgRtuAddress::OnInitDialog() 
{
	CDialog::OnInitDialog();

	// TODO: Add extra initialization here
	SetDlgItemInt(IDC_TXT_CURR_RTUNO, m_nNewRtuNo + 1);

	m_pFont = new CFont;
	m_pFont->CreateFont(
	   15,                        // nHeight
	   0,                         // nWidth
	   0,                         // nEscapement
	   0,                         // nOrientation
	   FW_BOLD,                   // nWeight
	   FALSE,                     // bItalic
	   FALSE,                     // bUnderline
	   0,                         // cStrikeOut
	   ANSI_CHARSET,              // nCharSet
	   OUT_DEFAULT_PRECIS,        // nOutPrecision
	   CLIP_DEFAULT_PRECIS,       // nClipPrecision
	   DEFAULT_QUALITY,           // nQuality
	   DEFAULT_PITCH | FF_SWISS,  // nPitchAndFamily
	   _T("Arial")); 

	GetDlgItem(IDC_LBL_MSG)->SetFont(m_pFont);

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CPrgRtuAddress::OnOK()
{
	if (!CheckDLPriv(A_RTU_ADDR)) 
		return;

	int curRtuNo = GetDlgItemInt(IDC_TXT_CURR_RTUNO) - 1;
	int newRtuNo = GetDlgItemInt(IDC_TXT_NEW_RTUNO) - 1;
	if ((uint)curRtuNo < SystemParams->StartRtu ||
		(uint)curRtuNo > SystemParams->EndRtu ||
		(uint)newRtuNo < SystemParams->StartRtu ||
		(uint)newRtuNo > SystemParams->EndRtu || 
		newRtuNo >= 9999) {
		DisplayError1(GetSafeHwnd(), InvRtuNo, Globals->hInst);
		return;
	}

	GetDlgItem(IDOK)->EnableWindow(FALSE);
	TCHAR sTmp[MAX_BUFF];
	LoadString(hrInst, IDS_WAIT_RTU_RES, sTmp, MAX_BUFF);
	DisplayMessage(sTmp);

	SendRtuAddress(m_pps.hmDlg, curRtuNo, newRtuNo, 0, 0, 0);
	curRtuNo = newRtuNo;
	GetParent()->SendMessage(WM_CHANGE_RTU_ADDRESS, 0, curRtuNo);
}

void CPrgRtuAddress::DisplayMessage(LPCTSTR msg)
{
	GetDlgItem(IDC_LBL_MSG)->ShowWindow(SW_SHOW);
	SetDlgItemText(IDC_LBL_MSG, msg);
}

void CPrgRtuAddress::ShowConfig(LPPARMPROC lpps, BYTE bDisp, LPBYTE, BYTE, LPBYTE)
{
	memcpy(&m_pps, lpps, sizeof(m_pps));
	m_pps.heDlg = GetSafeHwnd();
	m_pps.hmDlg = m_pps.heDlg;
	
	m_nNewRtuNo = MAKERTUNO(m_pps.eType, m_pps.eNo);
	
	SetDlgItemInt(IDC_TXT_CURR_RTUNO, m_nNewRtuNo + 1);
	SetDlgItemText(IDC_TXT_NEW_RTUNO, _T(""));
	GetDlgItem(IDC_LBL_MSG)->ShowWindow(SW_HIDE);
	GetDlgItem(IDOK)->EnableWindow(TRUE);
	GetDlgItem(IDC_TXT_NEW_RTUNO)->SetFocus();

	if(bDisp) {
		TCHAR sTmp[MAX_BUFF];
		LoadString(hrInst, IDS_RTU_NUM_CHNG, sTmp, MAX_BUFF);
		DisplayMessage(sTmp);
	}

	ShowWindow(SW_SHOW);
}

LRESULT CPrgRtuAddress::OnGms(WPARAM wParam, LPARAM /*lParam*/)
{
	UINT id = GET_WM_COMMAND_ID(wParam, 0);
	
	switch(id) {
		case IDD_COMMOVR_ERROR:
		case IDD_COMMOVR_DATA:
			break;
		case COMM_ONLINEMSG:
			break;
		case IDD_HIRESP:
			break;
		default:
			break;
	}
	
	CString s; s.Format(_T("\nCPrgRtuAddress::OnGms - id=%d ...\n\n"), id);
	GmsOutputDebugString(__FUNCTIONW__, __LINE__, s);
	return(0);
}
/*=========================================================================*/
/*=========================================================================*/
void CPrgEthernetParams::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPrgEthernetParams)
	DDX_Control(pDX, IDC_CBO_PROTOCOL, m_cboProtocol);
	DDX_Control(pDX, IDC_CBO_LINE1, m_cboLine1A);
	DDX_Control(pDX, IDC_CBO_LINE2, m_cboLine2A);
	DDX_Control(pDX, IDC_IPA_LOCAL_NODE, m_ipLocalNode);
	DDX_Control(pDX, IDC_IPA_SUBNET_MASK, m_ipSubnetMask);
	DDX_Control(pDX, IDC_IPA_ROUTER, m_ipRouter);
	//}}AFX_DATA_MAP
	RtuLib::DDX_Check(pDX, IDC_CHK_EN_DHCP, m_EthParams.ipParams.rpingRetry, 5);
	for (int i = 0; i < 2; i++) {
		RtuLib::DDX_Text(pDX, IDC_IPA_LINE1 + i, &m_LineAddr[i * 18]);
	}

}

BEGIN_MESSAGE_MAP(CPrgEthernetParams, CDialog)
	//{{AFX_MSG_MAP(CPrgEthernetParams)
	ON_BN_CLICKED(IDOK, OnOK)
	ON_BN_CLICKED(IDCANCEL, OnCancel)
	ON_MESSAGE(WM_GMS, OnGms)
	ON_MESSAGE(WM_ENABLE_WINDOWS, OnEnableWindows)
	ON_BN_CLICKED(IDC_BTN_DLOAD, OnBtnDownload)
	ON_BN_CLICKED(IDC_BTN_REBOOT, OnBtnReboot)
	ON_BN_CLICKED(IDC_BTN_DFAULT, OnBtnDefault)
	ON_BN_CLICKED(IDC_CHK_EN_DHCP, OnBtnDHCP)
	ON_CBN_SELCHANGE(IDC_CBO_PROTOCOL, OnSelChangedProtocol)		
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPrgEthernetParams message handlers
BOOL CPrgEthernetParams::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	m_pFont = new CFont;
	m_pFont->CreateFont(
	   15,                        // nHeight
	   0,                         // nWidth
	   0,                         // nEscapement
	   0,                         // nOrientation
	   FW_BOLD,                   // nWeight
	   FALSE,                     // bItalic
	   FALSE,                     // bUnderline
	   0,                         // cStrikeOut
	   ANSI_CHARSET,              // nCharSet
	   OUT_DEFAULT_PRECIS,        // nOutPrecision
	   CLIP_DEFAULT_PRECIS,       // nClipPrecision
	   DEFAULT_QUALITY,           // nQuality
	   DEFAULT_PITCH | FF_SWISS,  // nPitchAndFamily
	   _T("Arial")); 

	GetDlgItem(IDC_LBL_ETH_EN)->SetFont(m_pFont);
	m_bEthParams = TRUE;

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CPrgEthernetParams::OnOK()
{
	m_lpps.lpData = m_pData;
	*(m_pData + 1) |= 0x80;	// For new config
	switch(realRtuType) {
	case RTU_1057_TYPE:
		ShowPortParamsDlg(this, &m_lpps, m_nByteCount); break;
	case RTU_1058_TYPE:
		Show1058PortParamsDlg(this, &m_lpps, m_nByteCount); break;
	case RTU_2000_TYPE:
		ShowVCUPortParamsDlg(this, &m_lpps, m_nByteCount); break;
	case RTU_8001_TYPE:
		Show8001PortParamsDlg(this, &m_lpps, m_nByteCount); break;
	}
	
	GetParent()->PostMessage(WM_UPLOAD_CONFIG);
}

void CPrgEthernetParams::OnCancel()
{
	CDialog::OnCancel();
}

void CPrgEthernetParams::ShowConfig(LPPARMPROC lpps, BYTE nByteCount, LPBYTE ptrData, BYTE, LPBYTE)
{
	if( ((CRtuSetupWizard*)GetParent())->GetCurStep() != PROGRAM_ETHERNET_PARAMS )
		return;

	LPBYTE p = ptrData;
	memcpy(&m_lpps, lpps, sizeof(m_lpps));
	int bsSize = sizeof(PRIORITY_PARM1) + sizeof(PRIORITY_PARM2);
	memcpy((LPBYTE)&m_EthParams.bsParam1, p, bsSize);
	p += bsSize;
	m_pData = p;

	if(nByteCount > RTU_BUFF_SIZE)
		nByteCount = RTU_BUFF_SIZE;
	memcpy(m_data, p, nByteCount);

	memcpy((LPBYTE)&m_EthParams.nPortNum, p, 5); p += 5;
	BYTE appBC = *p++;
	m_pAppData = p;
	memcpy((LPBYTE)&m_EthParams.appDummy, p, sizeof(ANIP_PARM)); p += appBC;
	BYTE sesBC = *p++;
	m_pSesData = p;
	memcpy((LPBYTE)&m_EthParams.ipParams, p, sizeof(IP_PARM)); p += sesBC;
	BYTE lnkBC = *p++;
	m_pLnkData = p;
	memcpy((LPBYTE)&m_EthParams.lnkMacParams, p, sizeof(MAC_PARM) + sizeof(ETHDRV_PARM)); p += lnkBC;
	
	m_nByteCount = nByteCount;
	m_nNextBlock = -1; 
	m_bReboot = FALSE;
	m_lpps.heDlg = GetSafeHwnd();
	m_lpps.hmDlg = m_lpps.heDlg;

	ShowParams();
}

BOOL CPrgEthernetParams::StoreConfig(BOOL bStore)
{
	if( ((CRtuSetupWizard*)GetParent())->GetCurStep() != PROGRAM_ETHERNET_PARAMS )
		return TRUE;

	if(!m_bEthParams)
		return TRUE;

	UpdateData(TRUE);
	m_ipLocalNode.GetAddress(m_EthParams.ipParams.myIpAddr[0],
		m_EthParams.ipParams.myIpAddr[1],
		m_EthParams.ipParams.myIpAddr[2],
		m_EthParams.ipParams.myIpAddr[3]);

	m_ipSubnetMask.GetAddress(m_EthParams.ipParams.myIpMask[0],
		m_EthParams.ipParams.myIpMask[1],
		m_EthParams.ipParams.myIpMask[2],
		m_EthParams.ipParams.myIpMask[3]);

	m_ipRouter.GetAddress(m_EthParams.ipParams.rIpAddr1[0],
		m_EthParams.ipParams.rIpAddr1[1],
		m_EthParams.ipParams.rIpAddr1[2],
		m_EthParams.ipParams.rIpAddr1[3]);

	// Save Base Station Params
	int nLine1 = m_cboLine1A.GetCurSel();
	int nLine2 = m_cboLine2A.GetCurSel();
	if(nLine1 != -1) {
		m_EthParams.bsParam1.lcardALine1En = (BYTE)nLine1;
		if (SaveAddress((BYTE)nLine1, (&m_EthParams.bsParam1.lcardALine1Addr[0]), &m_LineAddr[0]) == FALSE) 
		{
			DispMessageBox(GetSafeHwnd(), IDS_INV_ADDR, IDS_ERROR, MB_OK | MB_ICONEXCLAMATION);
			return FALSE;
		}
	}

	if(nLine2 != -1) {
		m_EthParams.bsParam1.lcardALine2En = (BYTE)nLine2;
		if (SaveAddress((BYTE)nLine2, (&m_EthParams.bsParam1.lcardALine2Addr[0]), 
			&m_LineAddr[18]) == FALSE) {
			DispMessageBox(GetSafeHwnd(), IDS_INV_ADDR, IDS_ERROR, MB_OK | MB_ICONEXCLAMATION);
			return FALSE;
		}
	}

	if(bStore == FALSE) {

			return TRUE;

	}

	if(m_pData) {
		m_pData[0] = GetEthernetBlockNumber(realRtuType)+m_ethernetId; //ETHERNET_PARAMS_BLK;
		CString db;db.Format(L"CPrgEthernetParams::StoreConfig(bStore=%d): BlockNo=%d\n", bStore, m_pData[0]); OutputDebugString(db);
		m_pData[1] |= 0x80;	// For new config
		memcpy(m_pAppData, (LPBYTE)&m_EthParams.appDummy, sizeof(ANIP_PARM)); 
		memcpy(m_pSesData, (LPBYTE)&m_EthParams.ipParams, sizeof(IP_PARM)); 
		memcpy(m_pLnkData, (LPBYTE)&m_EthParams.lnkMacParams, sizeof(MAC_PARM) + sizeof(ETHDRV_PARM)); 
		
		m_lpps.lpData = m_pData;
		m_lpps.BC = (BYTE)(m_nByteCount + 5);
		send_rtuport_parms(&m_lpps);
		m_nNextBlock = PRIMARY_PRIORITY_PARAMS_BLK;
		bDownloading = TRUE;
	}

	return TRUE;
}

void CPrgEthernetParams::EnableCtrls(BOOL bEthernetEn)
{
	m_bEthParams = bEthernetEn;

	for(int i=0; i<11; i++) {
		GetDlgItem(IDC_IPA_LOCAL_NODE + i)->EnableWindow(bEthernetEn);
	}
	GetDlgItem(IDOK)->EnableWindow(bEthernetEn);

	GetDlgItem(IDC_LBL_ETH_EN)->ShowWindow(bEthernetEn ? SW_HIDE : SW_SHOW);

	if(!bEthernetEn) {
		SetDlgItemText(IDC_IPA_LINE1, _T(""));
		SetDlgItemText(IDC_IPA_LINE2, _T(""));
	}
}

LRESULT CPrgEthernetParams::OnEnableWindows(WPARAM, LPARAM lParam)
{
	BOOL bEn = (BOOL)lParam;
	//if(!bEn)
	EnableCtrls(bEn);
	return 0;
}

	
LRESULT CPrgEthernetParams::OnGms(WPARAM wParam, LPARAM lParam)
{
	LPBYTE d = (LPBYTE)(LPSTR)lParam;
	if(d == NULL)
		return 0;

	UINT id = GET_WM_COMMAND_ID(wParam, lParam);
	switch(id) {
		case IDD_HIRESP:
			if(m_nNextBlock == -1) {
			}
			else if(m_bReboot) {
				OnBtnReboot();
				m_bReboot = FALSE;
				m_nNextBlock = -1;

				//memcpy(m_pData, &m_EthParams, sizeof(m_EthParams));
			}
			else if(m_nNextBlock == PRIMARY_PRIORITY_PARAMS_BLK) {
				PARMPROC epps;
				BYTE edata[RTU_BUFF_SIZE];

				memcpy(&epps, &m_lpps, sizeof(epps));
				epps.lpData = &edata[0];

				epps.lpData[0] = PRIMARY_PRIORITY_PARAMS_BLK;
				memcpy(&edata[1], &m_EthParams.bsParam1, sizeof(SECONDARYPARM1) + sizeof(PRIORITY_PARM2));
				epps.BC = sizeof(SECONDARYPARM1) + sizeof(PRIORITY_PARM2) + 1;
				send_rtuport_parms(&epps);
				m_bReboot = TRUE;
			}
			break;

		default:
			break;
	}
	
	return(0);
}


void CPrgEthernetParams::OnBtnDownload()
{
	StoreConfig(TRUE);
	bDownloading = FALSE;
}

void CPrgEthernetParams::OnBtnReboot()
{
	BYTE tmpData[5];
	m_lpps.BC = 5;
	tmpData[0] = m_EthParams.nPortNum;
	tmpData[1] = 0;
	tmpData[2] = m_EthParams.nAppID;
	tmpData[3] = m_EthParams.nSesID;
	tmpData[4] = m_EthParams.nLnkID;
	m_lpps.lpData = tmpData;
	send_rtuport_parms(&m_lpps);
}

void CPrgEthernetParams::OnBtnDefault()
{
	/*
	m_bEthParams = TRUE;
	m_lpps.lpData[0] = ETHERNET_PARAMS_BLK;
	m_lpps.lpData[1] = 1;
	m_lpps.BC = 2;
	get_rtuport_parms(&m_lpps, 0, 0);
	*/
}

void CPrgEthernetParams::OnBtnDHCP()
{
	BOOL flag = IsDlgButtonChecked(IDC_CHK_EN_DHCP) ? FALSE : TRUE;
	GetDlgItem(IDC_IPA_LOCAL_NODE)->EnableWindow(flag);
	GetDlgItem(IDC_IPA_SUBNET_MASK)->EnableWindow(flag);
	GetDlgItem(IDC_IPA_ROUTER)->EnableWindow(flag);
}

void CPrgEthernetParams::OnSelChangedProtocol()
{
}

void CPrgEthernetParams::Initialize()
{
	int	appProt, sessProt, linkProt;
	CMyFile	hFile;
	TCHAR	str[MAX_PROTOCOL_STR];

	if(m_EthParams.nPriority > PORT_PRIO_DUAL_RPT)
		m_EthParams.nPriority = PORT_PRIO_DUAL_RPT;

	if (hFile.Open(DefaultLocation(RTUPROT1_STR_FILE), FILE_READ|FILE_DENYNONE, FF_DISERR) == FALSE) {
		if (hFile != NULL)
			hFile.Close();
		return;
	}

	memset(str, 0, sizeof(str));
	hFile.ReadString(str, MAX_PROTOCOL_STR - 1);
	if ((str[0] != '@') || (str[1] != '@')) {
		DispMessageBox(GetSafeHwnd(), IDS_INV_PROT_FILE, IDS_ERROR, MB_OK | MB_ICONSTOP);
		hFile.Close();
		return;
	}

	TCHAR sTmp[MAX_BUFF];
	LoadString(hrInst, IDS_UNDEFINED, sTmp, MAX_BUFF);
	LinkListItem* ProtocolList = new LinkListItem(sTmp, 0, 0, 0);
	LoadString(hrInst, IDS_DIS_PORT, sTmp, MAX_BUFF);
	ProtocolList->AddItem(sTmp, 0, 0, 0);
	
	while (hFile.ReadString(str, MAX_PROTOCOL_STR - 1) != NULL) 
	{
		TCHAR *s = str;
		TCHAR *p = 0;
		while (*s) {
			if (*s == ':') {
				p = s; // Mark start of parameter field
				*p++ = 0; // Separate field
				break; // We are done
			}
			s++;
		}
		if (p) {
			if (sscanfx(p, _T("%d:%d:%d"), &linkProt, &sessProt, &appProt) == 3) 
				ProtocolList->AddItem(str, (BYTE)linkProt, (BYTE)sessProt, (BYTE)appProt);
		}
	}

	hFile.Close();

	LinkListItem	*ptr;
	int				i, SelectionMatch;
	m_cboProtocol.ResetContent();
	SelectionMatch = 0;
	i = 0;
	for (ptr = ProtocolList; ptr != NULL; ptr = ptr->next) {
		m_cboProtocol.AddString(ptr->name);
		if ((m_EthParams.nLnkID == ptr->LinkProtocol) && 
			(m_EthParams.nSesID == ptr->SessionProtocol) && 
			(m_EthParams.nAppID == ptr->ApplicationProtocol))
			SelectionMatch = i;
		i++;
	}
	m_cboProtocol.SetCurSel(SelectionMatch);

	delete ProtocolList; ProtocolList = NULL;
}
void CPrgEthernetParams::ShowParams()
{
	Initialize();
	LPBYTE p = &m_EthParams.ipParams.myIpAddr[0];
	m_ipLocalNode.SetAddress(*p, *(p+1), *(p+2), *(p+3));

	p = &m_EthParams.ipParams.myIpMask[0];
	m_ipSubnetMask.SetAddress(*p, *(p+1), *(p+2), *(p+3));

	p = &m_EthParams.ipParams.rIpAddr1[0];
	m_ipRouter.SetAddress(*p, *(p+1), *(p+2), *(p+3));

	m_cboLine1A.SetCurSel(m_EthParams.bsParam1.lcardALine1En);
	m_cboLine2A.SetCurSel(m_EthParams.bsParam1.lcardALine2En);

	p = &m_EthParams.bsParam1.lcardALine1En;
	if(!CBasePrimary1ParamsPage::GetAddress(*p, p+1, &m_LineAddr[0])) {
		DispMessageBox(GetSafeHwnd(), IDS_WRONG_ADDR_TYPE, IDS_ERROR, MB_OK | MB_ICONSTOP);
	}
		

	p = &m_EthParams.bsParam1.lcardALine2En;
	if(!CBasePrimary1ParamsPage::GetAddress(*p, p+1, &m_LineAddr[18])) {
	 	DispMessageBox(GetSafeHwnd(), IDS_WRONG_ADDR_TYPE, IDS_ERROR, MB_OK | MB_ICONSTOP);
	}

	UpdateData(FALSE);
	OnBtnDHCP();
	ShowWindow(TRUE);
}

/*=========================================================================*/
/*=========================================================================*/
void CPrgDialupParams::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPrgDialupParams)
	DDX_Control(pDX, IDC_CBO_PRG_DIALUP_TYPE, m_cboDialerType);
	DDX_Control(pDX, IDC_CBO_PROTOCOL, m_cboProtocol);
	DDX_Control(pDX, IDC_CBO_PRG_DB_DIALUP_TYPE, m_cboDialupType);
	DDX_Control(pDX, IDC_CBO_PRG_PERI_TST_RPT, m_cboPeriodicTstRpt);
	DDX_Control(pDX, IDC_CBO_PRG_DIALER_PROTO, m_cboDialerProt);
	DDX_Control(pDX, IDC_LST_FLAGS, m_lstFlags);
	//}}AFX_DATA_MAP

	RtuLib::DDX_Text(pDX, IDC_TXT_PRG_ALM1, &Tel[0]);
	RtuLib::DDX_Text(pDX, IDC_TXT_PRG_PREDIAL_NUM, &PrePostTel[0]);
	RtuLib::DDX_Text(pDX, IDC_TXT_PRG_POSTDIAL_NUM, &PrePostTel[9]);

	RtuLib::DDX_Check(pDX, IDC_CHK_PRG_RAND_TIME, m_DluParams.bsParams2.dialupType, 6);
	DDX_Text(pDX, IDC_TXT_PRG_SCB_ACC_NUM, m_nAccountNumber);
	RtuLib::DDX_Text(pDX, IDC_TXT_PRG_RTU_TEL_NUM, m_ourTelNum);
	DDX_Text(pDX, IDC_TXT_PRG_NUM_RINGS, *(&m_DluParams.dluParams.ringAnswer));
	DDV_MinMaxByte(pDX, *(&m_DluParams.dluParams.ringAnswer), 0, 255);
}

BEGIN_MESSAGE_MAP(CPrgDialupParams, CDialog)
	//{{AFX_MSG_MAP(CPrgDialupParams)
	ON_BN_CLICKED(IDOK, OnOK)
	ON_MESSAGE(WM_GMS, OnGms)
	ON_CBN_SELCHANGE(IDC_CBO_PRG_DIALER_PROTO, OnSelChangedDialerProtocol)
	ON_CBN_SELCHANGE(IDC_CBO_PRG_DIALUP_TYPE, OnSelChangedDialupType)
	ON_BN_CLICKED(IDC_BTN_ADVANCED, OnBtnAdvanced)
	ON_BN_CLICKED(IDC_BTN_REBOOT, OnBtnReboot)
	ON_BN_CLICKED(IDC_BTN_DLOAD, OnBtnDownload)
	ON_BN_CLICKED(IDC_CHK_PRG_CREATE_CTRL_MSG, OnBtnAccCtrl)
	ON_LBN_SELCHANGE(IDC_LST_FLAGS, OnListBoxSelChange)
	//}}AFX_MSG_MAP
	ON_CLBN_CHKCHANGE(IDC_LST_FLAGS, OnListBoxCheckChange)
END_MESSAGE_MAP()

static void GetDluFlagList(CStringArray& strDluFlags)
{
	TCHAR sTmp[MAX_BUFF];
	for(int i=0; i<5; i++) {
		LoadString(hrInst, IDS_MIDNIGHT_DTONE_TST + i, sTmp, MAX_BUFF);
		strDluFlags.Add(sTmp);
	}
	LoadString(hrInst, IDS_EN_SEP_CARD_ACC_Q, sTmp, MAX_BUFF);
	strDluFlags.Add(sTmp);
}

static void GetPriorityStr(CStringArray& strPriority)
{
	TCHAR sTmp[MAX_BUFF];
	for(int i=0; i<3; i++) {
		LoadString(hrInst, IDS_PRIORITY_TXT3 + i, sTmp, MAX_BUFF);
		strPriority.Add(sTmp);
	}
	LoadString(hrInst, IDS_DIALER_ONLY, sTmp, MAX_BUFF);
	strPriority.Add(sTmp);
}
/////////////////////////////////////////////////////////////////////////////
// CPrgDialupParams message handlers
CPrgDialupParams::CPrgDialupParams()
{
	memset(&m_lpps, 0, sizeof(PARMPROC));
	m_pData = 0;
	m_nDialupType = 0;
	Tel[0] = _T('\0');
	PrePostTel[0] = _T('\0');
	m_ourTelNum[0] = _T('\0');
	m_nFlags = 0;
	m_nBlock = 0;
	m_bSysParams = 0;
	m_bDialerOnly = 0;
	m_bPacomProt = 0;
	m_nNextBlock = 0;
	m_nByteCount = 0;
	m_nAccountNumber = 0;
	
	memset(&m_DluParams,0, sizeof(DluParams));

	m_strTel =  m_strPredial = m_strPostdial = m_strRtuTel = _T("");
}
BOOL CPrgDialupParams::OnInitDialog() 
{
	CDialog::OnInitDialog();

	// TODO: Add extra initialization here
   	SendDlgItemMessage(IDC_TXT_PRG_PREDIAL_NUM, EM_SETLIMITTEXT, 8, 0);
	SendDlgItemMessage(IDC_TXT_PRG_ALM1, EM_SETLIMITTEXT, 18, 0);
	SendDlgItemMessage(IDC_TXT_PRG_POSTDIAL_NUM, EM_SETLIMITTEXT, 8, 0);
	SendDlgItemMessage(IDC_TXT_PRG_RTU_TEL_NUM, EM_SETLIMITTEXT, 17, 0);
	SendDlgItemMessage(IDC_TXT_PRG_NUM_RINGS, EM_SETLIMITTEXT, 3, 0);
	SendDlgItemMessage(IDC_TXT_PRG_SCB_ACC_NUM, EM_SETLIMITTEXT, 6, 0);

	m_lstFlags.SetCheckStyle(BS_AUTOCHECKBOX);
	CStringArray strDluFlags; GetDluFlagList(strDluFlags);
	for(int i=0; i<strDluFlags.GetSize(); i++) {
		m_lstFlags.AddString(strDluFlags.GetAt(i));
	}

	m_bDialerOnly = FALSE;
	m_bPacomProt = FALSE;

	m_lpps.heDlg = GetSafeHwnd();
	m_lpps.hmDlg = m_lpps.heDlg;
	
	TCHAR str[50];
	m_cboPeriodicTstRpt.ResetContent();
	for(int i=0; i<48; i++) {
		wsprintf(str, _T("%.2d:%s"), i/2, (i&1) ? _T("30") : _T("00"));
		m_cboPeriodicTstRpt.AddString(str);
	}

	m_cboDialerType.ResetContent();
	CStringArray strPriority; GetPriorityStr(strPriority);
	for(int i=0; i<strPriority.GetSize(); i++) {
		m_cboDialerType.AddString(strPriority.GetAt(i));
	}
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CPrgDialupParams::ShowConfig(LPPARMPROC lpps, BYTE bSys, LPBYTE ptrData, BYTE dialupBC, LPBYTE pDialupBuff)
{
	if( ((CRtuSetupWizard*)GetParent())->GetCurStep() != PROGRAM_DIALUP_PARAMS )
		return;

	m_dialupBC = dialupBC;
	m_pDialupBuffer = pDialupBuff;
	m_pData = ptrData;
	memcpy(&m_lpps, lpps, sizeof(m_lpps));
	memcpy(&m_DluParams, ptrData, sizeof(DluParams));
	m_nByteCount = m_DluParams.nByteCount;

	m_bSysParams = bSys;
	m_nNextBlock = -1;

	BYTE nDialupPortPriorityNumber = GetDialupPortPriorityNumber(realRtuType);
	if(m_bSysParams) {
		m_nBlock = m_DluParams.sysParams.p1.portPrty_Bx[nDialupPortPriorityNumber];
	}
	else {
		m_nBlock = m_DluParams.sysParams.p2.portPrty_Bx[nDialupPortPriorityNumber];
	}
	m_DluParams.bsParams2.flags &= 0x1f;
	m_nFlags = (BYTE)(m_DluParams.bsParams2.flags ^ 2);

	m_nAccountNumber = m_DluParams.msgFtrParams.accLByte;
	m_nAccountNumber |= m_DluParams.msgFtrParams.accHByte << 8;
	m_nAccountNumber |= (m_DluParams.msgFtrParams.accFlags & 0xf0) << 12;
	if(m_nAccountNumber == 0xfffff)		// Invalid default number
		m_nAccountNumber = 0;
	
	m_lpps.heDlg = GetSafeHwnd();
	m_lpps.hmDlg = m_lpps.heDlg;

	ShowPhoneNum((LPBYTE)&m_DluParams.bsParams1);
	GetProtocolList();
	ShowParams();
}

BOOL CPrgDialupParams::StoreConfig(BOOL bStore)
{
	if( ((CRtuSetupWizard*)GetParent())->GetCurStep() != PROGRAM_DIALUP_PARAMS )
		return TRUE;

	int dialProt = m_cboDialerProt.GetCurSel();
	int dialType = m_cboDialerType.GetCurSel();

	m_bDialerOnly = (dialType == DT_DIALER_ONLY) ? TRUE : FALSE;
	m_bPacomProt = (dialProt == DP_PACOM) ? TRUE : FALSE;
	UpdateData(TRUE);
	
	int i;
	TCHAR c;
	LPBYTE ptr;

	int nPriority = dialType;
	BYTE nDialupPortPriorityNumber = GetDialupPortPriorityNumber(realRtuType);
	// P1057, P1058
	if(m_bSysParams) {	
		if(m_bDialerOnly) { // Dialer Only
			ptr = &m_DluParams.sysParams.p1.portPrty_Bx[0]; 
			for(i=0; i<12; i++)	{
				if(*(ptr+i) == 1)
					*(ptr+i) = 0; // Force no priority
			}
			m_DluParams.sysParams.p1.portPrty_Bx[nDialupPortPriorityNumber] = 2;		// Force secondary priority for Dialup Port
			m_DluParams.nPriority = (BYTE)2;
		}
		else if(nPriority >= 0){
			m_DluParams.sysParams.p1.portPrty_Bx[nDialupPortPriorityNumber] = (BYTE)(nPriority + 2);
			m_DluParams.nPriority = (BYTE)(nPriority + 2);
		}
	}
	// Witness
	else {
		if(m_bDialerOnly) { // Dialer Only
			ptr = &m_DluParams.sysParams.p2.portPrty_Bx[0]; 
			for(i=0; i<7; i++)	{
				if(*(ptr+i) == 1)
					*(ptr+i) = 0; // Force no priority
			}
			m_DluParams.sysParams.p2.portPrty_Bx[nDialupPortPriorityNumber] = 2;		// Force secondary priority for Dialup Port
			m_DluParams.nPriority = (BYTE)2;
		}
		else if(nPriority >= 0){
			m_DluParams.sysParams.p2.portPrty_Bx[nDialupPortPriorityNumber] = (BYTE)(nPriority + 2);
			m_DluParams.nPriority = (BYTE)(nPriority + 2);
		}
	}

	if(dialProt != -1) {
		m_DluParams.bsParams1.alarmTel1En = (BYTE)(dialProt + 1);
		nReportCode = (BYTE)(dialProt);
	}
			  
	TCHAR	str[22];
	BYTE	temp[14];
	CString strPhone;

	// Save RTU Telephone Number
	for (i = 0; i < lstrlen(m_ourTelNum); i++) {
	    c = m_ourTelNum[i];
		if ((isdigitx(c) | (c == '*') | (c == '+')) == FALSE) {
			DispMessageBox(GetSafeHwnd(), IDS_INVALID_TEL_NUM, IDS_ERROR, MB_OK | MB_ICONEXCLAMATION);
			return FALSE;
		}
	}

	GetDlgItemText(IDC_TXT_PRG_RTU_TEL_NUM, strPhone);
	if(strPhone.Compare(m_strRtuTel) != 0) {
		memset(str, 0, sizeof(str));
		lstrncpy(str, m_ourTelNum, 20);
		Pack_Tel(str, temp);
		memcpy(&m_DluParams.dluParams.ourTelNum, &temp[1], 9);
	}
		
	// Save Telephone (alarm 1)
	for (i = 0; i < lstrlen(&Tel[0]); i++) {
		c = Tel[i];
		if ((isdigitx(c) | (c == '*') | (c == '+')) == FALSE) {
			DispMessageBox(GetSafeHwnd(), IDS_INVALID_TEL_NUM, IDS_ERROR, MB_OK | MB_ICONEXCLAMATION);
			return FALSE;
		}
	}
	
	GetDlgItemText(IDC_TXT_PRG_ALM1, strPhone);
	if(strPhone.Compare(m_strTel) != 0) {
		lstrncpy(str, &Tel[0], 18);
		str[18] = '\0';
		memset(temp, 0, sizeof(temp));
		Pack_Tel(str, temp);
		memcpy(&m_DluParams.bsParams1.alarmTel1[0], &temp[1], 9);
	}

	// Save Predial number
	for (i = 0; i < lstrlen(&PrePostTel[0]); i++) {
		c = PrePostTel[i];
		if ((isdigitx(c) | (c == '*') | (c == '+')) == FALSE) {
			DispMessageBox(GetSafeHwnd(), IDS_INV_PRE_TEL_NUM, IDS_ERROR, MB_OK | MB_ICONEXCLAMATION);
			return FALSE;
		}
	}

	GetDlgItemText(IDC_TXT_PRG_PREDIAL_NUM, strPhone);
	if(strPhone.Compare(m_strPredial) != 0) {
		lstrncpy(str, &PrePostTel[0], 8);
		str[8] = '\0';
		Pack_Tel(str, temp);
		memcpy(&m_DluParams.bsParams1.preTel1[0], &temp[1], 4);
	}

	// Save Postdial number
	for (i = 0; i < lstrlen(&PrePostTel[9]); i++) {
		c = PrePostTel[9 + i];
		if ((isdigitx(c) | (c == '*') | (c == '+')) == FALSE) {
			DispMessageBox(GetSafeHwnd(), IDS_INV_POST_TEL_NUM, IDS_ERROR, MB_OK | MB_ICONEXCLAMATION);
			return FALSE;
		}
	}

	GetDlgItemText(IDC_TXT_PRG_POSTDIAL_NUM, strPhone);
	if(strPhone.Compare(m_strPostdial) != 0) {
		lstrncpy(str, &PrePostTel[9], 8);
		str[8] = '\0';
		Pack_Tel(str, temp);
		memcpy(&m_DluParams.bsParams1.preTel1[0] + 4, &temp[1], 4);
	}

	BYTE d=0;
	BYTE mask=1;
	for(i=0; i<5; i++) {
		if(m_lstFlags.GetCheck(i))
			d |= mask;
		mask <<= 1;
	}
	m_nFlags &= 0xe0;
	m_nFlags |= d;
	m_nFlags ^= 0x02;
	m_DluParams.bsParams2.flags &= 0xe0;
	m_DluParams.bsParams2.flags |= (BYTE)(m_nFlags & 0x1f);

	if(m_bSysParams) {
		if(m_lstFlags.GetCheck(5))
			m_DluParams.sysParams.p1.numEvents |= BIT7;
		else
			m_DluParams.sysParams.p1.numEvents &= ~BIT7;
	}
	else {
		if(m_lstFlags.GetCheck(5))
			m_DluParams.sysParams.p2.numEvents |= BIT7;
		else
			m_DluParams.sysParams.p2.numEvents &= ~BIT7;
	}

	if(dialProt == DP_PACOM) { // Pacom Protocol
		m_DluParams.bsParams2.dialupType &= 0xc0;
		m_DluParams.bsParams2.dialupType |= (BYTE)(m_cboDialupType.GetCurSel() & 0x3f);
	}
	else if(dialProt > 0){
		m_DluParams.bsParams2.dialupType &= 0xc0;
		m_DluParams.bsParams2.dialupType |= (BYTE)(m_cboPeriodicTstRpt.GetCurSel() & 0x3f);
	}
	
	// Save Subcriber Account Number
	m_DluParams.msgFtrParams.accFlags &= 0x0f;
	m_DluParams.msgFtrParams.accFlags |= (BYTE)((m_nAccountNumber >> 12) & 0xf0);
	m_DluParams.msgFtrParams.accHByte = (BYTE)(m_nAccountNumber >> 8);
	m_DluParams.msgFtrParams.accLByte = (BYTE)(m_nAccountNumber );

	if(bStore == FALSE) {
		if(memcmp(&m_DluParams, m_pData, sizeof(m_DluParams)) != 0) {
			if(DispMessageBox(GetSafeHwnd(), IDS_WANT_DLOAD_CHNG, IDS_WARNING, MB_ICONINFORMATION | MB_YESNO) == IDNO)
				return TRUE;
		}
		else {
			return TRUE;
		}
	}
	
	if(dialProt == DP_PACOM) { // Pacom Protocol
		m_DluParams.bsParams2.dialupType &= ~BIT7;
	}
	else if(dialProt > 0){
		m_DluParams.bsParams2.dialupType |= BIT7;
	}

	BYTE tmpBuff[RTU_BUFF_SIZE];
	// Download Dialup Parameters
	m_lpps.lpData = tmpBuff;
	memcpy(tmpBuff, &m_DluParams.nPortNum, sizeof(LDIAL_PARM) + 5);
	tmpBuff[0] = GetDialupBlockNumber(realRtuType);
	m_lpps.BC = (BYTE)(sizeof(LDIAL_PARM) + 5);
	send_rtuport_parms(&m_lpps);
	m_nNextBlock = GENERAL_SYSTEM_PARAMS_BLK;
	memcpy(m_pData, &m_DluParams, sizeof(m_DluParams));

	return TRUE;
}

void CPrgDialupParams::ShowPhoneNum(LPBYTE pBsData)
{
	memcpy(&m_DluParams.bsParams1, pBsData, sizeof(SECONDARYPARM1) + sizeof(PRIORITY_PARM2));
	m_DluParams.bsParams2.flags &= 0x1f;
	m_nFlags = (BYTE)(m_DluParams.bsParams2.flags ^ 0x02);

	TCHAR str[50];
	BYTE temp[15];
	int i;
	memcpy(&temp[1], &m_DluParams.bsParams1.alarmTel1[0], 9);
	temp[0] = 18;
	Unpack_Tel(str, temp, 18);
	wsprintf(&Tel[0], _T("%s"), str);

	// pre/post stuff
	for (i = 0; i < 2; i++) {
		memcpy(&temp[1], &pBsData[60 + i*4], 4);
		temp[0] = 8;
		Unpack_Tel(str, temp, 8);
		wsprintf(&PrePostTel[i * 9], _T("%s"), str);
	}

	memset(temp, 0, sizeof(temp));
	memset(str, 0, sizeof(str));
	memcpy(&temp[1], &m_DluParams.dluParams.ourTelNum[0] , MAX_NUM_BYTES);
	temp[0] = 20;
	Unpack_Tel(str, temp, 20);
	wsprintf(m_ourTelNum, _T("%s"), str);

	for (i = 0; i < lstrlen(m_ourTelNum); i++) {
	    TCHAR c = m_ourTelNum[i];
		if ((isdigitx(c) | (c == '*') | (c == '+')) == FALSE) {
			wsprintf(m_ourTelNum, _T(""));
			break;
		}
	}

	UpdateData(FALSE);

	GetDlgItemText(IDC_TXT_PRG_PREDIAL_NUM, m_strPredial);
	GetDlgItemText(IDC_TXT_PRG_ALM1, m_strTel);
	GetDlgItemText(IDC_TXT_PRG_POSTDIAL_NUM, m_strPostdial);
	GetDlgItemText(IDC_TXT_PRG_RTU_TEL_NUM, m_strRtuTel);
}

LRESULT CPrgDialupParams::OnGms(WPARAM wParam, LPARAM lParam)
{
	PARMPROC pps;
	BYTE data[RTU_BUFF_SIZE];

	LPBYTE p = (LPBYTE)lParam;
	if(p == NULL)
		return 0;

	memcpy(&pps, &m_lpps, sizeof(pps));
	pps.lpData = &data[0];

	UINT id = GET_WM_COMMAND_ID(wParam, lParam);
	switch(id) {
		case IDD_COMMOVR_ERROR:
			return 0;
			break;
		case IDD_COMMOVR_DATA1:
			memcpy(m_pDialupBuffer, p+5, RTU_BUFF_SIZE);
			m_dialupBC = *p;
			m_dialupBC = (BYTE)(m_dialupBC - 10);
			m_nNextBlock = -1;
			break;
		case IDD_COMMOVR_DATA:
			if( ((CRtuSetupWizard*)GetParent())->GetCurStep() != PROGRAM_DIALUP_PARAMS )
				return 0;

			ShowPhoneNum(p+1);
			ShowDialupType();
			break;

		case IDD_HIRESP:
			if(m_nNextBlock == GENERAL_SYSTEM_PARAMS_BLK) {
				m_nNextBlock = SECONDARY_PRIORITY_PARAMS_BLK;
				
				pps.lpData[0] = GENERAL_SYSTEM_PARAMS_BLK;
				if(m_bSysParams) {
					memcpy(&pps.lpData[1], &m_DluParams.sysParams.p1, sizeof(SYSPARM));
					pps.BC = sizeof(SYSPARM) + 1;
				}
				else {
					memcpy(&pps.lpData[1], &m_DluParams.sysParams.p2, sizeof(SYSPARM2000));
					pps.BC = sizeof(SYSPARM2000) + 1;
				}
				send_rtuport_parms(&pps);
			}
			else if(m_nNextBlock == SECONDARY_PRIORITY_PARAMS_BLK) {
				m_nNextBlock = MESSAGE_FILTER_PARAMS_BLK;
				
				if(m_nBlock == 3)
					pps.lpData[0] = TERTIARY_PRIORITY_PARAMS_BLK;
				else if(m_nBlock == 4)
					pps.lpData[0] = BACKUP_OPARATION_PARAMS_BLK;
				else
					pps.lpData[0] = SECONDARY_PRIORITY_PARAMS_BLK;

				memcpy(&data[1], &m_DluParams.bsParams1, sizeof(SECONDARYPARM1) + sizeof(PRIORITY_PARM2));
				pps.BC = sizeof(SECONDARYPARM1) + sizeof(PRIORITY_PARM2) + 1;
				send_rtuport_parms(&pps);
			}
			else if(m_nNextBlock == MESSAGE_FILTER_PARAMS_BLK) {
				m_nNextBlock = DIALUP_PARAMS_BLK;

				pps.lpData[0] = MESSAGE_FILTER_PARAMS_BLK;
				memcpy(&(pps.lpData[1]), &m_DluParams.msgFtrParams, sizeof(MSGFILTERPARM));
				pps.BC = sizeof(MSGFILTERPARM) + 1; 
				send_rtuport_parms(&pps);

				memcpy(m_pData, &m_DluParams, sizeof(m_DluParams));
			}
			else if(m_nNextBlock == DIALUP_PARAMS_BLK) {
				pps.BC = 6;
				pps.lpData[0] = GetDialupBlockNumber(realRtuType);
				pps.lpData[1] = 0;
				pps.lpData[2] = m_DluParams.nAppID;
				pps.lpData[3] = m_DluParams.nSesID;
				pps.lpData[4] = m_DluParams.nLnkID;
				pps.lpData[5] = 1; // For new cfg
				get_rtuport_parms(&pps, 0, 0);
				m_nNextBlock = -1;
			}
			
			break;

		default:
			break;
	}
	
	return 0;
}

void CPrgDialupParams::ShowDialupType()
{
	BYTE nDialupPortPriorityNumber = GetDialupPortPriorityNumber(realRtuType);
	if(m_bSysParams) {
		m_nDialupType = m_DluParams.sysParams.p1.portPrty_Bx[nDialupPortPriorityNumber] - 2;
	}
	else {
		m_nDialupType = m_DluParams.sysParams.p2.portPrty_Bx[nDialupPortPriorityNumber] - 2;
	}

	BYTE nDialupProt = m_DluParams.bsParams1.alarmTel1En;
	m_cboDialerProt.SetCurSel(nDialupProt - 1);
	BYTE nDialupType = (BYTE)(m_DluParams.bsParams2.dialupType & 0x3f);

	if(nDialupProt == 1) {	// Pacom protocol
		m_cboDialupType.EnableWindow(TRUE);
		m_cboPeriodicTstRpt.EnableWindow(FALSE);
		GetDlgItem(IDC_CHK_PRG_RAND_TIME)->EnableWindow(FALSE);
		
		if(nDialupType >= m_cboDialupType.GetCount())
			nDialupType = 0;
		m_cboDialupType.SetCurSel(nDialupType);
	}
	else {
		m_cboDialupType.EnableWindow(FALSE);
		m_cboPeriodicTstRpt.EnableWindow(TRUE);
		GetDlgItem(IDC_CHK_PRG_RAND_TIME)->EnableWindow(TRUE);

		m_cboPeriodicTstRpt.SetCurSel(nDialupType);
	}
}

	
BOOL CPrgDialupParams::DialerOnly(LPBYTE ptr, int cnt, int dluType)
{
	BYTE nDialupPortPriorityNumber = GetDialupPortPriorityNumber(realRtuType);
	for(int i=0; i<cnt; i++) {
		if((i != nDialupPortPriorityNumber) && (*(ptr+i) == 1)) {
			return FALSE;
		}
	}

	if(dluType == DT_SECONDARY)
		return TRUE;
	else
		return FALSE;
}

void CPrgDialupParams::ShowParams()
{
	BYTE nDialupPortPriorityNumber = GetDialupPortPriorityNumber(realRtuType);
	if(m_bSysParams) {	// P1057, P1058
		m_nDialupType = m_DluParams.sysParams.p1.portPrty_Bx[nDialupPortPriorityNumber] - 2;
		m_bDialerOnly = DialerOnly(&m_DluParams.sysParams.p1.portPrty_Bx[0], 12, m_nDialupType);
	}
	else {				// Witness, 8001
		m_nDialupType = m_DluParams.sysParams.p2.portPrty_Bx[nDialupPortPriorityNumber] - 2;
		m_bDialerOnly = DialerOnly(&m_DluParams.sysParams.p2.portPrty_Bx[0], 7, m_nDialupType);
	}

	BYTE nDialupProt = m_DluParams.bsParams1.alarmTel1En;
	if(m_bDialerOnly)
		m_cboDialerType.SetCurSel(3);
	else
		m_cboDialerType.SetCurSel(m_nDialupType);

	int sel = nDialupProt - 1;
	m_cboDialerProt.SetCurSel(sel);

	SendDlgItemMessage(IDC_TXT_PRG_SCB_ACC_NUM, EM_SETLIMITTEXT, (sel == DP_SIA) ? 6 : 4, 0);
	
	ShowParams2();
	ShowWindow(TRUE);
}


void CPrgDialupParams::ShowParams2()
{
	BYTE nDialupType = (BYTE)(m_DluParams.bsParams2.dialupType & 0x3f);
	BYTE nDialupProt = m_DluParams.bsParams1.alarmTel1En;

	if(nDialupProt == 1) {	// Pacom protocol
		m_cboDialupType.EnableWindow(TRUE);
		m_cboPeriodicTstRpt.EnableWindow(FALSE);
		GetDlgItem(IDC_CHK_PRG_RAND_TIME)->EnableWindow(FALSE);
		
		if(nDialupType >= m_cboDialupType.GetCount())
			nDialupType = 0;
		m_cboDialupType.SetCurSel(nDialupType);
		m_cboPeriodicTstRpt.SetCurSel(nDialupType);
	}
	else {
		m_cboDialupType.EnableWindow(FALSE);
		m_cboPeriodicTstRpt.EnableWindow(TRUE);
		GetDlgItem(IDC_CHK_PRG_RAND_TIME)->EnableWindow(TRUE);

		m_cboPeriodicTstRpt.SetCurSel(nDialupType);
		m_cboDialupType.SetCurSel(nDialupType);

	}

	GetDlgItem(IDC_TXT_PRG_SCB_ACC_NUM)->EnableWindow(FALSE);

	int i;
	switch(nDialupProt) {
	case 1:		// Pacom protocol
		for(i=0; i<4; i++) 
			GetDlgItem(IDC_CHK_PGR_APP_MSG_FILTER + i)->EnableWindow(FALSE);
		GetDlgItem(IDC_CHK_PRG_MIDNIGHT)->EnableWindow(TRUE);

		for(i=2; i<6; i++)
			m_lstFlags.Enable(i, FALSE);
		m_lstFlags.Enable(0, TRUE);

		break;
	case 2:		// Contact ID
	case 3:		// SIA
		for(i=0; i<6; i++) 
			GetDlgItem(IDC_CHK_PRG_MIDNIGHT + i)->EnableWindow(TRUE);
		GetDlgItem(IDC_TXT_PRG_SCB_ACC_NUM)->EnableWindow(TRUE);

		for(i=0; i<6; i++)
			m_lstFlags.Enable(i, TRUE);
		break;
	case 4:		// SIM
		for(i=0; i<6; i++) 
			GetDlgItem(IDC_CHK_PRG_MIDNIGHT + i)->EnableWindow(TRUE);

		for(i=0; i<6; i++)
			m_lstFlags.Enable(i, TRUE);

		break;
	}

	GetDlgItem(IDC_CHK_PRG_MUL_ALM_RPT)->EnableWindow(nDialupProt == DT_DIALER_ONLY ? TRUE : FALSE);
	m_lstFlags.Enable(1, nDialupProt == DT_DIALER_ONLY ? TRUE : FALSE);

	BYTE d = m_nFlags;
	for(i=0; i<5; i++) {
		m_lstFlags.SetCheck(i, d & 1 ? TRUE : FALSE);
		d >>= 1;
	}
	
	d = m_bSysParams ? m_DluParams.sysParams.p1.numEvents : m_DluParams.sysParams.p2.numEvents;
	m_lstFlags.SetCheck(i, d & BIT7 ? TRUE : FALSE);

	if(m_cboDialerProt.GetCurSel() < 0)
		GetDlgItem(IDC_CBO_PRG_PERI_TST_RPT)->EnableWindow(FALSE);
}

void CPrgDialupParams::OnListBoxSelChange()
{
	int nIndex = m_lstFlags.GetCurSel();
	m_lstFlags.SetCheck(nIndex, m_lstFlags.GetCheck(nIndex) ? BST_UNCHECKED : BST_CHECKED);

	if(nIndex == 4) {
		if(m_lstFlags.GetCheck(nIndex))
			m_lstFlags.SetCheck(nIndex+1, TRUE);
	}
}

void CPrgDialupParams::OnListBoxCheckChange()
{
	int nIndex = m_lstFlags.GetCurSel();
	m_lstFlags.SetCheck(nIndex, m_lstFlags.GetCheck(nIndex) ? BST_UNCHECKED : BST_CHECKED);
}

void CPrgDialupParams::OnBtnAccCtrl()
{
	if(IsDlgButtonChecked(IDC_CHK_PRG_CREATE_CTRL_MSG)) {
		CheckDlgButton(IDC_CHK_PRG_EN_SEP_CACC, TRUE);
	}
}

void CPrgDialupParams::OnSelChangedDialerProtocol()
{
	int sel = m_cboDialerProt.GetCurSel();
	SendDlgItemMessage(IDC_TXT_PRG_SCB_ACC_NUM, EM_SETLIMITTEXT, (sel == DP_SIA) ? 6 : 4, 0);
	m_cboDialupType.EnableWindow(sel == 0 ? TRUE : FALSE);
	m_cboPeriodicTstRpt.EnableWindow(sel == 0 ? FALSE : TRUE);
	m_DluParams.bsParams1.alarmTel1En = (BYTE)(sel + 1);
	ShowParams2();
}

void CPrgDialupParams::OnSelChangedDialupType()
{
	int sel = m_cboDialerType.GetCurSel();
	if(sel == DT_DIALER_ONLY) // Dialer only selected
		m_nBlock = 2;
	else 
		m_nBlock = (BYTE)(sel + 2);

	BYTE nDialupPortPriorityNumber = GetDialupPortPriorityNumber(realRtuType);
	BYTE nEthernetPortPriorityNumber = GetEthernetPortPriorityNumber(realRtuType);
	if(m_bSysParams) {
		if(sel == DT_SECONDARY)
			m_DluParams.sysParams.p1.portPrty_Bx[nEthernetPortPriorityNumber] = 1;	// Force Eth Priority to Primary
		m_DluParams.sysParams.p1.portPrty_Bx[nDialupPortPriorityNumber] = m_nBlock;
	}
	else {
		if(sel == DT_SECONDARY)
			m_DluParams.sysParams.p2.portPrty_Bx[nEthernetPortPriorityNumber] = 1;	// Force Eth Priority to Primary
		m_DluParams.sysParams.p2.portPrty_Bx[nDialupPortPriorityNumber] = m_nBlock;
	}

	m_lpps.heDlg = GetSafeHwnd();
	m_lpps.hmDlg = m_lpps.heDlg;

	BYTE nBlock;
	if(m_nBlock == 3) 
		nBlock = TERTIARY_PRIORITY_PARAMS_BLK;
	else if(m_nBlock == 4)
		nBlock = BACKUP_OPARATION_PARAMS_BLK;
	else
		nBlock = SECONDARY_PRIORITY_PARAMS_BLK;

	PARMPROC ps; 
	BYTE tmpBuff[2];
	memcpy(&ps, &m_lpps, sizeof(ps));
	ps.lpData = &tmpBuff[0];
	tmpBuff[0] = nBlock;
	tmpBuff[1] = 0;
	ps.BC = 2;
	get_rtuport_parms(&ps, 0, 0);
}


void CPrgDialupParams::OnBtnAdvanced()
{
	if( ((CRtuSetupWizard*)GetParent())->GetCurStep() != PROGRAM_DIALUP_PARAMS )
		return;

	UINT accNum = GetDlgItemInt(IDC_TXT_PRG_SCB_ACC_NUM);
	if(accNum != m_nAccountNumber) {
		// Save Subcriber Account Number
		m_DluParams.msgFtrParams.accFlags &= 0x0f;
		m_DluParams.msgFtrParams.accFlags |= (BYTE)((accNum >> 12) & 0xf0);
		m_DluParams.msgFtrParams.accHByte = (BYTE)(accNum >> 8);
		m_DluParams.msgFtrParams.accLByte = (BYTE)(accNum);

		PARMPROC ps;
		BYTE tmpBuff[RTU_BUFF_SIZE];
		memcpy(&ps, &m_lpps, sizeof(ps));
		ps.lpData = tmpBuff;
		ps.lpData[0] = MESSAGE_FILTER_PARAMS_BLK;
		memcpy(&(ps.lpData[1]), &m_DluParams.msgFtrParams, sizeof(MSGFILTERPARM));
		ps.BC = sizeof(MSGFILTERPARM) + 1; 
		send_rtuport_parms(&ps);
		m_nNextBlock = -1;
	}

	m_lpps.lpData = m_pDialupBuffer;
	switch(realRtuType) {
	case RTU_1057_TYPE:
		ShowPortParamsDlg(this, &m_lpps, m_dialupBC); break;
	case RTU_1058_TYPE:
		Show1058PortParamsDlg(this, &m_lpps, m_dialupBC); break;
	case RTU_2000_TYPE:
		ShowVCUPortParamsDlg(this, &m_lpps, m_dialupBC); break;
	case RTU_8001_TYPE:
		Show8001PortParamsDlg(this, &m_lpps, m_dialupBC); break;
	}

	GetParent()->SendMessage(WM_UPLOAD_CONFIG);
}

void CPrgDialupParams::OnBtnReboot()
{
	PARMPROC ps;
	BYTE data[5];
	memcpy(&ps, &m_lpps, sizeof(ps));
	ps.lpData = data;
	ps.BC = 5;
	ps.lpData[0] = m_DluParams.nPortNum;
	ps.lpData[1] = 0;
	ps.lpData[2] = m_DluParams.nAppID;
	ps.lpData[3] = m_DluParams.nSesID;
	ps.lpData[4] = m_DluParams.nLnkID;
	send_rtuport_parms(&ps);
}

void CPrgDialupParams::OnBtnDownload()
{
	StoreConfig(TRUE);
}

void CPrgDialupParams::GetProtocolList()
{
	// Create list of valid protocol combinations.
	CMyFile	hFile;
	if (hFile.Open(DefaultLocation(RTUPROT1_STR_FILE), FILE_READ|FILE_DENYNONE, FF_DISERR) == FALSE) {
		if (hFile != NULL)
			hFile.Close();
		return;
	}

	TCHAR	str[MAX_PROTOCOL_STR];
	memset(str, 0, sizeof(str));
	hFile.ReadString(str, MAX_PROTOCOL_STR - 1);
	if ((str[0] != '@') || (str[1] != '@')) {
		DispMessageBox(GetSafeHwnd(), IDS_INV_PROT_FILE, IDS_ERROR, MB_OK | MB_ICONSTOP);
		hFile.Close();
		return;
	}
	TCHAR sTmp[MAX_BUFF];
	LoadString(hrInst, IDS_UNDEFINED, sTmp, MAX_BUFF);
	LinkListItem* ProtocolList = new LinkListItem(sTmp, 0, 0, 0);
	LoadString(hrInst, IDS_DIS_PORT, sTmp, MAX_BUFF);
	ProtocolList->AddItem(sTmp, 0, 0, 0);
	
	int	appProt, sessProt, linkProt;
	while (hFile.ReadString(str, MAX_PROTOCOL_STR - 1) != NULL) {
		TCHAR *s = str;
		TCHAR *p = 0;
		while (*s) {
			if (*s == ':') {
				p = s; // Mark start of parameter field
				*p++ = 0; // Separate field
				break; // We are done
			}
			s++;
		}
		if (p) {
			if (sscanfx(p, _T("%d:%d:%d"), &linkProt, &sessProt, &appProt) == 3) 
				ProtocolList->AddItem(str, (BYTE)linkProt, (BYTE)sessProt, (BYTE)appProt);
		}
	}

	hFile.Close();

	LinkListItem	*ptr;
	int				i, SelectionMatch;
	m_cboProtocol.ResetContent();
	SelectionMatch = 0;
	i = 0;
	for (ptr = ProtocolList; ptr != NULL; ptr = ptr->next) {
		m_cboProtocol.AddString(ptr->name);
		if ((m_DluParams.nLnkID == ptr->LinkProtocol) && 
			(m_DluParams.nSesID == ptr->SessionProtocol) && 
			(m_DluParams.nAppID == ptr->ApplicationProtocol))
			SelectionMatch = i;
		i++;
	}

	m_cboProtocol.SetCurSel(SelectionMatch);
	delete ProtocolList; ProtocolList = NULL;
}


/*=========================================================================*/
/*=========================================================================*/
void CPrgDialupMsgFilters::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPrgDialupMsgFilters)
	DDX_Control(pDX, IDC_LST_MSG, m_lstMessageFilter);
	DDX_Control(pDX, IDC_LST_MSG2, m_lstMessageFilter2);
	DDX_Control(pDX, IDC_LST_INT_ALM, m_lstIntAlm);
	DDX_Control(pDX, IDC_LST_STAT_ALM, m_lstStatAlm);
	DDX_Control(pDX, IDC_LST_CARD_ACC, m_lstCardAcc);
	//}}AFX_DATA_MAP
	
	RtuLib::DDX_Check(pDX, IDC_CHK_REPORT_AREAS, m_msgFtrParams.msgFtrParams.accFlags, 0);
	RtuLib::DDX_Check(pDX, IDC_CHK_SUP_CMD, m_msgFtrParams.msgFtrParams.accFlags, 1);

}

BEGIN_MESSAGE_MAP(CPrgDialupMsgFilters, CDialog)
	//{{AFX_MSG_MAP(CPrgDialupMsgFilters)
	ON_BN_CLICKED(IDOK, OnOK)
	ON_BN_CLICKED(IDCANCEL, OnCancel)
	ON_BN_CLICKED(IDC_BTN_DFAULT, OnBtnDefault)
	ON_BN_CLICKED(IDC_BTN_SELALL, OnBtnAddAll)
	ON_BN_CLICKED(IDC_BTN_DESELALL, OnBtnRemoveAll)
	ON_BN_CLICKED(IDC_BTN_Add, OnBtnAdd)
	ON_BN_CLICKED(IDC_BTN_REMOVE, OnBtnRemove)
	ON_MESSAGE(WM_GMS, OnGms)
	ON_LBN_SELCHANGE(IDC_LST_INT_ALM, OnLstIntAlmChange)
	ON_LBN_SELCHANGE(IDC_LST_STAT_ALM, OnLstStatAlmChange)
	ON_LBN_SELCHANGE(IDC_LST_CARD_ACC, OnLstCardAccChange)
	//}}AFX_MSG_MAP
	ON_CLBN_CHKCHANGE(IDC_LST_INT_ALM, OnLstIntAlmChange)
	ON_CLBN_CHKCHANGE(IDC_LST_STAT_ALM, OnLstStatAlmChange)
	ON_CLBN_CHKCHANGE(IDC_LST_CARD_ACC, OnLstCardAccChange)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPrgDialupMsgFilters message handlers
 
BOOL CPrgDialupMsgFilters::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	//m_cboIntAlm.ResetContent();
	TCHAR sTmp[80];
	LoadString(hrInst, IDS_TAMPER, sTmp, 80);
	m_lstIntAlm.AddString(sTmp);
	LoadString(hrInst, IDS_OFFLINE, sTmp, 80);
	m_lstIntAlm.AddString(sTmp);
	LoadString(hrInst, IDS_CARD_ACC, sTmp, 80);
	m_lstIntAlm.AddString(sTmp);
	LoadString(hrInst, IDS_LATE_TO_CLS, sTmp, 80);
	m_lstIntAlm.AddString(sTmp);

	LoadString(hrInst, IDS_PIN_ERR, sTmp, 80);
	m_lstStatAlm.AddString(sTmp);
	LoadString(hrInst, IDS_WARNING, sTmp, 80);
	m_lstStatAlm.AddString(sTmp);
	LoadString(hrInst, IDS_FINAL_SET, sTmp, 80);
	m_lstStatAlm.AddString(sTmp);
	LoadString(hrInst, IDS_DURESS, sTmp, 80);
	m_lstStatAlm.AddString(sTmp);
	LoadString(hrInst, IDS_MODE_CHNG, sTmp, 80);
	m_lstStatAlm.AddString(sTmp);
	LoadString(hrInst, IDS_SUBMODE_CHNG, sTmp, 80);
	m_lstStatAlm.AddString(sTmp);

	LoadString(hrInst, IDS_VALID, sTmp, 80);
	m_lstCardAcc.AddString(sTmp);
	LoadString(hrInst, IDS_INVALID, sTmp, 80);
	m_lstCardAcc.AddString(sTmp);
	LoadString(hrInst, IDS_DURESS, sTmp, 80);
	m_lstCardAcc.AddString(sTmp);

	RtuLib::GetFileStrings(MSG_FILTERS_FILE, m_strArrMsgs);
	RemoveFileIndex(m_strArrMsgs);
	m_nNumMsgs = m_strArrMsgs.GetSize();

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CPrgDialupMsgFilters::ShowConfig(LPPARMPROC lpps, BYTE bSysParm, LPBYTE ptrData, BYTE /*BC2*/, LPBYTE /*pBuffer2*/)
{
	if( ((CRtuSetupWizard*)GetParent())->GetCurStep() != MESSAGE_FILTERS )
		return;

	m_pData = ptrData;
	memcpy(&m_lpps, lpps, sizeof(m_lpps));
	memcpy(&m_msgFtrParams, ptrData, sizeof(m_msgFtrParams));
	m_bSysParams = bSysParm == 1 ? TRUE : FALSE;

	m_bMsgFilterParams = FALSE;
	m_nNextBlock = -1;

	m_lpps.heDlg = GetSafeHwnd();
	m_lpps.hmDlg = m_lpps.heDlg;

	ShowParams();
}

BOOL CPrgDialupMsgFilters::StoreConfig(BOOL bStore)
{
	if( ((CRtuSetupWizard*)GetParent())->GetCurStep() != MESSAGE_FILTERS )
		return TRUE;

	UpdateData();
	
	DWORD nItemData;
	int nOffset;
	int nByte;

	for(int i=0; i<m_lstMessageFilter.GetCount(); i++) {
		nItemData = m_lstMessageFilter.GetItemData(i);
		nOffset = nItemData / 8;
		nByte = nItemData % 8;
		nByte = 1 << nByte;
		m_msgFtrParams.msgFtrParams.filterData[nOffset] &= ~nByte;
	}

	for(int i=0; i<m_lstMessageFilter2.GetCount(); i++) {
		nItemData = m_lstMessageFilter2.GetItemData(i);
		nOffset = nItemData / 8;
		nByte = nItemData % 8;
		nByte = 1 << nByte;
		m_msgFtrParams.msgFtrParams.filterData[nOffset] |= nByte;
	}

	// Store Gen Config
	BYTE mask=BIT0;
	for(int i=0; i<4; i++) {
		if(m_lstIntAlm.GetCheck(i))
			m_nIntAlm |= mask;
		else 
			m_nIntAlm &= ~mask;
		mask <<= 1;
	}
	mask = BIT0;
	for(int i=0; i<6; i++) {
		if(m_lstStatAlm.GetCheck(i))
			m_nStatAlm |= mask;
		else
			m_nStatAlm &= ~mask;
		mask <<= 1;
	}
	mask = BIT0;
	for(int i=0; i<3; i++) {
		if(m_lstCardAcc.GetCheck(i))
			m_nCardAcc |= mask;
		else
			m_nCardAcc &= ~mask;
		mask <<= 1;
	}

	if (!m_bSysParams) {
		m_msgFtrParams.sysParams2.importantInternalFilters = m_nIntAlm;
		m_msgFtrParams.sysParams2.importantStatusFilters = m_nStatAlm;
		m_msgFtrParams.sysParams2.importantAccessFilters = m_nCardAcc;
	}		
	else {
		m_msgFtrParams.sysParams.importantInternalFilters = m_nIntAlm;
		m_msgFtrParams.sysParams.importantStatusFilters = m_nStatAlm;
		m_msgFtrParams.sysParams.importantAccessFilters = m_nCardAcc;
	}


	//download Params
	m_lpps.lpData[0] = MESSAGE_FILTER_PARAMS_BLK;	// Block number
	m_lpps.BC = sizeof(MSGFILTERPARM) + 1; // Byte count
	memcpy(&(m_lpps.lpData[1]), &m_msgFtrParams.msgFtrParams, sizeof(MSGFILTERPARM)); // data

	if(bStore == FALSE) {
		if(memcmp(&m_msgFtrParams, m_pData, sizeof(m_msgFtrParams)) != 0) {
			if(DispMessageBox(GetSafeHwnd(), IDS_WANT_DLOAD_CHNG, IDS_WARNING, MB_ICONINFORMATION | MB_YESNO) == IDNO)
				return TRUE;
		}
		else {
			return TRUE;
		}
	}


	m_lpps.Ret = IDD_COMMOVR;
	send_rtuport_parms(&m_lpps);

	m_nNextBlock = GENERAL_SYSTEM_PARAMS_BLK;

	return TRUE;
}

void CPrgDialupMsgFilters::OnOK()
{
	StoreConfig(TRUE);	
}

void CPrgDialupMsgFilters::OnBtnAdd()
{
	Move(IDC_LST_MSG2, IDC_LST_MSG);
}

void CPrgDialupMsgFilters::OnBtnRemove()
{
	Move(IDC_LST_MSG, IDC_LST_MSG2);
}

void CPrgDialupMsgFilters::Move(UINT desID, UINT srcID)
{
	CListBox* pSrc = (CListBox*)GetDlgItem(srcID);
	CListBox* pDes = (CListBox*)GetDlgItem(desID);
	if(pSrc == NULL || pDes == NULL)
		return;

	CStringArray strArr, strItemData;
	CString str;
	DWORD nItemData;
	BOOL flag;
	int cnt = pSrc->GetCount();
	for(int i=0; i<cnt; i++) {
		pSrc->GetText(i, str);
		strArr.Add(str);
		str.Format(_T("%d"), pSrc->GetItemData(i));
		strItemData.Add(str);
	}

	for(int i=0; i<cnt; i++) {
		if(pSrc->GetSel(i)) {
			pSrc->GetText(i, str);
			nItemData = pSrc->GetItemData(i);
			strArr.SetAt(i, _T(""));

			flag = FALSE;
			int j=0;
			for(; j<pDes->GetCount(); j++) {
				if(nItemData < pDes->GetItemData(j)) {
					pDes->InsertString(j, str);
					pDes->SetItemData(j, nItemData);
					flag = TRUE;
					break;
				}
			}

			if(!flag) {
				pDes->AddString(str);
				pDes->SetItemData(j, nItemData);
			}
		}
	}

	cnt = 0;
	pSrc->ResetContent();
	for(int i=0; i<strArr.GetSize(); i++) {
		str = strArr.GetAt(i);
		if(str != _T("")) {
			pSrc->AddString(strArr.GetAt(i));
			str = strItemData.GetAt(i);
			LPTSTR p = str.GetBuffer(str.GetLength());
			nItemData = wGetStrInt(p);
			pSrc->SetItemData(cnt++, nItemData);
			str.ReleaseBuffer();
		}
	}

}

void CPrgDialupMsgFilters::OnBtnDefault()
{
	m_bMsgFilterParams = TRUE;
	m_lpps.lpData[0] = MESSAGE_FILTER_PARAMS_BLK;
	m_lpps.lpData[1] = 1;
	m_lpps.BC = 2;
	get_rtuport_parms(&m_lpps, 0, 0);		
}

void CPrgDialupMsgFilters::OnBtnAddAll()
{
	m_lstMessageFilter.SelItemRange(TRUE, 0, m_lstMessageFilter.GetCount());
	OnBtnAdd();
}

void CPrgDialupMsgFilters::OnBtnRemoveAll()
{
	m_lstMessageFilter2.SelItemRange(TRUE, 0, m_lstMessageFilter2.GetCount());
	OnBtnRemove();
}

void CPrgDialupMsgFilters::ShowParams()
{
	m_lstMessageFilter.ResetContent();
	m_lstMessageFilter2.ResetContent();
	for(int j=0; j<m_nNumMsgs; j++) {
		m_lstMessageFilter.AddString(m_strArrMsgs.GetAt(j));
		m_lstMessageFilter.SetItemData(j, j);
	}

	UpdateData(FALSE);

	BYTE mask;
	int msgCnt = 0;
	CString str;
	int nItemData=0;
	int nIndex2=0;
	int nIndex1=0;
	LPBYTE pdata = &m_msgFtrParams.msgFtrParams.filterData[0];
	for(int i=0; i<sizeof(m_msgFtrParams.msgFtrParams.filterData); i++) {
		mask = 1;
		for(int j=0; j<8; j++) {
			if(*pdata & mask) {
				m_lstMessageFilter.GetText(nIndex1, str);
				nItemData = m_lstMessageFilter.GetItemData(nIndex1);
				m_lstMessageFilter.DeleteString(nIndex1);
				m_lstMessageFilter2.AddString(str);
				m_lstMessageFilter2.SetItemData(nIndex2, nItemData);
				nIndex2++;
			}
			else {
				nIndex1++;
			}

			mask <<= 1;
			if(++msgCnt >= m_nNumMsgs)
				break;
		}
		pdata++;
	}

	if (m_bSysParams) {
		m_nIntAlm = m_msgFtrParams.sysParams.importantInternalFilters;
		m_nStatAlm = m_msgFtrParams.sysParams.importantStatusFilters;
		m_nCardAcc = m_msgFtrParams.sysParams.importantAccessFilters;

	}
	else {
		m_nIntAlm = m_msgFtrParams.sysParams2.importantInternalFilters;
		m_nStatAlm = m_msgFtrParams.sysParams2.importantStatusFilters;
		m_nCardAcc = m_msgFtrParams.sysParams2.importantAccessFilters;
	}

	BYTE nIntAlm = m_nIntAlm;
	BYTE nStatAlm = m_nStatAlm;
	BYTE nCardAcc = m_nCardAcc;
	for(int i=0; i<4; i++) {
		m_lstIntAlm.SetCheck(i, nIntAlm & 1 ? TRUE : FALSE);
		nIntAlm >>= 1;
	}
	for(int i=0; i<6; i++) {
		m_lstStatAlm.SetCheck(i, nStatAlm & 1 ? TRUE : FALSE);
		nStatAlm >>= 1;
	}
	for(int i=0; i<3; i++) {
		m_lstCardAcc.SetCheck(i, nCardAcc & 1 ? TRUE : FALSE);
		nCardAcc >>= 1;
	}

	ShowWindow(TRUE);
}


void CPrgDialupMsgFilters::OnLstIntAlmChange()
{
	int nIndex = m_lstIntAlm.GetCurSel();
	m_lstIntAlm.SetCheck(nIndex, m_lstIntAlm.GetCheck(nIndex) ? BST_UNCHECKED : BST_CHECKED);
}

void CPrgDialupMsgFilters::OnLstStatAlmChange()
{
	int nIndex = m_lstStatAlm.GetCurSel();
	m_lstStatAlm.SetCheck(nIndex, m_lstStatAlm.GetCheck(nIndex) ? BST_UNCHECKED : BST_CHECKED);
}

void CPrgDialupMsgFilters::OnLstCardAccChange()
{
	int nIndex = m_lstCardAcc.GetCurSel();
	m_lstCardAcc.SetCheck(nIndex, m_lstCardAcc.GetCheck(nIndex) ? BST_UNCHECKED : BST_CHECKED);
}


LRESULT CPrgDialupMsgFilters::OnGms(WPARAM wParam, LPARAM lParam)
{
	LPBYTE d = (LPBYTE)(LPSTR)lParam;
	UINT id = GET_WM_COMMAND_ID(wParam, lParam);
	BYTE nByteCount = 0;
	
	switch(id) {
		case IDD_COMMOVR_ERROR:
			return 0;
			break;
		case IDD_COMMOVR_DATA:
			if( ((CRtuSetupWizard*)GetParent())->GetCurStep() != MESSAGE_FILTERS )
				return 0;

			if(lParam) {
				if(m_bMsgFilterParams) {
					m_bMsgFilterParams = FALSE;
					memcpy(&m_msgFtrParams.msgFtrParams, d+1, sizeof(MSGFILTERPARM));

					// Get General System Params
					m_lpps.lpData[0] = GENERAL_SYSTEM_PARAMS_BLK;
					m_lpps.lpData[1] = 1;
					m_lpps.BC = 2;
					get_rtuport_parms(&m_lpps, 0, 0);
				}
				else {
					nByteCount = *((LPSTR)lParam - 5);
					nByteCount = (BYTE)(nByteCount - 6);
					LPBYTE pCfg = NULL;
					if (nByteCount <= sizeof(SYSPARM2000))	{
						m_bSysParams = FALSE;
						pCfg = &m_msgFtrParams.sysParams2.portPrty_Bx[0]; // memcpy(&m_msgFtrParams.sysParams2.portPrty_Bx[0], d+1, nByteCount);
					}
					else if (nByteCount <= sizeof(SYSPARM)) {
						m_bSysParams = TRUE;
						pCfg = &m_msgFtrParams.sysParams.portPrty_Bx[0]; // memcpy(&m_msgFtrParams.sysParams.portPrty_Bx[0], d+1, nByteCount);
					}

					if(pCfg) {
						memcpy(pCfg, d+1, nByteCount);
					}

					ShowParams();		 
				}
			}
			break;

		case IDD_HIRESP:
			if(m_nNextBlock != -1) {
				m_nNextBlock = -1;
				PARMPROC pps;
				memcpy(&pps, &m_lpps, sizeof(pps));
				pps.lpData = &m_data[0];
				if(m_bSysParams) {
					memcpy(&(pps.lpData[1]), &m_msgFtrParams.sysParams, sizeof(SYSPARM));
					pps.BC = sizeof(SYSPARM) + 1;
				}
				else {
					memcpy(&(pps.lpData[1]), &m_msgFtrParams.sysParams2, sizeof(SYSPARM2000));
					pps.BC = sizeof(SYSPARM2000) + 1;
				}
				pps.lpData[0] = GENERAL_SYSTEM_PARAMS_BLK;	// Block number
				send_rtuport_parms(&pps);

				memcpy(m_pData, &m_msgFtrParams, sizeof(m_msgFtrParams));

			}
			break;
		  
		default:
			break;
	}
	
	return(0);
}

/*=========================================================================*/
/*=========================================================================*/
CTemplateCfgDlg::CTemplateCfgDlg(LPPARMPROC, CWnd* pParent)
	: CSWZDialog(CTemplateCfgDlg::IDD, pParent)
{

}

void CTemplateCfgDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CTemplateCfgDlg)
	DDX_Control(pDX, IDC_DEFNAME, m_cboDefList);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CTemplateCfgDlg, CDialog)
	//{{AFX_MSG_MAP(CTemplateCfgDlg)
	ON_BN_CLICKED(IDOK, OnOK)
	ON_BN_CLICKED(IDC_BTN_RAP, OnBtnRAP)
	ON_BN_CLICKED(IDC_BTN_ACC, OnBtnAcc)
	ON_BN_CLICKED(IDC_RTU_BROWSE, OnBtnBrowse)
	ON_MESSAGE(WM_GMS, OnGms)
	ON_EN_CHANGE(IDC_RTU_DIR, OnPathChanged)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTemplateCfgDlg message handlers
 
BOOL CTemplateCfgDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	m_pBigFont = new CFont;
	m_pBigFont->CreateFont(
	   15,                        // nHeight
	   0,                         // nWidth
	   0,                         // nEscapement
	   0,                         // nOrientation
	   FW_BOLD,                   // nWeight
	   FALSE,                     // bItalic
	   FALSE,                     // bUnderline
	   0,                         // cStrikeOut
	   ANSI_CHARSET,              // nCharSet
	   OUT_DEFAULT_PRECIS,        // nOutPrecision
	   CLIP_DEFAULT_PRECIS,       // nClipPrecision
	   DEFAULT_QUALITY,           // nQuality
	   DEFAULT_PITCH | FF_SWISS,  // nPitchAndFamily
	   _T("Arial")); 

	GetDlgItem(IDC_LBL_DISP_STS)->SetFont(m_pBigFont);

	ShowParams();
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
void CTemplateCfgDlg::ShowConfig(LPPARMPROC lpps, BYTE, LPBYTE, BYTE, LPBYTE)
{
	memcpy(&m_lpps, lpps, sizeof(m_lpps));
	memcpy(m_data, lpps->lpData, sizeof(m_data));
	m_lpps.lpData = m_data;
	m_lpps.heDlg = GetSafeHwnd();
	m_lpps.hmDlg = m_lpps.heDlg;
	m_bEnChangedOK = FALSE;
	GetGMSServerFolderPath(m_lpPathName);
	wsprintf(m_lpPathName, _T("%s\\%s"), m_lpPathName, CUSTOMER_FILES_FOLDER);
	SetDlgItemText(IDC_RTU_DIR, m_lpPathName);
	wsprintf(m_lpPathName, _T("%s\\%s"), m_lpPathName, _T("DEFNAMES.DAT"));
	m_cboDefList.ResetContent();
	InitComboBox(GetSafeHwnd(), IDC_DEFNAME, CB_ADDSTRING, m_lpPathName);
	if(m_cboDefList.GetCount())
		m_cboDefList.SetCurSel(0);

	const int BuffSize = MAX_RTUNO*2;
	std::unique_ptr<WORD[]> lpDefRtu(new WORD[BuffSize]());
	if (lpDefRtu != nullptr) {
		wReadFile(DefaultLocation(RTUFILES_DEF_FILE), lpDefRtu.get(), BuffSize, 0);
		m_nRtuNo = MAKERTUNO(lpps->eType,lpps->eNo);
		if (m_nRtuNo >= 0 && m_nRtuNo < MAX_RTUNO)
			defNo = *(lpDefRtu.get() + m_nRtuNo);
		if(!CheckAccess(C_DEF_FILES, EDIT_MODE, 0))
			GetDlgItem(IDOK)->EnableWindow(FALSE);
		ShowWindow(SW_SHOW);
	}
	
}

void CTemplateCfgDlg::OnOK()
{
	TCHAR text[48];
    HWND hCtrl = GetDlgItem(IDC_DEFNAME)->GetSafeHwnd();
	int sel;
	UpdateStringFile(hCtrl, m_lpPathName, NULL);
	GetDlgItemText(IDC_DEFNAME, text, 33);
	if ((sel = m_cboDefList.FindStringExact(0, text)) != CB_ERR)
    	Deflt_no = sel;
	else
		Deflt_no = 0;

	CString str = text;
	if(str.GetLength() == 0) {
		DispMessageBox(GetSafeHwnd(), IDS_CANT_FIND_CFG_FILE, IDS_DLOAD_TPLATE, MB_OK|MB_ICONSTOP);
		return;
	}
	
	TCHAR	dir[MAX_PATH], dir1[MAX_PATH], pathname[MAX_PATH], pathname1[MAX_PATH], 
		RtuDefaultFileName[MAX_PATH];

	GetGMSServerFolderPath(dir);
	if (!GetDlgItemText(IDC_RTU_DIR, dir1, MAX_PATH))
		return;

	for (int i=0; i<FileCount; i++)
	{	//.Now copy the files
		lstrcpy(RtuDefaultFileName, Deflt_Files[i]);
		wsprintf(&RtuDefaultFileName[9],_T("%03d"), Deflt_no);

		wsprintf(pathname, _T("%s\\%s\\%s"), dir, CUSTOMER_FILES_FOLDER, RtuDefaultFileName);
		wsprintf(pathname1, _T("%s\\%s"), dir1, RtuDefaultFileName);

		CopyAFile(DefaultLocation(pathname1), DefaultLocation(pathname), true);
	}

	if(DispMessageBox(GetSafeHwnd(), IDS_DAT_RST_CMPL, IDS_DLOAD_TPLATE, MB_YESNO) == IDYES)
	{
		m_nParmNum = 0;
		m_lpps.Ret = IDD_COMMOVR;

		GetDlgItem(IDC_LBL_DISP_STS)->ShowWindow(SW_SHOW);
		GetDlgItem(IDOK)->EnableWindow(FALSE);
		GetDlgItem(IDC_BTN_ACC)->EnableWindow(FALSE);
		GetDlgItem(IDC_BTN_RAP)->EnableWindow(FALSE);
		GetDlgItem(IDC_RTU_BROWSE)->EnableWindow(FALSE);
		GetParent()->SendMessage(WM_UPLOADING, 0, 0);
		PostMessage(WM_GMS, IDD_COMMOVR_CTRL_NUM, 0);
		}
}

void CTemplateCfgDlg::OnBtnRAP()
{
	CRapWnd::EditP1060Params(&m_lpps);
}

void CTemplateCfgDlg::OnBtnAcc()
{
	EditAccessParams(&m_lpps);
}

void CTemplateCfgDlg::OnBtnBrowse()
{
	GetBrowsePathName(GetSafeHwnd(), IDC_RTU_DIR);
	OnPathChanged();
}

void CTemplateCfgDlg::OnPathChanged()
{
	if(!m_bEnChangedOK) {
		m_bEnChangedOK = TRUE;
		return;
	}

	TCHAR	dir[MAX_PATH];
	if (!GetDlgItemText(IDC_RTU_DIR, dir, 47))
		return;

	wsprintf(m_lpPathName, _T("%s\\%s"), dir, _T("DEFNAMES.DAT"));
	m_cboDefList.ResetContent();
	InitComboBox(GetSafeHwnd(), IDC_DEFNAME, CB_ADDSTRING, m_lpPathName);
	if(m_cboDefList.GetCount())
		m_cboDefList.SetCurSel(0);
}

void CTemplateCfgDlg::ShowParams()
{
}

extern int SendCount;
extern int PanelType;
extern BOOL	EPW_FLAG;
extern int RtuType;
extern int (WINAPI *Rtu_Func2[])(LPPARMPROC, UINT, UINT);

int Check2SkipComms(int i)
{
	if (PanelType != P1060_TYPE && PanelType != EURO_TYPE && PanelType!=P8001_TYPE && i==1)
		i++;
    else if (PanelType==EURO_TYPE && i==6) 
		    i++;
	return i;
}

extern int GetCommParamOffset();
extern int GetRecordNumber(int index);

LRESULT CTemplateCfgDlg::OnGms(WPARAM wParam, LPARAM)
{

	int RtuNo;

	int id = GET_WM_COMMAND_ID(wParam, lParam);
	switch(id) {
		case IDD_COMMOVR_CTRL_NUM:
			m_nParmNum = Check2SkipComms(m_nParmNum);
			while (m_nParmNum < SendCount) {
				RtuNo = MAKERTUNO(m_lpps.eType,m_lpps.eNo);
  				if (wFileCopy(RtuNo, m_nParmNum, Deflt_no, 0, m_lpps.lpData, 128) == -1) {
					m_nParmNum++;
					continue;
				}
				
				switch (PanelType) {
					case P1060_TYPE:
					case P8001_TYPE:
						EPW_FLAG = TRUE;
						//id = (*Rtu_Func2[m_nParmNum])(&m_lpps, (m_nParmNum>=COMMS_PARAM_NUM) ? m_nParmNum-COMMS_PARAM_NUM : m_nParmNum, iblk);
						
						int recNo = GetRecordNumber(m_nParmNum);					
						if(m_nParmNum >= GetCommParamOffset())
							id = send_1060CA_parms(&m_lpps, recNo, iblk);
						else
							id = send_1060alm_parms(&m_lpps, recNo, iblk);
					}
				
				if (id == -1) {
					break;
					}

				m_nParmNum++;
				return FALSE;
				
				}

			if (EPW_FLAG == TRUE) {
                m_lpps.BlkNo = 0;
				send_wr_eeprom(&m_lpps);
				EPW_FLAG = FALSE;
				}

			GetDlgItem(IDOK)->EnableWindow(TRUE);
			GetDlgItem(IDC_BTN_ACC)->EnableWindow(TRUE);
			GetDlgItem(IDC_BTN_RAP)->EnableWindow(TRUE);
			GetDlgItem(IDC_RTU_BROWSE)->EnableWindow(TRUE);
			GetDlgItem(IDC_LBL_DISP_STS)->ShowWindow(SW_HIDE);
			GetParent()->SendMessage(WM_UPLOADING, 0, 1);
			break;
		  
		default:
			break;
	}
	
	return(0);
}

extern char licOp[];
/////////////////////////////////////////////////////////////////////////////
// CEnableCodeDlg dialog
CEnableCodeDlg::CEnableCodeDlg(LPPARMPROC , CWnd* pParent) 
	: CSWZDialog(CEnableCodeDlg::IDD, pParent)

{
}

void CEnableCodeDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CEnableCodeDlg)
	//}}AFX_DATA_MAP

	for(int i=0; i<E_MAX_OPTIONS; i++) {
		DDX_Check(pDX, IDC_CHK_ETH + i, m_bActEn[i]);
	}
	for(int i=0; i<E_MAX_OPTIONS; i++) {
		DDX_Control(pDX, IDC_LBL_RTU_SERNO_ETHEN + i*2, m_lblLicences[i]);
	}
}

BEGIN_MESSAGE_MAP(CEnableCodeDlg, CDialog)
	//{{AFX_MSG_MAP(CEnableCodeDlg)
	ON_BN_CLICKED(IDC_CHK_ACC,			OnBtnAccessControl)
	ON_BN_CLICKED(IDC_CHK_ETH,			OnBtnEthernet)
	ON_BN_CLICKED(IDC_CHK_ALM,			OnBtnAlarmOperation)
	ON_BN_CLICKED(IDC_CHK_ELEV_HLI,		OnBtnElevatorHLI)
	ON_BN_CLICKED(IDC_CHK_IRISYS,		OnBtnIrisysProtocol)
	ON_BN_CLICKED(IDC_CHK_BACK_OP,		OnBtnBackupOperation)
	ON_BN_CLICKED(IDC_CHK_MULT_FMT,		OnBtnMultiCardFormat)
	ON_BN_CLICKED(IDC_CHK_PTZ_DRV,		OnBtnWitnessPtzDriver)
	ON_BN_CLICKED(IDC_CHK_INOV_ES,		OnBtnInovonicsES)
	ON_BN_CLICKED(IDC_CHK_HOST_HLI,		OnBtnHostHLI)
	ON_BN_CLICKED(IDC_CHK_RMT_MAINT,	OnBtnRemoteMaintenance)
	ON_BN_CLICKED(IDC_CHK_GEN_DVR,		OnBtnGenericDVRInterface)
	ON_BN_CLICKED(IDC_CHK_EPAP,			OnBtnEPAP)
	ON_MESSAGE(WM_GMS, OnGms)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CEnableCodeDlg message handlers
CEnableCodeDlg::CEnableCodeDlg()
{
	memset(&m_lpps, 0, sizeof(PARMPROC));
	m_strSerialNumber = _T("");
	memset(m_nLicOp, 0, sizeof(m_nLicOp));
	m_nAddress1 = 0;
	m_nAddress2 = 0;
	m_LicOp = 0;
	m_nByteCount= 0;
	m_nCurSel= 0;
	memset(&m_bActEn, 0, sizeof(int)*E_MAX_OPTIONS);
}
BOOL CEnableCodeDlg::OnInitDialog()
{
	CDialog::OnInitDialog();
	return TRUE;
}

void CEnableCodeDlg::ShowConfig(LPPARMPROC lpps, BYTE nByteCount, LPBYTE ptrData, BYTE, LPBYTE) 
{
	LPBYTE p = ptrData;
	memcpy(&m_lpps, lpps, sizeof(m_lpps));
	memcpy(&data[0], lpps->lpData, sizeof(data));

	m_nByteCount = (nByteCount >= 0x25) ? 16 : 8;
	
	CString strSn;
	CRtuSetupWizard::GetUnitSerialNumber(strSn, p+8);

	char lcOp[17];
	int i=0;
	for(; i<m_nByteCount; i++)
		lcOp[i] = *(p + 16 + i);
	lcOp[i] = 0;

	m_strSerialNumber.Format(_T("%s: %s"), RES_STRING(IDS_MAIN_UNIT_SER_NUM), (LPCTSTR)strSn);
	memcpy(&m_nLicOp[0], lcOp, 16);
	m_nAddress1 = m_lpps.eType;
	m_nAddress2 = m_lpps.eNo;

	for(i=0; i<E_MAX_OPTIONS; i++) {
		m_nLicOp[i] == licOp[i] ? m_LicOp |= (1 << i) : m_LicOp &= ~(1 << i);
		m_bActEn[i] = (m_nLicOp[i] == licOp[i]) ? TRUE : FALSE;
	}

	m_lpps.heDlg = GetSafeHwnd();
	m_lpps.hmDlg = m_lpps.heDlg;

	GetDlgItem(IDC_LBL_SER_NUM)->SetWindowText(m_strSerialNumber);
	
	int licenses = m_LicOp;
	for(i=0; i<E_MAX_OPTIONS; i++) {
		UINT id = IDC_CHK_ETH + i;
		UINT id2 = IDC_LBL_RTU_SERNO_ETHEN + i*2;
		if(licenses & 1) {
			CheckDlgButton(id, TRUE);
			GetDlgItem(id)->EnableWindow(FALSE);
			UpdateText(id2, i, TRUE);
		}
		else {
			CheckDlgButton(id, FALSE);
			GetDlgItem(id)->EnableWindow(TRUE);
			UpdateText(id2, i, FALSE);
		}
		licenses >>= 1;
	}

	if(realRtuType == RTU_8001_TYPE) {
		if(m_nLicOp[1] == licOp[1]) {	// Large model system enabled
			// Disable medium model system
			GetDlgItem(IDC_CHK_ALM)->EnableWindow(FALSE);
			m_lblLicences[2].SetTextColor(RGB(0x80, 0x80, 0x80));
		}
		else {
			// Enable medium model system
			GetDlgItem(IDC_CHK_ALM)->EnableWindow(TRUE);
			m_lblLicences[2].SetTextColor(m_nLicOp[2] == licOp[2] ? RGB(0,0,255) : RGB(255,0,0));
		}

		UINT ids[] = { IDC_LBL_RTU_SERNO_ETHEN, IDC_LBL_RTU_SERNO_RTEEN, IDC_LBL_RTU_SERNO_EPAP, IDC_LBL_RTU_SERNO_MCFEN, 
			IDC_CHK_ETH, IDC_CHK_IRISYS, IDC_CHK_EPAP, IDC_CHK_MULT_FMT};
		for(int i2=0; i2<_countof(ids); i2++) {
			GetDlgItem(ids[i2])->EnableWindow(FALSE);
		}
	}

	ShowWindow(SW_SHOW);
}

LRESULT CEnableCodeDlg::OnGms(WPARAM wParam, LPARAM lParam)
{
	int id = GET_WM_COMMAND_ID(wParam, lParam);
	switch (id)	{
	case IDD_COMMOVR_ERROR:
		break;
	case IDD_COMMOVR_DATA:
		if(lParam != NULL) {
			BOOL flag;
			int bitpos = 1 << m_nCurSel;
			if(m_LicOp & bitpos)
				m_LicOp &= ~bitpos;
			else
				m_LicOp |= bitpos;
			flag = (m_LicOp & bitpos) ? TRUE : FALSE;
			m_bActEn[m_nCurSel] = flag;
			if(flag) {
				GetDlgItem(IDC_CHK_ETH + m_nCurSel)->EnableWindow(FALSE);
				m_lblLicences[m_nCurSel].SetTextColor(flag ? RGB(0,0,255) : RGB(255,0,0));
			}
		}
		break;

	default:
		break;
	}

	UpdateData(FALSE);
	return TRUE;
}

void CEnableCodeDlg::ChangeOption(int i)
{
	m_nCurSel = i;
	int op = 2*i;
	op = m_bActEn[i] ? op + 1 : op;
	CRTULicenceRenew licDlg(op, m_nAddress1, m_nAddress2, this);	
	if(licDlg.DoModal() == 0) {
		UpdateData(FALSE);
	}
}

void CEnableCodeDlg::UpdateText(UINT id, int index, BOOL flag)
{
	CStringArray strArr;
	if(flag) {
		GetEnabledStrings(strArr);
	}
	else {
		GetDisabledStrings(strArr);
	}
		
	GetDlgItem(id)->SetWindowText(strArr.GetAt(index));
	m_lblLicences[index].SetTextColor(flag ? RGB(0,0,255) : RGB(255,0,0));
}

void CEnableCodeDlg::GetEnabledStrings(CStringArray& strEn)
{
	UINT ids[E_MAX_OPTIONS];
	for(int i=0; i<10; i++) {
		ids[i] = IDS_ETH_EN + i;
	}
	for(int i=0; i<2; i++) {
		ids[i+10] = IDS_RMT_MAINT_EN + i;
	}
	ids[12] = IDS_EPAP_EN;

	if(realRtuType == RTU_8001_TYPE) {
		ids[1] = IDS_LARGE_MODEL_SYS_EN;
		ids[2] = IDS_MEDIUM_MODEL_SYS_EN;
		ids[3] = IDS_ELEV_HLI_AND_BMS_EN;
		ids[7] = IDS_PEER_TO_PEER_EN;
	}

	for(int i=0; i<E_MAX_OPTIONS; i++) {
		strEn.Add(CString((LPTSTR)ids[i]));
	}
}

void CEnableCodeDlg::GetDisabledStrings(CStringArray& strDis)
{
	UINT ids[E_MAX_OPTIONS];
	for(int i=0; i<10; i++) {
		ids[i] = IDS_ETH_DIS + i;
	}
	for(int i=0; i<2; i++) {
		ids[i+10] = IDS_RMT_MAINT_DIS + i;
	}
	ids[12] = IDS_EPAP_DIS;

	if(realRtuType == RTU_8001_TYPE) {
		ids[1] = IDS_LARGE_MODEL_SYS_DIS;
		ids[2] = IDS_MEDIUM_MODEL_SYS_DIS;
		ids[3] = IDS_ELEV_HLI_AND_BMS_DIS;
		ids[7] = IDS_PEER_TO_PEER_DIS;
	}

	for(int i=0; i<E_MAX_OPTIONS; i++) {
		strDis.Add(CString((LPTSTR)ids[i]));
	}
}