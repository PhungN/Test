/********************************************************************
 *		$History: Bms.cpp $
 ********************************************************************/

#include "stdafx.h"
#include "Bms.h"

#define MAX_BMS_DATA 4000

#define BACNET_INPUT_COPY	0
#define BACNET_ACTION_COPY	1
#define MODBUS_DINP_COPY	2
#define MODBUS_DOUT_COPY	3
#define MODBUS_AINP_COPY	4

#define ENABLE_BMS_BACNET_DRIVER 0x01
#define ENABLE_BMS_MODBUS_DRIVER 0x02

#define OBJ_TYPE_EVENT_ENROLLEMNT 9

static uchar bmsFile[5] =    
{
	BMS_REC0_FILE,
	BMS_REC1_FILE,
	BMS_REC2_FILE,
	BMS_REC3_FILE,
	BMS_REC4_FILE,
};

enum PrintColor {COLOR_LIGHT_YELLOW, COLOR_LIGHT_BLUE, COLOR_GOLD, COLOR_TAN};

static TCHAR* colors[] = 
{
	_T("bgcolor=#ffffe0"), // light yellow
	_T("bgcolor=#add8e6"), // light blue
	_T("bgcolor=#ffd700"), // gold
	_T("bgcolor=#ffdead")  // tan
};

extern int realRtuType;
extern int gRtuNo;
extern HINSTANCE hrInst;
/*=========================================================================*/
/*=========================================================================*/
CRtuBmsConfig* pBmsCfg;

BmsGenCfg			bmsGenCfg;
PULSECNTDEF			bmsPcntCfg[MAX_BMS_PCNT];
BACnetCfg			bmsBACnetCfg;
ModbusPointCfg		bmsModbusPntCfgSmall;
ModbusPointCfgLarge bmsModbusPntCfgLarge;
ModbusPointCfgLarge	bmsModbusPntCfg;
BOOL				bModbusCfgLarge;
BmsMacroCfg			bmsMacroCfg;

int portNum1057[] = {2, 3, 4, 5, 6, 7, 9, 10, 11, 12};
int portNum1058[] = {2, 3, 4, 9};
int portNum2000[] = {2, 3, 4, 6, 7};
int portNum8001[] = {1, 3, 4, 9, 10, 11, 12};
#define MAX_MODBUS_PORTS sizeof(portNum1057)/sizeof(portNum1057[0])
#define MAX_MODBUS_PORTS_1058 sizeof(portNum1058)/sizeof(portNum1058[0])
#define MAX_MODBUS_PORTS_2000 sizeof(portNum2000)/sizeof(portNum2000[0])
#define MAX_MODBUS_PORTS_8001 sizeof(portNum8001)/sizeof(portNum8001[0])
//........................................................................
class CModbusPort
{
public:
	CStringArray	_1057ModbusPortStr;
	CStringArray	_1058ModbusPortStr;
	
	CStringArray	_8001ModbusPortStr;
	CStringArray	_8002ModbusPortStr;
	CStringArray	_WitnessModbusPortStr;

	~CModbusPort()
	{
		_1057ModbusPortStr.RemoveAll();
		_1058ModbusPortStr.RemoveAll();
		_8001ModbusPortStr.RemoveAll();
		_8002ModbusPortStr.RemoveAll();
		_WitnessModbusPortStr.RemoveAll();
	}

public:
	void Init1057ModbusPortStrings()
	{
		if (_1057ModbusPortStr.GetSize() == 0)
		{
			_1057ModbusPortStr.Add(RES_STRING(IDS_1057_PORT_TXT1));
			_1057ModbusPortStr.Add(RES_STRING(IDS_1057_PORT_TXT2));
			_1057ModbusPortStr.Add(RES_STRING(IDS_1057_PORT_TXT3));
			_1057ModbusPortStr.Add(RES_STRING(IDS_1057_PORT_TXT4));
			_1057ModbusPortStr.Add(RES_STRING(IDS_1057_PORT_TXT5));
			_1057ModbusPortStr.Add(RES_STRING(IDS_1057_PORT_TXT6));
			_1057ModbusPortStr.Add(RES_STRING(IDS_1057_PORT_TXT8));
			_1057ModbusPortStr.Add(RES_STRING(IDS_1057_PORT_TXT9));
			_1057ModbusPortStr.Add(RES_STRING(IDS_1057_PORT_TXT10));
			_1057ModbusPortStr.Add(RES_STRING(IDS_1057_PORT_TXT11));
		}
	}

	void Get1057ModbusPortStrings(CStringArray& strPorts)
	{
		if (_1057ModbusPortStr.GetSize() == 0)
			Init1057ModbusPortStrings();

		strPorts.RemoveAll();
		strPorts.Copy(_1057ModbusPortStr);
	}

	CString Get1057ModbusPortString(int index)
	{
		if (_1057ModbusPortStr.GetSize() == 0)
			Init1057ModbusPortStrings();
		if (index >= 0 && index <  _1057ModbusPortStr.GetCount())
			return _1057ModbusPortStr.GetAt(index);
		return L"";
	}

	//.....................................................
	void Init1058ModbusPortStrings()
	{
		if (_1058ModbusPortStr.GetSize() == 0)
		{
			_1058ModbusPortStr.Add(RES_STRING(IDS_1058_PORT_TXT1));
			_1058ModbusPortStr.Add(RES_STRING(IDS_1058_PORT_TXT2));
			_1058ModbusPortStr.Add(RES_STRING(IDS_1058_PORT_TXT3));
			_1058ModbusPortStr.Add(RES_STRING(IDS_1058_PORT_TXT4));
		}
	}


	void Get1058ModbusPortStrings(CStringArray& strPorts)
	{
		if (_1058ModbusPortStr.GetSize() == 0)
			Init1058ModbusPortStrings();
		strPorts.RemoveAll();
		strPorts.Copy(_1058ModbusPortStr);
	}

	CString Get1058ModbusPortString(int index)
	{
		if (_1058ModbusPortStr.GetSize() == 0)
			Init1058ModbusPortStrings();

		if (index >= 0 && index <  _1057ModbusPortStr.GetCount())
			return _1058ModbusPortStr.GetAt(index);
		return L"";
	}
	
	//.....................................................
	void Init8001ModbusPortStrings()
	{
		if (_8001ModbusPortStr.GetSize() == 0)
		{
			_8001ModbusPortStr.Add(RES_STRING(IDS_8001_PORT_TXT));	// Mezz1
			_8001ModbusPortStr.Add(RES_STRING(IDS_8001_PORT_TXT2));	// Mezz2
			_8001ModbusPortStr.Add(RES_STRING(IDS_8001_PORT_TXT3));	// Mezz3
			_8001ModbusPortStr.Add(RES_STRING(IDS_8001_PORT_TXT8));	// Mezz4
			_8001ModbusPortStr.Add(RES_STRING(IDS_8001_PORT_TXT9));	// Mezz5
			_8001ModbusPortStr.Add(RES_STRING(IDS_8001_PORT_TXT10));	// Ethernet1
		}
	}

	void Get8001ModbusPortStrings(CStringArray& strPorts)
	{
		if (_8001ModbusPortStr.GetSize() == 0)
			Init8001ModbusPortStrings();
		
		strPorts.RemoveAll();
		strPorts.Copy(_8001ModbusPortStr);
	}

	CString Get8001ModbusPortString(int index)
	{
		if (_8001ModbusPortStr.GetSize() == 0)
			Init8001ModbusPortStrings();
		
		if (index >= 0 && index <  _8001ModbusPortStr.GetCount())
			return _8001ModbusPortStr.GetAt(index);
		return L"";
	}

	//.....................................................
	void Init8002ModbusPortStrings()
	{
		if (_8002ModbusPortStr.GetSize() == 0)
		{
			_8002ModbusPortStr.Add(RES_STRING(IDS_8001_PORT_TXT));	// Mezz1
			_8002ModbusPortStr.Add(RES_STRING(IDS_8001_PORT_TXT2));	// Mezz2
			_8002ModbusPortStr.Add(RES_STRING(IDS_8001_PORT_TXT3));	// Mezz3
			_8002ModbusPortStr.Add(RES_STRING(IDS_8001_PORT_TXT8));	// Mezz4
			_8002ModbusPortStr.Add(RES_STRING(IDS_8001_PORT_TXT9));	// Mezz5
			_8002ModbusPortStr.Add(RES_STRING(IDS_8001_PORT_TXT10));	// Ethernet1
			_8002ModbusPortStr.Add(RES_STRING(IDS_8001_PORT_TXT11));	// Ethernet2
		}
	}
	void Get8002ModbusPortStrings(CStringArray& strPorts)
	{
		if (_8002ModbusPortStr.GetSize() == 0)
			Init8002ModbusPortStrings();

		strPorts.RemoveAll();
		strPorts.Copy(_8002ModbusPortStr);
	}
	CString Get8002ModbusPortString(int index)
	{
		if (_8002ModbusPortStr.GetSize() == 0)
			Init8002ModbusPortStrings();

		if (index >= 0 && index <  _8002ModbusPortStr.GetCount())
			return _8002ModbusPortStr.GetAt(index);
		return L"";
	}
	//.....................................................
	void InitWitnessModbusPortStrings()
	{
		if (_WitnessModbusPortStr.GetSize() == 0)
		{
			_WitnessModbusPortStr.Add(RES_STRING(IDS_WNESS_PORT_TXT1));
			_WitnessModbusPortStr.Add(RES_STRING(IDS_WNESS_PORT_TXT2));
			_WitnessModbusPortStr.Add(RES_STRING(IDS_WNESS_PORT_TXT3));
			_WitnessModbusPortStr.Add(RES_STRING(IDS_WNESS_PORT_TXT5));
			_WitnessModbusPortStr.Add(RES_STRING(IDS_WNESS_PORT_TXT6));
		}
	}
	void GetWitnessModbusPortStrings(CStringArray& strPorts)
	{
		if (_WitnessModbusPortStr.GetSize() == 0)
			InitWitnessModbusPortStrings();
		strPorts.RemoveAll();
		strPorts.Copy(_WitnessModbusPortStr);
	}
	CString GetWitnessModbusPortString(int index)
	{
		if (_WitnessModbusPortStr.GetSize() == 0)
		{
			_WitnessModbusPortStr.Add(RES_STRING(IDS_WNESS_PORT_TXT1));
			_WitnessModbusPortStr.Add(RES_STRING(IDS_WNESS_PORT_TXT2));
			_WitnessModbusPortStr.Add(RES_STRING(IDS_WNESS_PORT_TXT3));
			_WitnessModbusPortStr.Add(RES_STRING(IDS_WNESS_PORT_TXT5));
			_WitnessModbusPortStr.Add(RES_STRING(IDS_WNESS_PORT_TXT6));
		}
		if (index >= 0 && index <  _WitnessModbusPortStr.GetCount())
			return _WitnessModbusPortStr.GetAt(index);
		return L"";
	}
};

CModbusPort g_ModbusPorts;
//........................................................................

// input: portIndex >= 0
// return portNumber base 1
int RTU8001_GetPortNumberFromPortIndex(int portIndex)
{
	int portNumber = 0;
	if (portIndex >= 0 && portIndex < _COUNTOF(portNum8001))
		portNumber = portNum8001[portIndex];
	return portNumber;
};


// return: portIndex >= 0
// input: portNumber base 0
int RTU8001_GetPortIndexFromPortNumber(int portNumber)
{
	int portIndex = -1;
	
		for (int i = 0; i < _COUNTOF(portNum8001); i++)
		{
			if (portNumber + 1 == portNum8001[i])
				return i;
		}

	
	//	switch(portNumber) { // start from 0
	//		case 0: portIndex = 0; break;
	//		case 2: portIndex = 1; break;
	//		case 3: portIndex = 2; break;
	//		case 8: portIndex = 3; break;
	//		case 9: portIndex = 4; break;
	//		case 10: portIndex = 5; break;
	//		default: portIndex = -1; break;
	//	}
	
		return portIndex;
};



ModbusPortCfg bmsModbusPortCfg[MAX_MODBUS_PORTS];

int nPortModbus[MAX_MODBUS_PORTS];

BOOL bBmsPcntChanged=0;	
BOOL bBmsGenCfgChanged=0;
BOOL bBmsBACnetChanged=0;
BOOL bBmsModbusChanged=0;
BOOL bBmsMacroChanged=0;

static HWND hStus, hBox;
static int nBlkSize;
static int maxModbusPort;
/*=========================================================================*/
/*=========================================================================*/
void DoAlignment();
int ModbusPortSel(int portNum);

HWND ProcBmsConfig(HINSTANCE hInst, HWND hSysWnd, HWND hParent, int iblk, LPPARMPROC lpps, int nShowCmd)
{
	HWND hDlg = NULL;
	pBmsCfg = new CRtuBmsConfig(hInst, hSysWnd, iblk, lpps, nShowCmd==SW_HIDE, CWnd::FromHandle(hParent));
	if(pBmsCfg != NULL) { //Always evaluates to true
		if(pBmsCfg->Create(IDD_RTU_BMS_CFG_DLG)) {
			pBmsCfg->ShowWindow(nShowCmd);
			hDlg = pBmsCfg->GetSafeHwnd();
			lpps->heDlg = hDlg;
		}
	}

	return hDlg;
}

void DispStusLine(HWND hWnd, HWND hStatus, HWND hBox2)
{
	RECT	rc;

	if (!hStatus)
		return ;
	if (!hBox2)
		return ;

	GetClientRect(hWnd, (LPRECT) &rc);
	if (IsWindow(hBox2))
		MoveWindow(hBox2, rc.left, rc.bottom - 30, rc.right, 30, 1);
	if (IsWindow(hStatus))
		MoveWindow(hStatus, rc.left + 10, rc.bottom - 25, rc.right - 20, 20, 1);
	return ;
}

void DoAlignment()
{
	int i;
	RtuLib::SwapByteOrder(bmsBACnetCfg.protocolCfg.myBacnetAddress);
	RtuLib::SwapByteOrder(bmsBACnetCfg.protocolCfg.udpPortNumber);
	RtuLib::SwapByteOrder(bmsBACnetCfg.protocolCfg.bbmdIpAddress);
	RtuLib::SwapByteOrder(bmsBACnetCfg.protocolCfg.networkNumber);

	for(i=0; i<MAX_BMS_BACNET_DEVCFG; i++) {
		RtuLib::SwapByteOrder(bmsBACnetCfg.input[i].deviceNumber);
		RtuLib::SwapByteOrder(bmsBACnetCfg.input[i].notificationClass);
		RtuLib::SwapByteOrder(bmsBACnetCfg.input[i].objectInstance);
	}

	for(i=0; i<MAX_BMS_BACNET_ACTION; i++) {
		RtuLib::SwapByteOrder(bmsBACnetCfg.action[i].deviceNumber);
		RtuLib::SwapByteOrder(bmsBACnetCfg.action[i].objectInstance);
	}

}

void CheckEditPriv(HWND hDlg, UINT uiPriv)
{
#ifdef _WIN32

	if(!CheckAccess(uiPriv, EDIT_MODE, 0))
	{
		if(GetDlgItem(hDlg, IDOK))
			EnableWindow(GetDlgItem(hDlg, IDOK), FALSE);
		if(GetDlgItem(hDlg, IDC_BMS_DELETE))
			EnableWindow(GetDlgItem(hDlg, IDC_BMS_DELETE), FALSE);
		if(GetDlgItem(hDlg, IDC_BMS_COPY))
			EnableWindow(GetDlgItem(hDlg, IDC_BMS_COPY), FALSE);
		if(GetDlgItem(hDlg, IDC_BMS_ACT_DELETE))
			EnableWindow(GetDlgItem(hDlg, IDC_BMS_ACT_DELETE), FALSE);
		if(GetDlgItem(hDlg, IDC_BMS_ACT_COPY))
			EnableWindow(GetDlgItem(hDlg, IDC_BMS_ACT_COPY), FALSE);
		if(GetDlgItem(hDlg, IDC_BMS_REBOOT_PORT))
			EnableWindow(GetDlgItem(hDlg, IDC_BMS_REBOOT_PORT), FALSE);
	}

#endif
}

void GetValidStrings(CStringArray& strArray, CStringArray& newStrArray, TCHAR wcDel=NULL)
{
	newStrArray.RemoveAll();
	CString str;
	int index=0;
		
	for(int i=0; i<strArray.GetSize(); i++) {
		str = strArray.GetAt(i);
		if(str.GetLength() > 0) {
			// A string start with ';' is not a valid string, it's a comment
			if(str.GetAt(0) != _T(';')) {
				LPTSTR pStrBuff = str.GetBuffer(str.GetLength());
				if(sscanfx(pStrBuff, _T("%d. %[^\r]"), &index, pStrBuff)) {}
				str.ReleaseBuffer();
				if(wcDel != NULL) {
					if((index = str.Find('#', 0)) > 0)
						newStrArray.Add(str.Left(index));
				}
				else {
					newStrArray.Add(str);
				}
			}
		}
	}
}

BOOL GetPointTypeStr(int nDevType, CString& str)
{
	if(str.GetLength() > 0) {
		int index = str.Find('#', 0);
		if(index == -1) {
			return TRUE;
		}

		CString strTemp = str.Mid(index + 1);
		char* pStrBuff = (char*)strTemp.GetBuffer(strTemp.GetLength());
		char* pEnd;
		int num = 0;
		while((num = strtoul(pStrBuff, &pEnd, 10)) != 0) {
			if(num == nDevType)	{
				strTemp.ReleaseBuffer();
				str = str.Left(index);
				return TRUE;
			}
			pStrBuff = (char*)((pEnd) + 1);
		}
		
		strTemp.ReleaseBuffer();
	}
	
	return FALSE;

}

int GetPortNumber(int num)
{
	int pNum = 0;
	switch(realRtuType) {
		case RTU_1057_TYPE:
			pNum = portNum1057[num];
			break;
		case RTU_1058_TYPE:
			pNum = portNum1058[num];
			break;
		case RTU_2000_TYPE:
			pNum = portNum2000[num];
			break;
		case RTU_8001_TYPE:
			pNum = portNum8001[num];
			break;
		default:
			pNum = 0;
			break;
	}

	return pNum;
}

void GetPulseCounterCatStr(CStringArray& strPCntCat)
{
	strPCntCat.Add(RES_STRING(IDS_NORMAL_PULSE_CNTR));
	strPCntCat.Add(RES_STRING(IDS_CARD_CNTR));
	strPCntCat.Add(RES_STRING(IDS_AREA_PPL_CNTR));
}

void GetBACnetDevCfgNTypeStr(CStringArray& strNType)
{
	strNType.Add(RES_STRING(IDS_UNDEFINED));
	strNType.Add(RES_STRING(IDS_INTRINSIC_ALM));
	strNType.Add(RES_STRING(IDS_INTRINSIC_EVT));
}

void GetBACnetDevCfgOTypeStr(CStringArray& strOType)
{
	for (int i=0; i<7; i++) {
		strOType.Add(RES_STRING(IDS_BNET_OTYPE_AINP + i));
	}
}

void GetBACnetDevCfgETypeStr(CStringArray& strEType)
{
	for (int i=0; i<6; i++) {
		strEType.Add(RES_STRING(IDS_BNET_ETYPE_BSTR + i));
	}
}

void GetBACnetDevCfgPTypeStr(CStringArray& strPType)
{
	strPType.Add(RES_STRING(IDS_DIGITAL_INP));
	strPType.Add(RES_STRING(IDS_ANALOG_INP));
}

void GetBACnetProtLLStr(CStringArray& strProt)
{
	strProt.Add(RES_STRING(IDS_UNDEFINED));
	strProt.Add(RES_STRING(IDS_BNET_PROT_IP));
}

void GetBACnetActReqTypeStr(CStringArray& strActType)
{
	strActType.Add(RES_STRING(IDS_UNDEFINED));
	for (int i=0; i<4; i++) {
		strActType.Add(RES_STRING(IDS_BNET_ACT_REQ_WR_PROP + i));
	}
}

void GetBACnetActObjTypeStr(CStringArray& strObjType)
{
	for (int i=0; i<6; i++) {
		strObjType.Add(RES_STRING(IDS_BNET_OTYPE_AINP + i));
	}
}

BOOL GetModbusPortTxt(LPTSTR szPort, int num)
{
	switch(realRtuType) {
		case RTU_1057_TYPE:
			wsprintf(szPort, _T("%s"), (LPCTSTR)g_ModbusPorts.Get1057ModbusPortString(num));
			return TRUE;
		case RTU_1058_TYPE:
			wsprintf(szPort, _T("%s"), (LPCTSTR)g_ModbusPorts.Get1058ModbusPortString(num));
			return TRUE;
		case RTU_2000_TYPE:
			wsprintf(szPort, _T("%s"), (LPCTSTR)g_ModbusPorts.GetWitnessModbusPortString(num));
			return TRUE;
		case RTU_8001_TYPE:
			if (IsRtu8002Type())
				wsprintf(szPort, _T("%s"), (LPCTSTR)g_ModbusPorts.Get8002ModbusPortString(num));
			else
				wsprintf(szPort, _T("%s"), (LPCTSTR)g_ModbusPorts.Get8001ModbusPortString(num));
			return TRUE;
	}

	wsprintf(szPort, _T(""));
	return FALSE;
}

void GetMacroDevTypeStr(CStringArray& strDevType)
{
	strDevType.Add(RES_STRING(IDS_IO_TYPE_PULSE_CNTR));
	strDevType.Add(RES_STRING(IDS_AREA_PPL_CNTR));
}

void GetMacCondStr(CStringArray& strCond)
{
	strCond.Add(RES_STRING(IDS_UNDEFINED));
	for (int i=0; i<5; i++) {
		strCond.Add(RES_STRING(IDS_MAC_COND_EQU + i));
	}
}

void GetMacroOpTypeStr(CStringArray& strOpType)
{
	for (int i=0; i<3; i++) {
		strOpType.Add(RES_STRING(IDS_GPO_OUT + i));
	}
}
/*=========================================================================*/
/*=========================================================================*/

CRtuBmsConfig::CRtuBmsConfig(HINSTANCE hInst, HWND hSysWnd, int iblk, LPPARMPROC lpps, BOOL bMsgToParent, CWnd* pParent)
	: CDialog(CRtuBmsConfig::IDD, pParent)
{
	m_pParent = pParent;
	m_bMessageToParent = bMsgToParent;
	m_lpps = lpps;
	m_hInst = hInst;
	m_hRtuSysWnd = hSysWnd;
	m_nBlkNum = -1;
	m_fDirn = -1;
	m_bPrintConfig = FALSE;
	m_nRtuNumber = (m_lpps->eNo + m_lpps->eType*50 + 1);
	m_bIsValidParam = FALSE;
	if(!bMsgToParent)
		m_bIsValidParam = TRUE;

	nBlkSize = iblk;
	bBmsPcntChanged = FALSE;
	bBmsGenCfgChanged = FALSE;
	bBmsBACnetChanged = FALSE;
	bBmsModbusChanged = FALSE;

	m_bStart = TRUE;
	m_nPortCnt = 0;
	m_bCtrlKey = FALSE;

	memset(&bmsModbusPortCfg[0], 0, sizeof(bmsModbusPortCfg));
	memset(&nPortModbus[0], 0, sizeof(nPortModbus));

	if(realRtuType == RTU_1057_TYPE) {
		maxModbusPort = MAX_MODBUS_PORTS;
	}
	else if(realRtuType == RTU_1058_TYPE) {
		maxModbusPort = MAX_MODBUS_PORTS_1058;
	}
	else if(realRtuType == RTU_2000_TYPE) {
		maxModbusPort = MAX_MODBUS_PORTS_2000;
	}
	else if(realRtuType == RTU_8001_TYPE) {
		maxModbusPort = MAX_MODBUS_PORTS_8001;
	}
	else {
		maxModbusPort = 0;
	}
}

void CRtuBmsConfig::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CRtuBmsConfig)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CRtuBmsConfig, CDialog)
	//{{AFX_MSG_MAP(CRtuBmsConfig)
	ON_MESSAGE(WM_GMS, OnGms)
	ON_REGISTERED_MESSAGE(UWM_TEXT, OnTextMessage)
	ON_COMMAND(ID_CFG_GENERAL, OnConfigueGeneral)
	ON_COMMAND(ID_CFG_PULSECOUNTER, OnConfiguePulseCount)
	ON_COMMAND(ID_CFG_BACNET, OnConfigueBacNet)
	ON_COMMAND(ID_CFG_MODBUS, OnConfigueModBus)
	ON_COMMAND(ID_CFG_MACROS, OnConfigueMacros)
	ON_COMMAND(ID_CFG_EXIT, OnConfigueExit)
	ON_WM_CLOSE()
	ON_WM_SIZE()
	ON_WM_PAINT()
	ON_COMMAND(ID_BMS_PRINT_GENERAL, OnPrintGeneral)
	ON_COMMAND(ID_BMS_PRINT_PULSECOUNTER, OnPrintPulseCounter)
	ON_COMMAND(ID_BMS_PRINT_BACNET, OnPrintBACNet)
	ON_COMMAND(ID_BMS_PRINT_MODBUS, OnPrintModbus)
	ON_COMMAND(ID_BMS_PRINT_MACROS, OnPrintMacros)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CRtuBmsConfig message handlers
BOOL CRtuBmsConfig::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	ModifyStyle(0, WS_OVERLAPPEDWINDOW | WS_VSCROLL | WS_CLIPCHILDREN);
	m_lpps->heDlg = GetSafeHwnd();
	m_lpps->hmDlg = m_lpps->heDlg;

	HWND hWnd = GetSafeHwnd();
	hStus = 0;
	hBox = 0;
	hBox = CreateWindow(_T("static"), 0,
		WS_CHILD | WS_VISIBLE | WS_DLGFRAME,
		0, 0, 0, 0,
		hWnd, (HMENU)1, m_hInst, 0);
   
	hStus = CreateWindow(_T("static"), 0,
		WS_CHILD | WS_VISIBLE | SS_LEFT,
		0, 0, 0, 0,
		hWnd, (HMENU)5001, m_hInst, 0);

	m_fDirn = BMS_UPLOAD;
	Upload(BMS_GEN_CFG);

	DispStusLine(hWnd, hStus, hBox);

	::SendMessage(m_hRtuSysWnd, WM_GMS, IDM_SETWINPOS, MAKELONG(m_lpps->heDlg, BMS_WIN));
	
	CMenu* pMenu = GetMenu();
	if(pMenu != NULL) {
		if(!CheckAccess(E_RTU_BMSPARMS, VIEW_MODE, 0)) {
			pMenu->EnableMenuItem(ID_CFG_GENERAL, MF_GRAYED);
			pMenu->EnableMenuItem(ID_CFG_PULSECOUNTER, MF_GRAYED);
			pMenu->EnableMenuItem(ID_CFG_BACNET, MF_GRAYED);
			pMenu->EnableMenuItem(ID_CFG_MODBUS, MF_GRAYED);
			pMenu->EnableMenuItem(ID_CFG_MACROS, MF_GRAYED);
		}

	}

		// TODO: Add extra initialization here
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CRtuBmsConfig::OnPaint()
{
	CPaintDC dc(this);
	CRect rc;
	GetClientRect(&rc);
	dc.FillSolidRect(&rc, GetSysColor(COLOR_WINDOW));
}

LRESULT CRtuBmsConfig::OnTextMessage(WPARAM wParam, LPARAM lParam)
{
	try {
		if(m_bMessageToParent && m_pParent) {
			m_pParent->SendMessage(UWM_TEXT, wParam, lParam);
		}
	} catch(...) {}

	return 0;
}

LRESULT CRtuBmsConfig::OnGms(WPARAM wParam, LPARAM lParam)
{
	PARMPROC lpps;
	BYTE data[RTU_BUFF_SIZE];
	memset(data, 0, sizeof(data));
	memcpy(&lpps, m_lpps, sizeof(PARMPROC));
	lpps.lpData = &data[0];
	UINT id;
	id = GET_WM_COMMAND_ID(wParam, lParam);
	switch(id) {
		case IDD_COMMOVR_ERROR:   
			break;

		case IDD_COMMOVR_DATA1: // TT 6842
		case IDD_COMMOVR_CTRL_NUM:
		case IDD_COMMOVR_DATA:
			SendMessage(UWM_TEXT, (WPARAM)_T(""));
			if(!m_bIsValidParam && (lParam == m_nRtuNumber)) {
				m_bIsValidParam = TRUE;
				break;
			}

			if(lParam) {
				if(m_fDirn == BMS_UPLOAD) {
					GetBmsConfig(m_lpps, m_nBlkNum);
				}
				if(m_fDirn == BMS_DOWNLOAD) {
					SendBmsConfig(m_lpps, m_nBlkNum);
				}
				if((m_fDirn == BMS_PORT_UPLOAD) && (id == IDD_COMMOVR_DATA1 /* TT 6842 */)) {
					BYTE dat[256]; memcpy(dat, (LPBYTE)lParam, 256);
					delete[] (LPBYTE)lParam;
					GetPortConfig(&lpps, dat+5);
				}
			}
			break;
		  
		case IDD_BMS_GET_PORT_PARAMS:
			int nPortNum;
			m_fDirn = BMS_PORT_UPLOAD;
			nPortNum = (LPARAM)lParam;
			lpps.BC = 2;
			lpps.lpData[1] = 0;
			lpps.lpData[0] = (BYTE)(nPortNum + 2);
			get_rtuport_parms(&lpps, nPortNum-1, 0);
			break;
			
		default:
			break;
	}
	
	return(0);
}

void CRtuBmsConfig::OnSize(UINT nType, int cx, int cy) 
{
	CDialog::OnSize(nType, cx, cy);

	// TODO: Add your message handler code here
	DispStusLine(GetSafeHwnd(), hStus, hBox);
}

void CRtuBmsConfig::UpdateMenu()
{
	if(!CheckAccess(E_RTU_BMSPARMS, VIEW_MODE))
		return;

	CMenu* pMenu = GetMenu();
	if(pMenu) {
		if(bmsGenCfg.flags & ENABLE_BMS_BACNET_DRIVER)
			pMenu->EnableMenuItem(ID_CFG_BACNET, MF_ENABLED);
		else
			pMenu->EnableMenuItem(ID_CFG_BACNET, MF_GRAYED);

		if(bmsGenCfg.flags & ENABLE_BMS_MODBUS_DRIVER)
			pMenu->EnableMenuItem(ID_CFG_MODBUS, MF_ENABLED);
		else
			pMenu->EnableMenuItem(ID_CFG_MODBUS, MF_GRAYED);
	}
}

void CRtuBmsConfig::OnConfigueGeneral()
{
	m_bPrintConfig = FALSE;
	m_bCtrlKey = (GetKeyState(VK_CONTROL) & 0x8000) ? TRUE : FALSE;
	Upload(BMS_GEN_CFG);
m_bIsValidParam = TRUE;
}

void CRtuBmsConfig::OnConfiguePulseCount()
{
	m_bPrintConfig = FALSE;
	m_bCtrlKey = (GetKeyState(VK_CONTROL) & 0x8000) ? TRUE : FALSE;
	Upload(BMS_PCNT_CFG);
}

void CRtuBmsConfig::OnConfigueBacNet()
{
	m_bPrintConfig = FALSE;
	m_bCtrlKey = (GetKeyState(VK_CONTROL) & 0x8000) ? TRUE : FALSE;
	Upload(BMS_BACNET_CFG);
}

void CRtuBmsConfig::OnConfigueModBus()
{
	m_bPrintConfig = FALSE;
	m_bCtrlKey = (GetKeyState(VK_CONTROL) & 0x8000) ? TRUE : FALSE;
	PostMessage(WM_GMS, IDD_BMS_GET_PORT_PARAMS, GetPortNumber(m_nPortCnt));
}

void CRtuBmsConfig::OnConfigueMacros()
{
	m_bPrintConfig = FALSE;
	m_bCtrlKey = (GetKeyState(VK_CONTROL) & 0x8000) ? TRUE : FALSE;
	Upload(BMS_MACROS_CFG);
}

void CRtuBmsConfig::OnPrintGeneral()
{
	m_bPrintConfig = TRUE;
	m_bCtrlKey = (GetKeyState(VK_CONTROL) & 0x8000) ? TRUE : FALSE;
	Upload(BMS_GEN_CFG);
}

void CRtuBmsConfig::OnPrintPulseCounter()
{
	m_bPrintConfig = TRUE;
	m_bCtrlKey = (GetKeyState(VK_CONTROL) & 0x8000) ? TRUE : FALSE;
	Upload(BMS_PCNT_CFG);
}

void CRtuBmsConfig::OnPrintBACNet()
{
	m_bPrintConfig = TRUE;
	m_bCtrlKey = (GetKeyState(VK_CONTROL) & 0x8000) ? TRUE : FALSE;
	Upload(BMS_BACNET_CFG);
}

void CRtuBmsConfig::OnPrintModbus()
{
	m_bPrintConfig = TRUE;
	m_bCtrlKey = (GetKeyState(VK_CONTROL) & 0x8000) ? TRUE : FALSE;
	PostMessage(WM_GMS, IDD_BMS_GET_PORT_PARAMS, GetPortNumber(m_nPortCnt));
}

void CRtuBmsConfig::OnPrintMacros()
{
	m_bPrintConfig = TRUE;
	m_bCtrlKey = (GetKeyState(VK_CONTROL) & 0x8000) ? TRUE : FALSE;
	Upload(BMS_MACROS_CFG);
}


void CRtuBmsConfig::OnConfigueExit()
{
	PostMessage(WM_CLOSE);
}

void CRtuBmsConfig::OnClose()
{
	if(DispMessageBox(GetSafeHwnd(), IDS_WANT_EXIT, IDS_EXIT, MB_YESNO | MB_ICONQUESTION) == IDYES) {
		//::SendMessage(m_hRtuSysWnd, WM_GMS, IDM_UPDATE,	MAKELONG(m_lpps->heDlg, BMS_WIN));

		if (::IsIconic(m_hWnd) == FALSE && ::IsMaximized(m_hWnd) == FALSE)
		{
			WINPOS wp;
			wp.hWnd = m_hWnd;
			wp.idx = BMS_WIN;
			::SendMessage(m_hRtuSysWnd, WM_GMS, IDM_UPDATE, (LPARAM)&wp);
		}


		DestroyWindow();
		delete pBmsCfg;
		pBmsCfg = NULL;
		}
}

void CRtuBmsConfig::Upload(int blkNum)
{
	m_nBlkNum = blkNum;
	m_fDirn = BMS_UPLOAD;

	if (m_bCtrlKey)
		PostMessage(WM_GMS, IDD_COMMOVR_ERROR, 1);
	else
		get_BMS_parms(m_lpps, blkNum, nBlkSize);
}

void CRtuBmsConfig::GetPortConfig(LPPARMPROC lpps, LPBYTE pData)
{
	BYTE buff[RTU_BUFF_SIZE];
	memset(buff, 0, sizeof(buff));
	lpps->lpData = &buff[0];
	if(pData != NULL) {
		memcpy(lpps->lpData, pData, sizeof(buff));

		if(lpps->lpData[4] == 46) {	//PCL_MODBUS = 46
			memcpy(&bmsModbusPortCfg[m_nPortCnt], &lpps->lpData[5], sizeof(ModbusPortCfg));
			nPortModbus[m_nPortCnt] = 1;
		}
		if(++m_nPortCnt < maxModbusPort) {
			PostMessage(WM_GMS, IDD_BMS_GET_PORT_PARAMS, GetPortNumber(m_nPortCnt));
		}
		else {
			m_fDirn = -1;
			m_nPortCnt = 0;
			Upload(BMS_MODBUS_CFG);
		}
	}
}


void CRtuBmsConfig::GetBmsConfig(LPPARMPROC lpps, int num)
{
	int		recSize=0;
	int     rtuNo;
	TCHAR	filename[MAX_PATH];

	if(m_bMessageToParent && m_pParent) {
		m_pParent->SendMessage(UWM_TEXT, (WPARAM)_T(""));
	}
	std::unique_ptr<BYTE[]> temp(new BYTE[MAX_BMS_DATA]());
	if (temp == nullptr) {
		DispMessageBox(GetSafeHwnd(), IDS_NOT_ENOUGH_MEM, IDS_BMS_CFG_TXT, MB_OK|MB_ICONSTOP);
		return;
	}

	rtuNo = MAKERTUNO(lpps->eType,lpps->eNo);
	GetRtuParmFile(filename, bmsFile[num], rtuNo);
	
	recSize = wFileRead(filename, temp.get(), MAX_BMS_DATA); //???
	 

	CString str;
	switch (num) {
		case BMS_GEN_CFG:
			if(recSize == sizeof(bmsGenCfg)) {
				memcpy(&bmsGenCfg, temp.get(), sizeof(bmsGenCfg));
				if(m_bStart) {
					m_bStart = FALSE;
					UpdateMenu();
				}
				else {
					if(m_bPrintConfig) {
						PrintGeneralConfg();
					}
					else 
						ShowGeneralConfig(lpps);
				}
			}
			else {
				DispMessageBox(GetSafeHwnd(), IDS_INV_DAT_SIZE, IDS_ERROR, MB_OK | MB_ICONSTOP);
			}
			break;

		case BMS_PCNT_CFG:
			if(recSize == sizeof(bmsPcntCfg)) {
				memcpy(&bmsPcntCfg[0], temp.get(), sizeof(bmsPcntCfg));
				if(m_bPrintConfig)
					PrintPulseCounter();
				else
					ShowPulseCounterConfig(lpps);
			}
			else {
				DispMessageBox(GetSafeHwnd(), IDS_INV_DAT_SIZE, IDS_ERROR, MB_OK | MB_ICONSTOP);
			}
			break;

		case BMS_BACNET_CFG:
			if(recSize == sizeof(bmsBACnetCfg)) {
				memcpy(&bmsBACnetCfg, temp.get(), sizeof(bmsBACnetCfg));
				DoAlignment();

				if(m_bPrintConfig)
					PrintBACnet();
				else
					ShowBACnetConfig(lpps);
			}
			else {
				DispMessageBox(GetSafeHwnd(), IDS_INV_DAT_SIZE, IDS_ERROR, MB_OK | MB_ICONSTOP);
			}
			break;

		case BMS_MODBUS_CFG:
			if(recSize == sizeof(bmsModbusPntCfgSmall)) {
				bModbusCfgLarge = FALSE;
			}
			else if(recSize == sizeof(bmsModbusPntCfgLarge)) {
				bModbusCfgLarge = TRUE;
			}
			else {
				DispMessageBox(GetSafeHwnd(), IDS_INV_DAT_SIZE, IDS_ERROR, MB_OK | MB_ICONSTOP);
				break;
			}

			LPBYTE p; p = temp.get();
			// digital inputs, block 1
			int nSize; nSize = sizeof(bmsModbusPntCfgSmall.digitalInput);
			memcpy(&bmsModbusPntCfg.digitalInput[0], p, nSize);
			p += nSize;
			// analog inputs, block 1
			nSize = sizeof(bmsModbusPntCfgSmall.analogInput);
			memcpy(&bmsModbusPntCfg.analogInput[0], p, nSize);
			p += nSize;
			// digital outputs, block 1
			nSize = sizeof(bmsModbusPntCfgSmall.digitalOutput);
			memcpy(&bmsModbusPntCfg.digitalOutput[0], p, nSize);
			p += nSize;

			if(bModbusCfgLarge) {
				// digital inputs, block 2
				nSize = sizeof(bmsModbusPntCfgLarge.digitalInput) - sizeof(bmsModbusPntCfgSmall.digitalInput);
				memcpy(&bmsModbusPntCfg.digitalInput[MODBUS_MAX_DIGITAL_INPUTS], p, nSize);
				p += nSize;
				// analog inputs, block 2
				nSize = sizeof(bmsModbusPntCfgLarge.analogInput) - sizeof(bmsModbusPntCfgSmall.analogInput);
				memcpy(&bmsModbusPntCfg.analogInput[MODBUS_MAX_ANALOG_INPUTS], p, nSize);
				p += nSize;
				// digital outputs, block 2
				nSize = sizeof(bmsModbusPntCfgLarge.digitalOutput) - sizeof(bmsModbusPntCfgSmall.digitalOutput);
				memcpy(&bmsModbusPntCfg.digitalOutput[MODBUS_MAX_DIGITAL_OUTPUTS], p, nSize);
			}

			if(m_bPrintConfig)
				PrintModbus();
			else
				ShowModbusConfig(lpps);
			break;

		case BMS_MACROS_CFG:
			if(recSize == sizeof(bmsMacroCfg)) {
				memcpy(&bmsMacroCfg, temp.get(), sizeof(bmsMacroCfg));
				if(m_bPrintConfig)
					PrintMacros();
				else
					ShowMacroConfig(lpps);			
			}
			else {
				DispMessageBox(GetSafeHwnd(), IDS_INV_DAT_SIZE, IDS_ERROR, MB_OK | MB_ICONSTOP);
			}
			break;

		default:
			break;
		}
}

void CRtuBmsConfig::ShowGeneralConfig(LPPARMPROC lpps)
{
	CRtuBmsGenCfg* pGenCfg=NULL;
	pGenCfg = new CRtuBmsGenCfg(&m_fDirn, lpps);
	if(pGenCfg != NULL) { //Always evaluates to true
		pGenCfg->DoModal();
		delete pGenCfg; pGenCfg = NULL;
	}
}

void CRtuBmsConfig::ShowPulseCounterConfig(LPPARMPROC lpps)
{
	CRtuBmsPulseCounter* pPcnt=NULL;
	pPcnt = new CRtuBmsPulseCounter(&m_fDirn, lpps);
	if(pPcnt != NULL) { //Always evaluates to true
		pPcnt->DoModal();
		delete pPcnt; pPcnt = NULL;
	}
}

void CRtuBmsConfig::ShowBACnetConfig(LPPARMPROC lpps)
{
	CRtuBmsBACnet* pBACnet=NULL;
	pBACnet = new CRtuBmsBACnet(&m_fDirn, lpps);
	if(pBACnet != NULL) { //Always evaluates to true
		pBACnet->DoModal();
		delete pBACnet; pBACnet = NULL;
	}
}

void CRtuBmsConfig::ShowModbusConfig(LPPARMPROC lpps)
{
	CRtuBmsModbus* pModbus=NULL;
	pModbus = new CRtuBmsModbus(&m_fDirn, lpps);
	if(pModbus != NULL) { //Always evaluates to true
		pModbus->DoModal();
		delete pModbus; pModbus = NULL;
	}				
}

void CRtuBmsConfig::ShowMacroConfig(LPPARMPROC lpps)
{
	CRtuBmsMacroConfig* pMacDlg;
	pMacDlg = new CRtuBmsMacroConfig(&m_fDirn, lpps);
	if(pMacDlg != NULL) { //Always evaluates to true
		pMacDlg->DoModal();
		delete pMacDlg; pMacDlg = NULL;
	}
}

void CRtuBmsConfig::PrintGeneralConfg()
{
	TCHAR fname[MAX_PATH] = _T("");
	if(!RtuLib::GetPrintFileName(fname, _T(".html")))
		return;

	CHtmlFile* pFile = new CHtmlFile(hrInst, fname);

	TCHAR txt[MAX_BUFF];

	pFile->StartTags(IsRtu8002Type()? RTU_8002_TYPE: realRtuType, gRtuNo, IDS_BMS_CFG_TXT, IDS_GENPARAMS_TXT);
	pFile->SetBgColor(colors[0]);

	TCHAR str[MAX_BUFF];
	LoadString(hrInst, IDS_BMS_MODBUS_T1, str, MAX_BUFF);
	if(bmsGenCfg.tftpTime == 0xFF) {
		pFile->AddRow(1, 1, COL_SPAN|2, str, 1, _T("255"));
		pFile->AddRow(hrInst, 1, 1, COL_SPAN|2, IDS_MIDNIGHT_TXT, 1,  IDS_YES_TXT);
	}
	else {
		wsprintf(txt, _T("%d"), bmsGenCfg.tftpTime);
		pFile->AddRow(1, 1, COL_SPAN|2, str, 1, txt);
		pFile->AddRow(hrInst, 1, 1, COL_SPAN|2, IDS_MIDNIGHT_TXT, 1, IDS_NO_TXT);
	}

	pFile->AddRow(hrInst, 2, 1, ROW_SPAN|2, IDS_EN_PROT_TXT, 
		1, IDS_BACNET_TXT, 1, bmsGenCfg.flags & 1 ? IDS_YES_TXT : IDS_NO_TXT);
	pFile->AddRowResID2(IDS_MODBUS_TXT, bmsGenCfg.flags & 2 ? IDS_YES_TXT : IDS_NO_TXT);
	
	pFile->EndTags();

	RtuLib::FileExecute(GetSafeHwnd(), fname, _T("open"));

	delete pFile; pFile = NULL;
}

void CRtuBmsConfig::PrintPulseCounter()
{
	TCHAR fname[MAX_PATH] = _T("");
	if(!RtuLib::GetPrintFileName(fname, _T(".html")))
		return;

	CHtmlFile* pFile = new CHtmlFile(hrInst, fname);

	TCHAR numTxt[MAX_BUFF];
	TCHAR pcatTxt[MAX_BUFF];
	TCHAR catTxt[MAX_BUFF];

	pFile->StartTags(IsRtu8002Type()? RTU_8002_TYPE: realRtuType, gRtuNo, IDS_BMS_CFG_TXT, IDS_PULSE_CNT_PARAMS);
	CStringArray strPCntCat;
	GetPulseCounterCatStr(strPCntCat);
	int cSize = strPCntCat.GetSize();

	LoadString(hrInst, IDS_CATEGORY, catTxt, MAX_BUFF);
	for(int i=0; i<MAX_BMS_PCNT; i++) {
		pFile->SetBgColor(colors[i & 1 ? 1 : 0]);
		wsprintf(numTxt, _T("%d"), i+1);
		int nCat = bmsPcntCfg[i].category;
		wsprintf(pcatTxt, _T("%s"), nCat >= cSize ? _T("") : strPCntCat.GetAt(nCat));
		pFile->AddRow(2, 1, ROW_SPAN|4, numTxt, 1, catTxt, 1, pcatTxt);
		pFile->AddRowResID1(IDS_AREA, bmsPcntCfg[i].area + 1);
		pFile->AddRowResID1(IDS_TRIGGER, bmsPcntCfg[i].trigger + 1);
		pFile->AddRowResID2(IDS_EN_CNT_CHG_STS, bmsPcntCfg[i].flags & 1 ? IDS_YES_TXT : IDS_NO_TXT);
	}

	pFile->EndTags();

	RtuLib::FileExecute(GetSafeHwnd(), fname, _T("open"));

	delete pFile; pFile = NULL;
}


void CRtuBmsConfig::PrintBACnet()
{
	TCHAR fname[MAX_PATH] = _T("");
	if(!RtuLib::GetPrintFileName(fname, _T(".html")))
		return;

	CHtmlFile* pFile = new CHtmlFile(hrInst, fname);

	TCHAR txt[MAX_BUFF];
	TCHAR txt2[MAX_BUFF];
	int i, nColor=0;
	
	pFile->StartTags(IsRtu8002Type()? RTU_8002_TYPE: realRtuType, gRtuNo, IDS_BMS_CFG_TXT, IDS_BACNET_PARAMS);
	// Print Protocol Parameter
	pFile->SetBgColor(colors[nColor&1 ? 1 : 0]);	nColor++;
	int sel = bmsBACnetCfg.protocolCfg.rtuPortNumber;
	CStringArray strPorts; 
	GetRtuPortList(strPorts, realRtuType, IsRtu8002Type());
	if((realRtuType == RTU_1058_TYPE) && (sel >= 8)) {
		sel -= 4;
	}
	wsprintf(txt, _T("%s"), (LPCTSTR)strPorts.GetAt(sel));

	TCHAR protTxt[MAX_BUFF], portNumTxt[MAX_BUFF];
	LoadString(hrInst, IDS_PROT_PARAMS, protTxt, MAX_BUFF);
	LoadString(hrInst, IDS_PORT_NUM, portNumTxt, MAX_BUFF);
	pFile->AddRow(2, 1, ROW_SPAN|11, protTxt, 1, portNumTxt, 1, txt);

	LoadString(hrInst, IDS_LNK_LAYER_PROT, txt, MAX_BUFF);
	CStringArray strProt; GetBACnetProtLLStr(strProt);
	int protSize = strProt.GetSize();
	int nProt = bmsBACnetCfg.protocolCfg.linkLayerProtocol;
	wsprintf(txt2, _T("%s"), nProt >= protSize ? _T("") : strProt.GetAt(nProt));
	pFile->AddRow(txt, txt2);

	pFile->AddRowResID1(IDS_BACNET_ADDR, bmsBACnetCfg.protocolCfg.myBacnetAddress);
	pFile->AddRowResID1(IDS_NUM_APDU_RET, bmsBACnetCfg.protocolCfg.numberOfApduRetries);
	pFile->AddRowResID1(IDS_APDU_TIMEOUT, bmsBACnetCfg.protocolCfg.apduTimeOut);
	pFile->AddRowResID1(IDS_APDU_SEG_TIMEOUT, bmsBACnetCfg.protocolCfg.apduSegmentTimeOut);
	pFile->AddRowResID1(IDS_TX_SEG_WIN_SIZE, bmsBACnetCfg.protocolCfg.txSegmentWindowSize);
	pFile->AddRowResID1(IDS_RX_SEG_WIN_SIZE, bmsBACnetCfg.protocolCfg.rxSegmentWindowSize);
	pFile->AddRowResID1(IDS_ALM_ENR_TIME, bmsBACnetCfg.protocolCfg.alarmEnrollmentTime);
	pFile->AddRowResID1(IDS_BACNET_UDP_PORT, bmsBACnetCfg.protocolCfg.udpPortNumber);
	
	int addr1, addr2, addr3, addr4;
	addr1 = bmsBACnetCfg.protocolCfg.bbmdIpAddress & 0xff;
	addr2 = (bmsBACnetCfg.protocolCfg.bbmdIpAddress >> 8) & 0xff;
	addr3 = (bmsBACnetCfg.protocolCfg.bbmdIpAddress >> 16) & 0xff;
	addr4 = (bmsBACnetCfg.protocolCfg.bbmdIpAddress >> 24) & 0xff;
	
	LoadString(hrInst, IDS_ADDR_BBMD, txt, MAX_BUFF);
	wsprintf(txt2, _T("%d.%d.%d.%d"), addr4, addr3, addr2, addr1);
	pFile->AddRow(txt, txt2);

	// Print Device Parameters
	TCHAR BACnetInputTxt[MAX_BUFF];
	TCHAR notifyTypeTxt[MAX_BUFF];

	LoadString(hrInst, IDS_BACNET_INPUT, BACnetInputTxt, MAX_BUFF);
	LoadString(hrInst, IDS_NOTIFY_TYPE, notifyTypeTxt, MAX_BUFF);

	CStringArray strNType; GetBACnetDevCfgNTypeStr(strNType);
	CStringArray strOType; GetBACnetDevCfgOTypeStr(strOType);
	CStringArray strEType; GetBACnetDevCfgETypeStr(strEType);
	CStringArray strPType; GetBACnetDevCfgETypeStr(strPType);
	int nSize = strNType.GetSize();
	int oSize = strOType.GetSize();
	int eSize = strEType.GetSize();
	int pSize = strPType.GetSize();

	for(i=0; i<MAX_BMS_BACNET_DEVCFG; i++) {
		pFile->SetBgColor(colors[nColor&1 ? 1 : 0]);	nColor++;
		
		wsprintf(txt2, _T("%s %d"), BACnetInputTxt, i+1);

		int nType = bmsBACnetCfg.input[i].notifyType_objectType >> 4;
		wsprintf(txt, _T("%s"), nType >= nSize ? _T("") : strNType.GetAt(nType));
		pFile->AddRow(2, 1, ROW_SPAN|8, txt2, 1, notifyTypeTxt, 1, txt);

		pFile->AddRowResID1(IDS_DEVICE, bmsBACnetCfg.input[i].deviceNumber);
		pFile->AddRowResID1(IDS_NOTIFICATION_CLASS, bmsBACnetCfg.input[i].notificationClass);

		int oType = bmsBACnetCfg.input[i].notifyType_objectType & 0x0f;
		if(oType == OBJ_TYPE_EVENT_ENROLLEMNT)
			oType -= 3;
		wsprintf(txt, _T("%s"), oType >= oSize ? _T("") : strOType.GetAt(oType));
		pFile->AddRowResID1(IDS_OBJ_TYPE, txt);
		pFile->AddRowResID1(IDS_OBJ_INSTANCE, bmsBACnetCfg.input[i].objectInstance);

		int eType = bmsBACnetCfg.input[i].eventType_pointType >> 4;
		wsprintf(txt, _T("%s"), eType >= eSize ? _T("") : strEType.GetAt(eType));
		pFile->AddRowResID1(IDS_EVENT_TYPE, txt);

		int pType = bmsBACnetCfg.input[i].eventType_pointType & 0x0f;
		wsprintf(txt, _T("%s"), pType >= pSize ? _T("") : strPType.GetAt(pType));
		pFile->AddRowResID1(IDS_POINT_TYPE, txt);
		
		pFile->AddRowResID1(IDS_POINT_NUM, bmsBACnetCfg.input[i].pointNumber + 1);
	}


	// Print Action Parameters
	TCHAR BACnetActTxt[MAX_BUFF];
	TCHAR reqTypeTxt[MAX_BUFF];

	LoadString(hrInst, IDS_BACNET_ACT, BACnetActTxt, MAX_BUFF);
	LoadString(hrInst, IDS_SER_REQ_TYPE, reqTypeTxt, MAX_BUFF);
	CStringArray strActReqType; GetBACnetActReqTypeStr(strActReqType);
	CStringArray strActObjType; GetBACnetActObjTypeStr(strActObjType);
	int reqSize = strActReqType.GetSize();
	int objSize = strActObjType.GetSize();

	for(i=0; i<MAX_BMS_BACNET_ACTION; i++) {
		pFile->SetBgColor(colors[nColor&1 ? 1 : 0]);	nColor++;
		
		wsprintf(txt2, _T("%s %d"),BACnetActTxt, i+1);

		int reqType = bmsBACnetCfg.action[i].serviceRequest_objectType >> 4;
		wsprintf(txt, _T("%s"), reqType >= reqSize ? _T("") : strActReqType.GetAt(reqType));
		pFile->AddRow(2, 1, ROW_SPAN|6, txt2, 1, reqTypeTxt, 1, txt);

		pFile->AddRowResID1(IDS_DEVICE_ADDR, bmsBACnetCfg.action[i].deviceNumber);
		
		int objType = bmsBACnetCfg.action[i].serviceRequest_objectType & 0x0f;
		wsprintf(txt, _T("%s"), objType >= objSize ? _T("") : strActObjType.GetAt(objType));
		pFile->AddRowResID1(IDS_OBJ_TYPE, txt);

		pFile->AddRowResID1(IDS_OBJ_INSTANCE, bmsBACnetCfg.action[i].objectInstance);
		pFile->AddRowResID1(IDS_NEW_PRES_VALUE, bmsBACnetCfg.action[i].newPresentValue);
		pFile->AddRowResID1(IDS_OUT_PNT_NUM, bmsBACnetCfg.action[i].pointNumber + 1);
	}

	pFile->EndTags();

	RtuLib::FileExecute(GetSafeHwnd(), fname, _T("open"));
}


void CRtuBmsConfig::PrintModbus()
{
	TCHAR fname[MAX_PATH] = _T("");
	if(!RtuLib::GetPrintFileName(fname, _T(".html")))
		return;

	CHtmlFile* pFile = new CHtmlFile(hrInst, fname);

	TCHAR txt[MAX_BUFF];
	TCHAR txt2[MAX_BUFF];
	int i, nColor=0;
	PrintColor prnColor = COLOR_LIGHT_YELLOW;

	CStringArray strArrayDevType;
	CStringArray strArrayPntType;
	CStringArray strArrayTemp;
	CString str;

	int index;
	int nDevType;
	
	pFile->StartTags(IsRtu8002Type()? RTU_8002_TYPE: realRtuType, gRtuNo, IDS_BMS_CFG_TXT, IDS_MODBUS_PARAMS);
	
	if(!RtuLib::GetFileStrings(MODBUS_DEVTYPE_FILE, strArrayTemp)) {
		return;
	}
	GetValidStrings(strArrayTemp, strArrayDevType);

	if(!RtuLib::GetFileStrings(MODBUS_INPTYPE_FILE, strArrayTemp)) {
		return;
	}
	GetValidStrings(strArrayTemp, strArrayPntType);

	
	// Print Digital Input
	TCHAR numTxt[MAX_BUFF];
	TCHAR mbusTxt[MAX_BUFF];
	LoadString(hrInst, IDS_DIGITAL_INP, numTxt, MAX_BUFF);
	LoadString(hrInst, IDS_MODBUS_PORT, mbusTxt, MAX_BUFF);

	int nNumDigitalInputs = bModbusCfgLarge ? MODBUS_MAX_DIGITAL_INPUTS_LARGE : MODBUS_MAX_DIGITAL_INPUTS;
	for(i=0; i<nNumDigitalInputs; i++) {
		pFile->SetBgColor(colors[nColor&1 ? 1 : 0]);	nColor++;
		wsprintf(txt, _T("%s %d"), numTxt, i+1);
		
		index = ModbusPortSel(bmsModbusPntCfg.digitalInput[i].portNumber);
		if (nPortModbus[index] == 0) 
			LoadString(hrInst, IDS_NOT_DEFINED, txt2, MAX_BUFF);
		else
			GetModbusPortTxt(txt2, index);

		pFile->AddRow(2, 1, ROW_SPAN|4, txt, 1, mbusTxt, 1, txt2);
				
		nDevType = bmsModbusPntCfg.digitalInput[i].deviceType;
		wsprintf(txt, _T("%s"), (LPCTSTR)strArrayDevType.GetAt(nDevType));
		pFile->AddRowResID1(IDS_DEVICE_TYPE, txt);
		pFile->AddRowResID1(IDS_DEVICE_ADDR, bmsModbusPntCfg.digitalInput[i].deviceAddress + 1);
		str = strArrayPntType.GetAt(bmsModbusPntCfg.digitalInput[i].dataType);

		if(GetPointTypeStr(nDevType+1, str)) {
			wsprintf(txt, _T("%s"), (LPCTSTR)str);
		}
		else
			wsprintf(txt, _T(""));
		pFile->AddRowResID1(IDS_INP_TYPE, txt);
	}

	// Print Digital Output
	if(!RtuLib::GetFileStrings(MODBUS_OUTTYPE_FILE, strArrayTemp)) {
		return;
	}
	GetValidStrings(strArrayTemp, strArrayPntType);

	prnColor = COLOR_GOLD;
	LoadString(hrInst, IDS_DIGITAL_OUT, numTxt, MAX_BUFF);

	int nNumDigitalOutputs = bModbusCfgLarge ? MODBUS_MAX_DIGITAL_OUTPUTS_LARGE : MODBUS_MAX_DIGITAL_OUTPUTS;
	for(i=0; i<nNumDigitalOutputs; i++) {
		prnColor = prnColor == COLOR_GOLD ? COLOR_TAN : COLOR_GOLD;
		pFile->SetBgColor(colors[prnColor]);
		wsprintf(txt, _T("%s %d"), numTxt, i+1);
		
		index = ModbusPortSel(bmsModbusPntCfg.digitalOutput[i].portNumber);

		if (nPortModbus[index] == 0) 
			LoadString(hrInst, IDS_NOT_DEFINED, txt2, MAX_BUFF);
		else
			GetModbusPortTxt(txt2, index);
		pFile->AddRow(2, 1, ROW_SPAN|4, txt, 1, mbusTxt, 1, txt2);

		nDevType = bmsModbusPntCfg.digitalOutput[i].deviceType;
		wsprintf(txt, _T("%s"), (LPCTSTR)strArrayDevType.GetAt(nDevType));
		pFile->AddRowResID1(IDS_DEVICE_TYPE, txt);
		pFile->AddRowResID1(IDS_DEVICE_ADDR, bmsModbusPntCfg.digitalOutput[i].deviceAddress + 1);
		str = strArrayPntType.GetAt(bmsModbusPntCfg.digitalOutput[i].dataType);

		if(GetPointTypeStr(nDevType+1, str)) {
			wsprintf(txt, _T("%s"), (LPCTSTR)str);
		}
		else
			wsprintf(txt, _T(""));
		pFile->AddRowResID1(IDS_OUT_TYPE, txt);
	}

	// Print Analog Digital Input
	if(!RtuLib::GetFileStrings(MODBUS_AINTYPE_FILE, strArrayTemp)) {
		return;
	}
	GetValidStrings(strArrayTemp, strArrayPntType);

	LoadString(hrInst, IDS_ANALOG_INP, numTxt, MAX_BUFF);

	int nNumAnalogInputs = bModbusCfgLarge ? MODBUS_MAX_ANALOG_INPUTS_LARGE : MODBUS_MAX_ANALOG_INPUTS;
	for(i=0; i<nNumAnalogInputs; i++) {
		pFile->SetBgColor(colors[nColor&1 ? 1 : 0]);	nColor++;
		wsprintf(txt, _T("%s %d"), numTxt, i+1);
		
		index = ModbusPortSel(bmsModbusPntCfg.analogInput[i].portNumber);

		if (nPortModbus[index] == 0)
			LoadString(hrInst, IDS_NOT_DEFINED, txt2, MAX_BUFF);
		else
			GetModbusPortTxt(txt2, index);
		pFile->AddRow(2, 1, ROW_SPAN|4, txt, 1, mbusTxt, 1, txt2);

		nDevType = bmsModbusPntCfg.analogInput[i].deviceType;
		wsprintf(txt, _T("%s"), (LPCTSTR)strArrayDevType.GetAt(nDevType));
		pFile->AddRowResID1(IDS_DEVICE_TYPE, txt);
		pFile->AddRowResID1(IDS_DEVICE_ADDR, bmsModbusPntCfg.analogInput[i].deviceAddress + 1);
		str = strArrayPntType.GetAt(bmsModbusPntCfg.analogInput[i].dataType);

		if(GetPointTypeStr(nDevType+1, str)) {
			wsprintf(txt, _T("%s"), (LPCTSTR)str);
		}
		else
			wsprintf(txt, _T(""));
		pFile->AddRowResID1(IDS_AINP_TYPE, txt);
	}

	pFile->EndTags();

	RtuLib::FileExecute(GetSafeHwnd(), fname, _T("open"));

	delete pFile; pFile = NULL;
}

void CRtuBmsConfig::PrintMacros()
{
	TCHAR fname[MAX_PATH] = _T("");
	if(!RtuLib::GetPrintFileName(fname, _T(".html")))
		return;

	CHtmlFile* pFile = new CHtmlFile(hrInst, fname);

	TCHAR txt[MAX_BUFF];
	TCHAR txt2[MAX_BUFF];
	int nColor=0;

	pFile->StartTags(IsRtu8002Type()? RTU_8002_TYPE: realRtuType, gRtuNo, IDS_BMS_CFG_TXT, IDS_MACRO_PARAMS);

	int numOfMacros = 0;
	TCHAR macNumTxt[MAX_BUFF];
	TCHAR devTypeTxt[MAX_BUFF];
	LoadString(hrInst, IDS_MACRO_NUM, macNumTxt, MAX_BUFF);
	LoadString(hrInst, IDS_DEVICE_TYPE, devTypeTxt, MAX_BUFF);

	CStringArray strDevType; GetMacroDevTypeStr(strDevType);
	CStringArray strCond; GetMacCondStr(strCond);
	CStringArray strOutType; GetMacroOpTypeStr(strOutType);
	int dtSize = strDevType.GetSize();
	int mcSize = strCond.GetSize();
	int opSize = strOutType.GetSize();

	for(int i=0; i<NUM_BMS_MACROS; i++) {
		int n=0;
		n = (bmsMacroCfg.cfg[i].con_devType >> 5) & 7;
		if(((bmsMacroCfg.cfg[i].con_devType >> 5) & 7) == 0)
			continue;

		numOfMacros++;
		pFile->SetBgColor(colors[nColor & 1 ? 1 : 0]); nColor++;
		
		wsprintf(txt, _T("%s %d"), macNumTxt, i+1);
		int nDevType = bmsMacroCfg.cfg[i].con_devType & 0x1f;
		wsprintf(txt2, _T("%s"), nDevType >= dtSize ? _T("") : strDevType.GetAt(nDevType));
		pFile->AddRow(2, 1, ROW_SPAN|7, txt, 1, devTypeTxt, 1, txt2);
		
		pFile->AddRowResID1(IDS_DEVICE_NUM, bmsMacroCfg.cfg[i].areaNo + 1);

		int nCond = (bmsMacroCfg.cfg[i].con_devType >> 5) & 7;
		wsprintf(txt, _T("%s"), nCond >= mcSize ? _T("") : strCond.GetAt(nCond));
		pFile->AddRowResID1(IDS_CONDITION, txt);

		int nCount = (bmsMacroCfg.cfg[i].countHi << 8) | (bmsMacroCfg.cfg[i].countLo);
		pFile->AddRowResID1(IDS_COUNT, nCount);

		int otype = (bmsMacroCfg.cfg[i].opType_Num >> 6) & 3;
		wsprintf(txt, _T("%s"), otype >= opSize ? _T("") : strOutType.GetAt(otype));
		pFile->AddRowResID1(IDS_OUT_TYPE, txt);

		switch(otype) {
			case 0:
				pFile->AddRowResID1(IDS_GPO_NUM, (bmsMacroCfg.cfg[i].opType_Num & 0x3f) + 1);	break;
			case 1:
				pFile->AddRowResID1(IDS_CCTV_NUM, (bmsMacroCfg.cfg[i].opType_Num & 0x3f) + 1);	break;
			case 2:
				pFile->AddRowResID1(IDS_TRIG_NUM, (bmsMacroCfg.cfg[i].opType_Num & 0x3f) + 1);	break;
			default: break;
		}
		
		uchar tm = bmsMacroCfg.cfg[i].actTime;
		if(tm & 0x80) { // Time is in minute(s)
			LoadString(hrInst, (tm & 0x7f) > 1 ? IDS_MINUTES : IDS_MINUTE, txt2, MAX_BUFF);
		}
		else {
			LoadString(hrInst, (tm & 0x7f) > 1 ? IDS_SECONDS : IDS_SECOND, txt2, MAX_BUFF);
		}
		wsprintf(txt, _T("%d %s"), tm & 0x7f, txt2);
		pFile->AddRowResID1(IDS_ACT_TIME, txt);
	}

	pFile->EndTags();

	if(numOfMacros == 0) {
		LoadString(hrInst, IDS_NO_MACRO_CFG, txt, MAX_BUFF);
		MessageBox(txt);
		return;
	}

	RtuLib::FileExecute(GetSafeHwnd(), fname, _T("open"));

	delete pFile; pFile = NULL;
}

int CRtuBmsConfig::SendBmsConfig(LPPARMPROC lpps, int num)
{
	int recSize = 0;
	TCHAR	filename[MAX_PATH];
	BOOL bResult = TRUE;
	LPBYTE pBuffer = NULL;
	switch (num) {
		case BMS_GEN_CFG:
			if(bBmsGenCfgChanged) {
				bBmsGenCfgChanged = FALSE;
				UpdateMenu();
				recSize = sizeof(bmsGenCfg);
				pBuffer = new BYTE[recSize];
				memcpy(pBuffer, &bmsGenCfg, recSize);
			}
			else if(m_bMessageToParent){
				if(m_pParent) {
					m_pParent->SendMessage(UWM_CONFIG_DOWNLOADED, BMS_CONFIG_TYPE, BMS_GEN_CFG);
				}
			}
			break;

		case BMS_PCNT_CFG:
			if(bBmsPcntChanged) {
				bBmsPcntChanged = FALSE;
				recSize = sizeof(bmsPcntCfg);
				pBuffer = new BYTE[recSize];
				memcpy(pBuffer, &bmsPcntCfg[0], recSize);
			}
			break;

		case BMS_BACNET_CFG:
			if(bBmsBACnetChanged) {
				bBmsBACnetChanged = FALSE;
				DoAlignment();
				recSize = sizeof(bmsBACnetCfg);
				pBuffer = new BYTE[recSize];
				memcpy(pBuffer, &bmsBACnetCfg, recSize);
			}
			break;

		case BMS_MODBUS_CFG:
			if(bBmsModbusChanged) {
				bBmsModbusChanged = FALSE;
				if(bModbusCfgLarge) {
					recSize = sizeof(bmsModbusPntCfgLarge);
					pBuffer = new BYTE[recSize];
				}
				else {
					recSize = sizeof(bmsModbusPntCfg);
					pBuffer = new BYTE[recSize];
				}

				LPBYTE p = pBuffer;
				// digital inputs, block 1
				int nSize = sizeof(bmsModbusPntCfgSmall.digitalInput);
				memcpy(p, &bmsModbusPntCfg.digitalInput[0], nSize);
				p += nSize;
				// analog inputs, block 1
				nSize = sizeof(bmsModbusPntCfgSmall.analogInput);
				memcpy(p, &bmsModbusPntCfg.analogInput[0], nSize);
				p += nSize;
				// digital outputs, block 1
				nSize = sizeof(bmsModbusPntCfgSmall.digitalOutput);
				memcpy(p, &bmsModbusPntCfg.digitalOutput[0], nSize);
				p += nSize;

				if(bModbusCfgLarge) {
					// digital inputs, block 2
					nSize = sizeof(bmsModbusPntCfgLarge.digitalInput) - sizeof(bmsModbusPntCfgSmall.digitalInput);
					memcpy(p, &bmsModbusPntCfg.digitalInput[MODBUS_MAX_DIGITAL_INPUTS], nSize);
					p += nSize;
					// analog inputs, block 2
					nSize = sizeof(bmsModbusPntCfgLarge.analogInput) - sizeof(bmsModbusPntCfgSmall.analogInput);
					memcpy(p, &bmsModbusPntCfg.analogInput[MODBUS_MAX_ANALOG_INPUTS], nSize);
					p += nSize;
					// digital outputs, block 2
					nSize = sizeof(bmsModbusPntCfgLarge.digitalOutput) - sizeof(bmsModbusPntCfgSmall.digitalOutput);
					memcpy(p, &bmsModbusPntCfg.digitalOutput[MODBUS_MAX_DIGITAL_OUTPUTS], nSize);
				}
			}
			break;

		case BMS_MACROS_CFG:
			if(bBmsMacroChanged) {
				bBmsMacroChanged = FALSE;
				recSize = sizeof(bmsMacroCfg);
				pBuffer = new BYTE[recSize];
				memcpy(pBuffer, &bmsMacroCfg, recSize);
			}
			break;

		default:
			break;
	}

	if(recSize) {
		
		int nRtuNo = MAKERTUNO(lpps->eType,lpps->eNo);
		 
		GetRtuParmFile(filename, bmsFile[num], nRtuNo);

		if ((wFileWrite(filename, pBuffer, recSize)) != recSize) {
			bResult = FALSE;
		}
	}

	if(pBuffer) {
		delete[] pBuffer; pBuffer = NULL;
	}

	return bResult;
}

/*=========================================================================*/
/*=========================================================================*/
CRtuBmsGenCfg::CRtuBmsGenCfg(int* dirn, LPPARMPROC lpps, CWnd* pParent)
	: CDialog(CRtuBmsGenCfg::IDD, pParent)
{
	m_fDirn = dirn;
	m_lpps = lpps;
}

void CRtuBmsGenCfg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CRtuBmsGenCfg)
	DDX_Control(pDX, IDC_BMS_GEN_TIME, m_txtGenTime);
	DDX_Control(pDX, IDC_CBO_EN_PROT, m_cboEnProtocol);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CRtuBmsGenCfg, CDialog)
	//{{AFX_MSG_MAP(CRtuBmsGenCfg)
	ON_BN_CLICKED(IDOK, OnOK)
	ON_BN_CLICKED(IDCANCEL, OnCancel)
	ON_BN_CLICKED(IDC_BMS_GEN_MIDNIGHT, OnMidnight)
	ON_CBN_SELCHANGE(IDC_CBO_EN_PROT, OnSelchangeEnableProtocol)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CRtuBmsGenCfg message handlers
BOOL CRtuBmsGenCfg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	m_txtGenTime.SetMinMaxLimit(0, 0xff, 3);
	memcpy(&m_genCfg, &bmsGenCfg, sizeof(m_genCfg));

	m_cboEnProtocol.AddString(RES_STRING(IDS_NONE));
	m_cboEnProtocol.AddString(RES_STRING(IDS_BACNET_TXT));
	m_cboEnProtocol.AddString(RES_STRING(IDS_MODBUS_TXT));
	m_cboEnProtocol.AddString(RES_STRING(IDS_BACNET_MODBUS_EN));
	m_nEnableProtocol = m_genCfg.flags & 0x03;
	ShowParams();
	
	CheckEditPriv(GetSafeHwnd(), E_RTU_BMSPARMS);
	CenterWindow();
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CRtuBmsGenCfg::ShowParams()
{
	UpdateData(FALSE);
	if(m_genCfg.tftpTime == 0xFF) {
		GetDlgItem(IDC_BMS_GEN_TIME)->EnableWindow(FALSE);
		m_txtGenTime.SetValue(255);
		CheckDlgButton(IDC_BMS_GEN_MIDNIGHT, TRUE);
	}
	else {
		GetDlgItem(IDC_BMS_GEN_TIME)->EnableWindow(TRUE);
		m_txtGenTime.SetValue(m_genCfg.tftpTime);
		CheckDlgButton(IDC_BMS_GEN_MIDNIGHT, FALSE);
	}
	m_cboEnProtocol.SetCurSel(m_nEnableProtocol);
}

void CRtuBmsGenCfg::StoreParams()
{
	UpdateData(TRUE);
	m_genCfg.tftpTime = (BYTE)m_txtGenTime.GetValue(); 
	m_genCfg.flags &= 0xfc;
	m_genCfg.flags |= (BYTE)m_cboEnProtocol.GetCurSel();
}

BOOL CRtuBmsGenCfg::CheckParams()
{
	if(!m_txtGenTime.IsValid())
		return FALSE;
	return TRUE;	
}

void CRtuBmsGenCfg::OnMidnight()
{
	if(IsDlgButtonChecked(IDC_BMS_GEN_MIDNIGHT)) {
		GetDlgItem(IDC_BMS_GEN_TIME)->EnableWindow(FALSE);
		SetDlgItemInt(IDC_BMS_GEN_TIME, 255);
	}
	else {
		GetDlgItem(IDC_BMS_GEN_TIME)->EnableWindow(TRUE);
	}
}

void CRtuBmsGenCfg::OnSelchangeEnableProtocol()
{
	if(m_nEnableProtocol == EN_PROT_MODBUS_ONLY) {
		int nCurSel = m_cboEnProtocol.GetCurSel();
		if(nCurSel == EN_PROT_BACNET_MODBUS) {
			DispMessageBox(GetSafeHwnd(), IDS_MODBUS_WARN_MSG, IDS_WARNING, MB_OK);
		}
	}
}

//void CRtuBmsGenCfg::OnEnBACnet()
//{
//	UpdateData(TRUE);
//}
//
//void CRtuBmsGenCfg::OnEnMODBUS()
//{
//	UpdateData(TRUE);
//}

void CRtuBmsGenCfg::OnCancel() 
{
	// TODO: Add extra cleanup here
	CDialog::OnCancel();
}

void CRtuBmsGenCfg::OnOK() 
{
	// TODO: Add extra validation here
	if(!CheckParams())
		return;

	StoreParams();
	if(memcmp(&bmsGenCfg, &m_genCfg, sizeof(m_genCfg)) != 0) {
		bBmsGenCfgChanged = TRUE;
		memcpy(&bmsGenCfg, &m_genCfg, sizeof(bmsGenCfg));
		*m_fDirn = BMS_DOWNLOAD;
		send_BMS_parms(m_lpps, BMS_GEN_CFG, nBlkSize);
	}

	CDialog::OnOK();
}

/*=========================================================================*/
/*=========================================================================*/
CRtuBmsPulseCounter::CRtuBmsPulseCounter(int* dirn, LPPARMPROC lpps, CWnd* pParent)
	: m_nPcntNum(0), CDialog(CRtuBmsPulseCounter::IDD, pParent)
{
	m_fDirn = dirn;
	m_lpps = lpps;
	memset(&m_bmsPcnt, 0, sizeof(m_bmsPcnt));
}

void CRtuBmsPulseCounter::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CRtuBmsPulseCounter)
	DDX_Control(pDX, IDC_RTU_ID1, m_cboCategory);
	DDX_Control(pDX, IDC_RTU_ID2, m_txtArea);
	DDX_Control(pDX, IDC_RTU_ID3, m_txtTrigger);
	//}}AFX_DATA_MAP
}



BEGIN_MESSAGE_MAP(CRtuBmsPulseCounter, CDialog)
	//{{AFX_MSG_MAP(CRtuBmsPulseCounter)
	ON_BN_CLICKED(IDC_BMS_PCNT_NUM, OnPcntNumber)
	ON_NOTIFY(UDN_DELTAPOS, IDC_BMS_PCNT_NEXT, OnPrevNext)
	ON_BN_CLICKED(IDOK, OnOK)
	ON_BN_CLICKED(IDCANCEL, OnCancel)
	ON_CBN_SELCHANGE(IDC_RTU_ID1, OnChangeCategory)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CRtuBmsPulseCounter message handlers
BOOL CRtuBmsPulseCounter::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	m_cboCategory.ResetContent();
	CStringArray strPCntCat;
	GetPulseCounterCatStr(strPCntCat);
	for (int i=0; i<strPCntCat.GetSize(); i++) {
		m_cboCategory.AddString(strPCntCat.GetAt(i));
	}

	m_txtArea.SetMinMaxLimit(1, 256, 3);
	m_txtTrigger.SetMinMaxLimit(1, 256, 3);
	SetDlgItemInt(IDC_BMS_PCNT_TNUM, MAX_BMS_PCNT);
	memcpy(&m_bmsPcnt, &bmsPcntCfg[0], sizeof(m_bmsPcnt));
	ShowParams(m_nPcntNum);
	
	CheckEditPriv(GetSafeHwnd(), E_RTU_BMSPARMS);
	CenterWindow();
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CRtuBmsPulseCounter::OnChangeCategory()
{
	BOOL flag = m_cboCategory.GetCurSel() ? TRUE : FALSE;
	m_txtArea.EnableWindow(flag);
	m_txtTrigger.EnableWindow(flag);
}

void CRtuBmsPulseCounter::ShowParams(int num)
{
	CString str;
	str.Format(_T("%s %d/32"), RES_STRING(IDS_PULSE_CNT), num+1);
	SetDlgItemText(IDC_RTU_ID6, str);
	
	SetDlgItemInt(IDC_BMS_PCNT_ENUM, num + 1);
	m_cboCategory.SetCurSel(bmsPcntCfg[num].category);
	m_txtArea.SetValue((__int64)bmsPcntCfg[num].area + 1);
	m_txtTrigger.SetValue((__int64)bmsPcntCfg[num].trigger + 1);
	CheckDlgButton(IDC_BMS_PCNT_EN_STAT_CHNG, bmsPcntCfg[num].flags & 1);
	OnChangeCategory();
}

void CRtuBmsPulseCounter::StoreParams(int num)
{
	m_bmsPcnt.category = (BYTE)m_cboCategory.GetCurSel();		 
	m_bmsPcnt.area = (BYTE)(m_txtArea.GetValue() - 1);		 
	m_bmsPcnt.trigger = (BYTE)(m_txtTrigger.GetValue() - 1); 
	
	if(IsDlgButtonChecked(IDC_BMS_PCNT_EN_STAT_CHNG))
		m_bmsPcnt.flags |= 1;
	else
		m_bmsPcnt.flags &= ~1;
	

	if(memcmp(&m_bmsPcnt, &bmsPcntCfg[num], sizeof(m_bmsPcnt)) != 0) {
		bBmsPcntChanged = TRUE;
		memcpy(&bmsPcntCfg[num], &m_bmsPcnt, sizeof(m_bmsPcnt));
	}
}

BOOL CRtuBmsPulseCounter::CheckParams()
{
	if(!m_txtArea.IsValid())
		return FALSE;
	if(!m_txtTrigger.IsValid())
		return FALSE;
	return TRUE;	
}

void CRtuBmsPulseCounter::OnPcntNumber()
{
	int i = GetDlgItemInt(IDC_BMS_PCNT_ENUM);
	if(i < 1 || i > MAX_BMS_PCNT) {
		DispMessageBox2(GetSafeHwnd(), IDS_ENTER_RANGE, IDS_ERROR, MB_OK|MB_ICONSTOP, 1, 32);
	}
	else if(CheckParams()){
		StoreParams(m_nPcntNum);
		m_nPcntNum = i - 1;
		ShowParams(m_nPcntNum);
	}
}

void CRtuBmsPulseCounter::OnPrevNext(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_UPDOWN* pNMUpDown = (NM_UPDOWN*)pNMHDR;
	// TODO: Add your control notification handler code here
		
	if(CheckParams()) {
		StoreParams(m_nPcntNum);

		if(pNMUpDown->iDelta == 1) {
			if(--m_nPcntNum < 0)
				m_nPcntNum = MAX_BMS_PCNT - 1;
		}
		else  {
			if(++m_nPcntNum >= MAX_BMS_PCNT)
				m_nPcntNum = 0;
		}
		ShowParams(m_nPcntNum);
	}

	*pResult = 0;
}

void CRtuBmsPulseCounter::OnCancel() 
{
	// TODO: Add extra cleanup here
	bBmsPcntChanged = FALSE;
	CDialog::OnCancel();
}

void CRtuBmsPulseCounter::OnOK() 
{
	// TODO: Add extra validation here
	if(!CheckParams())
		return;

	StoreParams(m_nPcntNum);

	if(bBmsPcntChanged) {
		*m_fDirn = BMS_DOWNLOAD;
		send_BMS_parms(m_lpps, BMS_PCNT_CFG, nBlkSize);
	}

	CDialog::OnOK();
}


/*------------------------------------------------------------------------------*/
/*					BMS Device Configuration Page Class							*/
/*------------------------------------------------------------------------------*/
IMPLEMENT_DYNCREATE(CRtuBmsBACnetDevCfg, CPropertyPage)

/*
CRtuBmsBACnetDevCfg::CRtuBmsBACnetDevCfg(LPBYTE pData) : 
	CPropertyPage(CRtuBmsBACnetDevCfg::IDD)
{
	m_devCfg = (BACnetInputCfg*)pData; 
};
*/

void CRtuBmsBACnetDevCfg::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CRtuBmsBACnetDevCfg)
	DDX_Control(pDX, IDC_BMS_DEVCFG_NTYPE, m_cboNotifyType);
	DDX_Control(pDX, IDC_BMS_DEVCFG_OTYPE, m_cboObjectType);
	DDX_Control(pDX, IDC_BMS_DEVCFG_ETYPE, m_cboEventType);
	DDX_Control(pDX, IDC_BMS_DEVCFG_PTYPE, m_cboPointType);
	DDX_Control(pDX, IDC_BMS_DEVCFG_DEVNUM, m_txtDevAddr);
	DDX_Control(pDX, IDC_BMS_DEVCFG_NCLASS, m_txtNotifyClass);
	DDX_Control(pDX, IDC_BMS_DEVCFG_OINST, m_txtObjInstance);
	DDX_Control(pDX, IDC_BMS_DEVCFG_PNUM, m_txtPointNum);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CRtuBmsBACnetDevCfg, CPropertyPage)
	//{{AFX_MSG_MAP(CRtuBmsBACnetDevCfg)	
	ON_BN_CLICKED(IDC_BMS_DEVCFG_BENUM, OnDeviceNumber)
	ON_NOTIFY(UDN_DELTAPOS, IDC_BMS_DEVCFG_NEXT, OnPrevNext)
	ON_BN_CLICKED(IDC_BMS_DELETE, OnBtnDelete)
	ON_BN_CLICKED(IDC_BMS_COPY, OnBtnCopy)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CRtuBmsBACnetDevCfg message handlers
/////////////////////////////////////////////////////////////////////////////
BOOL CRtuBmsBACnetDevCfg::OnInitDialog()
{
	CDialog::OnInitDialog();

	int i;
	m_cboNotifyType.ResetContent();
	m_cboObjectType.ResetContent();
	m_cboEventType.ResetContent();
	m_cboPointType.ResetContent();

	CStringArray strNType; GetBACnetDevCfgNTypeStr(strNType);
	CStringArray strOType; GetBACnetDevCfgOTypeStr(strOType);
	CStringArray strEType; GetBACnetDevCfgETypeStr(strEType);
	CStringArray strPType; GetBACnetDevCfgPTypeStr(strPType);

	for(i=0; i<strNType.GetSize(); i++)
		m_cboNotifyType.AddString(strNType.GetAt(i));

	for(i=0; i<strOType.GetSize(); i++)
		m_cboObjectType.AddString(strOType.GetAt(i));

	for(i=0; i<strEType.GetSize(); i++)
		m_cboEventType.AddString(strEType.GetAt(i));

	for(i=0; i<strPType.GetSize(); i++)
		m_cboPointType.AddString(strPType.GetAt(i));

	m_txtDevAddr.SetMinMaxLimit(0, 4194302, 7);
	m_txtNotifyClass.SetMinMaxLimit(0, 4194302, 7);
	m_txtObjInstance.SetMinMaxLimit(0, 4194302, 7);
	m_txtPointNum.SetMinMaxLimit(1, __int64(0xff) + 1, 3);

	m_nDevNum = 0;
	SetDlgItemInt(IDC_BMS_DEVCFG_ETOT, MAX_BMS_BACNET_DEVCFG);
	ShowConfig();

	CheckEditPriv(GetSafeHwnd(), E_RTU_BMSPARMS);
	return TRUE;
}

BOOL CRtuBmsBACnetDevCfg::OnKillActive()
{
	if(!CheckConfig())
		return FALSE;
	StoreConfig();
	return CPropertyPage::OnKillActive();
}

BOOL CRtuBmsBACnetDevCfg::OnSetActive()
{
	ShowConfig();
	return CPropertyPage::OnSetActive();
}

void CRtuBmsBACnetDevCfg::OnDeviceNumber()
{
	int i = GetDlgItemInt(IDC_BMS_DEVCFG_ENUM);
	if(i < 1 || i > MAX_BMS_BACNET_DEVCFG) {
		DispMessageBox2(GetSafeHwnd(), IDS_ENTER_RANGE, IDS_ERROR, MB_OK|MB_ICONSTOP, 1, 32);
	}
	else if(CheckConfig()){
		StoreConfig();
		m_nDevNum = i - 1;
		ShowConfig();
	}
}

void CRtuBmsBACnetDevCfg::ShowConfig()
{
	int num = m_nDevNum;
	SetDlgItemInt(IDC_BMS_DEVCFG_ENUM, num + 1);
	m_cboNotifyType.SetCurSel(bmsBACnetCfg.input[num].notifyType_objectType >> 4);
	int objType = bmsBACnetCfg.input[num].notifyType_objectType & 0x0f;
	if(objType == OBJ_TYPE_EVENT_ENROLLEMNT)
		objType -= 3;
	m_cboObjectType.SetCurSel(objType);

	m_cboEventType.SetCurSel(bmsBACnetCfg.input[num].eventType_pointType >> 4);
	m_cboPointType.SetCurSel(bmsBACnetCfg.input[num].eventType_pointType & 0x0f);

	if(bmsBACnetCfg.input[num].deviceNumber > 4194302)
		bmsBACnetCfg.input[num].deviceNumber = 4194302;
	if(bmsBACnetCfg.input[num].notificationClass > 4194302)
		bmsBACnetCfg.input[num].notificationClass = 4194302;
	if(bmsBACnetCfg.input[num].objectInstance > 4194302)
		bmsBACnetCfg.input[num].objectInstance = 4194302;

	m_txtDevAddr.SetValue(bmsBACnetCfg.input[num].deviceNumber);
	m_txtNotifyClass.SetValue(bmsBACnetCfg.input[num].notificationClass);
	m_txtObjInstance.SetValue(bmsBACnetCfg.input[num].objectInstance);
	m_txtPointNum.SetValue((__int64)bmsBACnetCfg.input[num].pointNumber + 1);
}
	
void CRtuBmsBACnetDevCfg::StoreConfig()
{
	int num = m_nDevNum;
	int temp;
	BACnetInputCfg cfg;
	memset(&cfg, 0, sizeof(cfg));

	if(CheckConfig()) {
		temp = (m_cboNotifyType.GetCurSel() << 4);

		int objType = m_cboObjectType.GetCurSel();
		if(objType == OBJ_TYPE_EVENT_ENROLLEMNT - 3)
			objType = OBJ_TYPE_EVENT_ENROLLEMNT;

		temp |= (objType & 0x0f);
		cfg.notifyType_objectType	= (BYTE)temp;
		temp = (m_cboEventType.GetCurSel() << 4);
		temp |= m_cboPointType.GetCurSel();
		cfg.eventType_pointType = (BYTE)temp;
		
		cfg.deviceNumber = (ulong)m_txtDevAddr.GetValue();
		cfg.notificationClass = (ulong)m_txtNotifyClass.GetValue();
		cfg.objectInstance = (ulong)m_txtObjInstance.GetValue();
		cfg.pointNumber = (uchar)(m_txtPointNum.GetValue() - 1);

		if(memcmp(&cfg, &bmsBACnetCfg.input[num], sizeof(cfg)) != 0) {
			memcpy(&bmsBACnetCfg.input[num], &cfg, sizeof(cfg));
			bBmsBACnetChanged = TRUE;
		}
	}
}
	
BOOL CRtuBmsBACnetDevCfg::CheckConfig()
{
	if(!m_txtDevAddr.IsValid())
		return FALSE;
	if(!m_txtNotifyClass.IsValid())
		return FALSE;
	if(!m_txtObjInstance.IsValid())
		return FALSE;
	if(!m_txtPointNum.IsValid())
		return FALSE;

	return TRUE;
}

void CRtuBmsBACnetDevCfg::OnPrevNext(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_UPDOWN* pNMUpDown = (NM_UPDOWN*)pNMHDR;
	// TODO: Add your control notification handler code here
		
	if(CheckConfig()) {
		StoreConfig();

		if(pNMUpDown->iDelta == 1) {
			if(--m_nDevNum < 0)
				m_nDevNum = MAX_BMS_BACNET_DEVCFG - 1;
		}
		else  {
			if(++m_nDevNum >= MAX_BMS_BACNET_DEVCFG)
				m_nDevNum = 0;
		}
		ShowConfig();
	}

	*pResult = 0;
}

void CRtuBmsBACnetDevCfg::OnBtnCopy()
{
	if(!CheckConfig())
		return;

	StoreConfig();
	CRtuBmsBACnetActCopy copyDlg(MAX_BMS_BACNET_DEVCFG, m_nDevNum+1, BACNET_INPUT_COPY);
	copyDlg.DoModal();
	ShowConfig();

}

void CRtuBmsBACnetDevCfg::OnBtnDelete()
{
	memset(&bmsBACnetCfg.input[m_nDevNum], 0, sizeof(BACnetInputCfg));
	bBmsBACnetChanged = TRUE;
	ShowConfig();
}


/*------------------------------------------------------------------------------*/
/*					BMS BACnet Protocol Page Class								*/
/*------------------------------------------------------------------------------*/
IMPLEMENT_DYNCREATE(CRtuBmsBACnetProtocol, CPropertyPage)

void CRtuBmsBACnetProtocol::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CRtuBmsBACnetProtocol)
	DDX_Control(pDX, IDC_BMS_PROTOCOL, m_cboLinkLayer);
	DDX_Control(pDX, IDC_BMS_PORT_NUM, m_cboRtuPortNum);
	DDX_Control(pDX, IDC_BMS_BBMD_ADDR, m_ipBbmdAddr);
	DDX_Control(pDX, IDC_BMS_BNET_ADDR, m_txtBACnetDevInstance);
	DDX_Control(pDX, IDC_BMS_BNET_NW_NUM, m_txtBACnetNwNumber);
	DDX_Control(pDX, IDC_BMS_NUM_RETRY, m_txtNumAPDUretries);
	DDX_Control(pDX, IDC_BMS_APDU_TOUT, m_txtAPDUTimeOut);
	DDX_Control(pDX, IDC_BMS_APDU_SEG_TOUT, m_txtAPDUsegTimeOut);
	DDX_Control(pDX, IDC_BMS_TX_WSIZE, m_txtTxSegWinSize);
	DDX_Control(pDX, IDC_BMS_RX_WSIZE, m_txtRxSegWinSize);
	DDX_Control(pDX, IDC_BMS_ALM_ENR_TIME, m_txtAlmEnrolTime);
	DDX_Control(pDX, IDC_BMS_UDP_PORT_NUM, m_txtBACnetUDPport);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CRtuBmsBACnetProtocol, CPropertyPage)
	//{{AFX_MSG_MAP(CRtuBmsBACnetProtocol)	
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CRtuBmsBACnetProtocol message handlers
/////////////////////////////////////////////////////////////////////////////
BOOL CRtuBmsBACnetProtocol::OnInitDialog()
{
	CDialog::OnInitDialog();

	CStringArray strProt; GetBACnetProtLLStr(strProt);
	m_cboLinkLayer.ResetContent();
	for(int i=0; i<strProt.GetSize(); i++)
		m_cboLinkLayer.AddString(strProt.GetAt(i));

	m_cboRtuPortNum.ResetContent();
	CStringArray strPorts; 
	GetRtuPortList(strPorts, realRtuType, IsRtu8002Type());
	for(int i=0; i<strPorts.GetSize(); i++)
		m_cboRtuPortNum.AddString(strPorts.GetAt(i));

	m_txtBACnetDevInstance.SetMinMaxLimit(0, 4194302, 7);
	m_txtBACnetNwNumber.SetMinMaxLimit(0, 0xffff, 5);
	m_txtNumAPDUretries.SetMinMaxLimit(0, 0xff, 3);
	m_txtAPDUsegTimeOut.SetMinMaxLimit(0, 0xff, 3);
	m_txtAPDUTimeOut.SetMinMaxLimit(0, 0xff, 3);   
	m_txtTxSegWinSize.SetMinMaxLimit(0, 0xff, 3);  
	m_txtRxSegWinSize.SetMinMaxLimit(0, 0xff, 3);  
	m_txtAlmEnrolTime.SetMinMaxLimit(0, 0xff, 3);  
	m_txtBACnetUDPport.SetMinMaxLimit(0, 0xffff, 5); 
	ShowConfig();
	
	CheckEditPriv(GetSafeHwnd(), E_RTU_BMSPARMS);
	return TRUE;
}

BOOL CRtuBmsBACnetProtocol::OnKillActive()
{
	if(!CheckConfig())
		return FALSE;
	StoreConfig();

	return CPropertyPage::OnKillActive();
}

BOOL CRtuBmsBACnetProtocol::OnSetActive()
{
	ShowConfig();
	return CPropertyPage::OnSetActive();
}


void CRtuBmsBACnetProtocol::ShowConfig()
{
	UpdateData(FALSE);
	m_cboLinkLayer.SetCurSel(bmsBACnetCfg.protocolCfg.linkLayerProtocol);
	
	int sel = GetPortIndexFromPortNumber(bmsBACnetCfg.protocolCfg.rtuPortNumber);
	m_cboRtuPortNum.SetCurSel(sel);

	if(bmsBACnetCfg.protocolCfg.myBacnetAddress > 4194302)
		bmsBACnetCfg.protocolCfg.myBacnetAddress = 4194302;
	m_txtBACnetDevInstance.SetValue(bmsBACnetCfg.protocolCfg.myBacnetAddress);
	m_txtBACnetNwNumber.SetValue(bmsBACnetCfg.protocolCfg.networkNumber);
	m_txtNumAPDUretries.SetValue(bmsBACnetCfg.protocolCfg.numberOfApduRetries);
	m_txtAPDUsegTimeOut.SetValue(bmsBACnetCfg.protocolCfg.apduSegmentTimeOut);
	m_txtAPDUTimeOut.SetValue(bmsBACnetCfg.protocolCfg.apduTimeOut);
	m_txtTxSegWinSize.SetValue(bmsBACnetCfg.protocolCfg.txSegmentWindowSize);  
	m_txtRxSegWinSize.SetValue(bmsBACnetCfg.protocolCfg.rxSegmentWindowSize);  
	m_txtAlmEnrolTime.SetValue(bmsBACnetCfg.protocolCfg.alarmEnrollmentTime);  
	m_txtBACnetUDPport.SetValue(bmsBACnetCfg.protocolCfg.udpPortNumber); 
	m_ipBbmdAddr.SetAddress(bmsBACnetCfg.protocolCfg.bbmdIpAddress);
}

int CRtuBmsBACnetProtocol::GetPortIndexFromPortNumber(int portNumber)
{
	int portIndex = portNumber;
	if(realRtuType == RTU_1058_TYPE) {
		if(portIndex >= 8)
			portIndex -= 4;
	}
	else if(realRtuType == RTU_8001_TYPE) {

		portIndex = RTU8001_GetPortIndexFromPortNumber(portNumber);
		//switch(portNumber) { // start from 0
		//	case 0: portIndex = 0; break;
		//	case 2: portIndex = 1; break;
		//	case 3: portIndex = 2; break;
		//	case 8: portIndex = 3; break;
		//	case 9: portIndex = 4; break;
		//	case 10: portIndex = 5; break;
		//	default: portIndex = -1; break;
		//}

	}
	return portIndex;
}
int CRtuBmsBACnetProtocol::GetPortNumberFromPortIndex(int portIndex)
{
	int portNumber = portIndex;
	if(realRtuType == RTU_1058_TYPE) {
		if(portNumber >= 4)
			portNumber += 4;
	}
	else if(realRtuType == RTU_8001_TYPE) {
		portNumber = RTU8001_GetPortNumberFromPortIndex(portIndex);
		if (portNumber > 0)
			--portNumber; 

		//switch(portIndex) { // return portNumber >= 0
		//	case 0: portNumber = 0; break;
		//	case 1: portNumber = 2; break;
		//	case 2: portNumber = 3; break;
		//	case 3: portNumber = 8; break;
		//	case 4: portNumber = 9; break;
		//	case 5: portNumber = 10; break;

		//	default: portIndex = 0; break;
		//}
	}

	return portNumber;
}

void CRtuBmsBACnetProtocol::StoreConfig()
{
	UpdateData();
	BACnetProtocolCfg cfg;
	memset(&cfg, 0, sizeof(cfg));

	cfg.rtuPortNumber = (uchar)GetPortNumberFromPortIndex(m_cboRtuPortNum.GetCurSel());

	cfg.linkLayerProtocol = (uchar)m_cboLinkLayer.GetCurSel();
	cfg.myBacnetAddress = (ulong)m_txtBACnetDevInstance.GetValue();
	cfg.networkNumber = (ushort)m_txtBACnetNwNumber.GetValue();
	cfg.numberOfApduRetries = (uchar)m_txtNumAPDUretries.GetValue();
	cfg.apduTimeOut = (uchar)m_txtAPDUTimeOut.GetValue();
	cfg.apduSegmentTimeOut = (uchar)m_txtAPDUsegTimeOut.GetValue();
	cfg.txSegmentWindowSize = (uchar)m_txtTxSegWinSize.GetValue();
	cfg.rxSegmentWindowSize = (uchar)m_txtRxSegWinSize.GetValue();
	cfg.alarmEnrollmentTime = (uchar)m_txtAlmEnrolTime.GetValue();
	cfg.udpPortNumber = (ushort)m_txtBACnetUDPport.GetValue();

	m_ipBbmdAddr.GetAddress(cfg.bbmdIpAddress);

	if(memcmp(&bmsBACnetCfg.protocolCfg, &cfg, sizeof(cfg)) != 0) {
		memcpy(&bmsBACnetCfg.protocolCfg, &cfg, sizeof(cfg));
		bBmsBACnetChanged = TRUE;
	}

}

BOOL CRtuBmsBACnetProtocol::CheckConfig()
{
	if(!m_txtBACnetDevInstance.IsValid())
		return FALSE;
	if(!m_txtBACnetNwNumber.IsValid())
		return FALSE;
	if(!m_txtNumAPDUretries.IsValid())
		return FALSE;
	if(!m_txtAPDUsegTimeOut.IsValid())
		return FALSE;
	if(!m_txtAPDUTimeOut.IsValid())
		return FALSE;
	if(!m_txtTxSegWinSize.IsValid())
		return FALSE;
	if(!m_txtRxSegWinSize.IsValid())
		return FALSE;
	if(!m_txtAlmEnrolTime.IsValid()) 
		return FALSE;
	if(!m_txtBACnetUDPport.IsValid()) 
		return FALSE;

	return TRUE;
}

int CRtuBmsBACnetProtocol::GetPortNumber()
{
	return m_cboRtuPortNum.GetCurSel();
}

/*------------------------------------------------------------------------------*/
/*					BMS BACnet Action Page Class								*/
/*------------------------------------------------------------------------------*/
IMPLEMENT_DYNCREATE(CRtuBmsBACnetAction, CPropertyPage)

void CRtuBmsBACnetAction::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CRtuBmsBACnetAction)
	DDX_Control(pDX, IDC_BMS_ACT_REQ_TYPE, m_cboServReqType);
	DDX_Control(pDX, IDC_BMS_ACT_OBJ_TYPE, m_cboObjType);
	DDX_Control(pDX, IDC_BMS_ACT_DEV_ADDR, m_txtDeviceNumber);
	DDX_Control(pDX, IDC_BMS_ACT_OBJ_INST, m_txtObjectInstance);
	DDX_Control(pDX, IDC_BMS_ACT_PRES_VAL, m_txtPresentValue);
	DDX_Control(pDX, IDC_BMS_ACT_OP_PNT_NUM, m_txtOutputPntNum);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CRtuBmsBACnetAction, CPropertyPage)
	//{{AFX_MSG_MAP(CRtuBmsBACnetAction)	
	ON_BN_CLICKED(IDC_BMS_ACT_BNUM, OnActionNumber)
	ON_NOTIFY(UDN_DELTAPOS, IDC_BMS_ACT_NEXT, OnPrevNext)
	ON_BN_CLICKED(IDC_BMS_ACT_DELETE, OnBtnDelete)
	ON_BN_CLICKED(IDC_BMS_ACT_COPY, OnBtnCopy)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CRtuBmsBACnetAction message handlers
/////////////////////////////////////////////////////////////////////////////
BOOL CRtuBmsBACnetAction::OnInitDialog()
{
	CDialog::OnInitDialog();

	int i;
	m_cboServReqType.ResetContent();
	m_cboObjType.ResetContent();

	CStringArray strActReqType; GetBACnetActReqTypeStr(strActReqType);
	CStringArray strActObjType; GetBACnetActObjTypeStr(strActObjType);
	for(i=0; i<strActReqType.GetSize(); i++)
		m_cboServReqType.AddString(strActReqType.GetAt(i));

	for(i=0; i<strActObjType.GetSize(); i++)
		m_cboObjType.AddString(strActObjType.GetAt(i));

	m_txtDeviceNumber.SetMinMaxLimit(0, 4194302, 10);
	m_txtObjectInstance.SetMinMaxLimit(0, 4194302, 10);
	m_txtPresentValue.SetMinMaxLimit(0, 0xff, 3);
	m_txtOutputPntNum.SetMinMaxLimit(1, 64, 2);

	SetDlgItemInt(IDC_BMS_ACT_ETOT, MAX_BMS_BACNET_ACTION);
	m_nActNum = 0;
	ShowConfig();
	
	CheckEditPriv(GetSafeHwnd(), E_RTU_BMSPARMS);
	return TRUE;
}

BOOL CRtuBmsBACnetAction::OnKillActive()
{
	if(!CheckConfig())
		return FALSE;
	StoreConfig();
	return CPropertyPage::OnKillActive();
}

BOOL CRtuBmsBACnetAction::OnSetActive()
{
	ShowConfig();
	return CPropertyPage::OnSetActive();
}

void CRtuBmsBACnetAction::ShowConfig()
{
	int num = m_nActNum;
	SetDlgItemInt(IDC_BMS_ACT_ENUM, num + 1);

	m_cboServReqType.SetCurSel(bmsBACnetCfg.action[num].serviceRequest_objectType >> 4);
	m_cboObjType.SetCurSel(bmsBACnetCfg.action[num].serviceRequest_objectType & 0x0f);

	if(bmsBACnetCfg.action[num].deviceNumber > 4194302)
		bmsBACnetCfg.action[num].deviceNumber = 4194302;
	if(bmsBACnetCfg.action[num].objectInstance > 4194302)
		bmsBACnetCfg.action[num].objectInstance = 4194302;

	m_txtDeviceNumber.SetValue(bmsBACnetCfg.action[num].deviceNumber);
	m_txtObjectInstance.SetValue(bmsBACnetCfg.action[num].objectInstance);
	m_txtPresentValue.SetValue(bmsBACnetCfg.action[num].newPresentValue);
	m_txtOutputPntNum.SetValue(bmsBACnetCfg.action[num].pointNumber + 1);
}

void CRtuBmsBACnetAction::StoreConfig()
{
	BACnetActionCfg cfg;
	int temp;
	int num = m_nActNum;

	memset(&cfg, 0, sizeof(cfg));
	temp = m_cboServReqType.GetCurSel() << 4;
	temp |= (m_cboObjType.GetCurSel() & 0x0f);
	cfg.serviceRequest_objectType = (uchar)temp;

	cfg.deviceNumber = (ulong)m_txtDeviceNumber.GetValue();
	cfg.objectInstance = (ulong)m_txtObjectInstance.GetValue();
	cfg.newPresentValue = (uchar)m_txtPresentValue.GetValue();
	cfg.pointNumber = (uchar)(m_txtOutputPntNum.GetValue() - 1);

	if(memcmp(&bmsBACnetCfg.action[num], &cfg, sizeof(cfg)) != 0) {
		memcpy(&bmsBACnetCfg.action[num], &cfg, sizeof(cfg));
		bBmsBACnetChanged = TRUE;
	}

}

BOOL CRtuBmsBACnetAction::CheckConfig()
{
	if(!m_txtDeviceNumber.IsValid())
		return FALSE;
	if(!m_txtObjectInstance.IsValid())
		return FALSE;
	if(!m_txtPresentValue.IsValid())
		return FALSE;
	if(!m_txtOutputPntNum.IsValid())
		return FALSE;
	return TRUE;
}

void CRtuBmsBACnetAction::OnPrevNext(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_UPDOWN* pNMUpDown = (NM_UPDOWN*)pNMHDR;
	// TODO: Add your control notification handler code here
		
	if(CheckConfig()) {
		StoreConfig();

		if(pNMUpDown->iDelta == 1) {
			if(--m_nActNum < 0)
				m_nActNum = MAX_BMS_BACNET_ACTION - 1;
		}
		else  {
			if(++m_nActNum >= MAX_BMS_BACNET_ACTION)
				m_nActNum = 0;
		}
		ShowConfig();
	}

	*pResult = 0;
}

void CRtuBmsBACnetAction::OnActionNumber()
{
	int i = GetDlgItemInt(IDC_BMS_ACT_ENUM);
	if(i < 1 || i > MAX_BMS_BACNET_ACTION) {
		DispMessageBox2(GetSafeHwnd(), IDS_ENTER_RANGE, IDS_ERROR, MB_OK|MB_ICONSTOP, 1, 64);
	}
	else if(CheckConfig()){
		StoreConfig();
		m_nActNum = i - 1;
		ShowConfig();
	}
}

void CRtuBmsBACnetAction::OnBtnCopy()
{
	if(!CheckConfig())
		return;

	StoreConfig();
	CRtuBmsBACnetActCopy copyDlg(MAX_BMS_BACNET_ACTION, m_nActNum+1, BACNET_ACTION_COPY);
	copyDlg.DoModal();
	ShowConfig();

}

void CRtuBmsBACnetAction::OnBtnDelete()
{
	memset(&bmsBACnetCfg.action[m_nActNum], 0, sizeof(BACnetActionCfg));
	bBmsBACnetChanged = TRUE;
	ShowConfig();
}

/*------------------------------------------------------------------------------*/
/*					BACnet Configuration Class									*/
/*------------------------------------------------------------------------------*/
CRtuBmsBACnet::CRtuBmsBACnet(int* dirn, LPPARMPROC lpps, CWnd* pParent) : 
	  CDialog(CRtuBmsBACnet::IDD, pParent)
{
	m_fDirn=dirn;
	//m_lpps=lpps;
	
	memset(data, 0, sizeof(data));
	memset(&m_lpps, 0, sizeof(PARMPROC));
	memcpy(&m_lpps, lpps, sizeof(PARMPROC));
	m_lpps.lpData = &data[0]; // MZ Insure
	memcpy(m_lpps.lpData, lpps->lpData, sizeof(data));
	
}
	  
void CRtuBmsBACnet::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CRtuBmsBACnet)
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CRtuBmsBACnet, CDialog)
	//{{AFX_MSG_MAP(CRtuBmsBACnet)
	ON_BN_CLICKED(IDOK, OnOK)
	ON_BN_CLICKED(IDCANCEL, OnCancel)
	ON_BN_CLICKED(IDC_BMS_REBOOT_PORT, OnReboot)
	ON_MESSAGE(WM_GMS, OnGms)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CRtuBmsBACnet message handlers
/////////////////////////////////////////////////////////////////////////////
BOOL CRtuBmsBACnet::OnInitDialog() 
{
	CDialog::OnInitDialog();

	m_hmWnd = m_lpps.hmDlg;
	m_lpps.hmDlg = GetSafeHwnd();

	m_sheet.AddPage(&m_pageProtocol);
	m_sheet.AddPage(&m_pageDevCfg);
	m_sheet.AddPage(&m_pageAction);
	
	DWORD styles =  WS_CHILD | WS_VISIBLE | WS_TABSTOP | WS_CLIPCHILDREN | DS_CONTROL;
	m_sheet.Create(this, styles, WS_EX_CONTROLPARENT); 
	//TT 8345
	CRect rect, psRect;
	GetWindowRect(&rect);
	ScreenToClient(&rect);
	
	m_sheet.GetWindowRect(&psRect);
	ScreenToClient(&psRect);
	
	m_sheet.SetWindowPos(NULL, rect.left+ abs(rect.Width() - psRect.Width())/2, 
							   rect.top+ GetSystemMetrics(SM_CYCAPTION) + 2*GetSystemMetrics(SM_CYFIXEDFRAME), 
							   0, 0, SWP_NOZORDER | SWP_NOSIZE | SWP_NOACTIVATE);

	AdjustPropertySheetLocation(this,&m_sheet, FALSE);

	CheckEditPriv(GetSafeHwnd(), E_RTU_BMSPARMS);
	CenterWindow();

	m_wndFont.CreatePointFont(85, _T("Tahoma"), NULL);
	CPropertyPage* pPage;
	RtuLib::ChangeDialogFont(this, &m_wndFont);
	RtuLib::ChangeDialogFont(&m_sheet, &m_wndFont);
	for(int i=0; i<m_sheet.GetPageCount(); i++) {
		VERIFY(m_sheet.SetActivePage(i));
		pPage = m_sheet.GetActivePage();
		ASSERT(pPage);
		RtuLib::ChangeDialogFont(pPage, &m_wndFont);
	}
	m_sheet.SetActivePage(0);

	return TRUE;
}

LRESULT CRtuBmsBACnet::OnGms(WPARAM wParam, LPARAM lParam)
{
	PARMPROC lpps;
	BYTE bmsData[RTU_BUFF_SIZE];
	memset(bmsData, 0, sizeof(bmsData));
	memcpy(&lpps, &m_lpps, sizeof(PARMPROC));
	lpps.lpData = &bmsData[0];

	UINT id = GET_WM_COMMAND_ID(wParam, lParam);
	switch(id) {
		case IDD_BMS_GET_PORT_PARAMS:
			lpps.BC = 2;
			lpps.lpData[0] = (BYTE)(m_pageProtocol.GetPortNumber() + 3);
			lpps.lpData[1] = 0;
			get_rtuport_parms(&lpps, 0, 0);

			break;

		case IDD_COMMOVR_DATA:
			if(lParam && HIWORD(lParam)) {
				memcpy(lpps.lpData, (LPSTR)lParam, sizeof(bmsData));
				lpps.BC = 5;
				lpps.lpData[1] = 0;
				send_rtuport_parms(&lpps);		// Reboot
			}

			break;

		default:
			break;
	}
	
	return 1;
}


void CRtuBmsBACnet::OnOK()
{

	int curPage = m_sheet.GetTabControl()->GetCurSel();
	switch(curPage) {
		case 0:
			if(m_pageProtocol.CheckConfig())
				m_pageProtocol.StoreConfig(); 
			break;
		case 1:
			if(m_pageDevCfg.CheckConfig())
				m_pageDevCfg.StoreConfig(); 
			break;
		case 2:
			if(m_pageAction.CheckConfig())
				m_pageAction.StoreConfig(); 
			break;
	}

	if(bBmsBACnetChanged) {
		*m_fDirn = BMS_DOWNLOAD;
		m_lpps.hmDlg = m_hmWnd;
		send_BMS_parms(&m_lpps, BMS_BACNET_CFG, nBlkSize);
	}
	
	CDialog::OnOK();
}

void CRtuBmsBACnet::OnCancel()
{
	CDialog::OnCancel();
}

void CRtuBmsBACnet::OnReboot()
{
	PostMessage(WM_GMS, IDD_BMS_GET_PORT_PARAMS, 0);
}

/*------------------------------------------------------------------------------*/
/*					BACnet Action Copy Class									*/
/*------------------------------------------------------------------------------*/
void CRtuBmsBACnetActCopy::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CRtuBmsBACnetActCopy)
	DDX_Control(pDX, IDC_RTU_ID1, m_txtFrom);
	DDX_Control(pDX, IDC_RTU_ID2, m_txtStart);
	DDX_Control(pDX, IDC_RTU_ID3, m_txtEnd);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CRtuBmsBACnetActCopy, CDialog)
	//{{AFX_MSG_MAP(CRtuBmsBACnetActCopy)
	ON_BN_CLICKED(IDCANCEL, OnCancel)
	ON_BN_CLICKED(IDOK, OnOK)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CRtuBmsBACnetActCopy message handlers
/////////////////////////////////////////////////////////////////////////////
BOOL CRtuBmsBACnetActCopy::OnInitDialog() 
{
	CDialog::OnInitDialog();
	m_txtFrom.SetMinMaxLimit(1, m_nMax, 3);
	m_txtStart.SetMinMaxLimit(1, m_nMax, 3);
	m_txtEnd.SetMinMaxLimit(1, m_nMax, 3);
	ShowParams();
	
	CheckEditPriv(GetSafeHwnd(), E_RTU_BMSPARMS);
	return TRUE;
}


BOOL CRtuBmsBACnetActCopy::CheckParams()
{
	if(!m_txtFrom.IsValid())
		return FALSE;
	if(!m_txtStart.IsValid())
		return FALSE;
	if(!m_txtEnd.IsValid())
		return FALSE;
	return TRUE;
}


void CRtuBmsBACnetActCopy::StoreParams()
{
	int from, startRng, endRng;
	int j;
	from = (int)m_txtFrom.GetValue();
	startRng = (int)m_txtStart.GetValue();
	endRng = (int)m_txtEnd.GetValue();

	if(endRng == 0)
		endRng = startRng;
	if(startRng == 0)
		startRng = endRng;

	if((from == 0) && (startRng == 0) && (endRng == 0))
		return;

	if ((from >= startRng) && (from <= endRng)) {
		DispMessageBox(GetSafeHwnd(), IDS_CPY_INSIDE_RNG, IDS_ERROR, MB_OK | MB_ICONSTOP);
		return;
	}

	if (startRng > endRng) {
		DispMessageBox(GetSafeHwnd(), IDS_INV_RNG, IDS_ERROR, MB_OK | MB_ICONSTOP);
		return;
	}

	int rCod = DispMessageBox3(GetSafeHwnd(), IDS_CPY_NUM_RNG, IDS_CPY_CFG, MB_YESNO | MB_ICONQUESTION, from, startRng, endRng);
	if (rCod == IDYES) {
		switch(m_nCfg) {
			case BACNET_ACTION_COPY:
				for (j = startRng; j <= endRng; j++) {
					memcpy(&bmsBACnetCfg.action[j-1], &bmsBACnetCfg.action[from-1], sizeof(BACnetActionCfg));
					bBmsBACnetChanged = TRUE;
				}
				break;

			case BACNET_INPUT_COPY:
				for (j = startRng; j <= endRng; j++) {
					memcpy(&bmsBACnetCfg.input[j-1], &bmsBACnetCfg.input[from-1], sizeof(BACnetInputCfg));
					bBmsBACnetChanged = TRUE;
				}
				break;

			case MODBUS_DINP_COPY:
				for (j = startRng; j <= endRng; j++) {
					memcpy(&bmsModbusPntCfg.digitalInput[j-1], &bmsModbusPntCfg.digitalInput[from-1], sizeof(ModbusIoCfg));
					bBmsModbusChanged = TRUE;
				}
				break;

			case MODBUS_DOUT_COPY:
				for (j = startRng; j <= endRng; j++) {
					memcpy(&bmsModbusPntCfg.digitalOutput[j-1], &bmsModbusPntCfg.digitalOutput[from-1], sizeof(ModbusIoCfg));
					bBmsModbusChanged = TRUE;
				}
				break;

			case MODBUS_AINP_COPY:
				for (j = startRng; j <= endRng; j++) {
					memcpy(&bmsModbusPntCfg.analogInput[j-1], &bmsModbusPntCfg.analogInput[from-1], sizeof(ModbusIoCfg));
					bBmsModbusChanged = TRUE;
				}
				break;

			default:
				break;
		}
	}
}

void CRtuBmsBACnetActCopy::ShowParams()
{
	m_txtFrom.SetValue(num);
	if(num >= m_nMax)
		num = 0;

	m_txtStart.SetValue(num + 1);
	m_txtEnd.SetValue(1);
}

void CRtuBmsBACnetActCopy::OnOK()
{
	if (CheckParams()) {
		StoreParams();
		EndDialog(TRUE);
	}	
}

void CRtuBmsBACnetActCopy::OnCancel()
{
	EndDialog(FALSE);
}


/*------------------------------------------------------------------------------*/
/*					Modbus Configuration Class									*/
/*------------------------------------------------------------------------------*/
CRtuBmsModbus::CRtuBmsModbus(int* dirn, LPPARMPROC lpps, CWnd* pParent) : 
	  CDialog(CRtuBmsModbus::IDD, pParent)
{
	m_fDirn=dirn;
	memset(data, 0, sizeof(data));
	memset(&m_lpps, 0, sizeof(PARMPROC));
	memcpy(&m_lpps, lpps, sizeof(PARMPROC));
	m_lpps.lpData = &data[0];
	memcpy(m_lpps.lpData, lpps->lpData, sizeof(data));
}
	  
void CRtuBmsModbus::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CRtuBmsModbus)
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CRtuBmsModbus, CDialog)
	//{{AFX_MSG_MAP(CRtuBmsModbus)
	ON_BN_CLICKED(IDOK, OnOK)
	ON_BN_CLICKED(IDCANCEL, OnCancel)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CRtuBmsModbus message handlers
/////////////////////////////////////////////////////////////////////////////
BOOL CRtuBmsModbus::OnInitDialog() 
{
	CDialog::OnInitDialog();

	m_hmWnd = m_lpps.hmDlg;
	m_lpps.hmDlg = GetSafeHwnd();

	m_sheet.AddPage(&m_pageDigInp);
	m_sheet.AddPage(&m_pageDigOut);
	m_sheet.AddPage(&m_pageAnalInp);
	
	DWORD styles =  WS_CHILD | WS_VISIBLE | WS_TABSTOP | WS_CLIPCHILDREN | DS_CONTROL;
	m_sheet.Create(this, styles, WS_EX_CONTROLPARENT); 
	//TT 8345
	CRect rect, psRect;
	GetWindowRect(&rect);
	ScreenToClient(&rect);
	
	m_sheet.GetWindowRect(&psRect);
	ScreenToClient(&psRect);
	
	m_sheet.SetWindowPos(NULL, rect.left+ abs(rect.Width() - psRect.Width())/2, 
							   rect.top+ GetSystemMetrics(SM_CYCAPTION) + 2*GetSystemMetrics(SM_CYFIXEDFRAME), 
							   0, 0, SWP_NOZORDER | SWP_NOSIZE | SWP_NOACTIVATE);

	AdjustPropertySheetLocation(this,&m_sheet, FALSE);

	CheckEditPriv(GetSafeHwnd(), E_RTU_BMSPARMS);
	CenterWindow();

	m_wndFont.CreatePointFont(85, _T("Tahoma"), NULL);
	CPropertyPage* pPage;
	RtuLib::ChangeDialogFont(this, &m_wndFont);
	RtuLib::ChangeDialogFont(&m_sheet, &m_wndFont);
	for(int i=0; i<m_sheet.GetPageCount(); i++) {
		VERIFY(m_sheet.SetActivePage(i));
		pPage = m_sheet.GetActivePage();
		ASSERT(pPage);
		RtuLib::ChangeDialogFont(pPage, &m_wndFont);
	}
	m_sheet.SetActivePage(0);

	return TRUE;
}

void CRtuBmsModbus::OnOK()
{
	int curPage = m_sheet.GetTabControl()->GetCurSel();
	switch(curPage) {
		case 0:
			if(m_pageDigInp.CheckConfig())
				m_pageDigInp.StoreConfig(); 
			break;
		case 1:
			if(m_pageDigOut.CheckConfig())
				m_pageDigOut.StoreConfig(); 
			break;
		case 2:
			if(m_pageAnalInp.CheckConfig())
				m_pageAnalInp.StoreConfig(); 
			break;
	}

	//bBmsModbusChanged = TRUE;
	if(bBmsModbusChanged) {
		*m_fDirn = BMS_DOWNLOAD;

		memcpy(&bmsModbusPntCfg.digitalInput[0], &m_pageDigInp.m_inpCfg[0], sizeof(bmsModbusPntCfg.digitalInput));
		memcpy(&bmsModbusPntCfg.digitalOutput[0], &m_pageDigOut.m_outCfg[0], sizeof(bmsModbusPntCfg.digitalOutput));
		memcpy(&bmsModbusPntCfg.analogInput[0], &m_pageAnalInp.m_inpCfg[0], sizeof(bmsModbusPntCfg.analogInput));

		m_lpps.hmDlg = m_hmWnd;
		send_BMS_parms(&m_lpps, BMS_MODBUS_CFG, nBlkSize);
	}
	
	CDialog::OnOK();
}

void CRtuBmsModbus::OnCancel()
{
	CDialog::OnCancel();
}

/*------------------------------------------------------------------------------*/
/*					BMS Modbus Digital Input Page Class							*/
/*------------------------------------------------------------------------------*/
IMPLEMENT_DYNCREATE(CRtuBmsModbusDigitalInput, CPropertyPage)

void CRtuBmsModbusDigitalInput::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CRtuBmsModbusDigitalInput)
	DDX_Control(pDX, IDC_TXT_MODBUS_DEV_ADDR, m_txtDevAddr);
	DDX_Control(pDX, IDC_CBO_MODBUS_PORT, m_cboModbusPort);
	DDX_Control(pDX, IDC_CBO_MODBUS_DEV_TYPE, m_cboDevType);
	DDX_Control(pDX, IDC_CBO_MODBUS_INP_TYPE, m_cboInpType);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CRtuBmsModbusDigitalInput, CPropertyPage)
	//{{AFX_MSG_MAP(CRtuBmsModbusDigitalInput)	
	ON_BN_CLICKED(IDC_BMS_ACT_BNUM, OnInputNumber)
	ON_NOTIFY(UDN_DELTAPOS, IDC_BMS_ACT_NEXT, OnPrevNext)
	ON_CBN_SELCHANGE(IDC_CBO_MODBUS_PORT, OnSelChangePort)
	ON_CBN_SELCHANGE(IDC_CBO_MODBUS_DEV_TYPE, OnSelChangeDeviceType)
	ON_CBN_SELCHANGE(IDC_CBO_MODBUS_INP_TYPE, OnSelChangeInputType)
	ON_BN_CLICKED(IDC_BMS_DELETE, OnBtnDelete)
	ON_BN_CLICKED(IDC_BMS_COPY, OnBtnCopy)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CRtuBmsModbusDigitalInput message handlers
/////////////////////////////////////////////////////////////////////////////
BOOL CRtuBmsModbusDigitalInput::OnInitDialog()
{
	CDialog::OnInitDialog();

	memcpy(&m_inpCfg[0], &bmsModbusPntCfg.digitalInput[0] , sizeof(bmsModbusPntCfg.digitalInput));
	m_txtDevAddr.SetMinMaxLimit(1, 247, 3);
	m_nInpNum = 0;
	
	TCHAR strPort[MAX_BUFF];
	m_cboModbusPort.ResetContent();
	m_cboModbusPort.AddString(RES_STRING(IDS_NOT_DEFINED));
	m_cboModbusPort.SetCurItem(0, TRUE);
	
	for(int i=0; i<maxModbusPort; i++) {
		GetModbusPortTxt(strPort, i);
		m_cboModbusPort.AddString(strPort);
		m_cboModbusPort.SetCurItem(i+1, (nPortModbus[i] == 1) ? TRUE : FALSE);
	}

	m_cboDevType.ResetContent();
	InitComboBox(GetSafeHwnd(), IDC_CBO_MODBUS_DEV_TYPE, CB_ADDSTRING, MODBUS_DEVTYPE_FILE);
	m_cboDevType.SetCurSel(m_inpCfg[m_nInpNum].deviceType);

	m_cboInpType.ResetContent();
	InitComboBox(GetSafeHwnd(), IDC_CBO_MODBUS_INP_TYPE, CB_ADDSTRING, MODBUS_INPTYPE_FILE);
	EnableInputBox();

	ShowConfig();
	
	CheckEditPriv(GetSafeHwnd(), E_RTU_BMSPARMS);
	return TRUE;
}

BOOL CRtuBmsModbusDigitalInput::OnKillActive()
{
	if(!CheckConfig())
		return FALSE;
	StoreConfig();
	return CPropertyPage::OnKillActive();
}

BOOL CRtuBmsModbusDigitalInput::OnSetActive()
{
	ShowConfig();
	return CPropertyPage::OnSetActive();
}

void CRtuBmsModbusDigitalInput::ShowConfig()
{
	int index = ModbusPortSel(m_inpCfg[m_nInpNum].portNumber) + 1;
	if(!m_cboModbusPort.IsItemEnabled(index))
		index = 0;
	
	SetDlgItemInt(IDC_BMS_ACT_ENUM, m_nInpNum+1);
	SetDlgItemInt(IDC_BMS_ACT_ETOT, bModbusCfgLarge ? MODBUS_MAX_DIGITAL_INPUTS_LARGE : MODBUS_MAX_DIGITAL_INPUTS);

	m_cboModbusPort.SetCurSel(index);
	m_cboDevType.SetCurSel(m_inpCfg[m_nInpNum].deviceType);
	m_cboInpType.SetCurSel(m_inpCfg[m_nInpNum].dataType);

	m_txtDevAddr.SetValue(m_inpCfg[m_nInpNum].deviceAddress + 1);
	OnSelChangeDeviceType();
}

void CRtuBmsModbusDigitalInput::StoreConfig()
{
	//int portNums[] = {0, 3, 4, 6, 9, 10, 11, 12};
	int index = m_cboModbusPort.GetCurSel();
	if(index > 0)
		index = GetPortNumber(index-1);

	//m_inpCfg[m_nInpNum].portNumber = (BYTE)portNums[index];
	m_inpCfg[m_nInpNum].portNumber = (BYTE)index;
	m_inpCfg[m_nInpNum].deviceType = (BYTE)m_cboDevType.GetCurSel();
	m_inpCfg[m_nInpNum].dataType = (BYTE)m_cboInpType.GetCurSel();
	m_inpCfg[m_nInpNum].deviceAddress = (BYTE)(m_txtDevAddr.GetValue() - 1);

	if(memcmp(&m_inpCfg[m_nInpNum], &bmsModbusPntCfg.digitalInput[m_nInpNum], sizeof(ModbusIoCfg)) != 0)
		bBmsModbusChanged = TRUE;
}

BOOL CRtuBmsModbusDigitalInput::CheckConfig()
{
	if(!m_txtDevAddr.IsValid())
		return FALSE;

	return TRUE;
}

void CRtuBmsModbusDigitalInput::OnPrevNext(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_UPDOWN* pNMUpDown = (NM_UPDOWN*)pNMHDR;
		
	if(CheckConfig()) {
		StoreConfig();

		int nMaxInputs = bModbusCfgLarge ? MODBUS_MAX_DIGITAL_INPUTS_LARGE : MODBUS_MAX_DIGITAL_INPUTS;
		if(pNMUpDown->iDelta == 1) {
			if(--m_nInpNum < 0)
				m_nInpNum = nMaxInputs - 1;
		}
		else  {
			if(++m_nInpNum >= nMaxInputs)
				m_nInpNum = 0;
		}
		ShowConfig();
	}

	*pResult = 0;
}

void CRtuBmsModbusDigitalInput::OnInputNumber()
{
	int nMaxInputs = bModbusCfgLarge ? MODBUS_MAX_DIGITAL_INPUTS_LARGE : MODBUS_MAX_DIGITAL_INPUTS;

	int i = GetDlgItemInt(IDC_BMS_ACT_ENUM);
	if(i < 1 || i > nMaxInputs) {
		DispMessageBox2(GetSafeHwnd(), IDS_ENTER_RANGE, IDS_ERROR, MB_OK|MB_ICONSTOP, 1, 32);
	}
	else if(CheckConfig()){
		StoreConfig();
		m_nInpNum = i - 1;
		ShowConfig();
	}
}

void CRtuBmsModbusDigitalInput::OnSelChangePort()
{
	int index = m_cboModbusPort.GetCurSel();
	if(!m_cboModbusPort.IsItemEnabled(index))
		m_cboModbusPort.SetCurSel(0);
}

void CRtuBmsModbusDigitalInput::OnBtnCopy()
{
	if(!CheckConfig())
		return;

	StoreConfig();

	memcpy(&bmsModbusPntCfg.digitalInput[0], &m_inpCfg[0], sizeof(bmsModbusPntCfg.digitalInput));
	CRtuBmsBACnetActCopy copyDlg(bModbusCfgLarge ? MODBUS_MAX_DIGITAL_INPUTS_LARGE : MODBUS_MAX_DIGITAL_INPUTS, m_nInpNum+1, MODBUS_DINP_COPY);
	copyDlg.DoModal();
	memcpy(&m_inpCfg[0], &bmsModbusPntCfg.digitalInput[0], sizeof(bmsModbusPntCfg.digitalInput));

	ShowConfig();

}

void CRtuBmsModbusDigitalInput::OnBtnDelete()
{
	memset(&m_inpCfg[m_nInpNum], 0, sizeof(ModbusIoCfg));
	bBmsModbusChanged = TRUE;
	ShowConfig();
}

void CRtuBmsModbusDigitalInput::OnSelChangeDeviceType()
{ 
	m_cboInpType.ResetContent();
	InitComboBox(GetSafeHwnd(), IDC_CBO_MODBUS_INP_TYPE, CB_ADDSTRING, MODBUS_INPTYPE_FILE);
	EnableInputBox();
		
	if(m_bInputEn[m_inpCfg[m_nInpNum].dataType]  == FALSE)	{
		int sel=0;
		for(int i=0; i<m_cboInpType.GetCount(); i++) {
			if(m_bInputEn[i] == TRUE) {
				sel = i;
				break;
			}
		}
		m_cboInpType.SetCurSel(sel);

	}
	else
		m_cboInpType.SetCurSel(m_inpCfg[m_nInpNum].dataType);


}

void CRtuBmsModbusDigitalInput::OnSelChangeInputType()
{
	int index = m_cboInpType.GetCurSel();
	if(m_bInputEn[index] == FALSE)
		index = 0;
	m_cboInpType.SetCurSel(index);
}

void CRtuBmsModbusDigitalInput::EnableInputBox()
{
	CString str;
	CString str2;
	int cnt = m_cboInpType.GetCount();
	int devTypeNum = m_cboDevType.GetCurSel() + 1;

	memset(&m_bInputEn, 0, sizeof(m_bInputEn));
	int index;
	int strLen;

	for(int i=0; i<cnt; i++) {
		m_cboInpType.GetLBText(i, str);

		index = str.Find('#', 0);
		if(index == -1)	{
			m_bInputEn[i] = TRUE;
		}
		else {
			str2 = str.Mid(index + 1);
			strLen = str2.GetLength();
			int num=0;
			for(int n=0; n<strLen; n++) {
				TCHAR c = str2[n];
				int y = TcharToDec(c);

				if(y < 0) {
					if(num == devTypeNum) {
						m_bInputEn[i] = TRUE;
						break;
					}
					num = 0;
					continue;
				}

				num = num * 10 + y;
			}

			if(num == devTypeNum) {
				m_bInputEn[i] = TRUE;
			}


			str.SetAt(index, '\0');
			if(m_cboInpType.DeleteString(i)) {
				m_cboInpType.InsertString(i, str);
			}

		}

		m_cboInpType.SetCurItem(i, m_bInputEn[i]);
	}
}

/*------------------------------------------------------------------------------*/
/*					BMS Modbus Digital Output Page Class						*/
/*------------------------------------------------------------------------------*/
IMPLEMENT_DYNCREATE(CRtuBmsModbusDigitalOutput, CPropertyPage)

void CRtuBmsModbusDigitalOutput::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CRtuBmsModbusDigitalOutput)
	DDX_Control(pDX, IDC_TXT_MODBUS_DEV_ADDR, m_txtDevAddr);
	DDX_Control(pDX, IDC_CBO_MODBUS_PORT, m_cboModbusPort);
	DDX_Control(pDX, IDC_CBO_MODBUS_DEV_TYPE, m_cboDevType);
	DDX_Control(pDX, IDC_CBO_MODBUS_OUT_TYPE, m_cboOutType);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CRtuBmsModbusDigitalOutput, CPropertyPage)
	//{{AFX_MSG_MAP(CRtuBmsModbusDigitalOutput)	
	ON_BN_CLICKED(IDC_BMS_ACT_BNUM, OnOutputNumber)
	ON_NOTIFY(UDN_DELTAPOS, IDC_BMS_ACT_NEXT, OnPrevNext)
	ON_CBN_SELCHANGE(IDC_CBO_MODBUS_PORT, OnSelChangePort)
	ON_CBN_SELCHANGE(IDC_CBO_MODBUS_DEV_TYPE, OnSelChangeDeviceType)
	ON_CBN_SELCHANGE(IDC_CBO_MODBUS_OUT_TYPE, OnSelChangeOutputType)
	ON_BN_CLICKED(IDC_BMS_DELETE, OnBtnDelete)
	ON_BN_CLICKED(IDC_BMS_COPY, OnBtnCopy)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CRtuBmsModbusDigitalOutput message handlers
/////////////////////////////////////////////////////////////////////////////
BOOL CRtuBmsModbusDigitalOutput::OnInitDialog()
{
	CDialog::OnInitDialog();

	memcpy(&m_outCfg[0], &bmsModbusPntCfg.digitalOutput[0] , sizeof(bmsModbusPntCfg.digitalOutput));
	m_txtDevAddr.SetMinMaxLimit(1, 247, 3);
	m_nOutNum = 0;
	
	TCHAR strPort[MAX_BUFF];
	m_cboModbusPort.ResetContent();
	m_cboModbusPort.AddString(RES_STRING(IDS_NOT_DEFINED));
	m_cboModbusPort.SetCurItem(0, TRUE);
	
	for(int i=0; i<maxModbusPort; i++)	{
		GetModbusPortTxt(strPort, i);
		m_cboModbusPort.AddString(strPort);
		m_cboModbusPort.SetCurItem(i+1, (nPortModbus[i] == 1) ? TRUE : FALSE);
	}

	m_cboDevType.ResetContent();
	InitComboBox(GetSafeHwnd(), IDC_CBO_MODBUS_DEV_TYPE, CB_ADDSTRING, MODBUS_DEVTYPE_FILE);
	m_cboDevType.SetCurSel(m_outCfg[m_nOutNum].deviceType);

	m_cboOutType.ResetContent();
	InitComboBox(GetSafeHwnd(), IDC_CBO_MODBUS_OUT_TYPE, CB_ADDSTRING, MODBUS_OUTTYPE_FILE);
	EnableOutputBox();

	ShowConfig();
	
	CheckEditPriv(GetSafeHwnd(), E_RTU_BMSPARMS);
	return TRUE;
}

BOOL CRtuBmsModbusDigitalOutput::OnKillActive()
{
	if(!CheckConfig())
		return FALSE;
	StoreConfig();
	return CPropertyPage::OnKillActive();
}

BOOL CRtuBmsModbusDigitalOutput::OnSetActive()
{
	ShowConfig();
	return CPropertyPage::OnSetActive();
}

void CRtuBmsModbusDigitalOutput::ShowConfig()
{
	int index = ModbusPortSel(m_outCfg[m_nOutNum].portNumber) + 1;
	if(!m_cboModbusPort.IsItemEnabled(index))
		index = 0;

	SetDlgItemInt(IDC_BMS_ACT_ENUM, m_nOutNum+1);
	SetDlgItemInt(IDC_BMS_ACT_ETOT, bModbusCfgLarge ? MODBUS_MAX_DIGITAL_OUTPUTS_LARGE : MODBUS_MAX_DIGITAL_OUTPUTS);

	m_cboModbusPort.SetCurSel(index);
	m_cboDevType.SetCurSel(m_outCfg[m_nOutNum].deviceType);
	m_txtDevAddr.SetValue(m_outCfg[m_nOutNum].deviceAddress + 1);
	
	if(m_bOutputEn[m_outCfg[m_nOutNum].dataType]  == FALSE)	{
		int sel=0;
		for(int i=0; i<m_cboOutType.GetCount(); i++) {
			if(m_bOutputEn[i] == TRUE) {
				sel = i;
				break;
			}
		}
		m_cboOutType.SetCurSel(sel);

	}
	else
		m_cboOutType.SetCurSel(m_outCfg[m_nOutNum].dataType);

	OnSelChangeDeviceType();

}

void CRtuBmsModbusDigitalOutput::StoreConfig()
{
	//int portNums[] = {0, 3, 4, 6, 9, 10, 11, 12};
	int index = m_cboModbusPort.GetCurSel();
	if(index > 0)
		index = GetPortNumber(index - 1);

	m_outCfg[m_nOutNum].portNumber = (BYTE)index;
	m_outCfg[m_nOutNum].deviceType = (BYTE)m_cboDevType.GetCurSel();
	m_outCfg[m_nOutNum].dataType = (BYTE)m_cboOutType.GetCurSel();
	m_outCfg[m_nOutNum].deviceAddress = (BYTE)(m_txtDevAddr.GetValue() - 1);

	if(memcmp(&m_outCfg[m_nOutNum], &bmsModbusPntCfg.digitalOutput[m_nOutNum], sizeof(ModbusIoCfg)) != 0)
		bBmsModbusChanged = TRUE;
}

BOOL CRtuBmsModbusDigitalOutput::CheckConfig()
{
	if(!m_txtDevAddr.IsValid())
		return FALSE;

	return TRUE;
}

void CRtuBmsModbusDigitalOutput::OnPrevNext(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_UPDOWN* pNMUpDown = (NM_UPDOWN*)pNMHDR;
		
	if(CheckConfig()) {
		StoreConfig();

		int nMaxOutputs = bModbusCfgLarge ? MODBUS_MAX_DIGITAL_OUTPUTS_LARGE : MODBUS_MAX_DIGITAL_OUTPUTS;
		if(pNMUpDown->iDelta == 1) {
			if(--m_nOutNum < 0)
				m_nOutNum = nMaxOutputs - 1;
		}
		else  {
			if(++m_nOutNum >= nMaxOutputs)
				m_nOutNum = 0;
		}
		ShowConfig();
	}

	*pResult = 0;
}

void CRtuBmsModbusDigitalOutput::OnOutputNumber()
{
	int i = GetDlgItemInt(IDC_BMS_ACT_ENUM);
	int nMaxOutputs = bModbusCfgLarge ? MODBUS_MAX_DIGITAL_OUTPUTS_LARGE : MODBUS_MAX_DIGITAL_OUTPUTS;
	if(i < 1 || i > nMaxOutputs) {
		DispMessageBox2(GetSafeHwnd(), IDS_ENTER_RANGE, IDS_ERROR, MB_OK|MB_ICONSTOP, 1, 16);
	}
	else if(CheckConfig()){
		StoreConfig();
		m_nOutNum = i - 1;
		ShowConfig();
	}
}

void CRtuBmsModbusDigitalOutput::OnSelChangePort()
{
	int index = m_cboModbusPort.GetCurSel();
	if(!m_cboModbusPort.IsItemEnabled(index))
		m_cboModbusPort.SetCurSel(0);
}

void CRtuBmsModbusDigitalOutput::OnBtnCopy()
{
	if(!CheckConfig())
		return;

	StoreConfig();

	memcpy(&bmsModbusPntCfg.digitalOutput[0], &m_outCfg[0], sizeof(m_outCfg));
	CRtuBmsBACnetActCopy copyDlg(bModbusCfgLarge ? MODBUS_MAX_DIGITAL_OUTPUTS_LARGE : MODBUS_MAX_DIGITAL_OUTPUTS, m_nOutNum+1, MODBUS_DOUT_COPY);
	copyDlg.DoModal();
	memcpy(&m_outCfg[0], &bmsModbusPntCfg.digitalOutput[0], sizeof(m_outCfg));

	ShowConfig();

}

void CRtuBmsModbusDigitalOutput::OnBtnDelete()
{
	memset(&m_outCfg[m_nOutNum], 0, sizeof(ModbusIoCfg));
	bBmsModbusChanged = TRUE;
	ShowConfig();
}

void CRtuBmsModbusDigitalOutput::OnSelChangeDeviceType()
{ 
	m_cboOutType.ResetContent();
	InitComboBox(GetSafeHwnd(), IDC_CBO_MODBUS_OUT_TYPE, CB_ADDSTRING, MODBUS_OUTTYPE_FILE);
	EnableOutputBox();
		
	if(m_bOutputEn[m_outCfg[m_nOutNum].dataType]  == FALSE)	{
		int sel=0;
		for(int i=0; i<m_cboOutType.GetCount(); i++) {
			if(m_bOutputEn[i] == TRUE) {
				sel = i;
				break;
			}
		}
		m_cboOutType.SetCurSel(sel);

	}
	else
		m_cboOutType.SetCurSel(m_outCfg[m_nOutNum].dataType);


}

void CRtuBmsModbusDigitalOutput::OnSelChangeOutputType()
{
	int index = m_cboOutType.GetCurSel();
	if(m_bOutputEn[index] == FALSE)
		index = 0;
	m_cboOutType.SetCurSel(index);
}

void CRtuBmsModbusDigitalOutput::EnableOutputBox()
{
	CString str;
	CString str2;
	int cnt = m_cboOutType.GetCount();
	int devTypeNum = m_cboDevType.GetCurSel() + 1;

	memset(&m_bOutputEn, 0, sizeof(m_bOutputEn));
	int index;
	int strLen;

	for(int i=0; i<cnt; i++) {
		m_cboOutType.GetLBText(i, str);

		index = str.Find('#', 0);
		if(index == -1)	{
			m_bOutputEn[i] = TRUE;
		}
		else {
			str2 = str.Mid(index + 1);
			strLen = str2.GetLength();
			int num=0;
			for(int n=0; n<strLen; n++) {
				TCHAR c = str2[n];
				int y = TcharToDec(c);

				if(y < 0) {
					if(num == devTypeNum) {
						m_bOutputEn[i] = TRUE;
						break;
					}
					num = 0;
					continue;
				}

				num = num * 10 + y;
			}

			if(num == devTypeNum) {
				m_bOutputEn[i] = TRUE;
			}


			str.SetAt(index, '\0');
			if(m_cboOutType.DeleteString(i)) {
				m_cboOutType.InsertString(i, str);
			}

		}

		m_cboOutType.SetCurItem(i, m_bOutputEn[i]);
	}
}
/*------------------------------------------------------------------------------*/
/*					BMS Modbus Analog Input Page Class							*/
/*------------------------------------------------------------------------------*/
IMPLEMENT_DYNCREATE(CRtuBmsModbusAnalogInput, CPropertyPage)

void CRtuBmsModbusAnalogInput::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CRtuBmsModbusAnalogInput)
	DDX_Control(pDX, IDC_TXT_MODBUS_DEV_ADDR, m_txtDevAddr);
	DDX_Control(pDX, IDC_CBO_MODBUS_PORT, m_cboModbusPort);
	DDX_Control(pDX, IDC_CBO_MODBUS_DEV_TYPE, m_cboDevType);
	DDX_Control(pDX, IDC_CBO_MODBUS_INP_TYPE, m_cboInpType);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CRtuBmsModbusAnalogInput, CPropertyPage)
	//{{AFX_MSG_MAP(CRtuBmsModbusAnalogInput)	
	ON_BN_CLICKED(IDC_BMS_ACT_BNUM, OnInputNumber)
	ON_NOTIFY(UDN_DELTAPOS, IDC_BMS_ACT_NEXT, OnPrevNext)
	ON_CBN_SELCHANGE(IDC_CBO_MODBUS_PORT, OnSelChangePort)
	ON_CBN_SELCHANGE(IDC_CBO_MODBUS_DEV_TYPE, OnSelChangeDeviceType)
	ON_CBN_SELCHANGE(IDC_CBO_MODBUS_INP_TYPE, OnSelChangeInputType)
	ON_BN_CLICKED(IDC_BMS_DELETE, OnBtnDelete)
	ON_BN_CLICKED(IDC_BMS_COPY, OnBtnCopy)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CRtuBmsModbusAnalogInput message handlers
/////////////////////////////////////////////////////////////////////////////
BOOL CRtuBmsModbusAnalogInput::OnInitDialog()
{
	CDialog::OnInitDialog();

	memcpy(&m_inpCfg[0], &bmsModbusPntCfg.analogInput[0] , sizeof(bmsModbusPntCfg.analogInput));
	m_txtDevAddr.SetMinMaxLimit(1, 247, 3);
	m_nInpNum = 0;
	
	TCHAR strPort[MAX_BUFF];
	m_cboModbusPort.ResetContent();
	m_cboModbusPort.AddString(RES_STRING(IDS_NOT_DEFINED));
	m_cboModbusPort.SetCurItem(0, TRUE);
	for(int i=0; i<maxModbusPort; i++) {
		GetModbusPortTxt(strPort, i);
		m_cboModbusPort.AddString(strPort);
		m_cboModbusPort.SetCurItem(i+1, (nPortModbus[i] == 1) ? TRUE : FALSE);
	}

	m_cboDevType.ResetContent();
	InitComboBox(GetSafeHwnd(), IDC_CBO_MODBUS_DEV_TYPE, CB_ADDSTRING, MODBUS_DEVTYPE_FILE);
	m_cboDevType.SetCurSel(m_inpCfg[m_nInpNum].deviceType);

	m_cboInpType.ResetContent();
	InitComboBox(GetSafeHwnd(), IDC_CBO_MODBUS_INP_TYPE, CB_ADDSTRING, MODBUS_AINTYPE_FILE);
	EnableInputBox();

	ShowConfig();
	
	CheckEditPriv(GetSafeHwnd(), E_RTU_BMSPARMS);
	return TRUE;
}

BOOL CRtuBmsModbusAnalogInput::OnKillActive()
{
	if(!CheckConfig())
		return FALSE;
	StoreConfig();
	return CPropertyPage::OnKillActive();
}

BOOL CRtuBmsModbusAnalogInput::OnSetActive()
{
	ShowConfig();
	return CPropertyPage::OnSetActive();
}

void CRtuBmsModbusAnalogInput::ShowConfig()
{
	int index = ModbusPortSel(m_inpCfg[m_nInpNum].portNumber) + 1;
	if(!m_cboModbusPort.IsItemEnabled(index))
		index = 0;

	SetDlgItemInt(IDC_BMS_ACT_ENUM, m_nInpNum+1);
	SetDlgItemInt(IDC_BMS_ACT_ETOT, bModbusCfgLarge ? MODBUS_MAX_ANALOG_INPUTS_LARGE : MODBUS_MAX_ANALOG_INPUTS);

	m_cboModbusPort.SetCurSel(index);
	m_cboDevType.SetCurSel(m_inpCfg[m_nInpNum].deviceType);
	m_cboInpType.SetCurSel(m_inpCfg[m_nInpNum].dataType);

	m_txtDevAddr.SetValue(m_inpCfg[m_nInpNum].deviceAddress + 1);
	OnSelChangeDeviceType();
}

void CRtuBmsModbusAnalogInput::StoreConfig()
{
	//int portNums[] = {0, 3, 4, 6, 9, 10, 11, 12};
	int index = m_cboModbusPort.GetCurSel();
	 if(index)
		index = GetPortNumber(index - 1);

	m_inpCfg[m_nInpNum].portNumber = (BYTE)index;
	m_inpCfg[m_nInpNum].deviceType = (BYTE)m_cboDevType.GetCurSel();
	m_inpCfg[m_nInpNum].dataType = (BYTE)m_cboInpType.GetCurSel();
	m_inpCfg[m_nInpNum].deviceAddress = (BYTE)(m_txtDevAddr.GetValue() - 1);

	if(memcmp(&m_inpCfg[m_nInpNum], &bmsModbusPntCfg.analogInput[m_nInpNum], sizeof(ModbusIoCfg)) != 0)
		bBmsModbusChanged = TRUE;
}

BOOL CRtuBmsModbusAnalogInput::CheckConfig()
{
	if(!m_txtDevAddr.IsValid())
		return FALSE;

	return TRUE;
}

void CRtuBmsModbusAnalogInput::OnPrevNext(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_UPDOWN* pNMUpDown = (NM_UPDOWN*)pNMHDR;
		
	if(CheckConfig()) {
		StoreConfig();

		int nMaxInputs = bModbusCfgLarge ? MODBUS_MAX_ANALOG_INPUTS_LARGE : MODBUS_MAX_ANALOG_INPUTS;
		if(pNMUpDown->iDelta == 1) {
			if(--m_nInpNum < 0)
				m_nInpNum = nMaxInputs - 1;
		}
		else  {
			if(++m_nInpNum >= nMaxInputs)
				m_nInpNum = 0;
		}
		ShowConfig();
	}

	*pResult = 0;
}

void CRtuBmsModbusAnalogInput::OnInputNumber()
{
	int nMaxInputs = bModbusCfgLarge ? MODBUS_MAX_ANALOG_INPUTS_LARGE : MODBUS_MAX_ANALOG_INPUTS;
	int i = GetDlgItemInt(IDC_BMS_ACT_ENUM);
	if(i < 1 || i > nMaxInputs) {
		DispMessageBox2(GetSafeHwnd(), IDS_ENTER_RANGE, IDS_ERROR, MB_OK|MB_ICONSTOP, 1, 16);
	}
	else if(CheckConfig()){
		StoreConfig();
		m_nInpNum = i - 1;
		ShowConfig();
	}
}

void CRtuBmsModbusAnalogInput::OnSelChangePort()
{
	int index = m_cboModbusPort.GetCurSel();
	if(!m_cboModbusPort.IsItemEnabled(index))
		m_cboModbusPort.SetCurSel(0);
}

void CRtuBmsModbusAnalogInput::OnBtnCopy()
{
	if(!CheckConfig())
		return;

	StoreConfig();

	memcpy(&bmsModbusPntCfg.analogInput[0], &m_inpCfg[0], sizeof(bmsModbusPntCfg.analogInput));
	CRtuBmsBACnetActCopy copyDlg(bModbusCfgLarge ? MODBUS_MAX_ANALOG_INPUTS_LARGE : MODBUS_MAX_ANALOG_INPUTS, m_nInpNum+1, MODBUS_AINP_COPY);
	copyDlg.DoModal();
	memcpy(&m_inpCfg[0], &bmsModbusPntCfg.analogInput[0], sizeof(bmsModbusPntCfg.analogInput));
		
	ShowConfig();

}

void CRtuBmsModbusAnalogInput::OnBtnDelete()
{
	memset(&m_inpCfg[m_nInpNum], 0, sizeof(ModbusIoCfg));
	bBmsModbusChanged = TRUE;
	ShowConfig();
}

void CRtuBmsModbusAnalogInput::OnSelChangeDeviceType()
{ 
	m_cboInpType.ResetContent();
	InitComboBox(GetSafeHwnd(), IDC_CBO_MODBUS_INP_TYPE, CB_ADDSTRING, MODBUS_AINTYPE_FILE);
	EnableInputBox();
		
	if(m_bInputEn[m_inpCfg[m_nInpNum].dataType]  == FALSE)	{
		int sel=0;
		for(int i=0; i<m_cboInpType.GetCount(); i++) {
			if(m_bInputEn[i] == TRUE) {
				sel = i;
				break;
			}
		}
		m_cboInpType.SetCurSel(sel);

	}
	else
		m_cboInpType.SetCurSel(m_inpCfg[m_nInpNum].dataType);


}

void CRtuBmsModbusAnalogInput::OnSelChangeInputType()
{
	int index = m_cboInpType.GetCurSel();
	if(m_bInputEn[index] == FALSE)
		index = 0;
	m_cboInpType.SetCurSel(index);
}

void CRtuBmsModbusAnalogInput::EnableInputBox()
{
	CString str;
	CString str2;
	int cnt = m_cboInpType.GetCount();
	int devTypeNum = m_cboDevType.GetCurSel() + 1;

	memset(&m_bInputEn, 0, sizeof(m_bInputEn));
	int index;
	int strLen;

	for(int i=0; i<cnt; i++) {
		m_cboInpType.GetLBText(i, str);

		index = str.Find('#', 0);
		if(index == -1)	{
			m_bInputEn[i] = TRUE;
		}
		else {
			str2 = str.Mid(index + 1);
			strLen = str2.GetLength();
			int num=0;
			for(int n=0; n<strLen; n++) {
				TCHAR c = str2[n];
				int y = TcharToDec(c);

				if(y < 0) {
					if(num == devTypeNum) {
						m_bInputEn[i] = TRUE;
						break;
					}
					num = 0;
					continue;
				}

				num = num * 10 + y;
			}

			if(num == devTypeNum) {
				m_bInputEn[i] = TRUE;
			}


			str.SetAt(index, '\0');
			if(m_cboInpType.DeleteString(i) != CB_ERR) {
				m_cboInpType.InsertString(i, str);
			}

		}

		m_cboInpType.SetCurItem(i, m_bInputEn[i]);
	}
}

//===================================================================================//
//===================================================================================//
//===================================================================================//

int ModbusPortSel(int portNum)
{
	int index=0;
	switch(realRtuType) {
		case RTU_1057_TYPE:
			if(portNum == 3)
				index = 1;
			else if(portNum == 4)
				index = 2;
			else if(portNum == 5)
				index = 3;
			else if(portNum == 6)
				index = 4;
			else if(portNum == 7)
				index = 5;
			else if(portNum == 9)
				index = 6;
			else if(portNum == 10)
				index = 7;
			else if(portNum == 11)
				index = 8;
			else if(portNum == 12)
				index = 9;
			else 
				index = 0;
			break;

		case RTU_1058_TYPE:
			if(portNum == 3)
				index = 1;
			else if(portNum == 4)
				index = 2;
			else if(portNum == 9)
				index = 3;
			else 
				index = 0;
			break;

		case RTU_2000_TYPE:
			if(portNum == 3)
				index = 1;
			else if(portNum == 4)
				index = 2;
			else if(portNum == 6)
				index = 3;
			else if(portNum == 7)
				index = 4;
			else 
				index = 0;
			break;
		
		case RTU_8001_TYPE:
			index = RTU8001_GetPortIndexFromPortNumber(portNum-1);
			if (index < 0) index = 0;
			//if(portNum == 1)
			//	index = 0;
			//else if(portNum == 3)
			//	index = 1;
			//else if(portNum == 4)
			//	index = 2;
			//else if(portNum == 9)
			//	index = 3;
			//else if(portNum == 10)
			//	index = 4;
			//else if(portNum == 11)
			//	index = 5;
			//else if(portNum == 12)
			//	index = 6;
			//else 
			//	index = 0;
			break;

		default:
			break;
	}
	return index;
}

//===================================================================================//
//===================================================================================//
//===================================================================================//
/*=========================================================================*/
/*=========================================================================*/
CRtuBmsMacroConfig::CRtuBmsMacroConfig(int* dirn, LPPARMPROC lpps, CWnd* pParent)
	: CDialog(CRtuBmsMacroConfig::IDD, pParent)
{
	m_fDirn = dirn;
	m_lpps = lpps;
	memcpy(&m_cfg, &bmsMacroCfg.cfg[0], sizeof(m_cfg));
	m_nCount = (m_cfg.countHi << 8) | m_cfg.countLo;
}

void CRtuBmsMacroConfig::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CRtuBmsMacroConfig)
	DDX_Control(pDX, IDC_TXT_BMS_COUNT, m_txtCount);
	DDX_Control(pDX, IDC_TXT_BMS_AREA_NUM, m_txtAreaNum);
	DDX_Control(pDX, IDC_TXT_BMS_OPNUM, m_txtOutputNum);
	DDX_Control(pDX, IDC_TXT_BMS_ACT_TIME, m_txtActTime);
	DDX_Control(pDX, IDC_CBO_BMS_DEV_TYPE, m_cboDevType);
	DDX_Control(pDX, IDC_CBO_BMS_COND, m_cboCond);
	DDX_Control(pDX, IDC_CBO_BMS_OPTYPE, m_cboOpType);
	//}}AFX_DATA_MAP

	//RtuLib::DDX_CBIndexEx(pDX, IDC_CBO_BMS_DEV_TYPE, m_cfg.con_devType,);
	RtuLib::DDX_CBIndex(pDX, IDC_CBO_BMS_DEV_TYPE, m_cfg.con_devType, 0x1f);
	RtuLib::DDX_CBIndexEx(pDX, IDC_CBO_BMS_COND, m_cfg.con_devType, 3, 5);
	DDX_Text(pDX, IDC_TXT_BMS_COUNT, m_nCount);
	//DDX_Text(pDX, IDC_TXT_BMS_AREA_NUM, m_cfg.areaNo);
	//RtuLib::DDX_CBIndexEx(pDX, IDC_CBO_BMS_OPTYPE, m_cfg.opType_Num, 2, 6);
	//RtuLib::DDX_Text(pDX, IDC_TXT_BMS_OPNUM, m_cfg.opType_Num, 0x3f);
	RtuLib::DDX_Text(pDX, IDC_TXT_BMS_ACT_TIME, m_cfg.actTime, 0x7f);
	RtuLib::DDX_Check(pDX, IDC_CHK_BMS_TIME_MIN, m_cfg.actTime, 7);
}



BEGIN_MESSAGE_MAP(CRtuBmsMacroConfig, CDialog)
	//{{AFX_MSG_MAP(CRtuBmsMacroConfig)
	ON_BN_CLICKED(IDOK, OnOK)
	ON_BN_CLICKED(IDCANCEL, OnCancel)
	ON_NOTIFY(UDN_DELTAPOS, IDC_BMS_ACT_NEXT, OnPrevNext)
	ON_BN_CLICKED(IDC_BMS_ACT_BNUM, OnBtnMacroNumber)
	ON_CBN_SELCHANGE(IDC_CBO_BMS_OPTYPE, OnSelChangeOutputType)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CRtuBmsMacroConfig message handlers
BOOL CRtuBmsMacroConfig::OnInitDialog() 
{
	CDialog::OnInitDialog();
	int i;
	// TODO: Add extra initialization here
	m_txtCount.SetMinMaxLimit(0, 0xffff, 5);
	m_txtAreaNum.SetMinMaxLimit(1, 32, 2);
	m_txtOutputNum.SetMinMaxLimit(1, 64, 2);
	m_txtActTime.SetMinMaxLimit(0, 127, 3);

	m_cboDevType.ResetContent();
	CStringArray strDevType; GetMacroDevTypeStr(strDevType);
	for(i=0; i<strDevType.GetSize(); i++)
		m_cboDevType.AddString(strDevType.GetAt(i));

	m_cboCond.ResetContent();
	CStringArray strCond; GetMacCondStr(strCond);
	for(i=0; i<strCond.GetSize(); i++)
		m_cboCond.AddString(strCond.GetAt(i));

	m_cboOpType.ResetContent();
	CStringArray strOutType; GetMacroOpTypeStr(strOutType);
	for(i=0; i<strOutType.GetSize(); i++)
		m_cboOpType.AddString(strOutType.GetAt(i));
	
	m_nMacroNum = 0;
	SetDlgItemInt(IDC_BMS_ACT_ETOT, NUM_BMS_MACROS);
	ShowParams();
	
	CheckEditPriv(GetSafeHwnd(), E_RTU_BMSPARMS);
	CenterWindow();
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CRtuBmsMacroConfig::ShowParams()
{
	SetDlgItemInt(IDC_BMS_ACT_ENUM, m_nMacroNum + 1);
	memcpy(&m_cfg, &bmsMacroCfg.cfg[m_nMacroNum], sizeof(m_cfg));
	m_nCount = (m_cfg.countHi << 8) | m_cfg.countLo;
	UpdateData(FALSE);
	m_txtAreaNum.SetValue(m_cfg.areaNo + 1);
	m_txtOutputNum.SetValue((m_cfg.opType_Num & 0x3f) + 1);
	m_cboOpType.SetCurSel((m_cfg.opType_Num >> 6) & 0x03);

	OnSelChangeOutputType();
}

void CRtuBmsMacroConfig::StoreParams()
{
	UpdateData(TRUE);
	m_cfg.areaNo = (uchar)(m_txtAreaNum.GetValue() - 1);
	m_cfg.opType_Num = 0;
	m_cfg.opType_Num |= (uchar)(m_cboOpType.GetCurSel() << 6);
	m_cfg.opType_Num |= (uchar)((m_txtOutputNum.GetValue() - 1) & 0x3f);

	m_cfg.countHi = (uchar)(m_nCount >> 8);
	m_cfg.countLo = (uchar)(m_nCount & 0xff);
	if(memcmp(&m_cfg, &bmsMacroCfg.cfg[m_nMacroNum], sizeof(m_cfg)) != 0) {
		bBmsMacroChanged = TRUE;
		memcpy(&bmsMacroCfg.cfg[m_nMacroNum], &m_cfg, sizeof(m_cfg));
	}
}

BOOL CRtuBmsMacroConfig::CheckParams()
{
	if(!m_txtCount.IsValid())
		return FALSE;
	if(!m_txtAreaNum.IsValid())
		return FALSE;
	if(!m_txtOutputNum.IsValid())
		return FALSE;
	if(!m_txtActTime.IsValid())
		return FALSE;

	return TRUE;
}

void CRtuBmsMacroConfig::OnCancel() 
{
	// TODO: Add extra cleanup here
	bBmsMacroChanged = FALSE;
	CDialog::OnCancel();
}

void CRtuBmsMacroConfig::OnOK() 
{
	// TODO: Add extra validation here
	if(!CheckParams())
		return;

	StoreParams();

	m_cfg.countHi = (uchar)(m_nCount >> 8);
	m_cfg.countLo = (uchar)(m_nCount & 0xff);
	
	if(bBmsMacroChanged) {
		*m_fDirn = BMS_DOWNLOAD;
		send_BMS_parms(m_lpps, BMS_MACROS_CFG, nBlkSize);
	}

	CDialog::OnOK();
}


void CRtuBmsMacroConfig::OnPrevNext(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_UPDOWN* pNMUpDown = (NM_UPDOWN*)pNMHDR;
	// TODO: Add your control notification handler code here
		
	if(CheckParams()) {
		StoreParams();

		if(pNMUpDown->iDelta == 1) {
			if(--m_nMacroNum < 0)
				m_nMacroNum = NUM_BMS_MACROS - 1;
		}
		else  {
			if(++m_nMacroNum >= NUM_BMS_MACROS)
				m_nMacroNum = 0;
		}
		ShowParams();
	}

	*pResult = 0;
}

void CRtuBmsMacroConfig::OnBtnMacroNumber()
{
	int i = GetDlgItemInt(IDC_BMS_ACT_ENUM);
	if(i < 1 || i > NUM_BMS_MACROS) {
		DispMessageBox2(GetSafeHwnd(), IDS_ENTER_RANGE, IDS_ERROR, MB_OK|MB_ICONSTOP, 1, 170);
	}
	else if(CheckParams()){
		StoreParams();
		m_nMacroNum = i - 1;
		ShowParams();
	}
}

void CRtuBmsMacroConfig::OnSelChangeOutputType()
{
	int sel = m_cboOpType.GetCurSel();
	CString strText = _T("");
	switch(sel) {
		case 0: strText = RES_STRING(IDS_GPO_NUM); break;
		case 1: strText = RES_STRING(IDS_CCTV_NUM); break;
		case 2: strText = RES_STRING(IDS_TRIG_NUM); break;
		default:  break;
	}

	SetDlgItemText(IDC_LBL_BMS_OPNUM, strText);
}
//===================================================================================//
//===================================================================================//
//===================================================================================//
